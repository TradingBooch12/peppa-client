package net.minecraft.block;

import net.minecraft.item.DyeColor;

public class StainedGlassPaneBlock extends PaneBlock implements IBeaconBeamColorProvider {
   private final DyeColor field_196420_C;

   public StainedGlassPaneBlock(DyeColor p_i48322_1_, AbstractBlock.Properties p_i48322_2_) {
      super(p_i48322_2_);
      this.field_196420_C = p_i48322_1_;
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196409_a, Boolean.valueOf(false)).func_206870_a(field_196411_b, Boolean.valueOf(false)).func_206870_a(field_196413_c, Boolean.valueOf(false)).func_206870_a(field_196414_y, Boolean.valueOf(false)).func_206870_a(field_204514_u, Boolean.valueOf(false)));
   }

   public DyeColor func_196457_d() {
      return this.field_196420_C;
   }
}
