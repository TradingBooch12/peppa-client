package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.trees.Tree;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class SaplingBlock extends BushBlock implements IGrowable {
   public static final IntegerProperty field_176479_b = BlockStateProperties.field_208137_al;
   protected static final VoxelShape field_196386_b = Block.func_208617_a(2.0D, 0.0D, 2.0D, 14.0D, 12.0D, 14.0D);
   private final Tree field_196387_c;

   protected SaplingBlock(Tree p_i48337_1_, AbstractBlock.Properties p_i48337_2_) {
      super(p_i48337_2_);
      this.field_196387_c = p_i48337_1_;
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176479_b, Integer.valueOf(0)));
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196386_b;
   }

   public void func_225542_b_(BlockState p_225542_1_, ServerWorld p_225542_2_, BlockPos p_225542_3_, Random p_225542_4_) {
      if (p_225542_2_.func_201696_r(p_225542_3_.func_177984_a()) >= 9 && p_225542_4_.nextInt(7) == 0) {
         this.func_226942_a_(p_225542_2_, p_225542_3_, p_225542_1_, p_225542_4_);
      }

   }

   public void func_226942_a_(ServerWorld p_226942_1_, BlockPos p_226942_2_, BlockState p_226942_3_, Random p_226942_4_) {
      if (p_226942_3_.func_177229_b(field_176479_b) == 0) {
         p_226942_1_.func_180501_a(p_226942_2_, p_226942_3_.func_235896_a_(field_176479_b), 4);
      } else {
         this.field_196387_c.func_230339_a_(p_226942_1_, p_226942_1_.func_72863_F().func_201711_g(), p_226942_2_, p_226942_3_, p_226942_4_);
      }

   }

   public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, BlockState p_176473_3_, boolean p_176473_4_) {
      return true;
   }

   public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, BlockState p_180670_4_) {
      return (double)p_180670_1_.field_73012_v.nextFloat() < 0.45D;
   }

   public void func_225535_a_(ServerWorld p_225535_1_, Random p_225535_2_, BlockPos p_225535_3_, BlockState p_225535_4_) {
      this.func_226942_a_(p_225535_1_, p_225535_3_, p_225535_4_, p_225535_2_);
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176479_b);
   }
}
