package net.minecraft.block;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.Direction;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class AttachedStemBlock extends BushBlock {
   public static final DirectionProperty field_196280_a = HorizontalBlock.field_185512_D;
   private final StemGrownBlock field_196281_b;
   private static final Map<Direction, VoxelShape> field_196282_c = Maps.newEnumMap(ImmutableMap.of(Direction.SOUTH, Block.func_208617_a(6.0D, 0.0D, 6.0D, 10.0D, 10.0D, 16.0D), Direction.WEST, Block.func_208617_a(0.0D, 0.0D, 6.0D, 10.0D, 10.0D, 10.0D), Direction.NORTH, Block.func_208617_a(6.0D, 0.0D, 0.0D, 10.0D, 10.0D, 10.0D), Direction.EAST, Block.func_208617_a(6.0D, 0.0D, 6.0D, 16.0D, 10.0D, 10.0D)));

   protected AttachedStemBlock(StemGrownBlock p_i48449_1_, AbstractBlock.Properties p_i48449_2_) {
      super(p_i48449_2_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196280_a, Direction.NORTH));
      this.field_196281_b = p_i48449_1_;
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196282_c.get(p_220053_1_.func_177229_b(field_196280_a));
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return !p_196271_3_.func_203425_a(this.field_196281_b) && p_196271_2_ == p_196271_1_.func_177229_b(field_196280_a) ? this.field_196281_b.func_196524_d().func_176223_P().func_206870_a(StemBlock.field_176484_a, Integer.valueOf(7)) : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   protected boolean func_200014_a_(BlockState p_200014_1_, IBlockReader p_200014_2_, BlockPos p_200014_3_) {
      return p_200014_1_.func_203425_a(Blocks.field_150458_ak);
   }

   @OnlyIn(Dist.CLIENT)
   protected Item func_196279_O_() {
      if (this.field_196281_b == Blocks.field_150423_aK) {
         return Items.field_151080_bb;
      } else {
         return this.field_196281_b == Blocks.field_150440_ba ? Items.field_151081_bc : Items.field_190931_a;
      }
   }

   @OnlyIn(Dist.CLIENT)
   public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, BlockState p_185473_3_) {
      return new ItemStack(this.func_196279_O_());
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_196280_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_196280_a)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_196280_a)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196280_a);
   }
}
