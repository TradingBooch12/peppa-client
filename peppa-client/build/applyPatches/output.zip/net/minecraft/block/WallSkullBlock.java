package net.minecraft.block;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.Direction;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;

public class WallSkullBlock extends AbstractSkullBlock {
   public static final DirectionProperty field_196302_a = HorizontalBlock.field_185512_D;
   private static final Map<Direction, VoxelShape> field_196303_A = Maps.newEnumMap(ImmutableMap.of(Direction.NORTH, Block.func_208617_a(4.0D, 4.0D, 8.0D, 12.0D, 12.0D, 16.0D), Direction.SOUTH, Block.func_208617_a(4.0D, 4.0D, 0.0D, 12.0D, 12.0D, 8.0D), Direction.EAST, Block.func_208617_a(0.0D, 4.0D, 4.0D, 8.0D, 12.0D, 12.0D), Direction.WEST, Block.func_208617_a(8.0D, 4.0D, 4.0D, 16.0D, 12.0D, 12.0D)));

   protected WallSkullBlock(SkullBlock.ISkullType p_i48299_1_, AbstractBlock.Properties p_i48299_2_) {
      super(p_i48299_1_, p_i48299_2_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196302_a, Direction.NORTH));
   }

   public String func_149739_a() {
      return this.func_199767_j().func_77658_a();
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196303_A.get(p_220053_1_.func_177229_b(field_196302_a));
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      BlockState blockstate = this.func_176223_P();
      IBlockReader iblockreader = p_196258_1_.func_195991_k();
      BlockPos blockpos = p_196258_1_.func_195995_a();
      Direction[] adirection = p_196258_1_.func_196009_e();

      for(Direction direction : adirection) {
         if (direction.func_176740_k().func_176722_c()) {
            Direction direction1 = direction.func_176734_d();
            blockstate = blockstate.func_206870_a(field_196302_a, direction1);
            if (!iblockreader.func_180495_p(blockpos.func_177972_a(direction)).func_196953_a(p_196258_1_)) {
               return blockstate;
            }
         }
      }

      return null;
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_196302_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_196302_a)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_196302_a)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196302_a);
   }
}
