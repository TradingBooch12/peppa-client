package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.SwordItem;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BambooLeaves;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class BambooBlock extends Block implements IGrowable {
   protected static final VoxelShape field_220261_a = Block.func_208617_a(5.0D, 0.0D, 5.0D, 11.0D, 16.0D, 11.0D);
   protected static final VoxelShape field_220262_b = Block.func_208617_a(3.0D, 0.0D, 3.0D, 13.0D, 16.0D, 13.0D);
   protected static final VoxelShape field_220263_c = Block.func_208617_a(6.5D, 0.0D, 6.5D, 9.5D, 16.0D, 9.5D);
   public static final IntegerProperty field_220264_d = BlockStateProperties.field_222512_Y;
   public static final EnumProperty<BambooLeaves> field_220265_e = BlockStateProperties.field_222508_aF;
   public static final IntegerProperty field_220266_f = BlockStateProperties.field_208137_al;

   public BambooBlock(AbstractBlock.Properties p_i49998_1_) {
      super(p_i49998_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_220264_d, Integer.valueOf(0)).func_206870_a(field_220265_e, BambooLeaves.NONE).func_206870_a(field_220266_f, Integer.valueOf(0)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_220264_d, field_220265_e, field_220266_f);
   }

   public AbstractBlock.OffsetType func_176218_Q() {
      return AbstractBlock.OffsetType.XZ;
   }

   public boolean func_200123_i(BlockState p_200123_1_, IBlockReader p_200123_2_, BlockPos p_200123_3_) {
      return true;
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      VoxelShape voxelshape = p_220053_1_.func_177229_b(field_220265_e) == BambooLeaves.LARGE ? field_220262_b : field_220261_a;
      Vector3d vector3d = p_220053_1_.func_191059_e(p_220053_2_, p_220053_3_);
      return voxelshape.func_197751_a(vector3d.field_72450_a, vector3d.field_72448_b, vector3d.field_72449_c);
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }

   public VoxelShape func_220071_b(BlockState p_220071_1_, IBlockReader p_220071_2_, BlockPos p_220071_3_, ISelectionContext p_220071_4_) {
      Vector3d vector3d = p_220071_1_.func_191059_e(p_220071_2_, p_220071_3_);
      return field_220263_c.func_197751_a(vector3d.field_72450_a, vector3d.field_72448_b, vector3d.field_72449_c);
   }

   @Nullable
   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      FluidState fluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
      if (!fluidstate.func_206888_e()) {
         return null;
      } else {
         BlockState blockstate = p_196258_1_.func_195991_k().func_180495_p(p_196258_1_.func_195995_a().func_177977_b());
         if (blockstate.func_235714_a_(BlockTags.field_219749_R)) {
            if (blockstate.func_203425_a(Blocks.field_222404_kP)) {
               return this.func_176223_P().func_206870_a(field_220264_d, Integer.valueOf(0));
            } else if (blockstate.func_203425_a(Blocks.field_222405_kQ)) {
               int i = blockstate.func_177229_b(field_220264_d) > 0 ? 1 : 0;
               return this.func_176223_P().func_206870_a(field_220264_d, Integer.valueOf(i));
            } else {
               BlockState blockstate1 = p_196258_1_.func_195991_k().func_180495_p(p_196258_1_.func_195995_a().func_177984_a());
               return !blockstate1.func_203425_a(Blocks.field_222405_kQ) && !blockstate1.func_203425_a(Blocks.field_222404_kP) ? Blocks.field_222404_kP.func_176223_P() : this.func_176223_P().func_206870_a(field_220264_d, blockstate1.func_177229_b(field_220264_d));
            }
         } else {
            return null;
         }
      }
   }

   public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
      if (!p_225534_1_.func_196955_c(p_225534_2_, p_225534_3_)) {
         p_225534_2_.func_175655_b(p_225534_3_, true);
      }

   }

   public boolean func_149653_t(BlockState p_149653_1_) {
      return p_149653_1_.func_177229_b(field_220266_f) == 0;
   }

   public void func_225542_b_(BlockState p_225542_1_, ServerWorld p_225542_2_, BlockPos p_225542_3_, Random p_225542_4_) {
      if (p_225542_1_.func_177229_b(field_220266_f) == 0) {
         if (p_225542_4_.nextInt(3) == 0 && p_225542_2_.func_175623_d(p_225542_3_.func_177984_a()) && p_225542_2_.func_226659_b_(p_225542_3_.func_177984_a(), 0) >= 9) {
            int i = this.func_220260_b(p_225542_2_, p_225542_3_) + 1;
            if (i < 16) {
               this.func_220258_a(p_225542_1_, p_225542_2_, p_225542_3_, p_225542_4_, i);
            }
         }

      }
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      return p_196260_2_.func_180495_p(p_196260_3_.func_177977_b()).func_235714_a_(BlockTags.field_219749_R);
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (!p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_)) {
         p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, 1);
      }

      if (p_196271_2_ == Direction.UP && p_196271_3_.func_203425_a(Blocks.field_222405_kQ) && p_196271_3_.func_177229_b(field_220264_d) > p_196271_1_.func_177229_b(field_220264_d)) {
         p_196271_4_.func_180501_a(p_196271_5_, p_196271_1_.func_235896_a_(field_220264_d), 2);
      }

      return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, BlockState p_176473_3_, boolean p_176473_4_) {
      int i = this.func_220259_a(p_176473_1_, p_176473_2_);
      int j = this.func_220260_b(p_176473_1_, p_176473_2_);
      return i + j + 1 < 16 && p_176473_1_.func_180495_p(p_176473_2_.func_177981_b(i)).func_177229_b(field_220266_f) != 1;
   }

   public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, BlockState p_180670_4_) {
      return true;
   }

   public void func_225535_a_(ServerWorld p_225535_1_, Random p_225535_2_, BlockPos p_225535_3_, BlockState p_225535_4_) {
      int i = this.func_220259_a(p_225535_1_, p_225535_3_);
      int j = this.func_220260_b(p_225535_1_, p_225535_3_);
      int k = i + j + 1;
      int l = 1 + p_225535_2_.nextInt(2);

      for(int i1 = 0; i1 < l; ++i1) {
         BlockPos blockpos = p_225535_3_.func_177981_b(i);
         BlockState blockstate = p_225535_1_.func_180495_p(blockpos);
         if (k >= 16 || blockstate.func_177229_b(field_220266_f) == 1 || !p_225535_1_.func_175623_d(blockpos.func_177984_a())) {
            return;
         }

         this.func_220258_a(blockstate, p_225535_1_, blockpos, p_225535_2_, k);
         ++i;
         ++k;
      }

   }

   public float func_180647_a(BlockState p_180647_1_, PlayerEntity p_180647_2_, IBlockReader p_180647_3_, BlockPos p_180647_4_) {
      return p_180647_2_.func_184614_ca().func_77973_b() instanceof SwordItem ? 1.0F : super.func_180647_a(p_180647_1_, p_180647_2_, p_180647_3_, p_180647_4_);
   }

   protected void func_220258_a(BlockState p_220258_1_, World p_220258_2_, BlockPos p_220258_3_, Random p_220258_4_, int p_220258_5_) {
      BlockState blockstate = p_220258_2_.func_180495_p(p_220258_3_.func_177977_b());
      BlockPos blockpos = p_220258_3_.func_177979_c(2);
      BlockState blockstate1 = p_220258_2_.func_180495_p(blockpos);
      BambooLeaves bambooleaves = BambooLeaves.NONE;
      if (p_220258_5_ >= 1) {
         if (blockstate.func_203425_a(Blocks.field_222405_kQ) && blockstate.func_177229_b(field_220265_e) != BambooLeaves.NONE) {
            if (blockstate.func_203425_a(Blocks.field_222405_kQ) && blockstate.func_177229_b(field_220265_e) != BambooLeaves.NONE) {
               bambooleaves = BambooLeaves.LARGE;
               if (blockstate1.func_203425_a(Blocks.field_222405_kQ)) {
                  p_220258_2_.func_180501_a(p_220258_3_.func_177977_b(), blockstate.func_206870_a(field_220265_e, BambooLeaves.SMALL), 3);
                  p_220258_2_.func_180501_a(blockpos, blockstate1.func_206870_a(field_220265_e, BambooLeaves.NONE), 3);
               }
            }
         } else {
            bambooleaves = BambooLeaves.SMALL;
         }
      }

      int i = p_220258_1_.func_177229_b(field_220264_d) != 1 && !blockstate1.func_203425_a(Blocks.field_222405_kQ) ? 0 : 1;
      int j = (p_220258_5_ < 11 || !(p_220258_4_.nextFloat() < 0.25F)) && p_220258_5_ != 15 ? 0 : 1;
      p_220258_2_.func_180501_a(p_220258_3_.func_177984_a(), this.func_176223_P().func_206870_a(field_220264_d, Integer.valueOf(i)).func_206870_a(field_220265_e, bambooleaves).func_206870_a(field_220266_f, Integer.valueOf(j)), 3);
   }

   protected int func_220259_a(IBlockReader p_220259_1_, BlockPos p_220259_2_) {
      int i;
      for(i = 0; i < 16 && p_220259_1_.func_180495_p(p_220259_2_.func_177981_b(i + 1)).func_203425_a(Blocks.field_222405_kQ); ++i) {
      }

      return i;
   }

   protected int func_220260_b(IBlockReader p_220260_1_, BlockPos p_220260_2_) {
      int i;
      for(i = 0; i < 16 && p_220260_1_.func_180495_p(p_220260_2_.func_177979_c(i + 1)).func_203425_a(Blocks.field_222405_kQ); ++i) {
      }

      return i;
   }
}
