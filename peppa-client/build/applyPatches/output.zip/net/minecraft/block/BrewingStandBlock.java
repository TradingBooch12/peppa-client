package net.minecraft.block;

import java.util.Random;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.inventory.container.Container;
import net.minecraft.item.ItemStack;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.stats.Stats;
import net.minecraft.tileentity.BrewingStandTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BrewingStandBlock extends ContainerBlock {
   public static final BooleanProperty[] field_176451_a = new BooleanProperty[]{BlockStateProperties.field_208184_k, BlockStateProperties.field_208185_l, BlockStateProperties.field_208186_m};
   protected static final VoxelShape field_196308_b = VoxelShapes.func_197872_a(Block.func_208617_a(1.0D, 0.0D, 1.0D, 15.0D, 2.0D, 15.0D), Block.func_208617_a(7.0D, 0.0D, 7.0D, 9.0D, 14.0D, 9.0D));

   public BrewingStandBlock(AbstractBlock.Properties p_i48438_1_) {
      super(p_i48438_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176451_a[0], Boolean.valueOf(false)).func_206870_a(field_176451_a[1], Boolean.valueOf(false)).func_206870_a(field_176451_a[2], Boolean.valueOf(false)));
   }

   public BlockRenderType func_149645_b(BlockState p_149645_1_) {
      return BlockRenderType.MODEL;
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new BrewingStandTileEntity();
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196308_b;
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      if (p_225533_2_.field_72995_K) {
         return ActionResultType.SUCCESS;
      } else {
         TileEntity tileentity = p_225533_2_.func_175625_s(p_225533_3_);
         if (tileentity instanceof BrewingStandTileEntity) {
            p_225533_4_.func_213829_a((BrewingStandTileEntity)tileentity);
            p_225533_4_.func_195066_a(Stats.field_188081_O);
         }

         return ActionResultType.CONSUME;
      }
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, BlockState p_180633_3_, LivingEntity p_180633_4_, ItemStack p_180633_5_) {
      if (p_180633_5_.func_82837_s()) {
         TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);
         if (tileentity instanceof BrewingStandTileEntity) {
            ((BrewingStandTileEntity)tileentity).func_213903_a(p_180633_5_.func_200301_q());
         }
      }

   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(BlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      double d0 = (double)p_180655_3_.func_177958_n() + 0.4D + (double)p_180655_4_.nextFloat() * 0.2D;
      double d1 = (double)p_180655_3_.func_177956_o() + 0.7D + (double)p_180655_4_.nextFloat() * 0.3D;
      double d2 = (double)p_180655_3_.func_177952_p() + 0.4D + (double)p_180655_4_.nextFloat() * 0.2D;
      p_180655_2_.func_195594_a(ParticleTypes.field_197601_L, d0, d1, d2, 0.0D, 0.0D, 0.0D);
   }

   public void func_196243_a(BlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, BlockState p_196243_4_, boolean p_196243_5_) {
      if (!p_196243_1_.func_203425_a(p_196243_4_.func_177230_c())) {
         TileEntity tileentity = p_196243_2_.func_175625_s(p_196243_3_);
         if (tileentity instanceof BrewingStandTileEntity) {
            InventoryHelper.func_180175_a(p_196243_2_, p_196243_3_, (BrewingStandTileEntity)tileentity);
         }

         super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
      }
   }

   public boolean func_149740_M(BlockState p_149740_1_) {
      return true;
   }

   public int func_180641_l(BlockState p_180641_1_, World p_180641_2_, BlockPos p_180641_3_) {
      return Container.func_178144_a(p_180641_2_.func_175625_s(p_180641_3_));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176451_a[0], field_176451_a[1], field_176451_a[2]);
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
