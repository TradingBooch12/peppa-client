package net.minecraft.block;

import java.util.Random;
import net.minecraft.fluid.Fluids;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public abstract class AbstractTopPlantBlock extends AbstractPlantBlock implements IGrowable {
   public static final IntegerProperty field_235502_d_ = BlockStateProperties.field_208172_Y;
   private final double field_235503_e_;

   protected AbstractTopPlantBlock(AbstractBlock.Properties p_i241180_1_, Direction p_i241180_2_, VoxelShape p_i241180_3_, boolean p_i241180_4_, double p_i241180_5_) {
      super(p_i241180_1_, p_i241180_2_, p_i241180_3_, p_i241180_4_);
      this.field_235503_e_ = p_i241180_5_;
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_235502_d_, Integer.valueOf(0)));
   }

   public BlockState func_235504_a_(IWorld p_235504_1_) {
      return this.func_176223_P().func_206870_a(field_235502_d_, Integer.valueOf(p_235504_1_.func_201674_k().nextInt(25)));
   }

   public boolean func_149653_t(BlockState p_149653_1_) {
      return p_149653_1_.func_177229_b(field_235502_d_) < 25;
   }

   public void func_225542_b_(BlockState p_225542_1_, ServerWorld p_225542_2_, BlockPos p_225542_3_, Random p_225542_4_) {
      if (p_225542_1_.func_177229_b(field_235502_d_) < 25 && p_225542_4_.nextDouble() < this.field_235503_e_) {
         BlockPos blockpos = p_225542_3_.func_177972_a(this.field_235498_a_);
         if (this.func_230334_h_(p_225542_2_.func_180495_p(blockpos))) {
            p_225542_2_.func_175656_a(blockpos, p_225542_1_.func_235896_a_(field_235502_d_));
         }
      }

   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_2_ == this.field_235498_a_.func_176734_d() && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_)) {
         p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, 1);
      }

      if (p_196271_2_ != this.field_235498_a_ || !p_196271_3_.func_203425_a(this) && !p_196271_3_.func_203425_a(this.func_230330_d_())) {
         if (this.field_235499_b_) {
            p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
         }

         return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      } else {
         return this.func_230330_d_().func_176223_P();
      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_235502_d_);
   }

   public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, BlockState p_176473_3_, boolean p_176473_4_) {
      return this.func_230334_h_(p_176473_1_.func_180495_p(p_176473_2_.func_177972_a(this.field_235498_a_)));
   }

   public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, BlockState p_180670_4_) {
      return true;
   }

   public void func_225535_a_(ServerWorld p_225535_1_, Random p_225535_2_, BlockPos p_225535_3_, BlockState p_225535_4_) {
      BlockPos blockpos = p_225535_3_.func_177972_a(this.field_235498_a_);
      int i = Math.min(p_225535_4_.func_177229_b(field_235502_d_) + 1, 25);
      int j = this.func_230332_a_(p_225535_2_);

      for(int k = 0; k < j && this.func_230334_h_(p_225535_1_.func_180495_p(blockpos)); ++k) {
         p_225535_1_.func_175656_a(blockpos, p_225535_4_.func_206870_a(field_235502_d_, Integer.valueOf(i)));
         blockpos = blockpos.func_177972_a(this.field_235498_a_);
         i = Math.min(i + 1, 25);
      }

   }

   protected abstract int func_230332_a_(Random p_230332_1_);

   protected abstract boolean func_230334_h_(BlockState p_230334_1_);

   protected AbstractTopPlantBlock func_230331_c_() {
      return this;
   }
}
