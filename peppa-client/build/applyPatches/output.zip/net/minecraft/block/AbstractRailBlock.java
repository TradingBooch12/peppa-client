package net.minecraft.block;

import net.minecraft.block.material.PushReaction;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.Property;
import net.minecraft.state.properties.RailShape;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;

public abstract class AbstractRailBlock extends Block {
   protected static final VoxelShape field_185590_a = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D);
   protected static final VoxelShape field_190959_b = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D);
   private final boolean field_196277_c;

   public static boolean func_208488_a(World p_208488_0_, BlockPos p_208488_1_) {
      return func_208487_j(p_208488_0_.func_180495_p(p_208488_1_));
   }

   public static boolean func_208487_j(BlockState p_208487_0_) {
      return p_208487_0_.func_235714_a_(BlockTags.field_203437_y) && p_208487_0_.func_177230_c() instanceof AbstractRailBlock;
   }

   protected AbstractRailBlock(boolean p_i48444_1_, AbstractBlock.Properties p_i48444_2_) {
      super(p_i48444_2_);
      this.field_196277_c = p_i48444_1_;
   }

   public boolean func_208490_b() {
      return this.field_196277_c;
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      RailShape railshape = p_220053_1_.func_203425_a(this) ? p_220053_1_.func_177229_b(this.func_176560_l()) : null;
      return railshape != null && railshape.func_208092_c() ? field_190959_b : field_185590_a;
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      return func_220064_c(p_196260_2_, p_196260_3_.func_177977_b());
   }

   public void func_220082_b(BlockState p_220082_1_, World p_220082_2_, BlockPos p_220082_3_, BlockState p_220082_4_, boolean p_220082_5_) {
      if (!p_220082_4_.func_203425_a(p_220082_1_.func_177230_c())) {
         this.func_235327_a_(p_220082_1_, p_220082_2_, p_220082_3_, p_220082_5_);
      }
   }

   protected BlockState func_235327_a_(BlockState p_235327_1_, World p_235327_2_, BlockPos p_235327_3_, boolean p_235327_4_) {
      p_235327_1_ = this.func_208489_a(p_235327_2_, p_235327_3_, p_235327_1_, true);
      if (this.field_196277_c) {
         p_235327_1_.func_215697_a(p_235327_2_, p_235327_3_, this, p_235327_3_, p_235327_4_);
      }

      return p_235327_1_;
   }

   public void func_220069_a(BlockState p_220069_1_, World p_220069_2_, BlockPos p_220069_3_, Block p_220069_4_, BlockPos p_220069_5_, boolean p_220069_6_) {
      if (!p_220069_2_.field_72995_K && p_220069_2_.func_180495_p(p_220069_3_).func_203425_a(this)) {
         RailShape railshape = p_220069_1_.func_177229_b(this.func_176560_l());
         if (func_235328_a_(p_220069_3_, p_220069_2_, railshape)) {
            func_220075_c(p_220069_1_, p_220069_2_, p_220069_3_);
            p_220069_2_.func_217377_a(p_220069_3_, p_220069_6_);
         } else {
            this.func_189541_b(p_220069_1_, p_220069_2_, p_220069_3_, p_220069_4_);
         }

      }
   }

   private static boolean func_235328_a_(BlockPos p_235328_0_, World p_235328_1_, RailShape p_235328_2_) {
      if (!func_220064_c(p_235328_1_, p_235328_0_.func_177977_b())) {
         return true;
      } else {
         switch(p_235328_2_) {
         case ASCENDING_EAST:
            return !func_220064_c(p_235328_1_, p_235328_0_.func_177974_f());
         case ASCENDING_WEST:
            return !func_220064_c(p_235328_1_, p_235328_0_.func_177976_e());
         case ASCENDING_NORTH:
            return !func_220064_c(p_235328_1_, p_235328_0_.func_177978_c());
         case ASCENDING_SOUTH:
            return !func_220064_c(p_235328_1_, p_235328_0_.func_177968_d());
         default:
            return false;
         }
      }
   }

   protected void func_189541_b(BlockState p_189541_1_, World p_189541_2_, BlockPos p_189541_3_, Block p_189541_4_) {
   }

   protected BlockState func_208489_a(World p_208489_1_, BlockPos p_208489_2_, BlockState p_208489_3_, boolean p_208489_4_) {
      if (p_208489_1_.field_72995_K) {
         return p_208489_3_;
      } else {
         RailShape railshape = p_208489_3_.func_177229_b(this.func_176560_l());
         return (new RailState(p_208489_1_, p_208489_2_, p_208489_3_)).func_226941_a_(p_208489_1_.func_175640_z(p_208489_2_), p_208489_4_, railshape).func_196916_c();
      }
   }

   public PushReaction func_149656_h(BlockState p_149656_1_) {
      return PushReaction.NORMAL;
   }

   public void func_196243_a(BlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, BlockState p_196243_4_, boolean p_196243_5_) {
      if (!p_196243_5_) {
         super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
         if (p_196243_1_.func_177229_b(this.func_176560_l()).func_208092_c()) {
            p_196243_2_.func_195593_d(p_196243_3_.func_177984_a(), this);
         }

         if (this.field_196277_c) {
            p_196243_2_.func_195593_d(p_196243_3_, this);
            p_196243_2_.func_195593_d(p_196243_3_.func_177977_b(), this);
         }

      }
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      BlockState blockstate = super.func_176223_P();
      Direction direction = p_196258_1_.func_195992_f();
      boolean flag = direction == Direction.EAST || direction == Direction.WEST;
      return blockstate.func_206870_a(this.func_176560_l(), flag ? RailShape.EAST_WEST : RailShape.NORTH_SOUTH);
   }

   public abstract Property<RailShape> func_176560_l();
}
