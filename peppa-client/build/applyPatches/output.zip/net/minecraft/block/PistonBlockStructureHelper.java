package net.minecraft.block;

import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.block.material.PushReaction;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class PistonBlockStructureHelper {
   private final World field_177261_a;
   private final BlockPos field_177259_b;
   private final boolean field_211724_c;
   private final BlockPos field_177260_c;
   private final Direction field_177257_d;
   private final List<BlockPos> field_177258_e = Lists.newArrayList();
   private final List<BlockPos> field_177256_f = Lists.newArrayList();
   private final Direction field_211906_h;

   public PistonBlockStructureHelper(World p_i45664_1_, BlockPos p_i45664_2_, Direction p_i45664_3_, boolean p_i45664_4_) {
      this.field_177261_a = p_i45664_1_;
      this.field_177259_b = p_i45664_2_;
      this.field_211906_h = p_i45664_3_;
      this.field_211724_c = p_i45664_4_;
      if (p_i45664_4_) {
         this.field_177257_d = p_i45664_3_;
         this.field_177260_c = p_i45664_2_.func_177972_a(p_i45664_3_);
      } else {
         this.field_177257_d = p_i45664_3_.func_176734_d();
         this.field_177260_c = p_i45664_2_.func_177967_a(p_i45664_3_, 2);
      }

   }

   public boolean func_177253_a() {
      this.field_177258_e.clear();
      this.field_177256_f.clear();
      BlockState blockstate = this.field_177261_a.func_180495_p(this.field_177260_c);
      if (!PistonBlock.func_185646_a(blockstate, this.field_177261_a, this.field_177260_c, this.field_177257_d, false, this.field_211906_h)) {
         if (this.field_211724_c && blockstate.func_185905_o() == PushReaction.DESTROY) {
            this.field_177256_f.add(this.field_177260_c);
            return true;
         } else {
            return false;
         }
      } else if (!this.func_177251_a(this.field_177260_c, this.field_177257_d)) {
         return false;
      } else {
         for(int i = 0; i < this.field_177258_e.size(); ++i) {
            BlockPos blockpos = this.field_177258_e.get(i);
            if (func_227029_a_(this.field_177261_a.func_180495_p(blockpos).func_177230_c()) && !this.func_177250_b(blockpos)) {
               return false;
            }
         }

         return true;
      }
   }

   private static boolean func_227029_a_(Block p_227029_0_) {
      return p_227029_0_ == Blocks.field_180399_cE || p_227029_0_ == Blocks.field_226907_mc_;
   }

   private static boolean func_227030_a_(Block p_227030_0_, Block p_227030_1_) {
      if (p_227030_0_ == Blocks.field_226907_mc_ && p_227030_1_ == Blocks.field_180399_cE) {
         return false;
      } else if (p_227030_0_ == Blocks.field_180399_cE && p_227030_1_ == Blocks.field_226907_mc_) {
         return false;
      } else {
         return func_227029_a_(p_227030_0_) || func_227029_a_(p_227030_1_);
      }
   }

   private boolean func_177251_a(BlockPos p_177251_1_, Direction p_177251_2_) {
      BlockState blockstate = this.field_177261_a.func_180495_p(p_177251_1_);
      Block block = blockstate.func_177230_c();
      if (blockstate.func_196958_f()) {
         return true;
      } else if (!PistonBlock.func_185646_a(blockstate, this.field_177261_a, p_177251_1_, this.field_177257_d, false, p_177251_2_)) {
         return true;
      } else if (p_177251_1_.equals(this.field_177259_b)) {
         return true;
      } else if (this.field_177258_e.contains(p_177251_1_)) {
         return true;
      } else {
         int i = 1;
         if (i + this.field_177258_e.size() > 12) {
            return false;
         } else {
            while(func_227029_a_(block)) {
               BlockPos blockpos = p_177251_1_.func_177967_a(this.field_177257_d.func_176734_d(), i);
               Block block1 = block;
               blockstate = this.field_177261_a.func_180495_p(blockpos);
               block = blockstate.func_177230_c();
               if (blockstate.func_196958_f() || !func_227030_a_(block1, block) || !PistonBlock.func_185646_a(blockstate, this.field_177261_a, blockpos, this.field_177257_d, false, this.field_177257_d.func_176734_d()) || blockpos.equals(this.field_177259_b)) {
                  break;
               }

               ++i;
               if (i + this.field_177258_e.size() > 12) {
                  return false;
               }
            }

            int l = 0;

            for(int i1 = i - 1; i1 >= 0; --i1) {
               this.field_177258_e.add(p_177251_1_.func_177967_a(this.field_177257_d.func_176734_d(), i1));
               ++l;
            }

            int j1 = 1;

            while(true) {
               BlockPos blockpos1 = p_177251_1_.func_177967_a(this.field_177257_d, j1);
               int j = this.field_177258_e.indexOf(blockpos1);
               if (j > -1) {
                  this.func_177255_a(l, j);

                  for(int k = 0; k <= j + l; ++k) {
                     BlockPos blockpos2 = this.field_177258_e.get(k);
                     if (func_227029_a_(this.field_177261_a.func_180495_p(blockpos2).func_177230_c()) && !this.func_177250_b(blockpos2)) {
                        return false;
                     }
                  }

                  return true;
               }

               blockstate = this.field_177261_a.func_180495_p(blockpos1);
               if (blockstate.func_196958_f()) {
                  return true;
               }

               if (!PistonBlock.func_185646_a(blockstate, this.field_177261_a, blockpos1, this.field_177257_d, true, this.field_177257_d) || blockpos1.equals(this.field_177259_b)) {
                  return false;
               }

               if (blockstate.func_185905_o() == PushReaction.DESTROY) {
                  this.field_177256_f.add(blockpos1);
                  return true;
               }

               if (this.field_177258_e.size() >= 12) {
                  return false;
               }

               this.field_177258_e.add(blockpos1);
               ++l;
               ++j1;
            }
         }
      }
   }

   private void func_177255_a(int p_177255_1_, int p_177255_2_) {
      List<BlockPos> list = Lists.newArrayList();
      List<BlockPos> list1 = Lists.newArrayList();
      List<BlockPos> list2 = Lists.newArrayList();
      list.addAll(this.field_177258_e.subList(0, p_177255_2_));
      list1.addAll(this.field_177258_e.subList(this.field_177258_e.size() - p_177255_1_, this.field_177258_e.size()));
      list2.addAll(this.field_177258_e.subList(p_177255_2_, this.field_177258_e.size() - p_177255_1_));
      this.field_177258_e.clear();
      this.field_177258_e.addAll(list);
      this.field_177258_e.addAll(list1);
      this.field_177258_e.addAll(list2);
   }

   private boolean func_177250_b(BlockPos p_177250_1_) {
      BlockState blockstate = this.field_177261_a.func_180495_p(p_177250_1_);

      for(Direction direction : Direction.values()) {
         if (direction.func_176740_k() != this.field_177257_d.func_176740_k()) {
            BlockPos blockpos = p_177250_1_.func_177972_a(direction);
            BlockState blockstate1 = this.field_177261_a.func_180495_p(blockpos);
            if (func_227030_a_(blockstate1.func_177230_c(), blockstate.func_177230_c()) && !this.func_177251_a(blockpos, direction)) {
               return false;
            }
         }
      }

      return true;
   }

   public List<BlockPos> func_177254_c() {
      return this.field_177258_e;
   }

   public List<BlockPos> func_177252_d() {
      return this.field_177256_f;
   }
}
