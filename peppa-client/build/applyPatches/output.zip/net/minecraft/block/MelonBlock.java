package net.minecraft.block;

public class MelonBlock extends StemGrownBlock {
   protected MelonBlock(AbstractBlock.Properties p_i48365_1_) {
      super(p_i48365_1_);
   }

   public StemBlock func_196524_d() {
      return (StemBlock)Blocks.field_150394_bc;
   }

   public AttachedStemBlock func_196523_e() {
      return (AttachedStemBlock)Blocks.field_196713_dt;
   }
}
