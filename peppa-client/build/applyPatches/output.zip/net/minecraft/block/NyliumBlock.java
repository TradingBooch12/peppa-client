package net.minecraft.block;

import java.util.Random;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.Features;
import net.minecraft.world.gen.feature.NetherVegetationFeature;
import net.minecraft.world.gen.feature.TwistingVineFeature;
import net.minecraft.world.lighting.LightEngine;
import net.minecraft.world.server.ServerWorld;

public class NyliumBlock extends Block implements IGrowable {
   protected NyliumBlock(AbstractBlock.Properties p_i241184_1_) {
      super(p_i241184_1_);
   }

   private static boolean func_235516_b_(BlockState p_235516_0_, IWorldReader p_235516_1_, BlockPos p_235516_2_) {
      BlockPos blockpos = p_235516_2_.func_177984_a();
      BlockState blockstate = p_235516_1_.func_180495_p(blockpos);
      int i = LightEngine.func_215613_a(p_235516_1_, p_235516_0_, p_235516_2_, blockstate, blockpos, Direction.UP, blockstate.func_200016_a(p_235516_1_, blockpos));
      return i < p_235516_1_.func_201572_C();
   }

   public void func_225542_b_(BlockState p_225542_1_, ServerWorld p_225542_2_, BlockPos p_225542_3_, Random p_225542_4_) {
      if (!func_235516_b_(p_225542_1_, p_225542_2_, p_225542_3_)) {
         p_225542_2_.func_175656_a(p_225542_3_, Blocks.field_150424_aL.func_176223_P());
      }

   }

   public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, BlockState p_176473_3_, boolean p_176473_4_) {
      return p_176473_1_.func_180495_p(p_176473_2_.func_177984_a()).func_196958_f();
   }

   public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, BlockState p_180670_4_) {
      return true;
   }

   public void func_225535_a_(ServerWorld p_225535_1_, Random p_225535_2_, BlockPos p_225535_3_, BlockState p_225535_4_) {
      BlockState blockstate = p_225535_1_.func_180495_p(p_225535_3_);
      BlockPos blockpos = p_225535_3_.func_177984_a();
      if (blockstate.func_203425_a(Blocks.field_235381_mu_)) {
         NetherVegetationFeature.func_236325_a_(p_225535_1_, p_225535_2_, blockpos, Features.Configs.field_243987_k, 3, 1);
      } else if (blockstate.func_203425_a(Blocks.field_235372_ml_)) {
         NetherVegetationFeature.func_236325_a_(p_225535_1_, p_225535_2_, blockpos, Features.Configs.field_243988_l, 3, 1);
         NetherVegetationFeature.func_236325_a_(p_225535_1_, p_225535_2_, blockpos, Features.Configs.field_243989_m, 3, 1);
         if (p_225535_2_.nextInt(8) == 0) {
            TwistingVineFeature.func_236423_a_(p_225535_1_, p_225535_2_, blockpos, 3, 1, 2);
         }
      }

   }
}
