package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.DyeColor;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.BannerTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public abstract class AbstractBannerBlock extends ContainerBlock {
   private final DyeColor field_196286_a;

   protected AbstractBannerBlock(DyeColor p_i48453_1_, AbstractBlock.Properties p_i48453_2_) {
      super(p_i48453_2_);
      this.field_196286_a = p_i48453_1_;
   }

   public boolean func_181623_g() {
      return true;
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new BannerTileEntity(this.field_196286_a);
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, BlockState p_180633_3_, @Nullable LivingEntity p_180633_4_, ItemStack p_180633_5_) {
      if (p_180633_5_.func_82837_s()) {
         TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);
         if (tileentity instanceof BannerTileEntity) {
            ((BannerTileEntity)tileentity).func_213136_a(p_180633_5_.func_200301_q());
         }
      }

   }

   @OnlyIn(Dist.CLIENT)
   public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, BlockState p_185473_3_) {
      TileEntity tileentity = p_185473_1_.func_175625_s(p_185473_2_);
      return tileentity instanceof BannerTileEntity ? ((BannerTileEntity)tileentity).func_190615_l(p_185473_3_) : super.func_185473_a(p_185473_1_, p_185473_2_, p_185473_3_);
   }

   public DyeColor func_196285_M_() {
      return this.field_196286_a;
   }
}
