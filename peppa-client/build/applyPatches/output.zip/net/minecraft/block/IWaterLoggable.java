package net.minecraft.block;

import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;

public interface IWaterLoggable extends IBucketPickupHandler, ILiquidContainer {
   default boolean func_204510_a(IBlockReader p_204510_1_, BlockPos p_204510_2_, BlockState p_204510_3_, Fluid p_204510_4_) {
      return !p_204510_3_.func_177229_b(BlockStateProperties.field_208198_y) && p_204510_4_ == Fluids.field_204546_a;
   }

   default boolean func_204509_a(IWorld p_204509_1_, BlockPos p_204509_2_, BlockState p_204509_3_, FluidState p_204509_4_) {
      if (!p_204509_3_.func_177229_b(BlockStateProperties.field_208198_y) && p_204509_4_.func_206886_c() == Fluids.field_204546_a) {
         if (!p_204509_1_.func_201670_d()) {
            p_204509_1_.func_180501_a(p_204509_2_, p_204509_3_.func_206870_a(BlockStateProperties.field_208198_y, Boolean.valueOf(true)), 3);
            p_204509_1_.func_205219_F_().func_205360_a(p_204509_2_, p_204509_4_.func_206886_c(), p_204509_4_.func_206886_c().func_205569_a(p_204509_1_));
         }

         return true;
      } else {
         return false;
      }
   }

   default Fluid func_204508_a(IWorld p_204508_1_, BlockPos p_204508_2_, BlockState p_204508_3_) {
      if (p_204508_3_.func_177229_b(BlockStateProperties.field_208198_y)) {
         p_204508_1_.func_180501_a(p_204508_2_, p_204508_3_.func_206870_a(BlockStateProperties.field_208198_y, Boolean.valueOf(false)), 3);
         return Fluids.field_204546_a;
      } else {
         return Fluids.field_204541_a;
      }
   }
}
