package net.minecraft.block;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.inventory.container.Container;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tileentity.AbstractFurnaceTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.World;

public abstract class AbstractFurnaceBlock extends ContainerBlock {
   public static final DirectionProperty field_220090_a = HorizontalBlock.field_185512_D;
   public static final BooleanProperty field_220091_b = BlockStateProperties.field_208190_q;

   protected AbstractFurnaceBlock(AbstractBlock.Properties p_i50000_1_) {
      super(p_i50000_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_220090_a, Direction.NORTH).func_206870_a(field_220091_b, Boolean.valueOf(false)));
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      if (p_225533_2_.field_72995_K) {
         return ActionResultType.SUCCESS;
      } else {
         this.func_220089_a(p_225533_2_, p_225533_3_, p_225533_4_);
         return ActionResultType.CONSUME;
      }
   }

   protected abstract void func_220089_a(World p_220089_1_, BlockPos p_220089_2_, PlayerEntity p_220089_3_);

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_220090_a, p_196258_1_.func_195992_f().func_176734_d());
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, BlockState p_180633_3_, LivingEntity p_180633_4_, ItemStack p_180633_5_) {
      if (p_180633_5_.func_82837_s()) {
         TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);
         if (tileentity instanceof AbstractFurnaceTileEntity) {
            ((AbstractFurnaceTileEntity)tileentity).func_213903_a(p_180633_5_.func_200301_q());
         }
      }

   }

   public void func_196243_a(BlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, BlockState p_196243_4_, boolean p_196243_5_) {
      if (!p_196243_1_.func_203425_a(p_196243_4_.func_177230_c())) {
         TileEntity tileentity = p_196243_2_.func_175625_s(p_196243_3_);
         if (tileentity instanceof AbstractFurnaceTileEntity) {
            InventoryHelper.func_180175_a(p_196243_2_, p_196243_3_, (AbstractFurnaceTileEntity)tileentity);
            ((AbstractFurnaceTileEntity)tileentity).func_235640_a_(p_196243_2_, Vector3d.func_237489_a_(p_196243_3_));
            p_196243_2_.func_175666_e(p_196243_3_, this);
         }

         super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
      }
   }

   public boolean func_149740_M(BlockState p_149740_1_) {
      return true;
   }

   public int func_180641_l(BlockState p_180641_1_, World p_180641_2_, BlockPos p_180641_3_) {
      return Container.func_178144_a(p_180641_2_.func_175625_s(p_180641_3_));
   }

   public BlockRenderType func_149645_b(BlockState p_149645_1_) {
      return BlockRenderType.MODEL;
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_220090_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_220090_a)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_220090_a)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_220090_a, field_220091_b);
   }
}
