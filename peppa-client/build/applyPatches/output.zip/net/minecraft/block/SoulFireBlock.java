package net.minecraft.block;

import net.minecraft.tags.BlockTags;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;

public class SoulFireBlock extends AbstractFireBlock {
   public SoulFireBlock(AbstractBlock.Properties p_i241187_1_) {
      super(p_i241187_1_, 2.0F);
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return this.func_196260_a(p_196271_1_, p_196271_4_, p_196271_5_) ? this.func_176223_P() : Blocks.field_150350_a.func_176223_P();
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      return func_235577_c_(p_196260_2_.func_180495_p(p_196260_3_.func_177977_b()).func_177230_c());
   }

   public static boolean func_235577_c_(Block p_235577_0_) {
      return p_235577_0_.func_203417_a(BlockTags.field_232880_av_);
   }

   protected boolean func_196446_i(BlockState p_196446_1_) {
      return true;
   }
}
