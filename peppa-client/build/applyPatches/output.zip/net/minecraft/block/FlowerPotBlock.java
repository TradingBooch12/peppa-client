package net.minecraft.block;

import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathType;
import net.minecraft.stats.Stats;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class FlowerPotBlock extends Block {
   private static final Map<Block, Block> field_196451_b = Maps.newHashMap();
   protected static final VoxelShape field_196450_a = Block.func_208617_a(5.0D, 0.0D, 5.0D, 11.0D, 6.0D, 11.0D);
   private final Block field_196452_c;

   public FlowerPotBlock(Block p_i48395_1_, AbstractBlock.Properties p_i48395_2_) {
      super(p_i48395_2_);
      this.field_196452_c = p_i48395_1_;
      field_196451_b.put(p_i48395_1_, this);
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196450_a;
   }

   public BlockRenderType func_149645_b(BlockState p_149645_1_) {
      return BlockRenderType.MODEL;
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      ItemStack itemstack = p_225533_4_.func_184586_b(p_225533_5_);
      Item item = itemstack.func_77973_b();
      Block block = item instanceof BlockItem ? field_196451_b.getOrDefault(((BlockItem)item).func_179223_d(), Blocks.field_150350_a) : Blocks.field_150350_a;
      boolean flag = block == Blocks.field_150350_a;
      boolean flag1 = this.field_196452_c == Blocks.field_150350_a;
      if (flag != flag1) {
         if (flag1) {
            p_225533_2_.func_180501_a(p_225533_3_, block.func_176223_P(), 3);
            p_225533_4_.func_195066_a(Stats.field_188088_V);
            if (!p_225533_4_.field_71075_bZ.field_75098_d) {
               itemstack.func_190918_g(1);
            }
         } else {
            ItemStack itemstack1 = new ItemStack(this.field_196452_c);
            if (itemstack.func_190926_b()) {
               p_225533_4_.func_184611_a(p_225533_5_, itemstack1);
            } else if (!p_225533_4_.func_191521_c(itemstack1)) {
               p_225533_4_.func_71019_a(itemstack1, false);
            }

            p_225533_2_.func_180501_a(p_225533_3_, Blocks.field_150457_bL.func_176223_P(), 3);
         }

         return ActionResultType.func_233537_a_(p_225533_2_.field_72995_K);
      } else {
         return ActionResultType.CONSUME;
      }
   }

   @OnlyIn(Dist.CLIENT)
   public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, BlockState p_185473_3_) {
      return this.field_196452_c == Blocks.field_150350_a ? super.func_185473_a(p_185473_1_, p_185473_2_, p_185473_3_) : new ItemStack(this.field_196452_c);
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return p_196271_2_ == Direction.DOWN && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public Block func_220276_d() {
      return this.field_196452_c;
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
