package net.minecraft.block;

import java.util.Random;
import java.util.function.Supplier;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.ConfiguredFeature;
import net.minecraft.world.gen.feature.HugeFungusConfig;
import net.minecraft.world.server.ServerWorld;

public class FungusBlock extends BushBlock implements IGrowable {
   protected static final VoxelShape field_235496_a_ = Block.func_208617_a(4.0D, 0.0D, 4.0D, 12.0D, 9.0D, 12.0D);
   private final Supplier<ConfiguredFeature<HugeFungusConfig, ?>> field_235497_b_;

   protected FungusBlock(AbstractBlock.Properties p_i241177_1_, Supplier<ConfiguredFeature<HugeFungusConfig, ?>> p_i241177_2_) {
      super(p_i241177_1_);
      this.field_235497_b_ = p_i241177_2_;
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_235496_a_;
   }

   protected boolean func_200014_a_(BlockState p_200014_1_, IBlockReader p_200014_2_, BlockPos p_200014_3_) {
      return p_200014_1_.func_235714_a_(BlockTags.field_232873_an_) || p_200014_1_.func_203425_a(Blocks.field_150391_bh) || p_200014_1_.func_203425_a(Blocks.field_235336_cN_) || super.func_200014_a_(p_200014_1_, p_200014_2_, p_200014_3_);
   }

   public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, BlockState p_176473_3_, boolean p_176473_4_) {
      Block block = ((HugeFungusConfig)(this.field_235497_b_.get()).field_222738_b).field_236303_f_.func_177230_c();
      Block block1 = p_176473_1_.func_180495_p(p_176473_2_.func_177977_b()).func_177230_c();
      return block1 == block;
   }

   public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, BlockState p_180670_4_) {
      return (double)p_180670_2_.nextFloat() < 0.4D;
   }

   public void func_225535_a_(ServerWorld p_225535_1_, Random p_225535_2_, BlockPos p_225535_3_, BlockState p_225535_4_) {
      this.field_235497_b_.get().func_242765_a(p_225535_1_, p_225535_1_.func_72863_F().func_201711_g(), p_225535_2_, p_225535_3_);
   }
}
