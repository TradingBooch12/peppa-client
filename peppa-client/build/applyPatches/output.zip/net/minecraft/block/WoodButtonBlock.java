package net.minecraft.block;

import net.minecraft.util.SoundEvent;
import net.minecraft.util.SoundEvents;

public class WoodButtonBlock extends AbstractButtonBlock {
   protected WoodButtonBlock(AbstractBlock.Properties p_i48291_1_) {
      super(true, p_i48291_1_);
   }

   protected SoundEvent func_196369_b(boolean p_196369_1_) {
      return p_196369_1_ ? SoundEvents.field_187885_gS : SoundEvents.field_187883_gR;
   }
}
