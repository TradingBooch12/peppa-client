package net.minecraft.block;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tileentity.DaylightDetectorTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.LightType;
import net.minecraft.world.World;

public class DaylightDetectorBlock extends ContainerBlock {
   public static final IntegerProperty field_176436_a = BlockStateProperties.field_208136_ak;
   public static final BooleanProperty field_196320_b = BlockStateProperties.field_208188_o;
   protected static final VoxelShape field_196321_c = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 6.0D, 16.0D);

   public DaylightDetectorBlock(AbstractBlock.Properties p_i48419_1_) {
      super(p_i48419_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176436_a, Integer.valueOf(0)).func_206870_a(field_196320_b, Boolean.valueOf(false)));
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196321_c;
   }

   public boolean func_220074_n(BlockState p_220074_1_) {
      return true;
   }

   public int func_180656_a(BlockState p_180656_1_, IBlockReader p_180656_2_, BlockPos p_180656_3_, Direction p_180656_4_) {
      return p_180656_1_.func_177229_b(field_176436_a);
   }

   public static void func_196319_d(BlockState p_196319_0_, World p_196319_1_, BlockPos p_196319_2_) {
      if (p_196319_1_.func_230315_m_().func_218272_d()) {
         int i = p_196319_1_.func_226658_a_(LightType.SKY, p_196319_2_) - p_196319_1_.func_175657_ab();
         float f = p_196319_1_.func_72929_e(1.0F);
         boolean flag = p_196319_0_.func_177229_b(field_196320_b);
         if (flag) {
            i = 15 - i;
         } else if (i > 0) {
            float f1 = f < (float)Math.PI ? 0.0F : ((float)Math.PI * 2F);
            f = f + (f1 - f) * 0.2F;
            i = Math.round((float)i * MathHelper.func_76134_b(f));
         }

         i = MathHelper.func_76125_a(i, 0, 15);
         if (p_196319_0_.func_177229_b(field_176436_a) != i) {
            p_196319_1_.func_180501_a(p_196319_2_, p_196319_0_.func_206870_a(field_176436_a, Integer.valueOf(i)), 3);
         }

      }
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      if (p_225533_4_.func_175142_cm()) {
         if (p_225533_2_.field_72995_K) {
            return ActionResultType.SUCCESS;
         } else {
            BlockState blockstate = p_225533_1_.func_235896_a_(field_196320_b);
            p_225533_2_.func_180501_a(p_225533_3_, blockstate, 4);
            func_196319_d(blockstate, p_225533_2_, p_225533_3_);
            return ActionResultType.CONSUME;
         }
      } else {
         return super.func_225533_a_(p_225533_1_, p_225533_2_, p_225533_3_, p_225533_4_, p_225533_5_, p_225533_6_);
      }
   }

   public BlockRenderType func_149645_b(BlockState p_149645_1_) {
      return BlockRenderType.MODEL;
   }

   public boolean func_149744_f(BlockState p_149744_1_) {
      return true;
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new DaylightDetectorTileEntity();
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176436_a, field_196320_b);
   }
}
