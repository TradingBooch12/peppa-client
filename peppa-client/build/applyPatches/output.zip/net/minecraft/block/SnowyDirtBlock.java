package net.minecraft.block;

import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorld;

public class SnowyDirtBlock extends Block {
   public static final BooleanProperty field_196382_a = BlockStateProperties.field_208196_w;

   protected SnowyDirtBlock(AbstractBlock.Properties p_i48327_1_) {
      super(p_i48327_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196382_a, Boolean.valueOf(false)));
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return p_196271_2_ != Direction.UP ? super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_) : p_196271_1_.func_206870_a(field_196382_a, Boolean.valueOf(p_196271_3_.func_203425_a(Blocks.field_196604_cC) || p_196271_3_.func_203425_a(Blocks.field_150433_aE)));
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      BlockState blockstate = p_196258_1_.func_195991_k().func_180495_p(p_196258_1_.func_195995_a().func_177984_a());
      return this.func_176223_P().func_206870_a(field_196382_a, Boolean.valueOf(blockstate.func_203425_a(Blocks.field_196604_cC) || blockstate.func_203425_a(Blocks.field_150433_aE)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196382_a);
   }
}
