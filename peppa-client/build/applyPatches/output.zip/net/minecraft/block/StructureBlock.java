package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.StructureMode;
import net.minecraft.tileentity.StructureBlockTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class StructureBlock extends ContainerBlock {
   public static final EnumProperty<StructureMode> field_185587_a = BlockStateProperties.field_208147_av;

   protected StructureBlock(AbstractBlock.Properties p_i48314_1_) {
      super(p_i48314_1_);
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new StructureBlockTileEntity();
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      TileEntity tileentity = p_225533_2_.func_175625_s(p_225533_3_);
      if (tileentity instanceof StructureBlockTileEntity) {
         return ((StructureBlockTileEntity)tileentity).func_189701_a(p_225533_4_) ? ActionResultType.func_233537_a_(p_225533_2_.field_72995_K) : ActionResultType.PASS;
      } else {
         return ActionResultType.PASS;
      }
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, BlockState p_180633_3_, @Nullable LivingEntity p_180633_4_, ItemStack p_180633_5_) {
      if (!p_180633_1_.field_72995_K) {
         if (p_180633_4_ != null) {
            TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);
            if (tileentity instanceof StructureBlockTileEntity) {
               ((StructureBlockTileEntity)tileentity).func_189720_a(p_180633_4_);
            }
         }

      }
   }

   public BlockRenderType func_149645_b(BlockState p_149645_1_) {
      return BlockRenderType.MODEL;
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_185587_a, StructureMode.DATA);
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_185587_a);
   }

   public void func_220069_a(BlockState p_220069_1_, World p_220069_2_, BlockPos p_220069_3_, Block p_220069_4_, BlockPos p_220069_5_, boolean p_220069_6_) {
      if (p_220069_2_ instanceof ServerWorld) {
         TileEntity tileentity = p_220069_2_.func_175625_s(p_220069_3_);
         if (tileentity instanceof StructureBlockTileEntity) {
            StructureBlockTileEntity structureblocktileentity = (StructureBlockTileEntity)tileentity;
            boolean flag = p_220069_2_.func_175640_z(p_220069_3_);
            boolean flag1 = structureblocktileentity.func_189722_G();
            if (flag && !flag1) {
               structureblocktileentity.func_189723_d(true);
               this.func_242679_a((ServerWorld)p_220069_2_, structureblocktileentity);
            } else if (!flag && flag1) {
               structureblocktileentity.func_189723_d(false);
            }

         }
      }
   }

   private void func_242679_a(ServerWorld p_242679_1_, StructureBlockTileEntity p_242679_2_) {
      switch(p_242679_2_.func_189700_k()) {
      case SAVE:
         p_242679_2_.func_189712_b(false);
         break;
      case LOAD:
         p_242679_2_.func_242688_a(p_242679_1_, false);
         break;
      case CORNER:
         p_242679_2_.func_189706_E();
      case DATA:
      }

   }
}
