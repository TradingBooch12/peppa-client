package net.minecraft.block;

import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Direction;
import net.minecraft.util.Rotation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.world.GameRules;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class NetherPortalBlock extends Block {
   public static final EnumProperty<Direction.Axis> field_176550_a = BlockStateProperties.field_208199_z;
   protected static final VoxelShape field_185683_b = Block.func_208617_a(0.0D, 0.0D, 6.0D, 16.0D, 16.0D, 10.0D);
   protected static final VoxelShape field_185684_c = Block.func_208617_a(6.0D, 0.0D, 0.0D, 10.0D, 16.0D, 16.0D);

   public NetherPortalBlock(AbstractBlock.Properties p_i48352_1_) {
      super(p_i48352_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176550_a, Direction.Axis.X));
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      switch((Direction.Axis)p_220053_1_.func_177229_b(field_176550_a)) {
      case Z:
         return field_185684_c;
      case X:
      default:
         return field_185683_b;
      }
   }

   public void func_225542_b_(BlockState p_225542_1_, ServerWorld p_225542_2_, BlockPos p_225542_3_, Random p_225542_4_) {
      if (p_225542_2_.func_230315_m_().func_236043_f_() && p_225542_2_.func_82736_K().func_223586_b(GameRules.field_223601_d) && p_225542_4_.nextInt(2000) < p_225542_2_.func_175659_aa().func_151525_a()) {
         while(p_225542_2_.func_180495_p(p_225542_3_).func_203425_a(this)) {
            p_225542_3_ = p_225542_3_.func_177977_b();
         }

         if (p_225542_2_.func_180495_p(p_225542_3_).func_215688_a(p_225542_2_, p_225542_3_, EntityType.field_233592_ba_)) {
            Entity entity = EntityType.field_233592_ba_.func_220342_a(p_225542_2_, (CompoundNBT)null, (ITextComponent)null, (PlayerEntity)null, p_225542_3_.func_177984_a(), SpawnReason.STRUCTURE, false, false);
            if (entity != null) {
               entity.func_242279_ag();
            }
         }
      }

   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      Direction.Axis direction$axis = p_196271_2_.func_176740_k();
      Direction.Axis direction$axis1 = p_196271_1_.func_177229_b(field_176550_a);
      boolean flag = direction$axis1 != direction$axis && direction$axis.func_176722_c();
      return !flag && !p_196271_3_.func_203425_a(this) && !(new PortalSize(p_196271_4_, p_196271_5_, direction$axis1)).func_208508_f() ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public void func_196262_a(BlockState p_196262_1_, World p_196262_2_, BlockPos p_196262_3_, Entity p_196262_4_) {
      if (!p_196262_4_.func_184218_aH() && !p_196262_4_.func_184207_aI() && p_196262_4_.func_184222_aU()) {
         p_196262_4_.func_181015_d(p_196262_3_);
      }

   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(BlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      if (p_180655_4_.nextInt(100) == 0) {
         p_180655_2_.func_184134_a((double)p_180655_3_.func_177958_n() + 0.5D, (double)p_180655_3_.func_177956_o() + 0.5D, (double)p_180655_3_.func_177952_p() + 0.5D, SoundEvents.field_187810_eg, SoundCategory.BLOCKS, 0.5F, p_180655_4_.nextFloat() * 0.4F + 0.8F, false);
      }

      for(int i = 0; i < 4; ++i) {
         double d0 = (double)p_180655_3_.func_177958_n() + p_180655_4_.nextDouble();
         double d1 = (double)p_180655_3_.func_177956_o() + p_180655_4_.nextDouble();
         double d2 = (double)p_180655_3_.func_177952_p() + p_180655_4_.nextDouble();
         double d3 = ((double)p_180655_4_.nextFloat() - 0.5D) * 0.5D;
         double d4 = ((double)p_180655_4_.nextFloat() - 0.5D) * 0.5D;
         double d5 = ((double)p_180655_4_.nextFloat() - 0.5D) * 0.5D;
         int j = p_180655_4_.nextInt(2) * 2 - 1;
         if (!p_180655_2_.func_180495_p(p_180655_3_.func_177976_e()).func_203425_a(this) && !p_180655_2_.func_180495_p(p_180655_3_.func_177974_f()).func_203425_a(this)) {
            d0 = (double)p_180655_3_.func_177958_n() + 0.5D + 0.25D * (double)j;
            d3 = (double)(p_180655_4_.nextFloat() * 2.0F * (float)j);
         } else {
            d2 = (double)p_180655_3_.func_177952_p() + 0.5D + 0.25D * (double)j;
            d5 = (double)(p_180655_4_.nextFloat() * 2.0F * (float)j);
         }

         p_180655_2_.func_195594_a(ParticleTypes.field_197599_J, d0, d1, d2, d3, d4, d5);
      }

   }

   @OnlyIn(Dist.CLIENT)
   public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, BlockState p_185473_3_) {
      return ItemStack.field_190927_a;
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      switch(p_185499_2_) {
      case COUNTERCLOCKWISE_90:
      case CLOCKWISE_90:
         switch((Direction.Axis)p_185499_1_.func_177229_b(field_176550_a)) {
         case Z:
            return p_185499_1_.func_206870_a(field_176550_a, Direction.Axis.X);
         case X:
            return p_185499_1_.func_206870_a(field_176550_a, Direction.Axis.Z);
         default:
            return p_185499_1_;
         }
      default:
         return p_185499_1_;
      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176550_a);
   }
}
