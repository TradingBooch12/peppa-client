package net.minecraft.block;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.DyeColor;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.Stats;
import net.minecraft.tileentity.BeaconTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

public class BeaconBlock extends ContainerBlock implements IBeaconBeamColorProvider {
   public BeaconBlock(AbstractBlock.Properties p_i48443_1_) {
      super(p_i48443_1_);
   }

   public DyeColor func_196457_d() {
      return DyeColor.WHITE;
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new BeaconTileEntity();
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      if (p_225533_2_.field_72995_K) {
         return ActionResultType.SUCCESS;
      } else {
         TileEntity tileentity = p_225533_2_.func_175625_s(p_225533_3_);
         if (tileentity instanceof BeaconTileEntity) {
            p_225533_4_.func_213829_a((BeaconTileEntity)tileentity);
            p_225533_4_.func_195066_a(Stats.field_188082_P);
         }

         return ActionResultType.CONSUME;
      }
   }

   public BlockRenderType func_149645_b(BlockState p_149645_1_) {
      return BlockRenderType.MODEL;
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, BlockState p_180633_3_, LivingEntity p_180633_4_, ItemStack p_180633_5_) {
      if (p_180633_5_.func_82837_s()) {
         TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);
         if (tileentity instanceof BeaconTileEntity) {
            ((BeaconTileEntity)tileentity).func_200227_a(p_180633_5_.func_200301_q());
         }
      }

   }
}
