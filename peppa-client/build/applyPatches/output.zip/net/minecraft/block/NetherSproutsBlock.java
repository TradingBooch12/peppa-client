package net.minecraft.block;

import net.minecraft.tags.BlockTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;

public class NetherSproutsBlock extends BushBlock {
   protected static final VoxelShape field_235513_a_ = Block.func_208617_a(2.0D, 0.0D, 2.0D, 14.0D, 3.0D, 14.0D);

   public NetherSproutsBlock(AbstractBlock.Properties p_i241182_1_) {
      super(p_i241182_1_);
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_235513_a_;
   }

   protected boolean func_200014_a_(BlockState p_200014_1_, IBlockReader p_200014_2_, BlockPos p_200014_3_) {
      return p_200014_1_.func_235714_a_(BlockTags.field_232873_an_) || p_200014_1_.func_203425_a(Blocks.field_235336_cN_) || super.func_200014_a_(p_200014_1_, p_200014_2_, p_200014_3_);
   }

   public AbstractBlock.OffsetType func_176218_Q() {
      return AbstractBlock.OffsetType.XZ;
   }
}
