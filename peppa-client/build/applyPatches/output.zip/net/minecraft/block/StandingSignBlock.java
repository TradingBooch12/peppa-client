package net.minecraft.block;

import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Direction;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;

public class StandingSignBlock extends AbstractSignBlock {
   public static final IntegerProperty field_176413_a = BlockStateProperties.field_208138_am;

   public StandingSignBlock(AbstractBlock.Properties p_i225764_1_, WoodType p_i225764_2_) {
      super(p_i225764_1_, p_i225764_2_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176413_a, Integer.valueOf(0)).func_206870_a(field_204613_a, Boolean.valueOf(false)));
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      return p_196260_2_.func_180495_p(p_196260_3_.func_177977_b()).func_185904_a().func_76220_a();
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      FluidState fluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
      return this.func_176223_P().func_206870_a(field_176413_a, Integer.valueOf(MathHelper.func_76128_c((double)((180.0F + p_196258_1_.func_195990_h()) * 16.0F / 360.0F) + 0.5D) & 15)).func_206870_a(field_204613_a, Boolean.valueOf(fluidstate.func_206886_c() == Fluids.field_204546_a));
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return p_196271_2_ == Direction.DOWN && !this.func_196260_a(p_196271_1_, p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_176413_a, Integer.valueOf(p_185499_2_.func_185833_a(p_185499_1_.func_177229_b(field_176413_a), 16)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_206870_a(field_176413_a, Integer.valueOf(p_185471_2_.func_185802_a(p_185471_1_.func_177229_b(field_176413_a), 16)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176413_a, field_204613_a);
   }
}
