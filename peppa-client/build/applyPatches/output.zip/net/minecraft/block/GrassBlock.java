package net.minecraft.block;

import java.util.List;
import java.util.Random;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.ConfiguredFeature;
import net.minecraft.world.gen.feature.FlowersFeature;
import net.minecraft.world.server.ServerWorld;

public class GrassBlock extends SpreadableSnowyDirtBlock implements IGrowable {
   public GrassBlock(AbstractBlock.Properties p_i48388_1_) {
      super(p_i48388_1_);
   }

   public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, BlockState p_176473_3_, boolean p_176473_4_) {
      return p_176473_1_.func_180495_p(p_176473_2_.func_177984_a()).func_196958_f();
   }

   public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, BlockState p_180670_4_) {
      return true;
   }

   public void func_225535_a_(ServerWorld p_225535_1_, Random p_225535_2_, BlockPos p_225535_3_, BlockState p_225535_4_) {
      BlockPos blockpos = p_225535_3_.func_177984_a();
      BlockState blockstate = Blocks.field_150349_c.func_176223_P();

      label48:
      for(int i = 0; i < 128; ++i) {
         BlockPos blockpos1 = blockpos;

         for(int j = 0; j < i / 16; ++j) {
            blockpos1 = blockpos1.func_177982_a(p_225535_2_.nextInt(3) - 1, (p_225535_2_.nextInt(3) - 1) * p_225535_2_.nextInt(3) / 2, p_225535_2_.nextInt(3) - 1);
            if (!p_225535_1_.func_180495_p(blockpos1.func_177977_b()).func_203425_a(this) || p_225535_1_.func_180495_p(blockpos1).func_235785_r_(p_225535_1_, blockpos1)) {
               continue label48;
            }
         }

         BlockState blockstate2 = p_225535_1_.func_180495_p(blockpos1);
         if (blockstate2.func_203425_a(blockstate.func_177230_c()) && p_225535_2_.nextInt(10) == 0) {
            ((IGrowable)blockstate.func_177230_c()).func_225535_a_(p_225535_1_, p_225535_2_, blockpos1, blockstate2);
         }

         if (blockstate2.func_196958_f()) {
            BlockState blockstate1;
            if (p_225535_2_.nextInt(8) == 0) {
               List<ConfiguredFeature<?, ?>> list = p_225535_1_.func_226691_t_(blockpos1).func_242440_e().func_242496_b();
               if (list.isEmpty()) {
                  continue;
               }

               ConfiguredFeature<?, ?> configuredfeature = list.get(0);
               FlowersFeature flowersfeature = (FlowersFeature)configuredfeature.field_222737_a;
               blockstate1 = flowersfeature.func_225562_b_(p_225535_2_, blockpos1, configuredfeature.func_242767_c());
            } else {
               blockstate1 = blockstate;
            }

            if (blockstate1.func_196955_c(p_225535_1_, blockpos1)) {
               p_225535_1_.func_180501_a(blockpos1, blockstate1, 3);
            }
         }
      }

   }
}
