package net.minecraft.block;

import net.minecraft.entity.item.FallingBlockEntity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class ConcretePowderBlock extends FallingBlock {
   private final BlockState field_200294_a;

   public ConcretePowderBlock(Block p_i48423_1_, AbstractBlock.Properties p_i48423_2_) {
      super(p_i48423_2_);
      this.field_200294_a = p_i48423_1_.func_176223_P();
   }

   public void func_176502_a_(World p_176502_1_, BlockPos p_176502_2_, BlockState p_176502_3_, BlockState p_176502_4_, FallingBlockEntity p_176502_5_) {
      if (func_230137_b_(p_176502_1_, p_176502_2_, p_176502_4_)) {
         p_176502_1_.func_180501_a(p_176502_2_, this.field_200294_a, 3);
      }

   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      IBlockReader iblockreader = p_196258_1_.func_195991_k();
      BlockPos blockpos = p_196258_1_.func_195995_a();
      BlockState blockstate = iblockreader.func_180495_p(blockpos);
      return func_230137_b_(iblockreader, blockpos, blockstate) ? this.field_200294_a : super.func_196258_a(p_196258_1_);
   }

   private static boolean func_230137_b_(IBlockReader p_230137_0_, BlockPos p_230137_1_, BlockState p_230137_2_) {
      return func_212566_x(p_230137_2_) || func_196441_b(p_230137_0_, p_230137_1_);
   }

   private static boolean func_196441_b(IBlockReader p_196441_0_, BlockPos p_196441_1_) {
      boolean flag = false;
      BlockPos.Mutable blockpos$mutable = p_196441_1_.func_239590_i_();

      for(Direction direction : Direction.values()) {
         BlockState blockstate = p_196441_0_.func_180495_p(blockpos$mutable);
         if (direction != Direction.DOWN || func_212566_x(blockstate)) {
            blockpos$mutable.func_239622_a_(p_196441_1_, direction);
            blockstate = p_196441_0_.func_180495_p(blockpos$mutable);
            if (func_212566_x(blockstate) && !blockstate.func_224755_d(p_196441_0_, p_196441_1_, direction.func_176734_d())) {
               flag = true;
               break;
            }
         }
      }

      return flag;
   }

   private static boolean func_212566_x(BlockState p_212566_0_) {
      return p_212566_0_.func_204520_s().func_206884_a(FluidTags.field_206959_a);
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return func_196441_b(p_196271_4_, p_196271_5_) ? this.field_200294_a : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   @OnlyIn(Dist.CLIENT)
   public int func_189876_x(BlockState p_189876_1_, IBlockReader p_189876_2_, BlockPos p_189876_3_) {
      return p_189876_1_.func_185909_g(p_189876_2_, p_189876_3_).field_76291_p;
   }
}
