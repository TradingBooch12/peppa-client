package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class StemBlock extends BushBlock implements IGrowable {
   public static final IntegerProperty field_176484_a = BlockStateProperties.field_208170_W;
   protected static final VoxelShape[] field_196388_b = new VoxelShape[]{Block.func_208617_a(7.0D, 0.0D, 7.0D, 9.0D, 2.0D, 9.0D), Block.func_208617_a(7.0D, 0.0D, 7.0D, 9.0D, 4.0D, 9.0D), Block.func_208617_a(7.0D, 0.0D, 7.0D, 9.0D, 6.0D, 9.0D), Block.func_208617_a(7.0D, 0.0D, 7.0D, 9.0D, 8.0D, 9.0D), Block.func_208617_a(7.0D, 0.0D, 7.0D, 9.0D, 10.0D, 9.0D), Block.func_208617_a(7.0D, 0.0D, 7.0D, 9.0D, 12.0D, 9.0D), Block.func_208617_a(7.0D, 0.0D, 7.0D, 9.0D, 14.0D, 9.0D), Block.func_208617_a(7.0D, 0.0D, 7.0D, 9.0D, 16.0D, 9.0D)};
   private final StemGrownBlock field_149877_a;

   protected StemBlock(StemGrownBlock p_i48318_1_, AbstractBlock.Properties p_i48318_2_) {
      super(p_i48318_2_);
      this.field_149877_a = p_i48318_1_;
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176484_a, Integer.valueOf(0)));
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196388_b[p_220053_1_.func_177229_b(field_176484_a)];
   }

   protected boolean func_200014_a_(BlockState p_200014_1_, IBlockReader p_200014_2_, BlockPos p_200014_3_) {
      return p_200014_1_.func_203425_a(Blocks.field_150458_ak);
   }

   public void func_225542_b_(BlockState p_225542_1_, ServerWorld p_225542_2_, BlockPos p_225542_3_, Random p_225542_4_) {
      if (p_225542_2_.func_226659_b_(p_225542_3_, 0) >= 9) {
         float f = CropsBlock.func_180672_a(this, p_225542_2_, p_225542_3_);
         if (p_225542_4_.nextInt((int)(25.0F / f) + 1) == 0) {
            int i = p_225542_1_.func_177229_b(field_176484_a);
            if (i < 7) {
               p_225542_1_ = p_225542_1_.func_206870_a(field_176484_a, Integer.valueOf(i + 1));
               p_225542_2_.func_180501_a(p_225542_3_, p_225542_1_, 2);
            } else {
               Direction direction = Direction.Plane.HORIZONTAL.func_179518_a(p_225542_4_);
               BlockPos blockpos = p_225542_3_.func_177972_a(direction);
               BlockState blockstate = p_225542_2_.func_180495_p(blockpos.func_177977_b());
               if (p_225542_2_.func_180495_p(blockpos).func_196958_f() && (blockstate.func_203425_a(Blocks.field_150458_ak) || blockstate.func_203425_a(Blocks.field_150346_d) || blockstate.func_203425_a(Blocks.field_196660_k) || blockstate.func_203425_a(Blocks.field_196661_l) || blockstate.func_203425_a(Blocks.field_196658_i))) {
                  p_225542_2_.func_175656_a(blockpos, this.field_149877_a.func_176223_P());
                  p_225542_2_.func_175656_a(p_225542_3_, this.field_149877_a.func_196523_e().func_176223_P().func_206870_a(HorizontalBlock.field_185512_D, direction));
               }
            }
         }

      }
   }

   @Nullable
   @OnlyIn(Dist.CLIENT)
   protected Item func_176481_j() {
      if (this.field_149877_a == Blocks.field_150423_aK) {
         return Items.field_151080_bb;
      } else {
         return this.field_149877_a == Blocks.field_150440_ba ? Items.field_151081_bc : null;
      }
   }

   @OnlyIn(Dist.CLIENT)
   public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, BlockState p_185473_3_) {
      Item item = this.func_176481_j();
      return item == null ? ItemStack.field_190927_a : new ItemStack(item);
   }

   public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, BlockState p_176473_3_, boolean p_176473_4_) {
      return p_176473_3_.func_177229_b(field_176484_a) != 7;
   }

   public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, BlockState p_180670_4_) {
      return true;
   }

   public void func_225535_a_(ServerWorld p_225535_1_, Random p_225535_2_, BlockPos p_225535_3_, BlockState p_225535_4_) {
      int i = Math.min(7, p_225535_4_.func_177229_b(field_176484_a) + MathHelper.func_76136_a(p_225535_1_.field_73012_v, 2, 5));
      BlockState blockstate = p_225535_4_.func_206870_a(field_176484_a, Integer.valueOf(i));
      p_225535_1_.func_180501_a(p_225535_3_, blockstate, 2);
      if (i == 7) {
         blockstate.func_227034_b_(p_225535_1_, p_225535_3_, p_225535_1_.field_73012_v);
      }

   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176484_a);
   }

   public StemGrownBlock func_208486_d() {
      return this.field_149877_a;
   }
}
