package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.block.material.PushReaction;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;

public class LanternBlock extends Block implements IWaterLoggable {
   public static final BooleanProperty field_220278_a = BlockStateProperties.field_222514_j;
   public static final BooleanProperty field_242675_b = BlockStateProperties.field_208198_y;
   protected static final VoxelShape field_220279_b = VoxelShapes.func_197872_a(Block.func_208617_a(5.0D, 0.0D, 5.0D, 11.0D, 7.0D, 11.0D), Block.func_208617_a(6.0D, 7.0D, 6.0D, 10.0D, 9.0D, 10.0D));
   protected static final VoxelShape field_220280_c = VoxelShapes.func_197872_a(Block.func_208617_a(5.0D, 1.0D, 5.0D, 11.0D, 8.0D, 11.0D), Block.func_208617_a(6.0D, 8.0D, 6.0D, 10.0D, 10.0D, 10.0D));

   public LanternBlock(AbstractBlock.Properties p_i49980_1_) {
      super(p_i49980_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_220278_a, Boolean.valueOf(false)).func_206870_a(field_242675_b, Boolean.valueOf(false)));
   }

   @Nullable
   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      FluidState fluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());

      for(Direction direction : p_196258_1_.func_196009_e()) {
         if (direction.func_176740_k() == Direction.Axis.Y) {
            BlockState blockstate = this.func_176223_P().func_206870_a(field_220278_a, Boolean.valueOf(direction == Direction.UP));
            if (blockstate.func_196955_c(p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a())) {
               return blockstate.func_206870_a(field_242675_b, Boolean.valueOf(fluidstate.func_206886_c() == Fluids.field_204546_a));
            }
         }
      }

      return null;
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return p_220053_1_.func_177229_b(field_220278_a) ? field_220280_c : field_220279_b;
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_220278_a, field_242675_b);
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      Direction direction = func_220277_j(p_196260_1_).func_176734_d();
      return Block.func_220055_a(p_196260_2_, p_196260_3_.func_177972_a(direction), direction.func_176734_d());
   }

   protected static Direction func_220277_j(BlockState p_220277_0_) {
      return p_220277_0_.func_177229_b(field_220278_a) ? Direction.DOWN : Direction.UP;
   }

   public PushReaction func_149656_h(BlockState p_149656_1_) {
      return PushReaction.DESTROY;
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_1_.func_177229_b(field_242675_b)) {
         p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
      }

      return func_220277_j(p_196271_1_).func_176734_d() == p_196271_2_ && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public FluidState func_204507_t(BlockState p_204507_1_) {
      return p_204507_1_.func_177229_b(field_242675_b) ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(p_204507_1_);
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
