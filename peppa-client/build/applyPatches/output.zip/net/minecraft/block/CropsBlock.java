package net.minecraft.block;

import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.RavagerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.GameRules;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class CropsBlock extends BushBlock implements IGrowable {
   public static final IntegerProperty field_176488_a = BlockStateProperties.field_208170_W;
   private static final VoxelShape[] field_196393_a = new VoxelShape[]{Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 4.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 6.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 10.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 12.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 14.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D)};

   protected CropsBlock(AbstractBlock.Properties p_i48421_1_) {
      super(p_i48421_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(this.func_185524_e(), Integer.valueOf(0)));
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196393_a[p_220053_1_.func_177229_b(this.func_185524_e())];
   }

   protected boolean func_200014_a_(BlockState p_200014_1_, IBlockReader p_200014_2_, BlockPos p_200014_3_) {
      return p_200014_1_.func_203425_a(Blocks.field_150458_ak);
   }

   public IntegerProperty func_185524_e() {
      return field_176488_a;
   }

   public int func_185526_g() {
      return 7;
   }

   protected int func_185527_x(BlockState p_185527_1_) {
      return p_185527_1_.func_177229_b(this.func_185524_e());
   }

   public BlockState func_185528_e(int p_185528_1_) {
      return this.func_176223_P().func_206870_a(this.func_185524_e(), Integer.valueOf(p_185528_1_));
   }

   public boolean func_185525_y(BlockState p_185525_1_) {
      return p_185525_1_.func_177229_b(this.func_185524_e()) >= this.func_185526_g();
   }

   public boolean func_149653_t(BlockState p_149653_1_) {
      return !this.func_185525_y(p_149653_1_);
   }

   public void func_225542_b_(BlockState p_225542_1_, ServerWorld p_225542_2_, BlockPos p_225542_3_, Random p_225542_4_) {
      if (p_225542_2_.func_226659_b_(p_225542_3_, 0) >= 9) {
         int i = this.func_185527_x(p_225542_1_);
         if (i < this.func_185526_g()) {
            float f = func_180672_a(this, p_225542_2_, p_225542_3_);
            if (p_225542_4_.nextInt((int)(25.0F / f) + 1) == 0) {
               p_225542_2_.func_180501_a(p_225542_3_, this.func_185528_e(i + 1), 2);
            }
         }
      }

   }

   public void func_176487_g(World p_176487_1_, BlockPos p_176487_2_, BlockState p_176487_3_) {
      int i = this.func_185527_x(p_176487_3_) + this.func_185529_b(p_176487_1_);
      int j = this.func_185526_g();
      if (i > j) {
         i = j;
      }

      p_176487_1_.func_180501_a(p_176487_2_, this.func_185528_e(i), 2);
   }

   protected int func_185529_b(World p_185529_1_) {
      return MathHelper.func_76136_a(p_185529_1_.field_73012_v, 2, 5);
   }

   protected static float func_180672_a(Block p_180672_0_, IBlockReader p_180672_1_, BlockPos p_180672_2_) {
      float f = 1.0F;
      BlockPos blockpos = p_180672_2_.func_177977_b();

      for(int i = -1; i <= 1; ++i) {
         for(int j = -1; j <= 1; ++j) {
            float f1 = 0.0F;
            BlockState blockstate = p_180672_1_.func_180495_p(blockpos.func_177982_a(i, 0, j));
            if (blockstate.func_203425_a(Blocks.field_150458_ak)) {
               f1 = 1.0F;
               if (blockstate.func_177229_b(FarmlandBlock.field_176531_a) > 0) {
                  f1 = 3.0F;
               }
            }

            if (i != 0 || j != 0) {
               f1 /= 4.0F;
            }

            f += f1;
         }
      }

      BlockPos blockpos1 = p_180672_2_.func_177978_c();
      BlockPos blockpos2 = p_180672_2_.func_177968_d();
      BlockPos blockpos3 = p_180672_2_.func_177976_e();
      BlockPos blockpos4 = p_180672_2_.func_177974_f();
      boolean flag = p_180672_0_ == p_180672_1_.func_180495_p(blockpos3).func_177230_c() || p_180672_0_ == p_180672_1_.func_180495_p(blockpos4).func_177230_c();
      boolean flag1 = p_180672_0_ == p_180672_1_.func_180495_p(blockpos1).func_177230_c() || p_180672_0_ == p_180672_1_.func_180495_p(blockpos2).func_177230_c();
      if (flag && flag1) {
         f /= 2.0F;
      } else {
         boolean flag2 = p_180672_0_ == p_180672_1_.func_180495_p(blockpos3.func_177978_c()).func_177230_c() || p_180672_0_ == p_180672_1_.func_180495_p(blockpos4.func_177978_c()).func_177230_c() || p_180672_0_ == p_180672_1_.func_180495_p(blockpos4.func_177968_d()).func_177230_c() || p_180672_0_ == p_180672_1_.func_180495_p(blockpos3.func_177968_d()).func_177230_c();
         if (flag2) {
            f /= 2.0F;
         }
      }

      return f;
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      return (p_196260_2_.func_226659_b_(p_196260_3_, 0) >= 8 || p_196260_2_.func_226660_f_(p_196260_3_)) && super.func_196260_a(p_196260_1_, p_196260_2_, p_196260_3_);
   }

   public void func_196262_a(BlockState p_196262_1_, World p_196262_2_, BlockPos p_196262_3_, Entity p_196262_4_) {
      if (p_196262_4_ instanceof RavagerEntity && p_196262_2_.func_82736_K().func_223586_b(GameRules.field_223599_b)) {
         p_196262_2_.func_225521_a_(p_196262_3_, true, p_196262_4_);
      }

      super.func_196262_a(p_196262_1_, p_196262_2_, p_196262_3_, p_196262_4_);
   }

   @OnlyIn(Dist.CLIENT)
   protected IItemProvider func_199772_f() {
      return Items.field_151014_N;
   }

   @OnlyIn(Dist.CLIENT)
   public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, BlockState p_185473_3_) {
      return new ItemStack(this.func_199772_f());
   }

   public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, BlockState p_176473_3_, boolean p_176473_4_) {
      return !this.func_185525_y(p_176473_3_);
   }

   public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, BlockState p_180670_4_) {
      return true;
   }

   public void func_225535_a_(ServerWorld p_225535_1_, Random p_225535_2_, BlockPos p_225535_3_, BlockState p_225535_4_) {
      this.func_176487_g(p_225535_1_, p_225535_3_, p_225535_4_);
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176488_a);
   }
}
