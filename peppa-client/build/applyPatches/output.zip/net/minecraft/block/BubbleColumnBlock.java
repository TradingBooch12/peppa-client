package net.minecraft.block;

import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Direction;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BubbleColumnBlock extends Block implements IBucketPickupHandler {
   public static final BooleanProperty field_203160_a = BlockStateProperties.field_208179_f;

   public BubbleColumnBlock(AbstractBlock.Properties p_i48783_1_) {
      super(p_i48783_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_203160_a, Boolean.valueOf(true)));
   }

   public void func_196262_a(BlockState p_196262_1_, World p_196262_2_, BlockPos p_196262_3_, Entity p_196262_4_) {
      BlockState blockstate = p_196262_2_.func_180495_p(p_196262_3_.func_177984_a());
      if (blockstate.func_196958_f()) {
         p_196262_4_.func_203002_i(p_196262_1_.func_177229_b(field_203160_a));
         if (!p_196262_2_.field_72995_K) {
            ServerWorld serverworld = (ServerWorld)p_196262_2_;

            for(int i = 0; i < 2; ++i) {
               serverworld.func_195598_a(ParticleTypes.field_218422_X, (double)p_196262_3_.func_177958_n() + p_196262_2_.field_73012_v.nextDouble(), (double)(p_196262_3_.func_177956_o() + 1), (double)p_196262_3_.func_177952_p() + p_196262_2_.field_73012_v.nextDouble(), 1, 0.0D, 0.0D, 0.0D, 1.0D);
               serverworld.func_195598_a(ParticleTypes.field_197612_e, (double)p_196262_3_.func_177958_n() + p_196262_2_.field_73012_v.nextDouble(), (double)(p_196262_3_.func_177956_o() + 1), (double)p_196262_3_.func_177952_p() + p_196262_2_.field_73012_v.nextDouble(), 1, 0.0D, 0.01D, 0.0D, 0.2D);
            }
         }
      } else {
         p_196262_4_.func_203004_j(p_196262_1_.func_177229_b(field_203160_a));
      }

   }

   public void func_220082_b(BlockState p_220082_1_, World p_220082_2_, BlockPos p_220082_3_, BlockState p_220082_4_, boolean p_220082_5_) {
      func_203159_a(p_220082_2_, p_220082_3_.func_177984_a(), func_203157_b(p_220082_2_, p_220082_3_.func_177977_b()));
   }

   public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
      func_203159_a(p_225534_2_, p_225534_3_.func_177984_a(), func_203157_b(p_225534_2_, p_225534_3_));
   }

   public FluidState func_204507_t(BlockState p_204507_1_) {
      return Fluids.field_204546_a.func_207204_a(false);
   }

   public static void func_203159_a(IWorld p_203159_0_, BlockPos p_203159_1_, boolean p_203159_2_) {
      if (func_208072_b(p_203159_0_, p_203159_1_)) {
         p_203159_0_.func_180501_a(p_203159_1_, Blocks.field_203203_C.func_176223_P().func_206870_a(field_203160_a, Boolean.valueOf(p_203159_2_)), 2);
      }

   }

   public static boolean func_208072_b(IWorld p_208072_0_, BlockPos p_208072_1_) {
      FluidState fluidstate = p_208072_0_.func_204610_c(p_208072_1_);
      return p_208072_0_.func_180495_p(p_208072_1_).func_203425_a(Blocks.field_150355_j) && fluidstate.func_206882_g() >= 8 && fluidstate.func_206889_d();
   }

   private static boolean func_203157_b(IBlockReader p_203157_0_, BlockPos p_203157_1_) {
      BlockState blockstate = p_203157_0_.func_180495_p(p_203157_1_);
      if (blockstate.func_203425_a(Blocks.field_203203_C)) {
         return blockstate.func_177229_b(field_203160_a);
      } else {
         return !blockstate.func_203425_a(Blocks.field_150425_aM);
      }
   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(BlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      double d0 = (double)p_180655_3_.func_177958_n();
      double d1 = (double)p_180655_3_.func_177956_o();
      double d2 = (double)p_180655_3_.func_177952_p();
      if (p_180655_1_.func_177229_b(field_203160_a)) {
         p_180655_2_.func_195589_b(ParticleTypes.field_203218_U, d0 + 0.5D, d1 + 0.8D, d2, 0.0D, 0.0D, 0.0D);
         if (p_180655_4_.nextInt(200) == 0) {
            p_180655_2_.func_184134_a(d0, d1, d2, SoundEvents.field_203282_jc, SoundCategory.BLOCKS, 0.2F + p_180655_4_.nextFloat() * 0.2F, 0.9F + p_180655_4_.nextFloat() * 0.15F, false);
         }
      } else {
         p_180655_2_.func_195589_b(ParticleTypes.field_203220_f, d0 + 0.5D, d1, d2 + 0.5D, 0.0D, 0.04D, 0.0D);
         p_180655_2_.func_195589_b(ParticleTypes.field_203220_f, d0 + (double)p_180655_4_.nextFloat(), d1 + (double)p_180655_4_.nextFloat(), d2 + (double)p_180655_4_.nextFloat(), 0.0D, 0.04D, 0.0D);
         if (p_180655_4_.nextInt(200) == 0) {
            p_180655_2_.func_184134_a(d0, d1, d2, SoundEvents.field_203251_S, SoundCategory.BLOCKS, 0.2F + p_180655_4_.nextFloat() * 0.2F, 0.9F + p_180655_4_.nextFloat() * 0.15F, false);
         }
      }

   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (!p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_)) {
         return Blocks.field_150355_j.func_176223_P();
      } else {
         if (p_196271_2_ == Direction.DOWN) {
            p_196271_4_.func_180501_a(p_196271_5_, Blocks.field_203203_C.func_176223_P().func_206870_a(field_203160_a, Boolean.valueOf(func_203157_b(p_196271_4_, p_196271_6_))), 2);
         } else if (p_196271_2_ == Direction.UP && !p_196271_3_.func_203425_a(Blocks.field_203203_C) && func_208072_b(p_196271_4_, p_196271_6_)) {
            p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, 5);
         }

         p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
         return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      }
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      BlockState blockstate = p_196260_2_.func_180495_p(p_196260_3_.func_177977_b());
      return blockstate.func_203425_a(Blocks.field_203203_C) || blockstate.func_203425_a(Blocks.field_196814_hQ) || blockstate.func_203425_a(Blocks.field_150425_aM);
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return VoxelShapes.func_197880_a();
   }

   public BlockRenderType func_149645_b(BlockState p_149645_1_) {
      return BlockRenderType.INVISIBLE;
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_203160_a);
   }

   public Fluid func_204508_a(IWorld p_204508_1_, BlockPos p_204508_2_, BlockState p_204508_3_) {
      p_204508_1_.func_180501_a(p_204508_2_, Blocks.field_150350_a.func_176223_P(), 11);
      return Fluids.field_204546_a;
   }
}
