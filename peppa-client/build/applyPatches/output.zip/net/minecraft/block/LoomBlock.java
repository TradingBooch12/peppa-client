package net.minecraft.block;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.container.INamedContainerProvider;
import net.minecraft.inventory.container.LoomContainer;
import net.minecraft.inventory.container.SimpleNamedContainerProvider;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.StateContainer;
import net.minecraft.stats.Stats;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.IWorldPosCallable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.World;

public class LoomBlock extends HorizontalBlock {
   private static final ITextComponent field_220255_a = new TranslationTextComponent("container.loom");

   protected LoomBlock(AbstractBlock.Properties p_i49978_1_) {
      super(p_i49978_1_);
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      if (p_225533_2_.field_72995_K) {
         return ActionResultType.SUCCESS;
      } else {
         p_225533_4_.func_213829_a(p_225533_1_.func_215699_b(p_225533_2_, p_225533_3_));
         p_225533_4_.func_195066_a(Stats.field_219738_av);
         return ActionResultType.CONSUME;
      }
   }

   public INamedContainerProvider func_220052_b(BlockState p_220052_1_, World p_220052_2_, BlockPos p_220052_3_) {
      return new SimpleNamedContainerProvider((p_220254_2_, p_220254_3_, p_220254_4_) -> {
         return new LoomContainer(p_220254_2_, p_220254_3_, IWorldPosCallable.func_221488_a(p_220052_2_, p_220052_3_));
      }, field_220255_a);
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_185512_D, p_196258_1_.func_195992_f().func_176734_d());
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_185512_D);
   }
}
