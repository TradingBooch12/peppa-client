package net.minecraft.block;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.inventory.container.Container;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.stats.Stats;
import net.minecraft.tileentity.HopperTileEntity;
import net.minecraft.tileentity.IHopper;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.shapes.IBooleanFunction;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

public class HopperBlock extends ContainerBlock {
   public static final DirectionProperty field_176430_a = BlockStateProperties.field_208156_I;
   public static final BooleanProperty field_176429_b = BlockStateProperties.field_208180_g;
   private static final VoxelShape field_196328_c = Block.func_208617_a(0.0D, 10.0D, 0.0D, 16.0D, 16.0D, 16.0D);
   private static final VoxelShape field_196339_z = Block.func_208617_a(4.0D, 4.0D, 4.0D, 12.0D, 10.0D, 12.0D);
   private static final VoxelShape field_199607_z = VoxelShapes.func_197872_a(field_196339_z, field_196328_c);
   private static final VoxelShape field_196326_A = VoxelShapes.func_197878_a(field_199607_z, IHopper.field_200101_a, IBooleanFunction.field_223234_e_);
   private static final VoxelShape field_196333_G = VoxelShapes.func_197872_a(field_196326_A, Block.func_208617_a(6.0D, 0.0D, 6.0D, 10.0D, 4.0D, 10.0D));
   private static final VoxelShape field_196334_H = VoxelShapes.func_197872_a(field_196326_A, Block.func_208617_a(12.0D, 4.0D, 6.0D, 16.0D, 8.0D, 10.0D));
   private static final VoxelShape field_196335_I = VoxelShapes.func_197872_a(field_196326_A, Block.func_208617_a(6.0D, 4.0D, 0.0D, 10.0D, 8.0D, 4.0D));
   private static final VoxelShape field_196336_J = VoxelShapes.func_197872_a(field_196326_A, Block.func_208617_a(6.0D, 4.0D, 12.0D, 10.0D, 8.0D, 16.0D));
   private static final VoxelShape field_196337_K = VoxelShapes.func_197872_a(field_196326_A, Block.func_208617_a(0.0D, 4.0D, 6.0D, 4.0D, 8.0D, 10.0D));
   private static final VoxelShape field_199602_G = IHopper.field_200101_a;
   private static final VoxelShape field_199603_H = VoxelShapes.func_197872_a(IHopper.field_200101_a, Block.func_208617_a(12.0D, 8.0D, 6.0D, 16.0D, 10.0D, 10.0D));
   private static final VoxelShape field_199604_I = VoxelShapes.func_197872_a(IHopper.field_200101_a, Block.func_208617_a(6.0D, 8.0D, 0.0D, 10.0D, 10.0D, 4.0D));
   private static final VoxelShape field_199605_J = VoxelShapes.func_197872_a(IHopper.field_200101_a, Block.func_208617_a(6.0D, 8.0D, 12.0D, 10.0D, 10.0D, 16.0D));
   private static final VoxelShape field_199606_K = VoxelShapes.func_197872_a(IHopper.field_200101_a, Block.func_208617_a(0.0D, 8.0D, 6.0D, 4.0D, 10.0D, 10.0D));

   public HopperBlock(AbstractBlock.Properties p_i48378_1_) {
      super(p_i48378_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176430_a, Direction.DOWN).func_206870_a(field_176429_b, Boolean.valueOf(true)));
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      switch((Direction)p_220053_1_.func_177229_b(field_176430_a)) {
      case DOWN:
         return field_196333_G;
      case NORTH:
         return field_196335_I;
      case SOUTH:
         return field_196336_J;
      case WEST:
         return field_196337_K;
      case EAST:
         return field_196334_H;
      default:
         return field_196326_A;
      }
   }

   public VoxelShape func_199600_g(BlockState p_199600_1_, IBlockReader p_199600_2_, BlockPos p_199600_3_) {
      switch((Direction)p_199600_1_.func_177229_b(field_176430_a)) {
      case DOWN:
         return field_199602_G;
      case NORTH:
         return field_199604_I;
      case SOUTH:
         return field_199605_J;
      case WEST:
         return field_199606_K;
      case EAST:
         return field_199603_H;
      default:
         return IHopper.field_200101_a;
      }
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      Direction direction = p_196258_1_.func_196000_l().func_176734_d();
      return this.func_176223_P().func_206870_a(field_176430_a, direction.func_176740_k() == Direction.Axis.Y ? Direction.DOWN : direction).func_206870_a(field_176429_b, Boolean.valueOf(true));
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new HopperTileEntity();
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, BlockState p_180633_3_, LivingEntity p_180633_4_, ItemStack p_180633_5_) {
      if (p_180633_5_.func_82837_s()) {
         TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);
         if (tileentity instanceof HopperTileEntity) {
            ((HopperTileEntity)tileentity).func_213903_a(p_180633_5_.func_200301_q());
         }
      }

   }

   public void func_220082_b(BlockState p_220082_1_, World p_220082_2_, BlockPos p_220082_3_, BlockState p_220082_4_, boolean p_220082_5_) {
      if (!p_220082_4_.func_203425_a(p_220082_1_.func_177230_c())) {
         this.func_176427_e(p_220082_2_, p_220082_3_, p_220082_1_);
      }
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      if (p_225533_2_.field_72995_K) {
         return ActionResultType.SUCCESS;
      } else {
         TileEntity tileentity = p_225533_2_.func_175625_s(p_225533_3_);
         if (tileentity instanceof HopperTileEntity) {
            p_225533_4_.func_213829_a((HopperTileEntity)tileentity);
            p_225533_4_.func_195066_a(Stats.field_188084_R);
         }

         return ActionResultType.CONSUME;
      }
   }

   public void func_220069_a(BlockState p_220069_1_, World p_220069_2_, BlockPos p_220069_3_, Block p_220069_4_, BlockPos p_220069_5_, boolean p_220069_6_) {
      this.func_176427_e(p_220069_2_, p_220069_3_, p_220069_1_);
   }

   private void func_176427_e(World p_176427_1_, BlockPos p_176427_2_, BlockState p_176427_3_) {
      boolean flag = !p_176427_1_.func_175640_z(p_176427_2_);
      if (flag != p_176427_3_.func_177229_b(field_176429_b)) {
         p_176427_1_.func_180501_a(p_176427_2_, p_176427_3_.func_206870_a(field_176429_b, Boolean.valueOf(flag)), 4);
      }

   }

   public void func_196243_a(BlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, BlockState p_196243_4_, boolean p_196243_5_) {
      if (!p_196243_1_.func_203425_a(p_196243_4_.func_177230_c())) {
         TileEntity tileentity = p_196243_2_.func_175625_s(p_196243_3_);
         if (tileentity instanceof HopperTileEntity) {
            InventoryHelper.func_180175_a(p_196243_2_, p_196243_3_, (HopperTileEntity)tileentity);
            p_196243_2_.func_175666_e(p_196243_3_, this);
         }

         super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
      }
   }

   public BlockRenderType func_149645_b(BlockState p_149645_1_) {
      return BlockRenderType.MODEL;
   }

   public boolean func_149740_M(BlockState p_149740_1_) {
      return true;
   }

   public int func_180641_l(BlockState p_180641_1_, World p_180641_2_, BlockPos p_180641_3_) {
      return Container.func_178144_a(p_180641_2_.func_175625_s(p_180641_3_));
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_176430_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_176430_a)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_176430_a)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176430_a, field_176429_b);
   }

   public void func_196262_a(BlockState p_196262_1_, World p_196262_2_, BlockPos p_196262_3_, Entity p_196262_4_) {
      TileEntity tileentity = p_196262_2_.func_175625_s(p_196262_3_);
      if (tileentity instanceof HopperTileEntity) {
         ((HopperTileEntity)tileentity).func_200113_a(p_196262_4_);
      }

   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
