package net.minecraft.block;

import java.util.Random;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.server.ServerWorld;

public class OreBlock extends Block {
   public OreBlock(AbstractBlock.Properties p_i48357_1_) {
      super(p_i48357_1_);
   }

   protected int func_220281_a(Random p_220281_1_) {
      if (this == Blocks.field_150365_q) {
         return MathHelper.func_76136_a(p_220281_1_, 0, 2);
      } else if (this == Blocks.field_150482_ag) {
         return MathHelper.func_76136_a(p_220281_1_, 3, 7);
      } else if (this == Blocks.field_150412_bA) {
         return MathHelper.func_76136_a(p_220281_1_, 3, 7);
      } else if (this == Blocks.field_150369_x) {
         return MathHelper.func_76136_a(p_220281_1_, 2, 5);
      } else if (this == Blocks.field_196766_fg) {
         return MathHelper.func_76136_a(p_220281_1_, 2, 5);
      } else {
         return this == Blocks.field_235334_I_ ? MathHelper.func_76136_a(p_220281_1_, 0, 1) : 0;
      }
   }

   public void func_220062_a(BlockState p_220062_1_, ServerWorld p_220062_2_, BlockPos p_220062_3_, ItemStack p_220062_4_) {
      super.func_220062_a(p_220062_1_, p_220062_2_, p_220062_3_, p_220062_4_);
      if (EnchantmentHelper.func_77506_a(Enchantments.field_185306_r, p_220062_4_) == 0) {
         int i = this.func_220281_a(p_220062_2_.field_73012_v);
         if (i > 0) {
            this.func_180637_b(p_220062_2_, p_220062_3_, i);
         }
      }

   }
}
