package net.minecraft.block;

import it.unimi.dsi.fastutil.floats.Float2FloatFunction;
import java.util.List;
import java.util.Optional;
import java.util.function.BiPredicate;
import java.util.function.Supplier;
import javax.annotation.Nullable;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.monster.piglin.PiglinTasks;
import net.minecraft.entity.passive.CatEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.inventory.DoubleSidedInventory;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.inventory.container.ChestContainer;
import net.minecraft.inventory.container.Container;
import net.minecraft.inventory.container.INamedContainerProvider;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.ChestType;
import net.minecraft.stats.Stat;
import net.minecraft.stats.Stats;
import net.minecraft.tileentity.ChestTileEntity;
import net.minecraft.tileentity.IChestLid;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityMerger;
import net.minecraft.tileentity.TileEntityType;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.Mirror;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class ChestBlock extends AbstractChestBlock<ChestTileEntity> implements IWaterLoggable {
   public static final DirectionProperty field_176459_a = HorizontalBlock.field_185512_D;
   public static final EnumProperty<ChestType> field_196314_b = BlockStateProperties.field_208140_ao;
   public static final BooleanProperty field_204511_c = BlockStateProperties.field_208198_y;
   protected static final VoxelShape field_196316_c = Block.func_208617_a(1.0D, 0.0D, 0.0D, 15.0D, 14.0D, 15.0D);
   protected static final VoxelShape field_196317_y = Block.func_208617_a(1.0D, 0.0D, 1.0D, 15.0D, 14.0D, 16.0D);
   protected static final VoxelShape field_196318_z = Block.func_208617_a(0.0D, 0.0D, 1.0D, 15.0D, 14.0D, 15.0D);
   protected static final VoxelShape field_196313_A = Block.func_208617_a(1.0D, 0.0D, 1.0D, 16.0D, 14.0D, 15.0D);
   protected static final VoxelShape field_196315_B = Block.func_208617_a(1.0D, 0.0D, 1.0D, 15.0D, 14.0D, 15.0D);
   private static final TileEntityMerger.ICallback<ChestTileEntity, Optional<IInventory>> field_220109_i = new TileEntityMerger.ICallback<ChestTileEntity, Optional<IInventory>>() {
      public Optional<IInventory> func_225539_a_(ChestTileEntity p_225539_1_, ChestTileEntity p_225539_2_) {
         return Optional.of(new DoubleSidedInventory(p_225539_1_, p_225539_2_));
      }

      public Optional<IInventory> func_225538_a_(ChestTileEntity p_225538_1_) {
         return Optional.of(p_225538_1_);
      }

      public Optional<IInventory> func_225537_b_() {
         return Optional.empty();
      }
   };
   private static final TileEntityMerger.ICallback<ChestTileEntity, Optional<INamedContainerProvider>> field_220110_j = new TileEntityMerger.ICallback<ChestTileEntity, Optional<INamedContainerProvider>>() {
      public Optional<INamedContainerProvider> func_225539_a_(final ChestTileEntity p_225539_1_, final ChestTileEntity p_225539_2_) {
         final IInventory iinventory = new DoubleSidedInventory(p_225539_1_, p_225539_2_);
         return Optional.of(new INamedContainerProvider() {
            @Nullable
            public Container createMenu(int p_createMenu_1_, PlayerInventory p_createMenu_2_, PlayerEntity p_createMenu_3_) {
               if (p_225539_1_.func_213904_e(p_createMenu_3_) && p_225539_2_.func_213904_e(p_createMenu_3_)) {
                  p_225539_1_.func_184281_d(p_createMenu_2_.field_70458_d);
                  p_225539_2_.func_184281_d(p_createMenu_2_.field_70458_d);
                  return ChestContainer.func_216984_b(p_createMenu_1_, p_createMenu_2_, iinventory);
               } else {
                  return null;
               }
            }

            public ITextComponent func_145748_c_() {
               if (p_225539_1_.func_145818_k_()) {
                  return p_225539_1_.func_145748_c_();
               } else {
                  return (ITextComponent)(p_225539_2_.func_145818_k_() ? p_225539_2_.func_145748_c_() : new TranslationTextComponent("container.chestDouble"));
               }
            }
         });
      }

      public Optional<INamedContainerProvider> func_225538_a_(ChestTileEntity p_225538_1_) {
         return Optional.of(p_225538_1_);
      }

      public Optional<INamedContainerProvider> func_225537_b_() {
         return Optional.empty();
      }
   };

   protected ChestBlock(AbstractBlock.Properties p_i225757_1_, Supplier<TileEntityType<? extends ChestTileEntity>> p_i225757_2_) {
      super(p_i225757_1_, p_i225757_2_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176459_a, Direction.NORTH).func_206870_a(field_196314_b, ChestType.SINGLE).func_206870_a(field_204511_c, Boolean.valueOf(false)));
   }

   public static TileEntityMerger.Type func_226919_h_(BlockState p_226919_0_) {
      ChestType chesttype = p_226919_0_.func_177229_b(field_196314_b);
      if (chesttype == ChestType.SINGLE) {
         return TileEntityMerger.Type.SINGLE;
      } else {
         return chesttype == ChestType.RIGHT ? TileEntityMerger.Type.FIRST : TileEntityMerger.Type.SECOND;
      }
   }

   public BlockRenderType func_149645_b(BlockState p_149645_1_) {
      return BlockRenderType.ENTITYBLOCK_ANIMATED;
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_1_.func_177229_b(field_204511_c)) {
         p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
      }

      if (p_196271_3_.func_203425_a(this) && p_196271_2_.func_176740_k().func_176722_c()) {
         ChestType chesttype = p_196271_3_.func_177229_b(field_196314_b);
         if (p_196271_1_.func_177229_b(field_196314_b) == ChestType.SINGLE && chesttype != ChestType.SINGLE && p_196271_1_.func_177229_b(field_176459_a) == p_196271_3_.func_177229_b(field_176459_a) && func_196311_i(p_196271_3_) == p_196271_2_.func_176734_d()) {
            return p_196271_1_.func_206870_a(field_196314_b, chesttype.func_208081_a());
         }
      } else if (func_196311_i(p_196271_1_) == p_196271_2_) {
         return p_196271_1_.func_206870_a(field_196314_b, ChestType.SINGLE);
      }

      return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      if (p_220053_1_.func_177229_b(field_196314_b) == ChestType.SINGLE) {
         return field_196315_B;
      } else {
         switch(func_196311_i(p_220053_1_)) {
         case NORTH:
         default:
            return field_196316_c;
         case SOUTH:
            return field_196317_y;
         case WEST:
            return field_196318_z;
         case EAST:
            return field_196313_A;
         }
      }
   }

   public static Direction func_196311_i(BlockState p_196311_0_) {
      Direction direction = p_196311_0_.func_177229_b(field_176459_a);
      return p_196311_0_.func_177229_b(field_196314_b) == ChestType.LEFT ? direction.func_176746_e() : direction.func_176735_f();
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      ChestType chesttype = ChestType.SINGLE;
      Direction direction = p_196258_1_.func_195992_f().func_176734_d();
      FluidState fluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
      boolean flag = p_196258_1_.func_225518_g_();
      Direction direction1 = p_196258_1_.func_196000_l();
      if (direction1.func_176740_k().func_176722_c() && flag) {
         Direction direction2 = this.func_196312_a(p_196258_1_, direction1.func_176734_d());
         if (direction2 != null && direction2.func_176740_k() != direction1.func_176740_k()) {
            direction = direction2;
            chesttype = direction2.func_176735_f() == direction1.func_176734_d() ? ChestType.RIGHT : ChestType.LEFT;
         }
      }

      if (chesttype == ChestType.SINGLE && !flag) {
         if (direction == this.func_196312_a(p_196258_1_, direction.func_176746_e())) {
            chesttype = ChestType.LEFT;
         } else if (direction == this.func_196312_a(p_196258_1_, direction.func_176735_f())) {
            chesttype = ChestType.RIGHT;
         }
      }

      return this.func_176223_P().func_206870_a(field_176459_a, direction).func_206870_a(field_196314_b, chesttype).func_206870_a(field_204511_c, Boolean.valueOf(fluidstate.func_206886_c() == Fluids.field_204546_a));
   }

   public FluidState func_204507_t(BlockState p_204507_1_) {
      return p_204507_1_.func_177229_b(field_204511_c) ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(p_204507_1_);
   }

   @Nullable
   private Direction func_196312_a(BlockItemUseContext p_196312_1_, Direction p_196312_2_) {
      BlockState blockstate = p_196312_1_.func_195991_k().func_180495_p(p_196312_1_.func_195995_a().func_177972_a(p_196312_2_));
      return blockstate.func_203425_a(this) && blockstate.func_177229_b(field_196314_b) == ChestType.SINGLE ? blockstate.func_177229_b(field_176459_a) : null;
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, BlockState p_180633_3_, LivingEntity p_180633_4_, ItemStack p_180633_5_) {
      if (p_180633_5_.func_82837_s()) {
         TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);
         if (tileentity instanceof ChestTileEntity) {
            ((ChestTileEntity)tileentity).func_213903_a(p_180633_5_.func_200301_q());
         }
      }

   }

   public void func_196243_a(BlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, BlockState p_196243_4_, boolean p_196243_5_) {
      if (!p_196243_1_.func_203425_a(p_196243_4_.func_177230_c())) {
         TileEntity tileentity = p_196243_2_.func_175625_s(p_196243_3_);
         if (tileentity instanceof IInventory) {
            InventoryHelper.func_180175_a(p_196243_2_, p_196243_3_, (IInventory)tileentity);
            p_196243_2_.func_175666_e(p_196243_3_, this);
         }

         super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
      }
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      if (p_225533_2_.field_72995_K) {
         return ActionResultType.SUCCESS;
      } else {
         INamedContainerProvider inamedcontainerprovider = this.func_220052_b(p_225533_1_, p_225533_2_, p_225533_3_);
         if (inamedcontainerprovider != null) {
            p_225533_4_.func_213829_a(inamedcontainerprovider);
            p_225533_4_.func_71029_a(this.func_196310_d());
            PiglinTasks.func_234478_a_(p_225533_4_, true);
         }

         return ActionResultType.CONSUME;
      }
   }

   protected Stat<ResourceLocation> func_196310_d() {
      return Stats.field_199092_j.func_199076_b(Stats.field_188063_ac);
   }

   @Nullable
   public static IInventory func_226916_a_(ChestBlock p_226916_0_, BlockState p_226916_1_, World p_226916_2_, BlockPos p_226916_3_, boolean p_226916_4_) {
      return p_226916_0_.func_225536_a_(p_226916_1_, p_226916_2_, p_226916_3_, p_226916_4_).<Optional<IInventory>>apply(field_220109_i).orElse((IInventory)null);
   }

   public TileEntityMerger.ICallbackWrapper<? extends ChestTileEntity> func_225536_a_(BlockState p_225536_1_, World p_225536_2_, BlockPos p_225536_3_, boolean p_225536_4_) {
      BiPredicate<IWorld, BlockPos> bipredicate;
      if (p_225536_4_) {
         bipredicate = (p_226918_0_, p_226918_1_) -> {
            return false;
         };
      } else {
         bipredicate = ChestBlock::func_220108_a;
      }

      return TileEntityMerger.func_226924_a_(this.field_226859_a_.get(), ChestBlock::func_226919_h_, ChestBlock::func_196311_i, field_176459_a, p_225536_1_, p_225536_2_, p_225536_3_, bipredicate);
   }

   @Nullable
   public INamedContainerProvider func_220052_b(BlockState p_220052_1_, World p_220052_2_, BlockPos p_220052_3_) {
      return this.func_225536_a_(p_220052_1_, p_220052_2_, p_220052_3_, false).<Optional<INamedContainerProvider>>apply(field_220110_j).orElse((INamedContainerProvider)null);
   }

   @OnlyIn(Dist.CLIENT)
   public static TileEntityMerger.ICallback<ChestTileEntity, Float2FloatFunction> func_226917_a_(final IChestLid p_226917_0_) {
      return new TileEntityMerger.ICallback<ChestTileEntity, Float2FloatFunction>() {
         public Float2FloatFunction func_225539_a_(ChestTileEntity p_225539_1_, ChestTileEntity p_225539_2_) {
            return (p_226921_2_) -> {
               return Math.max(p_225539_1_.func_195480_a(p_226921_2_), p_225539_2_.func_195480_a(p_226921_2_));
            };
         }

         public Float2FloatFunction func_225538_a_(ChestTileEntity p_225538_1_) {
            return p_225538_1_::func_195480_a;
         }

         public Float2FloatFunction func_225537_b_() {
            return p_226917_0_::func_195480_a;
         }
      };
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new ChestTileEntity();
   }

   public static boolean func_220108_a(IWorld p_220108_0_, BlockPos p_220108_1_) {
      return func_176456_n(p_220108_0_, p_220108_1_) || func_220107_b(p_220108_0_, p_220108_1_);
   }

   private static boolean func_176456_n(IBlockReader p_176456_0_, BlockPos p_176456_1_) {
      BlockPos blockpos = p_176456_1_.func_177984_a();
      return p_176456_0_.func_180495_p(blockpos).func_215686_e(p_176456_0_, blockpos);
   }

   private static boolean func_220107_b(IWorld p_220107_0_, BlockPos p_220107_1_) {
      List<CatEntity> list = p_220107_0_.func_217357_a(CatEntity.class, new AxisAlignedBB((double)p_220107_1_.func_177958_n(), (double)(p_220107_1_.func_177956_o() + 1), (double)p_220107_1_.func_177952_p(), (double)(p_220107_1_.func_177958_n() + 1), (double)(p_220107_1_.func_177956_o() + 2), (double)(p_220107_1_.func_177952_p() + 1)));
      if (!list.isEmpty()) {
         for(CatEntity catentity : list) {
            if (catentity.func_233684_eK_()) {
               return true;
            }
         }
      }

      return false;
   }

   public boolean func_149740_M(BlockState p_149740_1_) {
      return true;
   }

   public int func_180641_l(BlockState p_180641_1_, World p_180641_2_, BlockPos p_180641_3_) {
      return Container.func_94526_b(func_226916_a_(this, p_180641_1_, p_180641_2_, p_180641_3_, false));
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_176459_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_176459_a)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_176459_a)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176459_a, field_196314_b, field_204511_c);
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
