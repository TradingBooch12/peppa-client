package net.minecraft.block;

import net.minecraft.block.material.PushReaction;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.StateContainer;

public class GlazedTerracottaBlock extends HorizontalBlock {
   public GlazedTerracottaBlock(AbstractBlock.Properties p_i48390_1_) {
      super(p_i48390_1_);
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_185512_D);
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_185512_D, p_196258_1_.func_195992_f().func_176734_d());
   }

   public PushReaction func_149656_h(BlockState p_149656_1_) {
      return PushReaction.PUSH_ONLY;
   }
}
