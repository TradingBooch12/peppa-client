package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.block.material.PushReaction;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BellAttachment;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.stats.Stats;
import net.minecraft.tileentity.BellTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;

public class BellBlock extends ContainerBlock {
   public static final DirectionProperty field_220133_a = HorizontalBlock.field_185512_D;
   public static final EnumProperty<BellAttachment> field_220134_b = BlockStateProperties.field_222511_P;
   public static final BooleanProperty field_226883_b_ = BlockStateProperties.field_208194_u;
   private static final VoxelShape field_220135_c = Block.func_208617_a(0.0D, 0.0D, 4.0D, 16.0D, 16.0D, 12.0D);
   private static final VoxelShape field_220136_d = Block.func_208617_a(4.0D, 0.0D, 0.0D, 12.0D, 16.0D, 16.0D);
   private static final VoxelShape field_220137_e = Block.func_208617_a(5.0D, 6.0D, 5.0D, 11.0D, 13.0D, 11.0D);
   private static final VoxelShape field_220138_f = Block.func_208617_a(4.0D, 4.0D, 4.0D, 12.0D, 6.0D, 12.0D);
   private static final VoxelShape field_220139_g = VoxelShapes.func_197872_a(field_220138_f, field_220137_e);
   private static final VoxelShape field_220140_h = VoxelShapes.func_197872_a(field_220139_g, Block.func_208617_a(7.0D, 13.0D, 0.0D, 9.0D, 15.0D, 16.0D));
   private static final VoxelShape field_220141_i = VoxelShapes.func_197872_a(field_220139_g, Block.func_208617_a(0.0D, 13.0D, 7.0D, 16.0D, 15.0D, 9.0D));
   private static final VoxelShape field_220142_j = VoxelShapes.func_197872_a(field_220139_g, Block.func_208617_a(0.0D, 13.0D, 7.0D, 13.0D, 15.0D, 9.0D));
   private static final VoxelShape field_220143_k = VoxelShapes.func_197872_a(field_220139_g, Block.func_208617_a(3.0D, 13.0D, 7.0D, 16.0D, 15.0D, 9.0D));
   private static final VoxelShape field_220144_w = VoxelShapes.func_197872_a(field_220139_g, Block.func_208617_a(7.0D, 13.0D, 0.0D, 9.0D, 15.0D, 13.0D));
   private static final VoxelShape field_220145_x = VoxelShapes.func_197872_a(field_220139_g, Block.func_208617_a(7.0D, 13.0D, 3.0D, 9.0D, 15.0D, 16.0D));
   private static final VoxelShape field_220146_y = VoxelShapes.func_197872_a(field_220139_g, Block.func_208617_a(7.0D, 13.0D, 7.0D, 9.0D, 16.0D, 9.0D));

   public BellBlock(AbstractBlock.Properties p_i49993_1_) {
      super(p_i49993_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_220133_a, Direction.NORTH).func_206870_a(field_220134_b, BellAttachment.FLOOR).func_206870_a(field_226883_b_, Boolean.valueOf(false)));
   }

   public void func_220069_a(BlockState p_220069_1_, World p_220069_2_, BlockPos p_220069_3_, Block p_220069_4_, BlockPos p_220069_5_, boolean p_220069_6_) {
      boolean flag = p_220069_2_.func_175640_z(p_220069_3_);
      if (flag != p_220069_1_.func_177229_b(field_226883_b_)) {
         if (flag) {
            this.func_226885_a_(p_220069_2_, p_220069_3_, (Direction)null);
         }

         p_220069_2_.func_180501_a(p_220069_3_, p_220069_1_.func_206870_a(field_226883_b_, Boolean.valueOf(flag)), 3);
      }

   }

   public void func_220066_a(World p_220066_1_, BlockState p_220066_2_, BlockRayTraceResult p_220066_3_, ProjectileEntity p_220066_4_) {
      Entity entity = p_220066_4_.func_234616_v_();
      PlayerEntity playerentity = entity instanceof PlayerEntity ? (PlayerEntity)entity : null;
      this.func_226884_a_(p_220066_1_, p_220066_2_, p_220066_3_, playerentity, true);
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      return this.func_226884_a_(p_225533_2_, p_225533_1_, p_225533_6_, p_225533_4_, true) ? ActionResultType.func_233537_a_(p_225533_2_.field_72995_K) : ActionResultType.PASS;
   }

   public boolean func_226884_a_(World p_226884_1_, BlockState p_226884_2_, BlockRayTraceResult p_226884_3_, @Nullable PlayerEntity p_226884_4_, boolean p_226884_5_) {
      Direction direction = p_226884_3_.func_216354_b();
      BlockPos blockpos = p_226884_3_.func_216350_a();
      boolean flag = !p_226884_5_ || this.func_220129_a(p_226884_2_, direction, p_226884_3_.func_216347_e().field_72448_b - (double)blockpos.func_177956_o());
      if (flag) {
         boolean flag1 = this.func_226885_a_(p_226884_1_, blockpos, direction);
         if (flag1 && p_226884_4_ != null) {
            p_226884_4_.func_195066_a(Stats.field_219740_ax);
         }

         return true;
      } else {
         return false;
      }
   }

   private boolean func_220129_a(BlockState p_220129_1_, Direction p_220129_2_, double p_220129_3_) {
      if (p_220129_2_.func_176740_k() != Direction.Axis.Y && !(p_220129_3_ > (double)0.8124F)) {
         Direction direction = p_220129_1_.func_177229_b(field_220133_a);
         BellAttachment bellattachment = p_220129_1_.func_177229_b(field_220134_b);
         switch(bellattachment) {
         case FLOOR:
            return direction.func_176740_k() == p_220129_2_.func_176740_k();
         case SINGLE_WALL:
         case DOUBLE_WALL:
            return direction.func_176740_k() != p_220129_2_.func_176740_k();
         case CEILING:
            return true;
         default:
            return false;
         }
      } else {
         return false;
      }
   }

   public boolean func_226885_a_(World p_226885_1_, BlockPos p_226885_2_, @Nullable Direction p_226885_3_) {
      TileEntity tileentity = p_226885_1_.func_175625_s(p_226885_2_);
      if (!p_226885_1_.field_72995_K && tileentity instanceof BellTileEntity) {
         if (p_226885_3_ == null) {
            p_226885_3_ = p_226885_1_.func_180495_p(p_226885_2_).func_177229_b(field_220133_a);
         }

         ((BellTileEntity)tileentity).func_213939_a(p_226885_3_);
         p_226885_1_.func_184133_a((PlayerEntity)null, p_226885_2_, SoundEvents.field_219603_Y, SoundCategory.BLOCKS, 2.0F, 1.0F);
         return true;
      } else {
         return false;
      }
   }

   private VoxelShape func_220128_j(BlockState p_220128_1_) {
      Direction direction = p_220128_1_.func_177229_b(field_220133_a);
      BellAttachment bellattachment = p_220128_1_.func_177229_b(field_220134_b);
      if (bellattachment == BellAttachment.FLOOR) {
         return direction != Direction.NORTH && direction != Direction.SOUTH ? field_220136_d : field_220135_c;
      } else if (bellattachment == BellAttachment.CEILING) {
         return field_220146_y;
      } else if (bellattachment == BellAttachment.DOUBLE_WALL) {
         return direction != Direction.NORTH && direction != Direction.SOUTH ? field_220141_i : field_220140_h;
      } else if (direction == Direction.NORTH) {
         return field_220144_w;
      } else if (direction == Direction.SOUTH) {
         return field_220145_x;
      } else {
         return direction == Direction.EAST ? field_220143_k : field_220142_j;
      }
   }

   public VoxelShape func_220071_b(BlockState p_220071_1_, IBlockReader p_220071_2_, BlockPos p_220071_3_, ISelectionContext p_220071_4_) {
      return this.func_220128_j(p_220071_1_);
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return this.func_220128_j(p_220053_1_);
   }

   public BlockRenderType func_149645_b(BlockState p_149645_1_) {
      return BlockRenderType.MODEL;
   }

   @Nullable
   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      Direction direction = p_196258_1_.func_196000_l();
      BlockPos blockpos = p_196258_1_.func_195995_a();
      World world = p_196258_1_.func_195991_k();
      Direction.Axis direction$axis = direction.func_176740_k();
      if (direction$axis == Direction.Axis.Y) {
         BlockState blockstate = this.func_176223_P().func_206870_a(field_220134_b, direction == Direction.DOWN ? BellAttachment.CEILING : BellAttachment.FLOOR).func_206870_a(field_220133_a, p_196258_1_.func_195992_f());
         if (blockstate.func_196955_c(p_196258_1_.func_195991_k(), blockpos)) {
            return blockstate;
         }
      } else {
         boolean flag = direction$axis == Direction.Axis.X && world.func_180495_p(blockpos.func_177976_e()).func_224755_d(world, blockpos.func_177976_e(), Direction.EAST) && world.func_180495_p(blockpos.func_177974_f()).func_224755_d(world, blockpos.func_177974_f(), Direction.WEST) || direction$axis == Direction.Axis.Z && world.func_180495_p(blockpos.func_177978_c()).func_224755_d(world, blockpos.func_177978_c(), Direction.SOUTH) && world.func_180495_p(blockpos.func_177968_d()).func_224755_d(world, blockpos.func_177968_d(), Direction.NORTH);
         BlockState blockstate1 = this.func_176223_P().func_206870_a(field_220133_a, direction.func_176734_d()).func_206870_a(field_220134_b, flag ? BellAttachment.DOUBLE_WALL : BellAttachment.SINGLE_WALL);
         if (blockstate1.func_196955_c(p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a())) {
            return blockstate1;
         }

         boolean flag1 = world.func_180495_p(blockpos.func_177977_b()).func_224755_d(world, blockpos.func_177977_b(), Direction.UP);
         blockstate1 = blockstate1.func_206870_a(field_220134_b, flag1 ? BellAttachment.FLOOR : BellAttachment.CEILING);
         if (blockstate1.func_196955_c(p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a())) {
            return blockstate1;
         }
      }

      return null;
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      BellAttachment bellattachment = p_196271_1_.func_177229_b(field_220134_b);
      Direction direction = func_220131_q(p_196271_1_).func_176734_d();
      if (direction == p_196271_2_ && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) && bellattachment != BellAttachment.DOUBLE_WALL) {
         return Blocks.field_150350_a.func_176223_P();
      } else {
         if (p_196271_2_.func_176740_k() == p_196271_1_.func_177229_b(field_220133_a).func_176740_k()) {
            if (bellattachment == BellAttachment.DOUBLE_WALL && !p_196271_3_.func_224755_d(p_196271_4_, p_196271_6_, p_196271_2_)) {
               return p_196271_1_.func_206870_a(field_220134_b, BellAttachment.SINGLE_WALL).func_206870_a(field_220133_a, p_196271_2_.func_176734_d());
            }

            if (bellattachment == BellAttachment.SINGLE_WALL && direction.func_176734_d() == p_196271_2_ && p_196271_3_.func_224755_d(p_196271_4_, p_196271_6_, p_196271_1_.func_177229_b(field_220133_a))) {
               return p_196271_1_.func_206870_a(field_220134_b, BellAttachment.DOUBLE_WALL);
            }
         }

         return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      }
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      Direction direction = func_220131_q(p_196260_1_).func_176734_d();
      return direction == Direction.UP ? Block.func_220055_a(p_196260_2_, p_196260_3_.func_177984_a(), Direction.DOWN) : HorizontalFaceBlock.func_220185_b(p_196260_2_, p_196260_3_, direction);
   }

   private static Direction func_220131_q(BlockState p_220131_0_) {
      switch((BellAttachment)p_220131_0_.func_177229_b(field_220134_b)) {
      case FLOOR:
         return Direction.UP;
      case CEILING:
         return Direction.DOWN;
      default:
         return p_220131_0_.func_177229_b(field_220133_a).func_176734_d();
      }
   }

   public PushReaction func_149656_h(BlockState p_149656_1_) {
      return PushReaction.DESTROY;
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_220133_a, field_220134_b, field_226883_b_);
   }

   @Nullable
   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new BellTileEntity();
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
