package net.minecraft.block;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.LeadItem;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.StateContainer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class FenceBlock extends FourWayBlock {
   private final VoxelShape[] field_199609_B;

   public FenceBlock(AbstractBlock.Properties p_i48399_1_) {
      super(2.0F, 2.0F, 16.0F, 16.0F, 24.0F, p_i48399_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196409_a, Boolean.valueOf(false)).func_206870_a(field_196411_b, Boolean.valueOf(false)).func_206870_a(field_196413_c, Boolean.valueOf(false)).func_206870_a(field_196414_y, Boolean.valueOf(false)).func_206870_a(field_204514_u, Boolean.valueOf(false)));
      this.field_199609_B = this.func_196408_a(2.0F, 1.0F, 16.0F, 6.0F, 15.0F);
   }

   public VoxelShape func_196247_c(BlockState p_196247_1_, IBlockReader p_196247_2_, BlockPos p_196247_3_) {
      return this.field_199609_B[this.func_196406_i(p_196247_1_)];
   }

   public VoxelShape func_230322_a_(BlockState p_230322_1_, IBlockReader p_230322_2_, BlockPos p_230322_3_, ISelectionContext p_230322_4_) {
      return this.func_220053_a(p_230322_1_, p_230322_2_, p_230322_3_, p_230322_4_);
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }

   public boolean func_220111_a(BlockState p_220111_1_, boolean p_220111_2_, Direction p_220111_3_) {
      Block block = p_220111_1_.func_177230_c();
      boolean flag = this.func_235493_c_(block);
      boolean flag1 = block instanceof FenceGateBlock && FenceGateBlock.func_220253_a(p_220111_1_, p_220111_3_);
      return !func_220073_a(block) && p_220111_2_ || flag || flag1;
   }

   private boolean func_235493_c_(Block p_235493_1_) {
      return p_235493_1_.func_203417_a(BlockTags.field_219748_G) && p_235493_1_.func_203417_a(BlockTags.field_219756_j) == this.func_176223_P().func_235714_a_(BlockTags.field_219756_j);
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      if (p_225533_2_.field_72995_K) {
         ItemStack itemstack = p_225533_4_.func_184586_b(p_225533_5_);
         return itemstack.func_77973_b() == Items.field_151058_ca ? ActionResultType.SUCCESS : ActionResultType.PASS;
      } else {
         return LeadItem.func_226641_a_(p_225533_4_, p_225533_2_, p_225533_3_);
      }
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      IBlockReader iblockreader = p_196258_1_.func_195991_k();
      BlockPos blockpos = p_196258_1_.func_195995_a();
      FluidState fluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
      BlockPos blockpos1 = blockpos.func_177978_c();
      BlockPos blockpos2 = blockpos.func_177974_f();
      BlockPos blockpos3 = blockpos.func_177968_d();
      BlockPos blockpos4 = blockpos.func_177976_e();
      BlockState blockstate = iblockreader.func_180495_p(blockpos1);
      BlockState blockstate1 = iblockreader.func_180495_p(blockpos2);
      BlockState blockstate2 = iblockreader.func_180495_p(blockpos3);
      BlockState blockstate3 = iblockreader.func_180495_p(blockpos4);
      return super.func_196258_a(p_196258_1_).func_206870_a(field_196409_a, Boolean.valueOf(this.func_220111_a(blockstate, blockstate.func_224755_d(iblockreader, blockpos1, Direction.SOUTH), Direction.SOUTH))).func_206870_a(field_196411_b, Boolean.valueOf(this.func_220111_a(blockstate1, blockstate1.func_224755_d(iblockreader, blockpos2, Direction.WEST), Direction.WEST))).func_206870_a(field_196413_c, Boolean.valueOf(this.func_220111_a(blockstate2, blockstate2.func_224755_d(iblockreader, blockpos3, Direction.NORTH), Direction.NORTH))).func_206870_a(field_196414_y, Boolean.valueOf(this.func_220111_a(blockstate3, blockstate3.func_224755_d(iblockreader, blockpos4, Direction.EAST), Direction.EAST))).func_206870_a(field_204514_u, Boolean.valueOf(fluidstate.func_206886_c() == Fluids.field_204546_a));
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_1_.func_177229_b(field_204514_u)) {
         p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
      }

      return p_196271_2_.func_176740_k().func_176716_d() == Direction.Plane.HORIZONTAL ? p_196271_1_.func_206870_a(field_196415_z.get(p_196271_2_), Boolean.valueOf(this.func_220111_a(p_196271_3_, p_196271_3_.func_224755_d(p_196271_4_, p_196271_6_, p_196271_2_.func_176734_d()), p_196271_2_.func_176734_d()))) : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196409_a, field_196411_b, field_196414_y, field_196413_c, field_204514_u);
   }
}
