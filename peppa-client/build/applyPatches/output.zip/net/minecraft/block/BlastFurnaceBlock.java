package net.minecraft.block;

import java.util.Random;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.container.INamedContainerProvider;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.stats.Stats;
import net.minecraft.tileentity.BlastFurnaceTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Direction;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BlastFurnaceBlock extends AbstractFurnaceBlock {
   protected BlastFurnaceBlock(AbstractBlock.Properties p_i49992_1_) {
      super(p_i49992_1_);
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new BlastFurnaceTileEntity();
   }

   protected void func_220089_a(World p_220089_1_, BlockPos p_220089_2_, PlayerEntity p_220089_3_) {
      TileEntity tileentity = p_220089_1_.func_175625_s(p_220089_2_);
      if (tileentity instanceof BlastFurnaceTileEntity) {
         p_220089_3_.func_213829_a((INamedContainerProvider)tileentity);
         p_220089_3_.func_195066_a(Stats.field_219733_aq);
      }

   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(BlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      if (p_180655_1_.func_177229_b(field_220091_b)) {
         double d0 = (double)p_180655_3_.func_177958_n() + 0.5D;
         double d1 = (double)p_180655_3_.func_177956_o();
         double d2 = (double)p_180655_3_.func_177952_p() + 0.5D;
         if (p_180655_4_.nextDouble() < 0.1D) {
            p_180655_2_.func_184134_a(d0, d1, d2, SoundEvents.field_219619_am, SoundCategory.BLOCKS, 1.0F, 1.0F, false);
         }

         Direction direction = p_180655_1_.func_177229_b(field_220090_a);
         Direction.Axis direction$axis = direction.func_176740_k();
         double d3 = 0.52D;
         double d4 = p_180655_4_.nextDouble() * 0.6D - 0.3D;
         double d5 = direction$axis == Direction.Axis.X ? (double)direction.func_82601_c() * 0.52D : d4;
         double d6 = p_180655_4_.nextDouble() * 9.0D / 16.0D;
         double d7 = direction$axis == Direction.Axis.Z ? (double)direction.func_82599_e() * 0.52D : d4;
         p_180655_2_.func_195594_a(ParticleTypes.field_197601_L, d0 + d5, d1 + d6, d2 + d7, 0.0D, 0.0D, 0.0D);
      }
   }
}
