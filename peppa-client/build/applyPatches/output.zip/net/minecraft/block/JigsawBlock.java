package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tileentity.JigsawTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.world.gen.feature.jigsaw.JigsawOrientation;
import net.minecraft.world.gen.feature.template.Template;

public class JigsawBlock extends Block implements ITileEntityProvider {
   public static final EnumProperty<JigsawOrientation> field_235506_a_ = BlockStateProperties.field_235907_P_;

   protected JigsawBlock(AbstractBlock.Properties p_i49981_1_) {
      super(p_i49981_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_235506_a_, JigsawOrientation.NORTH_UP));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_235506_a_);
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_235506_a_, p_185499_2_.func_235574_a_().func_235531_a_(p_185499_1_.func_177229_b(field_235506_a_)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_206870_a(field_235506_a_, p_185471_2_.func_235512_a_().func_235531_a_(p_185471_1_.func_177229_b(field_235506_a_)));
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      Direction direction = p_196258_1_.func_196000_l();
      Direction direction1;
      if (direction.func_176740_k() == Direction.Axis.Y) {
         direction1 = p_196258_1_.func_195992_f().func_176734_d();
      } else {
         direction1 = Direction.UP;
      }

      return this.func_176223_P().func_206870_a(field_235506_a_, JigsawOrientation.func_239641_a_(direction, direction1));
   }

   @Nullable
   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new JigsawTileEntity();
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      TileEntity tileentity = p_225533_2_.func_175625_s(p_225533_3_);
      if (tileentity instanceof JigsawTileEntity && p_225533_4_.func_195070_dx()) {
         p_225533_4_.func_213826_a((JigsawTileEntity)tileentity);
         return ActionResultType.func_233537_a_(p_225533_2_.field_72995_K);
      } else {
         return ActionResultType.PASS;
      }
   }

   public static boolean func_220171_a(Template.BlockInfo p_220171_0_, Template.BlockInfo p_220171_1_) {
      Direction direction = func_235508_h_(p_220171_0_.field_186243_b);
      Direction direction1 = func_235508_h_(p_220171_1_.field_186243_b);
      Direction direction2 = func_235509_l_(p_220171_0_.field_186243_b);
      Direction direction3 = func_235509_l_(p_220171_1_.field_186243_b);
      JigsawTileEntity.OrientationType jigsawtileentity$orientationtype = JigsawTileEntity.OrientationType.func_235673_a_(p_220171_0_.field_186244_c.func_74779_i("joint")).orElseGet(() -> {
         return direction.func_176740_k().func_176722_c() ? JigsawTileEntity.OrientationType.ALIGNED : JigsawTileEntity.OrientationType.ROLLABLE;
      });
      boolean flag = jigsawtileentity$orientationtype == JigsawTileEntity.OrientationType.ROLLABLE;
      return direction == direction1.func_176734_d() && (flag || direction2 == direction3) && p_220171_0_.field_186244_c.func_74779_i("target").equals(p_220171_1_.field_186244_c.func_74779_i("name"));
   }

   public static Direction func_235508_h_(BlockState p_235508_0_) {
      return p_235508_0_.func_177229_b(field_235506_a_).func_239642_b_();
   }

   public static Direction func_235509_l_(BlockState p_235509_0_) {
      return p_235509_0_.func_177229_b(field_235506_a_).func_239644_c_();
   }
}
