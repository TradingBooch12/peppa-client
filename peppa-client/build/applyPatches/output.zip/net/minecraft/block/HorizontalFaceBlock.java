package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.properties.AttachFace;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;

public class HorizontalFaceBlock extends HorizontalBlock {
   public static final EnumProperty<AttachFace> field_196366_M = BlockStateProperties.field_208158_K;

   protected HorizontalFaceBlock(AbstractBlock.Properties p_i48402_1_) {
      super(p_i48402_1_);
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      return func_220185_b(p_196260_2_, p_196260_3_, func_196365_i(p_196260_1_).func_176734_d());
   }

   public static boolean func_220185_b(IWorldReader p_220185_0_, BlockPos p_220185_1_, Direction p_220185_2_) {
      BlockPos blockpos = p_220185_1_.func_177972_a(p_220185_2_);
      return p_220185_0_.func_180495_p(blockpos).func_224755_d(p_220185_0_, blockpos, p_220185_2_.func_176734_d());
   }

   @Nullable
   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      for(Direction direction : p_196258_1_.func_196009_e()) {
         BlockState blockstate;
         if (direction.func_176740_k() == Direction.Axis.Y) {
            blockstate = this.func_176223_P().func_206870_a(field_196366_M, direction == Direction.UP ? AttachFace.CEILING : AttachFace.FLOOR).func_206870_a(field_185512_D, p_196258_1_.func_195992_f());
         } else {
            blockstate = this.func_176223_P().func_206870_a(field_196366_M, AttachFace.WALL).func_206870_a(field_185512_D, direction.func_176734_d());
         }

         if (blockstate.func_196955_c(p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a())) {
            return blockstate;
         }
      }

      return null;
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return func_196365_i(p_196271_1_).func_176734_d() == p_196271_2_ && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   protected static Direction func_196365_i(BlockState p_196365_0_) {
      switch((AttachFace)p_196365_0_.func_177229_b(field_196366_M)) {
      case CEILING:
         return Direction.DOWN;
      case FLOOR:
         return Direction.UP;
      default:
         return p_196365_0_.func_177229_b(field_185512_D);
      }
   }
}
