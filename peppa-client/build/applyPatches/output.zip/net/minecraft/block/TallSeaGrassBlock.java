package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.properties.DoubleBlockHalf;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class TallSeaGrassBlock extends DoublePlantBlock implements ILiquidContainer {
   public static final EnumProperty<DoubleBlockHalf> field_208065_c = DoublePlantBlock.field_176492_b;
   protected static final VoxelShape field_207799_b = Block.func_208617_a(2.0D, 0.0D, 2.0D, 14.0D, 16.0D, 14.0D);

   public TallSeaGrassBlock(AbstractBlock.Properties p_i49970_1_) {
      super(p_i49970_1_);
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_207799_b;
   }

   protected boolean func_200014_a_(BlockState p_200014_1_, IBlockReader p_200014_2_, BlockPos p_200014_3_) {
      return p_200014_1_.func_224755_d(p_200014_2_, p_200014_3_, Direction.UP) && !p_200014_1_.func_203425_a(Blocks.field_196814_hQ);
   }

   @OnlyIn(Dist.CLIENT)
   public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, BlockState p_185473_3_) {
      return new ItemStack(Blocks.field_203198_aQ);
   }

   @Nullable
   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      BlockState blockstate = super.func_196258_a(p_196258_1_);
      if (blockstate != null) {
         FluidState fluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a().func_177984_a());
         if (fluidstate.func_206884_a(FluidTags.field_206959_a) && fluidstate.func_206882_g() == 8) {
            return blockstate;
         }
      }

      return null;
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      if (p_196260_1_.func_177229_b(field_208065_c) == DoubleBlockHalf.UPPER) {
         BlockState blockstate = p_196260_2_.func_180495_p(p_196260_3_.func_177977_b());
         return blockstate.func_203425_a(this) && blockstate.func_177229_b(field_208065_c) == DoubleBlockHalf.LOWER;
      } else {
         FluidState fluidstate = p_196260_2_.func_204610_c(p_196260_3_);
         return super.func_196260_a(p_196260_1_, p_196260_2_, p_196260_3_) && fluidstate.func_206884_a(FluidTags.field_206959_a) && fluidstate.func_206882_g() == 8;
      }
   }

   public FluidState func_204507_t(BlockState p_204507_1_) {
      return Fluids.field_204546_a.func_207204_a(false);
   }

   public boolean func_204510_a(IBlockReader p_204510_1_, BlockPos p_204510_2_, BlockState p_204510_3_, Fluid p_204510_4_) {
      return false;
   }

   public boolean func_204509_a(IWorld p_204509_1_, BlockPos p_204509_2_, BlockState p_204509_3_, FluidState p_204509_4_) {
      return false;
   }
}
