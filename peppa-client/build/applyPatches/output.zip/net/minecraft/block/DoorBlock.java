package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.material.PushReaction;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.DoorHingeSide;
import net.minecraft.state.properties.DoubleBlockHalf;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class DoorBlock extends Block {
   public static final DirectionProperty field_176520_a = HorizontalBlock.field_185512_D;
   public static final BooleanProperty field_176519_b = BlockStateProperties.field_208193_t;
   public static final EnumProperty<DoorHingeSide> field_176521_M = BlockStateProperties.field_208142_aq;
   public static final BooleanProperty field_176522_N = BlockStateProperties.field_208194_u;
   public static final EnumProperty<DoubleBlockHalf> field_176523_O = BlockStateProperties.field_208163_P;
   protected static final VoxelShape field_185658_f = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 3.0D);
   protected static final VoxelShape field_185659_g = Block.func_208617_a(0.0D, 0.0D, 13.0D, 16.0D, 16.0D, 16.0D);
   protected static final VoxelShape field_185656_B = Block.func_208617_a(13.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D);
   protected static final VoxelShape field_185657_C = Block.func_208617_a(0.0D, 0.0D, 0.0D, 3.0D, 16.0D, 16.0D);

   protected DoorBlock(AbstractBlock.Properties p_i48413_1_) {
      super(p_i48413_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176520_a, Direction.NORTH).func_206870_a(field_176519_b, Boolean.valueOf(false)).func_206870_a(field_176521_M, DoorHingeSide.LEFT).func_206870_a(field_176522_N, Boolean.valueOf(false)).func_206870_a(field_176523_O, DoubleBlockHalf.LOWER));
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      Direction direction = p_220053_1_.func_177229_b(field_176520_a);
      boolean flag = !p_220053_1_.func_177229_b(field_176519_b);
      boolean flag1 = p_220053_1_.func_177229_b(field_176521_M) == DoorHingeSide.RIGHT;
      switch(direction) {
      case EAST:
      default:
         return flag ? field_185657_C : (flag1 ? field_185659_g : field_185658_f);
      case SOUTH:
         return flag ? field_185658_f : (flag1 ? field_185657_C : field_185656_B);
      case WEST:
         return flag ? field_185656_B : (flag1 ? field_185658_f : field_185659_g);
      case NORTH:
         return flag ? field_185659_g : (flag1 ? field_185656_B : field_185657_C);
      }
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      DoubleBlockHalf doubleblockhalf = p_196271_1_.func_177229_b(field_176523_O);
      if (p_196271_2_.func_176740_k() == Direction.Axis.Y && doubleblockhalf == DoubleBlockHalf.LOWER == (p_196271_2_ == Direction.UP)) {
         return p_196271_3_.func_203425_a(this) && p_196271_3_.func_177229_b(field_176523_O) != doubleblockhalf ? p_196271_1_.func_206870_a(field_176520_a, p_196271_3_.func_177229_b(field_176520_a)).func_206870_a(field_176519_b, p_196271_3_.func_177229_b(field_176519_b)).func_206870_a(field_176521_M, p_196271_3_.func_177229_b(field_176521_M)).func_206870_a(field_176522_N, p_196271_3_.func_177229_b(field_176522_N)) : Blocks.field_150350_a.func_176223_P();
      } else {
         return doubleblockhalf == DoubleBlockHalf.LOWER && p_196271_2_ == Direction.DOWN && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      }
   }

   public void func_176208_a(World p_176208_1_, BlockPos p_176208_2_, BlockState p_176208_3_, PlayerEntity p_176208_4_) {
      if (!p_176208_1_.field_72995_K && p_176208_4_.func_184812_l_()) {
         DoublePlantBlock.func_241471_b_(p_176208_1_, p_176208_2_, p_176208_3_, p_176208_4_);
      }

      super.func_176208_a(p_176208_1_, p_176208_2_, p_176208_3_, p_176208_4_);
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      switch(p_196266_4_) {
      case LAND:
         return p_196266_1_.func_177229_b(field_176519_b);
      case WATER:
         return false;
      case AIR:
         return p_196266_1_.func_177229_b(field_176519_b);
      default:
         return false;
      }
   }

   private int func_185654_e() {
      return this.field_149764_J == Material.field_151573_f ? 1011 : 1012;
   }

   private int func_185655_g() {
      return this.field_149764_J == Material.field_151573_f ? 1005 : 1006;
   }

   @Nullable
   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      BlockPos blockpos = p_196258_1_.func_195995_a();
      if (blockpos.func_177956_o() < 255 && p_196258_1_.func_195991_k().func_180495_p(blockpos.func_177984_a()).func_196953_a(p_196258_1_)) {
         World world = p_196258_1_.func_195991_k();
         boolean flag = world.func_175640_z(blockpos) || world.func_175640_z(blockpos.func_177984_a());
         return this.func_176223_P().func_206870_a(field_176520_a, p_196258_1_.func_195992_f()).func_206870_a(field_176521_M, this.func_208073_b(p_196258_1_)).func_206870_a(field_176522_N, Boolean.valueOf(flag)).func_206870_a(field_176519_b, Boolean.valueOf(flag)).func_206870_a(field_176523_O, DoubleBlockHalf.LOWER);
      } else {
         return null;
      }
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, BlockState p_180633_3_, LivingEntity p_180633_4_, ItemStack p_180633_5_) {
      p_180633_1_.func_180501_a(p_180633_2_.func_177984_a(), p_180633_3_.func_206870_a(field_176523_O, DoubleBlockHalf.UPPER), 3);
   }

   private DoorHingeSide func_208073_b(BlockItemUseContext p_208073_1_) {
      IBlockReader iblockreader = p_208073_1_.func_195991_k();
      BlockPos blockpos = p_208073_1_.func_195995_a();
      Direction direction = p_208073_1_.func_195992_f();
      BlockPos blockpos1 = blockpos.func_177984_a();
      Direction direction1 = direction.func_176735_f();
      BlockPos blockpos2 = blockpos.func_177972_a(direction1);
      BlockState blockstate = iblockreader.func_180495_p(blockpos2);
      BlockPos blockpos3 = blockpos1.func_177972_a(direction1);
      BlockState blockstate1 = iblockreader.func_180495_p(blockpos3);
      Direction direction2 = direction.func_176746_e();
      BlockPos blockpos4 = blockpos.func_177972_a(direction2);
      BlockState blockstate2 = iblockreader.func_180495_p(blockpos4);
      BlockPos blockpos5 = blockpos1.func_177972_a(direction2);
      BlockState blockstate3 = iblockreader.func_180495_p(blockpos5);
      int i = (blockstate.func_235785_r_(iblockreader, blockpos2) ? -1 : 0) + (blockstate1.func_235785_r_(iblockreader, blockpos3) ? -1 : 0) + (blockstate2.func_235785_r_(iblockreader, blockpos4) ? 1 : 0) + (blockstate3.func_235785_r_(iblockreader, blockpos5) ? 1 : 0);
      boolean flag = blockstate.func_203425_a(this) && blockstate.func_177229_b(field_176523_O) == DoubleBlockHalf.LOWER;
      boolean flag1 = blockstate2.func_203425_a(this) && blockstate2.func_177229_b(field_176523_O) == DoubleBlockHalf.LOWER;
      if ((!flag || flag1) && i <= 0) {
         if ((!flag1 || flag) && i >= 0) {
            int j = direction.func_82601_c();
            int k = direction.func_82599_e();
            Vector3d vector3d = p_208073_1_.func_221532_j();
            double d0 = vector3d.field_72450_a - (double)blockpos.func_177958_n();
            double d1 = vector3d.field_72449_c - (double)blockpos.func_177952_p();
            return (j >= 0 || !(d1 < 0.5D)) && (j <= 0 || !(d1 > 0.5D)) && (k >= 0 || !(d0 > 0.5D)) && (k <= 0 || !(d0 < 0.5D)) ? DoorHingeSide.LEFT : DoorHingeSide.RIGHT;
         } else {
            return DoorHingeSide.LEFT;
         }
      } else {
         return DoorHingeSide.RIGHT;
      }
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      if (this.field_149764_J == Material.field_151573_f) {
         return ActionResultType.PASS;
      } else {
         p_225533_1_ = p_225533_1_.func_235896_a_(field_176519_b);
         p_225533_2_.func_180501_a(p_225533_3_, p_225533_1_, 10);
         p_225533_2_.func_217378_a(p_225533_4_, p_225533_1_.func_177229_b(field_176519_b) ? this.func_185655_g() : this.func_185654_e(), p_225533_3_, 0);
         return ActionResultType.func_233537_a_(p_225533_2_.field_72995_K);
      }
   }

   public boolean func_242664_h(BlockState p_242664_1_) {
      return p_242664_1_.func_177229_b(field_176519_b);
   }

   public void func_242663_a(World p_242663_1_, BlockState p_242663_2_, BlockPos p_242663_3_, boolean p_242663_4_) {
      if (p_242663_2_.func_203425_a(this) && p_242663_2_.func_177229_b(field_176519_b) != p_242663_4_) {
         p_242663_1_.func_180501_a(p_242663_3_, p_242663_2_.func_206870_a(field_176519_b, Boolean.valueOf(p_242663_4_)), 10);
         this.func_196426_b(p_242663_1_, p_242663_3_, p_242663_4_);
      }
   }

   public void func_220069_a(BlockState p_220069_1_, World p_220069_2_, BlockPos p_220069_3_, Block p_220069_4_, BlockPos p_220069_5_, boolean p_220069_6_) {
      boolean flag = p_220069_2_.func_175640_z(p_220069_3_) || p_220069_2_.func_175640_z(p_220069_3_.func_177972_a(p_220069_1_.func_177229_b(field_176523_O) == DoubleBlockHalf.LOWER ? Direction.UP : Direction.DOWN));
      if (p_220069_4_ != this && flag != p_220069_1_.func_177229_b(field_176522_N)) {
         if (flag != p_220069_1_.func_177229_b(field_176519_b)) {
            this.func_196426_b(p_220069_2_, p_220069_3_, flag);
         }

         p_220069_2_.func_180501_a(p_220069_3_, p_220069_1_.func_206870_a(field_176522_N, Boolean.valueOf(flag)).func_206870_a(field_176519_b, Boolean.valueOf(flag)), 2);
      }

   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      BlockPos blockpos = p_196260_3_.func_177977_b();
      BlockState blockstate = p_196260_2_.func_180495_p(blockpos);
      return p_196260_1_.func_177229_b(field_176523_O) == DoubleBlockHalf.LOWER ? blockstate.func_224755_d(p_196260_2_, blockpos, Direction.UP) : blockstate.func_203425_a(this);
   }

   private void func_196426_b(World p_196426_1_, BlockPos p_196426_2_, boolean p_196426_3_) {
      p_196426_1_.func_217378_a((PlayerEntity)null, p_196426_3_ ? this.func_185655_g() : this.func_185654_e(), p_196426_2_, 0);
   }

   public PushReaction func_149656_h(BlockState p_149656_1_) {
      return PushReaction.DESTROY;
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_176520_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_176520_a)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_2_ == Mirror.NONE ? p_185471_1_ : p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_176520_a))).func_235896_a_(field_176521_M);
   }

   @OnlyIn(Dist.CLIENT)
   public long func_209900_a(BlockState p_209900_1_, BlockPos p_209900_2_) {
      return MathHelper.func_180187_c(p_209900_2_.func_177958_n(), p_209900_2_.func_177979_c(p_209900_1_.func_177229_b(field_176523_O) == DoubleBlockHalf.LOWER ? 0 : 1).func_177956_o(), p_209900_2_.func_177952_p());
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176523_O, field_176520_a, field_176519_b, field_176521_M, field_176522_N);
   }

   public static boolean func_235491_a_(World p_235491_0_, BlockPos p_235491_1_) {
      return func_235492_h_(p_235491_0_.func_180495_p(p_235491_1_));
   }

   public static boolean func_235492_h_(BlockState p_235492_0_) {
      return p_235492_0_.func_177230_c() instanceof DoorBlock && (p_235492_0_.func_185904_a() == Material.field_151575_d || p_235492_0_.func_185904_a() == Material.field_237214_y_);
   }
}
