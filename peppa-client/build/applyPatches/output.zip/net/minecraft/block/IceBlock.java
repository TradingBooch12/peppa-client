package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.material.PushReaction;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.LightType;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class IceBlock extends BreakableBlock {
   public IceBlock(AbstractBlock.Properties p_i48375_1_) {
      super(p_i48375_1_);
   }

   public void func_180657_a(World p_180657_1_, PlayerEntity p_180657_2_, BlockPos p_180657_3_, BlockState p_180657_4_, @Nullable TileEntity p_180657_5_, ItemStack p_180657_6_) {
      super.func_180657_a(p_180657_1_, p_180657_2_, p_180657_3_, p_180657_4_, p_180657_5_, p_180657_6_);
      if (EnchantmentHelper.func_77506_a(Enchantments.field_185306_r, p_180657_6_) == 0) {
         if (p_180657_1_.func_230315_m_().func_236040_e_()) {
            p_180657_1_.func_217377_a(p_180657_3_, false);
            return;
         }

         Material material = p_180657_1_.func_180495_p(p_180657_3_.func_177977_b()).func_185904_a();
         if (material.func_76230_c() || material.func_76224_d()) {
            p_180657_1_.func_175656_a(p_180657_3_, Blocks.field_150355_j.func_176223_P());
         }
      }

   }

   public void func_225542_b_(BlockState p_225542_1_, ServerWorld p_225542_2_, BlockPos p_225542_3_, Random p_225542_4_) {
      if (p_225542_2_.func_226658_a_(LightType.BLOCK, p_225542_3_) > 11 - p_225542_1_.func_200016_a(p_225542_2_, p_225542_3_)) {
         this.func_196454_d(p_225542_1_, p_225542_2_, p_225542_3_);
      }

   }

   protected void func_196454_d(BlockState p_196454_1_, World p_196454_2_, BlockPos p_196454_3_) {
      if (p_196454_2_.func_230315_m_().func_236040_e_()) {
         p_196454_2_.func_217377_a(p_196454_3_, false);
      } else {
         p_196454_2_.func_175656_a(p_196454_3_, Blocks.field_150355_j.func_176223_P());
         p_196454_2_.func_190524_a(p_196454_3_, Blocks.field_150355_j, p_196454_3_);
      }
   }

   public PushReaction func_149656_h(BlockState p_149656_1_) {
      return PushReaction.NORMAL;
   }
}
