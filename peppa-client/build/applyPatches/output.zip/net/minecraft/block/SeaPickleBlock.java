package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class SeaPickleBlock extends BushBlock implements IGrowable, IWaterLoggable {
   public static final IntegerProperty field_204902_a = BlockStateProperties.field_208135_aj;
   public static final BooleanProperty field_204903_b = BlockStateProperties.field_208198_y;
   protected static final VoxelShape field_204904_c = Block.func_208617_a(6.0D, 0.0D, 6.0D, 10.0D, 6.0D, 10.0D);
   protected static final VoxelShape field_204905_t = Block.func_208617_a(3.0D, 0.0D, 3.0D, 13.0D, 6.0D, 13.0D);
   protected static final VoxelShape field_204906_u = Block.func_208617_a(2.0D, 0.0D, 2.0D, 14.0D, 6.0D, 14.0D);
   protected static final VoxelShape field_204907_v = Block.func_208617_a(2.0D, 0.0D, 2.0D, 14.0D, 7.0D, 14.0D);

   protected SeaPickleBlock(AbstractBlock.Properties p_i48924_1_) {
      super(p_i48924_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_204902_a, Integer.valueOf(1)).func_206870_a(field_204903_b, Boolean.valueOf(true)));
   }

   @Nullable
   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      BlockState blockstate = p_196258_1_.func_195991_k().func_180495_p(p_196258_1_.func_195995_a());
      if (blockstate.func_203425_a(this)) {
         return blockstate.func_206870_a(field_204902_a, Integer.valueOf(Math.min(4, blockstate.func_177229_b(field_204902_a) + 1)));
      } else {
         FluidState fluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
         boolean flag = fluidstate.func_206886_c() == Fluids.field_204546_a;
         return super.func_196258_a(p_196258_1_).func_206870_a(field_204903_b, Boolean.valueOf(flag));
      }
   }

   public static boolean func_204901_j(BlockState p_204901_0_) {
      return !p_204901_0_.func_177229_b(field_204903_b);
   }

   protected boolean func_200014_a_(BlockState p_200014_1_, IBlockReader p_200014_2_, BlockPos p_200014_3_) {
      return !p_200014_1_.func_196952_d(p_200014_2_, p_200014_3_).func_212434_a(Direction.UP).func_197766_b() || p_200014_1_.func_224755_d(p_200014_2_, p_200014_3_, Direction.UP);
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      BlockPos blockpos = p_196260_3_.func_177977_b();
      return this.func_200014_a_(p_196260_2_.func_180495_p(blockpos), p_196260_2_, blockpos);
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (!p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_)) {
         return Blocks.field_150350_a.func_176223_P();
      } else {
         if (p_196271_1_.func_177229_b(field_204903_b)) {
            p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
         }

         return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      }
   }

   public boolean func_196253_a(BlockState p_196253_1_, BlockItemUseContext p_196253_2_) {
      return p_196253_2_.func_195996_i().func_77973_b() == this.func_199767_j() && p_196253_1_.func_177229_b(field_204902_a) < 4 ? true : super.func_196253_a(p_196253_1_, p_196253_2_);
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      switch(p_220053_1_.func_177229_b(field_204902_a)) {
      case 1:
      default:
         return field_204904_c;
      case 2:
         return field_204905_t;
      case 3:
         return field_204906_u;
      case 4:
         return field_204907_v;
      }
   }

   public FluidState func_204507_t(BlockState p_204507_1_) {
      return p_204507_1_.func_177229_b(field_204903_b) ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(p_204507_1_);
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_204902_a, field_204903_b);
   }

   public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, BlockState p_176473_3_, boolean p_176473_4_) {
      return true;
   }

   public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, BlockState p_180670_4_) {
      return true;
   }

   public void func_225535_a_(ServerWorld p_225535_1_, Random p_225535_2_, BlockPos p_225535_3_, BlockState p_225535_4_) {
      if (!func_204901_j(p_225535_4_) && p_225535_1_.func_180495_p(p_225535_3_.func_177977_b()).func_235714_a_(BlockTags.field_205598_B)) {
         int i = 5;
         int j = 1;
         int k = 2;
         int l = 0;
         int i1 = p_225535_3_.func_177958_n() - 2;
         int j1 = 0;

         for(int k1 = 0; k1 < 5; ++k1) {
            for(int l1 = 0; l1 < j; ++l1) {
               int i2 = 2 + p_225535_3_.func_177956_o() - 1;

               for(int j2 = i2 - 2; j2 < i2; ++j2) {
                  BlockPos blockpos = new BlockPos(i1 + k1, j2, p_225535_3_.func_177952_p() - j1 + l1);
                  if (blockpos != p_225535_3_ && p_225535_2_.nextInt(6) == 0 && p_225535_1_.func_180495_p(blockpos).func_203425_a(Blocks.field_150355_j)) {
                     BlockState blockstate = p_225535_1_.func_180495_p(blockpos.func_177977_b());
                     if (blockstate.func_235714_a_(BlockTags.field_205598_B)) {
                        p_225535_1_.func_180501_a(blockpos, Blocks.field_204913_jW.func_176223_P().func_206870_a(field_204902_a, Integer.valueOf(p_225535_2_.nextInt(4) + 1)), 3);
                     }
                  }
               }
            }

            if (l < 2) {
               j += 2;
               ++j1;
            } else {
               j -= 2;
               --j1;
            }

            ++l;
         }

         p_225535_1_.func_180501_a(p_225535_3_, p_225535_4_.func_206870_a(field_204902_a, Integer.valueOf(4)), 2);
      }

   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
