package net.minecraft.block;

import java.util.Random;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.StateContainer;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.server.ServerWorld;

public class ChorusPlantBlock extends SixWayBlock {
   protected ChorusPlantBlock(AbstractBlock.Properties p_i48428_1_) {
      super(0.3125F, p_i48428_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196488_a, Boolean.valueOf(false)).func_206870_a(field_196490_b, Boolean.valueOf(false)).func_206870_a(field_196492_c, Boolean.valueOf(false)).func_206870_a(field_196495_y, Boolean.valueOf(false)).func_206870_a(field_196496_z, Boolean.valueOf(false)).func_206870_a(field_196489_A, Boolean.valueOf(false)));
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_196497_a(p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a());
   }

   public BlockState func_196497_a(IBlockReader p_196497_1_, BlockPos p_196497_2_) {
      Block block = p_196497_1_.func_180495_p(p_196497_2_.func_177977_b()).func_177230_c();
      Block block1 = p_196497_1_.func_180495_p(p_196497_2_.func_177984_a()).func_177230_c();
      Block block2 = p_196497_1_.func_180495_p(p_196497_2_.func_177978_c()).func_177230_c();
      Block block3 = p_196497_1_.func_180495_p(p_196497_2_.func_177974_f()).func_177230_c();
      Block block4 = p_196497_1_.func_180495_p(p_196497_2_.func_177968_d()).func_177230_c();
      Block block5 = p_196497_1_.func_180495_p(p_196497_2_.func_177976_e()).func_177230_c();
      return this.func_176223_P().func_206870_a(field_196489_A, Boolean.valueOf(block == this || block == Blocks.field_185766_cS || block == Blocks.field_150377_bs)).func_206870_a(field_196496_z, Boolean.valueOf(block1 == this || block1 == Blocks.field_185766_cS)).func_206870_a(field_196488_a, Boolean.valueOf(block2 == this || block2 == Blocks.field_185766_cS)).func_206870_a(field_196490_b, Boolean.valueOf(block3 == this || block3 == Blocks.field_185766_cS)).func_206870_a(field_196492_c, Boolean.valueOf(block4 == this || block4 == Blocks.field_185766_cS)).func_206870_a(field_196495_y, Boolean.valueOf(block5 == this || block5 == Blocks.field_185766_cS));
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (!p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_)) {
         p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, 1);
         return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      } else {
         boolean flag = p_196271_3_.func_177230_c() == this || p_196271_3_.func_203425_a(Blocks.field_185766_cS) || p_196271_2_ == Direction.DOWN && p_196271_3_.func_203425_a(Blocks.field_150377_bs);
         return p_196271_1_.func_206870_a(field_196491_B.get(p_196271_2_), Boolean.valueOf(flag));
      }
   }

   public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
      if (!p_225534_1_.func_196955_c(p_225534_2_, p_225534_3_)) {
         p_225534_2_.func_175655_b(p_225534_3_, true);
      }

   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      BlockState blockstate = p_196260_2_.func_180495_p(p_196260_3_.func_177977_b());
      boolean flag = !p_196260_2_.func_180495_p(p_196260_3_.func_177984_a()).func_196958_f() && !blockstate.func_196958_f();

      for(Direction direction : Direction.Plane.HORIZONTAL) {
         BlockPos blockpos = p_196260_3_.func_177972_a(direction);
         Block block = p_196260_2_.func_180495_p(blockpos).func_177230_c();
         if (block == this) {
            if (flag) {
               return false;
            }

            Block block1 = p_196260_2_.func_180495_p(blockpos.func_177977_b()).func_177230_c();
            if (block1 == this || block1 == Blocks.field_150377_bs) {
               return true;
            }
         }
      }

      Block block2 = blockstate.func_177230_c();
      return block2 == this || block2 == Blocks.field_150377_bs;
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196488_a, field_196490_b, field_196492_c, field_196495_y, field_196496_z, field_196489_A);
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
