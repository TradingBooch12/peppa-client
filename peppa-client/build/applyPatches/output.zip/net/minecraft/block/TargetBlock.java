package net.minecraft.block;

import java.util.Random;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.projectile.AbstractArrowEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.stats.Stats;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class TargetBlock extends Block {
   private static final IntegerProperty field_235603_a_ = BlockStateProperties.field_208136_ak;

   public TargetBlock(AbstractBlock.Properties p_i241188_1_) {
      super(p_i241188_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_235603_a_, Integer.valueOf(0)));
   }

   public void func_220066_a(World p_220066_1_, BlockState p_220066_2_, BlockRayTraceResult p_220066_3_, ProjectileEntity p_220066_4_) {
      int i = func_235605_a_(p_220066_1_, p_220066_2_, p_220066_3_, p_220066_4_);
      Entity entity = p_220066_4_.func_234616_v_();
      if (entity instanceof ServerPlayerEntity) {
         ServerPlayerEntity serverplayerentity = (ServerPlayerEntity)entity;
         serverplayerentity.func_195066_a(Stats.field_232863_aD_);
         CriteriaTriggers.field_232606_L_.func_236350_a_(serverplayerentity, p_220066_4_, p_220066_3_.func_216347_e(), i);
      }

   }

   private static int func_235605_a_(IWorld p_235605_0_, BlockState p_235605_1_, BlockRayTraceResult p_235605_2_, Entity p_235605_3_) {
      int i = func_235606_a_(p_235605_2_, p_235605_2_.func_216347_e());
      int j = p_235605_3_ instanceof AbstractArrowEntity ? 20 : 8;
      if (!p_235605_0_.func_205220_G_().func_205359_a(p_235605_2_.func_216350_a(), p_235605_1_.func_177230_c())) {
         func_235604_a_(p_235605_0_, p_235605_1_, i, p_235605_2_.func_216350_a(), j);
      }

      return i;
   }

   private static int func_235606_a_(BlockRayTraceResult p_235606_0_, Vector3d p_235606_1_) {
      Direction direction = p_235606_0_.func_216354_b();
      double d0 = Math.abs(MathHelper.func_181162_h(p_235606_1_.field_72450_a) - 0.5D);
      double d1 = Math.abs(MathHelper.func_181162_h(p_235606_1_.field_72448_b) - 0.5D);
      double d2 = Math.abs(MathHelper.func_181162_h(p_235606_1_.field_72449_c) - 0.5D);
      Direction.Axis direction$axis = direction.func_176740_k();
      double d3;
      if (direction$axis == Direction.Axis.Y) {
         d3 = Math.max(d0, d2);
      } else if (direction$axis == Direction.Axis.Z) {
         d3 = Math.max(d0, d1);
      } else {
         d3 = Math.max(d1, d2);
      }

      return Math.max(1, MathHelper.func_76143_f(15.0D * MathHelper.func_151237_a((0.5D - d3) / 0.5D, 0.0D, 1.0D)));
   }

   private static void func_235604_a_(IWorld p_235604_0_, BlockState p_235604_1_, int p_235604_2_, BlockPos p_235604_3_, int p_235604_4_) {
      p_235604_0_.func_180501_a(p_235604_3_, p_235604_1_.func_206870_a(field_235603_a_, Integer.valueOf(p_235604_2_)), 3);
      p_235604_0_.func_205220_G_().func_205360_a(p_235604_3_, p_235604_1_.func_177230_c(), p_235604_4_);
   }

   public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
      if (p_225534_1_.func_177229_b(field_235603_a_) != 0) {
         p_225534_2_.func_180501_a(p_225534_3_, p_225534_1_.func_206870_a(field_235603_a_, Integer.valueOf(0)), 3);
      }

   }

   public int func_180656_a(BlockState p_180656_1_, IBlockReader p_180656_2_, BlockPos p_180656_3_, Direction p_180656_4_) {
      return p_180656_1_.func_177229_b(field_235603_a_);
   }

   public boolean func_149744_f(BlockState p_149744_1_) {
      return true;
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_235603_a_);
   }

   public void func_220082_b(BlockState p_220082_1_, World p_220082_2_, BlockPos p_220082_3_, BlockState p_220082_4_, boolean p_220082_5_) {
      if (!p_220082_2_.func_201670_d() && !p_220082_1_.func_203425_a(p_220082_4_.func_177230_c())) {
         if (p_220082_1_.func_177229_b(field_235603_a_) > 0 && !p_220082_2_.func_205220_G_().func_205359_a(p_220082_3_, this)) {
            p_220082_2_.func_180501_a(p_220082_3_, p_220082_1_.func_206870_a(field_235603_a_, Integer.valueOf(0)), 18);
         }

      }
   }
}
