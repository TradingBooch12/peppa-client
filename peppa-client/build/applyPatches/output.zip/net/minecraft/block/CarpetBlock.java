package net.minecraft.block;

import net.minecraft.item.DyeColor;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;

public class CarpetBlock extends Block {
   protected static final VoxelShape field_196548_a = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 1.0D, 16.0D);
   private final DyeColor field_196549_b;

   protected CarpetBlock(DyeColor p_i48290_1_, AbstractBlock.Properties p_i48290_2_) {
      super(p_i48290_2_);
      this.field_196549_b = p_i48290_1_;
   }

   public DyeColor func_196547_d() {
      return this.field_196549_b;
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196548_a;
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      return !p_196260_2_.func_175623_d(p_196260_3_.func_177977_b());
   }
}
