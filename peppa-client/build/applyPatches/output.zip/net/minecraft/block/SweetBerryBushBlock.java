package net.minecraft.block;

import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class SweetBerryBushBlock extends BushBlock implements IGrowable {
   public static final IntegerProperty field_220125_a = BlockStateProperties.field_208168_U;
   private static final VoxelShape field_220126_b = Block.func_208617_a(3.0D, 0.0D, 3.0D, 13.0D, 8.0D, 13.0D);
   private static final VoxelShape field_220127_c = Block.func_208617_a(1.0D, 0.0D, 1.0D, 15.0D, 16.0D, 15.0D);

   public SweetBerryBushBlock(AbstractBlock.Properties p_i49971_1_) {
      super(p_i49971_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_220125_a, Integer.valueOf(0)));
   }

   @OnlyIn(Dist.CLIENT)
   public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, BlockState p_185473_3_) {
      return new ItemStack(Items.field_222112_pR);
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      if (p_220053_1_.func_177229_b(field_220125_a) == 0) {
         return field_220126_b;
      } else {
         return p_220053_1_.func_177229_b(field_220125_a) < 3 ? field_220127_c : super.func_220053_a(p_220053_1_, p_220053_2_, p_220053_3_, p_220053_4_);
      }
   }

   public boolean func_149653_t(BlockState p_149653_1_) {
      return p_149653_1_.func_177229_b(field_220125_a) < 3;
   }

   public void func_225542_b_(BlockState p_225542_1_, ServerWorld p_225542_2_, BlockPos p_225542_3_, Random p_225542_4_) {
      int i = p_225542_1_.func_177229_b(field_220125_a);
      if (i < 3 && p_225542_4_.nextInt(5) == 0 && p_225542_2_.func_226659_b_(p_225542_3_.func_177984_a(), 0) >= 9) {
         p_225542_2_.func_180501_a(p_225542_3_, p_225542_1_.func_206870_a(field_220125_a, Integer.valueOf(i + 1)), 2);
      }

   }

   public void func_196262_a(BlockState p_196262_1_, World p_196262_2_, BlockPos p_196262_3_, Entity p_196262_4_) {
      if (p_196262_4_ instanceof LivingEntity && p_196262_4_.func_200600_R() != EntityType.field_220356_B && p_196262_4_.func_200600_R() != EntityType.field_226289_e_) {
         p_196262_4_.func_213295_a(p_196262_1_, new Vector3d((double)0.8F, 0.75D, (double)0.8F));
         if (!p_196262_2_.field_72995_K && p_196262_1_.func_177229_b(field_220125_a) > 0 && (p_196262_4_.field_70142_S != p_196262_4_.func_226277_ct_() || p_196262_4_.field_70136_U != p_196262_4_.func_226281_cx_())) {
            double d0 = Math.abs(p_196262_4_.func_226277_ct_() - p_196262_4_.field_70142_S);
            double d1 = Math.abs(p_196262_4_.func_226281_cx_() - p_196262_4_.field_70136_U);
            if (d0 >= (double)0.003F || d1 >= (double)0.003F) {
               p_196262_4_.func_70097_a(DamageSource.field_220302_v, 1.0F);
            }
         }

      }
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      int i = p_225533_1_.func_177229_b(field_220125_a);
      boolean flag = i == 3;
      if (!flag && p_225533_4_.func_184586_b(p_225533_5_).func_77973_b() == Items.field_196106_bc) {
         return ActionResultType.PASS;
      } else if (i > 1) {
         int j = 1 + p_225533_2_.field_73012_v.nextInt(2);
         func_180635_a(p_225533_2_, p_225533_3_, new ItemStack(Items.field_222112_pR, j + (flag ? 1 : 0)));
         p_225533_2_.func_184133_a((PlayerEntity)null, p_225533_3_, SoundEvents.field_219693_lB, SoundCategory.BLOCKS, 1.0F, 0.8F + p_225533_2_.field_73012_v.nextFloat() * 0.4F);
         p_225533_2_.func_180501_a(p_225533_3_, p_225533_1_.func_206870_a(field_220125_a, Integer.valueOf(1)), 2);
         return ActionResultType.func_233537_a_(p_225533_2_.field_72995_K);
      } else {
         return super.func_225533_a_(p_225533_1_, p_225533_2_, p_225533_3_, p_225533_4_, p_225533_5_, p_225533_6_);
      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_220125_a);
   }

   public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, BlockState p_176473_3_, boolean p_176473_4_) {
      return p_176473_3_.func_177229_b(field_220125_a) < 3;
   }

   public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, BlockState p_180670_4_) {
      return true;
   }

   public void func_225535_a_(ServerWorld p_225535_1_, Random p_225535_2_, BlockPos p_225535_3_, BlockState p_225535_4_) {
      int i = Math.min(3, p_225535_4_.func_177229_b(field_220125_a) + 1);
      p_225535_1_.func_180501_a(p_225535_3_, p_225535_4_.func_206870_a(field_220125_a, Integer.valueOf(i)), 2);
   }
}
