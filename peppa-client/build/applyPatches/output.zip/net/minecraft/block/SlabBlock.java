package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.SlabType;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;

public class SlabBlock extends Block implements IWaterLoggable {
   public static final EnumProperty<SlabType> field_196505_a = BlockStateProperties.field_208145_at;
   public static final BooleanProperty field_204512_b = BlockStateProperties.field_208198_y;
   protected static final VoxelShape field_196506_b = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D);
   protected static final VoxelShape field_196507_c = Block.func_208617_a(0.0D, 8.0D, 0.0D, 16.0D, 16.0D, 16.0D);

   public SlabBlock(AbstractBlock.Properties p_i48331_1_) {
      super(p_i48331_1_);
      this.func_180632_j(this.func_176223_P().func_206870_a(field_196505_a, SlabType.BOTTOM).func_206870_a(field_204512_b, Boolean.valueOf(false)));
   }

   public boolean func_220074_n(BlockState p_220074_1_) {
      return p_220074_1_.func_177229_b(field_196505_a) != SlabType.DOUBLE;
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196505_a, field_204512_b);
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      SlabType slabtype = p_220053_1_.func_177229_b(field_196505_a);
      switch(slabtype) {
      case DOUBLE:
         return VoxelShapes.func_197868_b();
      case TOP:
         return field_196507_c;
      default:
         return field_196506_b;
      }
   }

   @Nullable
   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      BlockPos blockpos = p_196258_1_.func_195995_a();
      BlockState blockstate = p_196258_1_.func_195991_k().func_180495_p(blockpos);
      if (blockstate.func_203425_a(this)) {
         return blockstate.func_206870_a(field_196505_a, SlabType.DOUBLE).func_206870_a(field_204512_b, Boolean.valueOf(false));
      } else {
         FluidState fluidstate = p_196258_1_.func_195991_k().func_204610_c(blockpos);
         BlockState blockstate1 = this.func_176223_P().func_206870_a(field_196505_a, SlabType.BOTTOM).func_206870_a(field_204512_b, Boolean.valueOf(fluidstate.func_206886_c() == Fluids.field_204546_a));
         Direction direction = p_196258_1_.func_196000_l();
         return direction != Direction.DOWN && (direction == Direction.UP || !(p_196258_1_.func_221532_j().field_72448_b - (double)blockpos.func_177956_o() > 0.5D)) ? blockstate1 : blockstate1.func_206870_a(field_196505_a, SlabType.TOP);
      }
   }

   public boolean func_196253_a(BlockState p_196253_1_, BlockItemUseContext p_196253_2_) {
      ItemStack itemstack = p_196253_2_.func_195996_i();
      SlabType slabtype = p_196253_1_.func_177229_b(field_196505_a);
      if (slabtype != SlabType.DOUBLE && itemstack.func_77973_b() == this.func_199767_j()) {
         if (p_196253_2_.func_196012_c()) {
            boolean flag = p_196253_2_.func_221532_j().field_72448_b - (double)p_196253_2_.func_195995_a().func_177956_o() > 0.5D;
            Direction direction = p_196253_2_.func_196000_l();
            if (slabtype == SlabType.BOTTOM) {
               return direction == Direction.UP || flag && direction.func_176740_k().func_176722_c();
            } else {
               return direction == Direction.DOWN || !flag && direction.func_176740_k().func_176722_c();
            }
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   public FluidState func_204507_t(BlockState p_204507_1_) {
      return p_204507_1_.func_177229_b(field_204512_b) ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(p_204507_1_);
   }

   public boolean func_204509_a(IWorld p_204509_1_, BlockPos p_204509_2_, BlockState p_204509_3_, FluidState p_204509_4_) {
      return p_204509_3_.func_177229_b(field_196505_a) != SlabType.DOUBLE ? IWaterLoggable.super.func_204509_a(p_204509_1_, p_204509_2_, p_204509_3_, p_204509_4_) : false;
   }

   public boolean func_204510_a(IBlockReader p_204510_1_, BlockPos p_204510_2_, BlockState p_204510_3_, Fluid p_204510_4_) {
      return p_204510_3_.func_177229_b(field_196505_a) != SlabType.DOUBLE ? IWaterLoggable.super.func_204510_a(p_204510_1_, p_204510_2_, p_204510_3_, p_204510_4_) : false;
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_1_.func_177229_b(field_204512_b)) {
         p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
      }

      return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      switch(p_196266_4_) {
      case LAND:
         return false;
      case WATER:
         return p_196266_2_.func_204610_c(p_196266_3_).func_206884_a(FluidTags.field_206959_a);
      case AIR:
         return false;
      default:
         return false;
      }
   }
}
