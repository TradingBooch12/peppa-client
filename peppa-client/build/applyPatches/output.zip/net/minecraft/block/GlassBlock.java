package net.minecraft.block;

public class GlassBlock extends AbstractGlassBlock {
   public GlassBlock(AbstractBlock.Properties p_i48392_1_) {
      super(p_i48392_1_);
   }
}
