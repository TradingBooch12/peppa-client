package net.minecraft.block;

import java.util.Random;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.particles.RedstoneParticleData;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class RepeaterBlock extends RedstoneDiodeBlock {
   public static final BooleanProperty field_176411_a = BlockStateProperties.field_208191_r;
   public static final IntegerProperty field_176410_b = BlockStateProperties.field_208126_aa;

   protected RepeaterBlock(AbstractBlock.Properties p_i48340_1_) {
      super(p_i48340_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_185512_D, Direction.NORTH).func_206870_a(field_176410_b, Integer.valueOf(1)).func_206870_a(field_176411_a, Boolean.valueOf(false)).func_206870_a(field_196348_c, Boolean.valueOf(false)));
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      if (!p_225533_4_.field_71075_bZ.field_75099_e) {
         return ActionResultType.PASS;
      } else {
         p_225533_2_.func_180501_a(p_225533_3_, p_225533_1_.func_235896_a_(field_176410_b), 3);
         return ActionResultType.func_233537_a_(p_225533_2_.field_72995_K);
      }
   }

   protected int func_196346_i(BlockState p_196346_1_) {
      return p_196346_1_.func_177229_b(field_176410_b) * 2;
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      BlockState blockstate = super.func_196258_a(p_196258_1_);
      return blockstate.func_206870_a(field_176411_a, Boolean.valueOf(this.func_176405_b(p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a(), blockstate)));
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return !p_196271_4_.func_201670_d() && p_196271_2_.func_176740_k() != p_196271_1_.func_177229_b(field_185512_D).func_176740_k() ? p_196271_1_.func_206870_a(field_176411_a, Boolean.valueOf(this.func_176405_b(p_196271_4_, p_196271_5_, p_196271_1_))) : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public boolean func_176405_b(IWorldReader p_176405_1_, BlockPos p_176405_2_, BlockState p_176405_3_) {
      return this.func_176407_c(p_176405_1_, p_176405_2_, p_176405_3_) > 0;
   }

   protected boolean func_185545_A(BlockState p_185545_1_) {
      return func_185546_B(p_185545_1_);
   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(BlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      if (p_180655_1_.func_177229_b(field_196348_c)) {
         Direction direction = p_180655_1_.func_177229_b(field_185512_D);
         double d0 = (double)p_180655_3_.func_177958_n() + 0.5D + (p_180655_4_.nextDouble() - 0.5D) * 0.2D;
         double d1 = (double)p_180655_3_.func_177956_o() + 0.4D + (p_180655_4_.nextDouble() - 0.5D) * 0.2D;
         double d2 = (double)p_180655_3_.func_177952_p() + 0.5D + (p_180655_4_.nextDouble() - 0.5D) * 0.2D;
         float f = -5.0F;
         if (p_180655_4_.nextBoolean()) {
            f = (float)(p_180655_1_.func_177229_b(field_176410_b) * 2 - 1);
         }

         f = f / 16.0F;
         double d3 = (double)(f * (float)direction.func_82601_c());
         double d4 = (double)(f * (float)direction.func_82599_e());
         p_180655_2_.func_195594_a(RedstoneParticleData.field_197564_a, d0 + d3, d1, d2 + d4, 0.0D, 0.0D, 0.0D);
      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_185512_D, field_176410_b, field_176411_a, field_196348_c);
   }
}
