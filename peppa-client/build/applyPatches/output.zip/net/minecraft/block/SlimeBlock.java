package net.minecraft.block;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

public class SlimeBlock extends BreakableBlock {
   public SlimeBlock(AbstractBlock.Properties p_i48330_1_) {
      super(p_i48330_1_);
   }

   public void func_180658_a(World p_180658_1_, BlockPos p_180658_2_, Entity p_180658_3_, float p_180658_4_) {
      if (p_180658_3_.func_226272_bl_()) {
         super.func_180658_a(p_180658_1_, p_180658_2_, p_180658_3_, p_180658_4_);
      } else {
         p_180658_3_.func_225503_b_(p_180658_4_, 0.0F);
      }

   }

   public void func_176216_a(IBlockReader p_176216_1_, Entity p_176216_2_) {
      if (p_176216_2_.func_226272_bl_()) {
         super.func_176216_a(p_176216_1_, p_176216_2_);
      } else {
         this.func_226946_a_(p_176216_2_);
      }

   }

   private void func_226946_a_(Entity p_226946_1_) {
      Vector3d vector3d = p_226946_1_.func_213322_ci();
      if (vector3d.field_72448_b < 0.0D) {
         double d0 = p_226946_1_ instanceof LivingEntity ? 1.0D : 0.8D;
         p_226946_1_.func_213293_j(vector3d.field_72450_a, -vector3d.field_72448_b * d0, vector3d.field_72449_c);
      }

   }

   public void func_176199_a(World p_176199_1_, BlockPos p_176199_2_, Entity p_176199_3_) {
      double d0 = Math.abs(p_176199_3_.func_213322_ci().field_72448_b);
      if (d0 < 0.1D && !p_176199_3_.func_226271_bk_()) {
         double d1 = 0.4D + d0 * 0.2D;
         p_176199_3_.func_213317_d(p_176199_3_.func_213322_ci().func_216372_d(d1, 1.0D, d1));
      }

      super.func_176199_a(p_176199_1_, p_176199_2_, p_176199_3_);
   }
}
