package net.minecraft.block;

import java.util.Optional;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.CampfireCookingRecipe;
import net.minecraft.particles.BasicParticleType;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.stats.Stats;
import net.minecraft.tags.BlockTags;
import net.minecraft.tileentity.CampfireTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.shapes.IBooleanFunction;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.GameRules;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class CampfireBlock extends ContainerBlock implements IWaterLoggable {
   protected static final VoxelShape field_220100_a = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 7.0D, 16.0D);
   public static final BooleanProperty field_220101_b = BlockStateProperties.field_208190_q;
   public static final BooleanProperty field_220102_c = BlockStateProperties.field_222516_y;
   public static final BooleanProperty field_220103_d = BlockStateProperties.field_208198_y;
   public static final DirectionProperty field_220104_e = BlockStateProperties.field_208157_J;
   private static final VoxelShape field_226912_f_ = Block.func_208617_a(6.0D, 0.0D, 6.0D, 10.0D, 16.0D, 10.0D);
   private final boolean field_235472_g_;
   private final int field_235473_h_;

   public CampfireBlock(boolean p_i241174_1_, int p_i241174_2_, AbstractBlock.Properties p_i241174_3_) {
      super(p_i241174_3_);
      this.field_235472_g_ = p_i241174_1_;
      this.field_235473_h_ = p_i241174_2_;
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_220101_b, Boolean.valueOf(true)).func_206870_a(field_220102_c, Boolean.valueOf(false)).func_206870_a(field_220103_d, Boolean.valueOf(false)).func_206870_a(field_220104_e, Direction.NORTH));
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      TileEntity tileentity = p_225533_2_.func_175625_s(p_225533_3_);
      if (tileentity instanceof CampfireTileEntity) {
         CampfireTileEntity campfiretileentity = (CampfireTileEntity)tileentity;
         ItemStack itemstack = p_225533_4_.func_184586_b(p_225533_5_);
         Optional<CampfireCookingRecipe> optional = campfiretileentity.func_213980_a(itemstack);
         if (optional.isPresent()) {
            if (!p_225533_2_.field_72995_K && campfiretileentity.func_213984_a(p_225533_4_.field_71075_bZ.field_75098_d ? itemstack.func_77946_l() : itemstack, optional.get().func_222137_e())) {
               p_225533_4_.func_195066_a(Stats.field_219736_at);
               return ActionResultType.SUCCESS;
            }

            return ActionResultType.CONSUME;
         }
      }

      return ActionResultType.PASS;
   }

   public void func_196262_a(BlockState p_196262_1_, World p_196262_2_, BlockPos p_196262_3_, Entity p_196262_4_) {
      if (!p_196262_4_.func_230279_az_() && p_196262_1_.func_177229_b(field_220101_b) && p_196262_4_ instanceof LivingEntity && !EnchantmentHelper.func_189869_j((LivingEntity)p_196262_4_)) {
         p_196262_4_.func_70097_a(DamageSource.field_76372_a, (float)this.field_235473_h_);
      }

      super.func_196262_a(p_196262_1_, p_196262_2_, p_196262_3_, p_196262_4_);
   }

   public void func_196243_a(BlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, BlockState p_196243_4_, boolean p_196243_5_) {
      if (!p_196243_1_.func_203425_a(p_196243_4_.func_177230_c())) {
         TileEntity tileentity = p_196243_2_.func_175625_s(p_196243_3_);
         if (tileentity instanceof CampfireTileEntity) {
            InventoryHelper.func_219961_a(p_196243_2_, p_196243_3_, ((CampfireTileEntity)tileentity).func_213985_c());
         }

         super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
      }
   }

   @Nullable
   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      IWorld iworld = p_196258_1_.func_195991_k();
      BlockPos blockpos = p_196258_1_.func_195995_a();
      boolean flag = iworld.func_204610_c(blockpos).func_206886_c() == Fluids.field_204546_a;
      return this.func_176223_P().func_206870_a(field_220103_d, Boolean.valueOf(flag)).func_206870_a(field_220102_c, Boolean.valueOf(this.func_220099_j(iworld.func_180495_p(blockpos.func_177977_b())))).func_206870_a(field_220101_b, Boolean.valueOf(!flag)).func_206870_a(field_220104_e, p_196258_1_.func_195992_f());
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_1_.func_177229_b(field_220103_d)) {
         p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
      }

      return p_196271_2_ == Direction.DOWN ? p_196271_1_.func_206870_a(field_220102_c, Boolean.valueOf(this.func_220099_j(p_196271_3_))) : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   private boolean func_220099_j(BlockState p_220099_1_) {
      return p_220099_1_.func_203425_a(Blocks.field_150407_cf);
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_220100_a;
   }

   public BlockRenderType func_149645_b(BlockState p_149645_1_) {
      return BlockRenderType.MODEL;
   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(BlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      if (p_180655_1_.func_177229_b(field_220101_b)) {
         if (p_180655_4_.nextInt(10) == 0) {
            p_180655_2_.func_184134_a((double)p_180655_3_.func_177958_n() + 0.5D, (double)p_180655_3_.func_177956_o() + 0.5D, (double)p_180655_3_.func_177952_p() + 0.5D, SoundEvents.field_219605_aC, SoundCategory.BLOCKS, 0.5F + p_180655_4_.nextFloat(), p_180655_4_.nextFloat() * 0.7F + 0.6F, false);
         }

         if (this.field_235472_g_ && p_180655_4_.nextInt(5) == 0) {
            for(int i = 0; i < p_180655_4_.nextInt(1) + 1; ++i) {
               p_180655_2_.func_195594_a(ParticleTypes.field_197595_F, (double)p_180655_3_.func_177958_n() + 0.5D, (double)p_180655_3_.func_177956_o() + 0.5D, (double)p_180655_3_.func_177952_p() + 0.5D, (double)(p_180655_4_.nextFloat() / 2.0F), 5.0E-5D, (double)(p_180655_4_.nextFloat() / 2.0F));
            }
         }

      }
   }

   public static void func_235475_c_(IWorld p_235475_0_, BlockPos p_235475_1_, BlockState p_235475_2_) {
      if (p_235475_0_.func_201670_d()) {
         for(int i = 0; i < 20; ++i) {
            func_220098_a((World)p_235475_0_, p_235475_1_, p_235475_2_.func_177229_b(field_220102_c), true);
         }
      }

      TileEntity tileentity = p_235475_0_.func_175625_s(p_235475_1_);
      if (tileentity instanceof CampfireTileEntity) {
         ((CampfireTileEntity)tileentity).func_213986_d();
      }

   }

   public boolean func_204509_a(IWorld p_204509_1_, BlockPos p_204509_2_, BlockState p_204509_3_, FluidState p_204509_4_) {
      if (!p_204509_3_.func_177229_b(BlockStateProperties.field_208198_y) && p_204509_4_.func_206886_c() == Fluids.field_204546_a) {
         boolean flag = p_204509_3_.func_177229_b(field_220101_b);
         if (flag) {
            if (!p_204509_1_.func_201670_d()) {
               p_204509_1_.func_184133_a((PlayerEntity)null, p_204509_2_, SoundEvents.field_187541_bC, SoundCategory.BLOCKS, 1.0F, 1.0F);
            }

            func_235475_c_(p_204509_1_, p_204509_2_, p_204509_3_);
         }

         p_204509_1_.func_180501_a(p_204509_2_, p_204509_3_.func_206870_a(field_220103_d, Boolean.valueOf(true)).func_206870_a(field_220101_b, Boolean.valueOf(false)), 3);
         p_204509_1_.func_205219_F_().func_205360_a(p_204509_2_, p_204509_4_.func_206886_c(), p_204509_4_.func_206886_c().func_205569_a(p_204509_1_));
         return true;
      } else {
         return false;
      }
   }

   public void func_220066_a(World p_220066_1_, BlockState p_220066_2_, BlockRayTraceResult p_220066_3_, ProjectileEntity p_220066_4_) {
      if (!p_220066_1_.field_72995_K && p_220066_4_.func_70027_ad()) {
         Entity entity = p_220066_4_.func_234616_v_();
         boolean flag = entity == null || entity instanceof PlayerEntity || p_220066_1_.func_82736_K().func_223586_b(GameRules.field_223599_b);
         if (flag && !p_220066_2_.func_177229_b(field_220101_b) && !p_220066_2_.func_177229_b(field_220103_d)) {
            BlockPos blockpos = p_220066_3_.func_216350_a();
            p_220066_1_.func_180501_a(blockpos, p_220066_2_.func_206870_a(BlockStateProperties.field_208190_q, Boolean.valueOf(true)), 11);
         }
      }

   }

   public static void func_220098_a(World p_220098_0_, BlockPos p_220098_1_, boolean p_220098_2_, boolean p_220098_3_) {
      Random random = p_220098_0_.func_201674_k();
      BasicParticleType basicparticletype = p_220098_2_ ? ParticleTypes.field_218418_af : ParticleTypes.field_218417_ae;
      p_220098_0_.func_217404_b(basicparticletype, true, (double)p_220098_1_.func_177958_n() + 0.5D + random.nextDouble() / 3.0D * (double)(random.nextBoolean() ? 1 : -1), (double)p_220098_1_.func_177956_o() + random.nextDouble() + random.nextDouble(), (double)p_220098_1_.func_177952_p() + 0.5D + random.nextDouble() / 3.0D * (double)(random.nextBoolean() ? 1 : -1), 0.0D, 0.07D, 0.0D);
      if (p_220098_3_) {
         p_220098_0_.func_195594_a(ParticleTypes.field_197601_L, (double)p_220098_1_.func_177958_n() + 0.25D + random.nextDouble() / 2.0D * (double)(random.nextBoolean() ? 1 : -1), (double)p_220098_1_.func_177956_o() + 0.4D, (double)p_220098_1_.func_177952_p() + 0.25D + random.nextDouble() / 2.0D * (double)(random.nextBoolean() ? 1 : -1), 0.0D, 0.005D, 0.0D);
      }

   }

   public static boolean func_235474_a_(World p_235474_0_, BlockPos p_235474_1_) {
      for(int i = 1; i <= 5; ++i) {
         BlockPos blockpos = p_235474_1_.func_177979_c(i);
         BlockState blockstate = p_235474_0_.func_180495_p(blockpos);
         if (func_226915_i_(blockstate)) {
            return true;
         }

         boolean flag = VoxelShapes.func_197879_c(field_226912_f_, blockstate.func_215685_b(p_235474_0_, p_235474_1_, ISelectionContext.func_216377_a()), IBooleanFunction.field_223238_i_);
         if (flag) {
            BlockState blockstate1 = p_235474_0_.func_180495_p(blockpos.func_177977_b());
            return func_226915_i_(blockstate1);
         }
      }

      return false;
   }

   public static boolean func_226915_i_(BlockState p_226915_0_) {
      return p_226915_0_.func_235901_b_(field_220101_b) && p_226915_0_.func_235714_a_(BlockTags.field_232882_ax_) && p_226915_0_.func_177229_b(field_220101_b);
   }

   public FluidState func_204507_t(BlockState p_204507_1_) {
      return p_204507_1_.func_177229_b(field_220103_d) ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(p_204507_1_);
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_220104_e, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_220104_e)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_220104_e)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_220101_b, field_220102_c, field_220103_d, field_220104_e);
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new CampfireTileEntity();
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }

   public static boolean func_241470_h_(BlockState p_241470_0_) {
      return p_241470_0_.func_235715_a_(BlockTags.field_232882_ax_, (p_241469_0_) -> {
         return p_241469_0_.func_235901_b_(BlockStateProperties.field_208198_y) && p_241469_0_.func_235901_b_(BlockStateProperties.field_208190_q);
      }) && !p_241470_0_.func_177229_b(BlockStateProperties.field_208198_y) && !p_241470_0_.func_177229_b(BlockStateProperties.field_208190_q);
   }
}
