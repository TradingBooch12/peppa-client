package net.minecraft.block;

import net.minecraft.dispenser.DefaultDispenseItemBehavior;
import net.minecraft.dispenser.IDispenseItemBehavior;
import net.minecraft.dispenser.ProxyBlockSource;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.DispenserTileEntity;
import net.minecraft.tileentity.DropperTileEntity;
import net.minecraft.tileentity.HopperTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.server.ServerWorld;

public class DropperBlock extends DispenserBlock {
   private static final IDispenseItemBehavior field_149947_P = new DefaultDispenseItemBehavior();

   public DropperBlock(AbstractBlock.Properties p_i48410_1_) {
      super(p_i48410_1_);
   }

   protected IDispenseItemBehavior func_149940_a(ItemStack p_149940_1_) {
      return field_149947_P;
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new DropperTileEntity();
   }

   protected void func_176439_d(ServerWorld p_176439_1_, BlockPos p_176439_2_) {
      ProxyBlockSource proxyblocksource = new ProxyBlockSource(p_176439_1_, p_176439_2_);
      DispenserTileEntity dispensertileentity = proxyblocksource.func_150835_j();
      int i = dispensertileentity.func_146017_i();
      if (i < 0) {
         p_176439_1_.func_217379_c(1001, p_176439_2_, 0);
      } else {
         ItemStack itemstack = dispensertileentity.func_70301_a(i);
         if (!itemstack.func_190926_b()) {
            Direction direction = p_176439_1_.func_180495_p(p_176439_2_).func_177229_b(field_176441_a);
            IInventory iinventory = HopperTileEntity.func_195484_a(p_176439_1_, p_176439_2_.func_177972_a(direction));
            ItemStack itemstack1;
            if (iinventory == null) {
               itemstack1 = field_149947_P.dispense(proxyblocksource, itemstack);
            } else {
               itemstack1 = HopperTileEntity.func_174918_a(dispensertileentity, iinventory, itemstack.func_77946_l().func_77979_a(1), direction.func_176734_d());
               if (itemstack1.func_190926_b()) {
                  itemstack1 = itemstack.func_77946_l();
                  itemstack1.func_190918_g(1);
               } else {
                  itemstack1 = itemstack.func_77946_l();
               }
            }

            dispensertileentity.func_70299_a(i, itemstack1);
         }
      }
   }
}
