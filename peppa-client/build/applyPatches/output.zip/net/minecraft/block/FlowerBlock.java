package net.minecraft.block;

import net.minecraft.potion.Effect;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.IBlockReader;

public class FlowerBlock extends BushBlock {
   protected static final VoxelShape field_196398_a = Block.func_208617_a(5.0D, 0.0D, 5.0D, 11.0D, 10.0D, 11.0D);
   private final Effect field_220096_b;
   private final int field_220097_c;

   public FlowerBlock(Effect p_i49984_1_, int p_i49984_2_, AbstractBlock.Properties p_i49984_3_) {
      super(p_i49984_3_);
      this.field_220096_b = p_i49984_1_;
      if (p_i49984_1_.func_76403_b()) {
         this.field_220097_c = p_i49984_2_;
      } else {
         this.field_220097_c = p_i49984_2_ * 20;
      }

   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      Vector3d vector3d = p_220053_1_.func_191059_e(p_220053_2_, p_220053_3_);
      return field_196398_a.func_197751_a(vector3d.field_72450_a, vector3d.field_72448_b, vector3d.field_72449_c);
   }

   public AbstractBlock.OffsetType func_176218_Q() {
      return AbstractBlock.OffsetType.XZ;
   }

   public Effect func_220094_d() {
      return this.field_220096_b;
   }

   public int func_220095_e() {
      return this.field_220097_c;
   }
}
