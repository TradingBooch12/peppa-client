package net.minecraft.block;

import java.util.Random;
import net.minecraft.entity.monster.piglin.PiglinTasks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.inventory.EnderChestInventory;
import net.minecraft.inventory.container.ChestContainer;
import net.minecraft.inventory.container.SimpleNamedContainerProvider;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.stats.Stats;
import net.minecraft.tileentity.ChestTileEntity;
import net.minecraft.tileentity.EnderChestTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityMerger;
import net.minecraft.tileentity.TileEntityType;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class EnderChestBlock extends AbstractChestBlock<EnderChestTileEntity> implements IWaterLoggable {
   public static final DirectionProperty field_176437_a = HorizontalBlock.field_185512_D;
   public static final BooleanProperty field_204615_b = BlockStateProperties.field_208198_y;
   protected static final VoxelShape field_196324_b = Block.func_208617_a(1.0D, 0.0D, 1.0D, 15.0D, 14.0D, 15.0D);
   private static final ITextComponent field_220115_d = new TranslationTextComponent("container.enderchest");

   protected EnderChestBlock(AbstractBlock.Properties p_i48403_1_) {
      super(p_i48403_1_, () -> {
         return TileEntityType.field_200974_e;
      });
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176437_a, Direction.NORTH).func_206870_a(field_204615_b, Boolean.valueOf(false)));
   }

   @OnlyIn(Dist.CLIENT)
   public TileEntityMerger.ICallbackWrapper<? extends ChestTileEntity> func_225536_a_(BlockState p_225536_1_, World p_225536_2_, BlockPos p_225536_3_, boolean p_225536_4_) {
      return TileEntityMerger.ICallback::func_225537_b_;
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196324_b;
   }

   public BlockRenderType func_149645_b(BlockState p_149645_1_) {
      return BlockRenderType.ENTITYBLOCK_ANIMATED;
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      FluidState fluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
      return this.func_176223_P().func_206870_a(field_176437_a, p_196258_1_.func_195992_f().func_176734_d()).func_206870_a(field_204615_b, Boolean.valueOf(fluidstate.func_206886_c() == Fluids.field_204546_a));
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      EnderChestInventory enderchestinventory = p_225533_4_.func_71005_bN();
      TileEntity tileentity = p_225533_2_.func_175625_s(p_225533_3_);
      if (enderchestinventory != null && tileentity instanceof EnderChestTileEntity) {
         BlockPos blockpos = p_225533_3_.func_177984_a();
         if (p_225533_2_.func_180495_p(blockpos).func_215686_e(p_225533_2_, blockpos)) {
            return ActionResultType.func_233537_a_(p_225533_2_.field_72995_K);
         } else if (p_225533_2_.field_72995_K) {
            return ActionResultType.SUCCESS;
         } else {
            EnderChestTileEntity enderchesttileentity = (EnderChestTileEntity)tileentity;
            enderchestinventory.func_146031_a(enderchesttileentity);
            p_225533_4_.func_213829_a(new SimpleNamedContainerProvider((p_226928_1_, p_226928_2_, p_226928_3_) -> {
               return ChestContainer.func_216992_a(p_226928_1_, p_226928_2_, enderchestinventory);
            }, field_220115_d));
            p_225533_4_.func_195066_a(Stats.field_188090_X);
            PiglinTasks.func_234478_a_(p_225533_4_, true);
            return ActionResultType.CONSUME;
         }
      } else {
         return ActionResultType.func_233537_a_(p_225533_2_.field_72995_K);
      }
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new EnderChestTileEntity();
   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(BlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      for(int i = 0; i < 3; ++i) {
         int j = p_180655_4_.nextInt(2) * 2 - 1;
         int k = p_180655_4_.nextInt(2) * 2 - 1;
         double d0 = (double)p_180655_3_.func_177958_n() + 0.5D + 0.25D * (double)j;
         double d1 = (double)((float)p_180655_3_.func_177956_o() + p_180655_4_.nextFloat());
         double d2 = (double)p_180655_3_.func_177952_p() + 0.5D + 0.25D * (double)k;
         double d3 = (double)(p_180655_4_.nextFloat() * (float)j);
         double d4 = ((double)p_180655_4_.nextFloat() - 0.5D) * 0.125D;
         double d5 = (double)(p_180655_4_.nextFloat() * (float)k);
         p_180655_2_.func_195594_a(ParticleTypes.field_197599_J, d0, d1, d2, d3, d4, d5);
      }

   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_176437_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_176437_a)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_176437_a)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176437_a, field_204615_b);
   }

   public FluidState func_204507_t(BlockState p_204507_1_) {
      return p_204507_1_.func_177229_b(field_204615_b) ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(p_204507_1_);
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_1_.func_177229_b(field_204615_b)) {
         p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
      }

      return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
