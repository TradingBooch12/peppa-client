package net.minecraft.block;

import java.util.Collections;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.LootContext;
import net.minecraft.loot.LootParameters;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.PistonType;
import net.minecraft.tileentity.PistonTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class MovingPistonBlock extends ContainerBlock {
   public static final DirectionProperty field_196344_a = PistonHeadBlock.field_176387_N;
   public static final EnumProperty<PistonType> field_196345_b = PistonHeadBlock.field_176325_b;

   public MovingPistonBlock(AbstractBlock.Properties p_i48282_1_) {
      super(p_i48282_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196344_a, Direction.NORTH).func_206870_a(field_196345_b, PistonType.DEFAULT));
   }

   @Nullable
   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return null;
   }

   public static TileEntity func_196343_a(BlockState p_196343_0_, Direction p_196343_1_, boolean p_196343_2_, boolean p_196343_3_) {
      return new PistonTileEntity(p_196343_0_, p_196343_1_, p_196343_2_, p_196343_3_);
   }

   public void func_196243_a(BlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, BlockState p_196243_4_, boolean p_196243_5_) {
      if (!p_196243_1_.func_203425_a(p_196243_4_.func_177230_c())) {
         TileEntity tileentity = p_196243_2_.func_175625_s(p_196243_3_);
         if (tileentity instanceof PistonTileEntity) {
            ((PistonTileEntity)tileentity).func_145866_f();
         }

      }
   }

   public void func_176206_d(IWorld p_176206_1_, BlockPos p_176206_2_, BlockState p_176206_3_) {
      BlockPos blockpos = p_176206_2_.func_177972_a(p_176206_3_.func_177229_b(field_196344_a).func_176734_d());
      BlockState blockstate = p_176206_1_.func_180495_p(blockpos);
      if (blockstate.func_177230_c() instanceof PistonBlock && blockstate.func_177229_b(PistonBlock.field_176320_b)) {
         p_176206_1_.func_217377_a(blockpos, false);
      }

   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      if (!p_225533_2_.field_72995_K && p_225533_2_.func_175625_s(p_225533_3_) == null) {
         p_225533_2_.func_217377_a(p_225533_3_, false);
         return ActionResultType.CONSUME;
      } else {
         return ActionResultType.PASS;
      }
   }

   public List<ItemStack> func_220076_a(BlockState p_220076_1_, LootContext.Builder p_220076_2_) {
      PistonTileEntity pistontileentity = this.func_220170_a(p_220076_2_.func_216018_a(), new BlockPos(p_220076_2_.func_216024_a(LootParameters.field_237457_g_)));
      return pistontileentity == null ? Collections.emptyList() : pistontileentity.func_200230_i().func_215693_a(p_220076_2_);
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return VoxelShapes.func_197880_a();
   }

   public VoxelShape func_220071_b(BlockState p_220071_1_, IBlockReader p_220071_2_, BlockPos p_220071_3_, ISelectionContext p_220071_4_) {
      PistonTileEntity pistontileentity = this.func_220170_a(p_220071_2_, p_220071_3_);
      return pistontileentity != null ? pistontileentity.func_195508_a(p_220071_2_, p_220071_3_) : VoxelShapes.func_197880_a();
   }

   @Nullable
   private PistonTileEntity func_220170_a(IBlockReader p_220170_1_, BlockPos p_220170_2_) {
      TileEntity tileentity = p_220170_1_.func_175625_s(p_220170_2_);
      return tileentity instanceof PistonTileEntity ? (PistonTileEntity)tileentity : null;
   }

   @OnlyIn(Dist.CLIENT)
   public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, BlockState p_185473_3_) {
      return ItemStack.field_190927_a;
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_196344_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_196344_a)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_196344_a)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196344_a, field_196345_b);
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
