package net.minecraft.block;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;
import java.util.Map;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.Property;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Direction;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.IBooleanFunction;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;

public class WallBlock extends Block implements IWaterLoggable {
   public static final BooleanProperty field_176256_a = BlockStateProperties.field_208149_B;
   public static final EnumProperty<WallHeight> field_235612_b_ = BlockStateProperties.field_235908_S_;
   public static final EnumProperty<WallHeight> field_235613_c_ = BlockStateProperties.field_235909_T_;
   public static final EnumProperty<WallHeight> field_235614_d_ = BlockStateProperties.field_235910_U_;
   public static final EnumProperty<WallHeight> field_235615_e_ = BlockStateProperties.field_235911_V_;
   public static final BooleanProperty field_235616_f_ = BlockStateProperties.field_208198_y;
   private final Map<BlockState, VoxelShape> field_235617_g_;
   private final Map<BlockState, VoxelShape> field_235618_h_;
   private static final VoxelShape field_235619_i_ = Block.func_208617_a(7.0D, 0.0D, 7.0D, 9.0D, 16.0D, 9.0D);
   private static final VoxelShape field_235620_j_ = Block.func_208617_a(7.0D, 0.0D, 0.0D, 9.0D, 16.0D, 9.0D);
   private static final VoxelShape field_235621_k_ = Block.func_208617_a(7.0D, 0.0D, 7.0D, 9.0D, 16.0D, 16.0D);
   private static final VoxelShape field_235622_o_ = Block.func_208617_a(0.0D, 0.0D, 7.0D, 9.0D, 16.0D, 9.0D);
   private static final VoxelShape field_235623_p_ = Block.func_208617_a(7.0D, 0.0D, 7.0D, 16.0D, 16.0D, 9.0D);

   public WallBlock(AbstractBlock.Properties p_i48301_1_) {
      super(p_i48301_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176256_a, Boolean.valueOf(true)).func_206870_a(field_235613_c_, WallHeight.NONE).func_206870_a(field_235612_b_, WallHeight.NONE).func_206870_a(field_235614_d_, WallHeight.NONE).func_206870_a(field_235615_e_, WallHeight.NONE).func_206870_a(field_235616_f_, Boolean.valueOf(false)));
      this.field_235617_g_ = this.func_235624_a_(4.0F, 3.0F, 16.0F, 0.0F, 14.0F, 16.0F);
      this.field_235618_h_ = this.func_235624_a_(4.0F, 3.0F, 24.0F, 0.0F, 24.0F, 24.0F);
   }

   private static VoxelShape func_235631_a_(VoxelShape p_235631_0_, WallHeight p_235631_1_, VoxelShape p_235631_2_, VoxelShape p_235631_3_) {
      if (p_235631_1_ == WallHeight.TALL) {
         return VoxelShapes.func_197872_a(p_235631_0_, p_235631_3_);
      } else {
         return p_235631_1_ == WallHeight.LOW ? VoxelShapes.func_197872_a(p_235631_0_, p_235631_2_) : p_235631_0_;
      }
   }

   private Map<BlockState, VoxelShape> func_235624_a_(float p_235624_1_, float p_235624_2_, float p_235624_3_, float p_235624_4_, float p_235624_5_, float p_235624_6_) {
      float f = 8.0F - p_235624_1_;
      float f1 = 8.0F + p_235624_1_;
      float f2 = 8.0F - p_235624_2_;
      float f3 = 8.0F + p_235624_2_;
      VoxelShape voxelshape = Block.func_208617_a((double)f, 0.0D, (double)f, (double)f1, (double)p_235624_3_, (double)f1);
      VoxelShape voxelshape1 = Block.func_208617_a((double)f2, (double)p_235624_4_, 0.0D, (double)f3, (double)p_235624_5_, (double)f3);
      VoxelShape voxelshape2 = Block.func_208617_a((double)f2, (double)p_235624_4_, (double)f2, (double)f3, (double)p_235624_5_, 16.0D);
      VoxelShape voxelshape3 = Block.func_208617_a(0.0D, (double)p_235624_4_, (double)f2, (double)f3, (double)p_235624_5_, (double)f3);
      VoxelShape voxelshape4 = Block.func_208617_a((double)f2, (double)p_235624_4_, (double)f2, 16.0D, (double)p_235624_5_, (double)f3);
      VoxelShape voxelshape5 = Block.func_208617_a((double)f2, (double)p_235624_4_, 0.0D, (double)f3, (double)p_235624_6_, (double)f3);
      VoxelShape voxelshape6 = Block.func_208617_a((double)f2, (double)p_235624_4_, (double)f2, (double)f3, (double)p_235624_6_, 16.0D);
      VoxelShape voxelshape7 = Block.func_208617_a(0.0D, (double)p_235624_4_, (double)f2, (double)f3, (double)p_235624_6_, (double)f3);
      VoxelShape voxelshape8 = Block.func_208617_a((double)f2, (double)p_235624_4_, (double)f2, 16.0D, (double)p_235624_6_, (double)f3);
      Builder<BlockState, VoxelShape> builder = ImmutableMap.builder();

      for(Boolean obool : field_176256_a.func_177700_c()) {
         for(WallHeight wallheight : field_235612_b_.func_177700_c()) {
            for(WallHeight wallheight1 : field_235613_c_.func_177700_c()) {
               for(WallHeight wallheight2 : field_235615_e_.func_177700_c()) {
                  for(WallHeight wallheight3 : field_235614_d_.func_177700_c()) {
                     VoxelShape voxelshape9 = VoxelShapes.func_197880_a();
                     voxelshape9 = func_235631_a_(voxelshape9, wallheight, voxelshape4, voxelshape8);
                     voxelshape9 = func_235631_a_(voxelshape9, wallheight2, voxelshape3, voxelshape7);
                     voxelshape9 = func_235631_a_(voxelshape9, wallheight1, voxelshape1, voxelshape5);
                     voxelshape9 = func_235631_a_(voxelshape9, wallheight3, voxelshape2, voxelshape6);
                     if (obool) {
                        voxelshape9 = VoxelShapes.func_197872_a(voxelshape9, voxelshape);
                     }

                     BlockState blockstate = this.func_176223_P().func_206870_a(field_176256_a, obool).func_206870_a(field_235612_b_, wallheight).func_206870_a(field_235615_e_, wallheight2).func_206870_a(field_235613_c_, wallheight1).func_206870_a(field_235614_d_, wallheight3);
                     builder.put(blockstate.func_206870_a(field_235616_f_, Boolean.valueOf(false)), voxelshape9);
                     builder.put(blockstate.func_206870_a(field_235616_f_, Boolean.valueOf(true)), voxelshape9);
                  }
               }
            }
         }
      }

      return builder.build();
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return this.field_235617_g_.get(p_220053_1_);
   }

   public VoxelShape func_220071_b(BlockState p_220071_1_, IBlockReader p_220071_2_, BlockPos p_220071_3_, ISelectionContext p_220071_4_) {
      return this.field_235618_h_.get(p_220071_1_);
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }

   private boolean func_220113_a(BlockState p_220113_1_, boolean p_220113_2_, Direction p_220113_3_) {
      Block block = p_220113_1_.func_177230_c();
      boolean flag = block instanceof FenceGateBlock && FenceGateBlock.func_220253_a(p_220113_1_, p_220113_3_);
      return p_220113_1_.func_235714_a_(BlockTags.field_219757_z) || !func_220073_a(block) && p_220113_2_ || block instanceof PaneBlock || flag;
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      IWorldReader iworldreader = p_196258_1_.func_195991_k();
      BlockPos blockpos = p_196258_1_.func_195995_a();
      FluidState fluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
      BlockPos blockpos1 = blockpos.func_177978_c();
      BlockPos blockpos2 = blockpos.func_177974_f();
      BlockPos blockpos3 = blockpos.func_177968_d();
      BlockPos blockpos4 = blockpos.func_177976_e();
      BlockPos blockpos5 = blockpos.func_177984_a();
      BlockState blockstate = iworldreader.func_180495_p(blockpos1);
      BlockState blockstate1 = iworldreader.func_180495_p(blockpos2);
      BlockState blockstate2 = iworldreader.func_180495_p(blockpos3);
      BlockState blockstate3 = iworldreader.func_180495_p(blockpos4);
      BlockState blockstate4 = iworldreader.func_180495_p(blockpos5);
      boolean flag = this.func_220113_a(blockstate, blockstate.func_224755_d(iworldreader, blockpos1, Direction.SOUTH), Direction.SOUTH);
      boolean flag1 = this.func_220113_a(blockstate1, blockstate1.func_224755_d(iworldreader, blockpos2, Direction.WEST), Direction.WEST);
      boolean flag2 = this.func_220113_a(blockstate2, blockstate2.func_224755_d(iworldreader, blockpos3, Direction.NORTH), Direction.NORTH);
      boolean flag3 = this.func_220113_a(blockstate3, blockstate3.func_224755_d(iworldreader, blockpos4, Direction.EAST), Direction.EAST);
      BlockState blockstate5 = this.func_176223_P().func_206870_a(field_235616_f_, Boolean.valueOf(fluidstate.func_206886_c() == Fluids.field_204546_a));
      return this.func_235626_a_(iworldreader, blockstate5, blockpos5, blockstate4, flag, flag1, flag2, flag3);
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_1_.func_177229_b(field_235616_f_)) {
         p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
      }

      if (p_196271_2_ == Direction.DOWN) {
         return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      } else {
         return p_196271_2_ == Direction.UP ? this.func_235625_a_(p_196271_4_, p_196271_1_, p_196271_6_, p_196271_3_) : this.func_235627_a_(p_196271_4_, p_196271_5_, p_196271_1_, p_196271_6_, p_196271_3_, p_196271_2_);
      }
   }

   private static boolean func_235629_a_(BlockState p_235629_0_, Property<WallHeight> p_235629_1_) {
      return p_235629_0_.func_177229_b(p_235629_1_) != WallHeight.NONE;
   }

   private static boolean func_235632_a_(VoxelShape p_235632_0_, VoxelShape p_235632_1_) {
      return !VoxelShapes.func_197879_c(p_235632_1_, p_235632_0_, IBooleanFunction.field_223234_e_);
   }

   private BlockState func_235625_a_(IWorldReader p_235625_1_, BlockState p_235625_2_, BlockPos p_235625_3_, BlockState p_235625_4_) {
      boolean flag = func_235629_a_(p_235625_2_, field_235613_c_);
      boolean flag1 = func_235629_a_(p_235625_2_, field_235612_b_);
      boolean flag2 = func_235629_a_(p_235625_2_, field_235614_d_);
      boolean flag3 = func_235629_a_(p_235625_2_, field_235615_e_);
      return this.func_235626_a_(p_235625_1_, p_235625_2_, p_235625_3_, p_235625_4_, flag, flag1, flag2, flag3);
   }

   private BlockState func_235627_a_(IWorldReader p_235627_1_, BlockPos p_235627_2_, BlockState p_235627_3_, BlockPos p_235627_4_, BlockState p_235627_5_, Direction p_235627_6_) {
      Direction direction = p_235627_6_.func_176734_d();
      boolean flag = p_235627_6_ == Direction.NORTH ? this.func_220113_a(p_235627_5_, p_235627_5_.func_224755_d(p_235627_1_, p_235627_4_, direction), direction) : func_235629_a_(p_235627_3_, field_235613_c_);
      boolean flag1 = p_235627_6_ == Direction.EAST ? this.func_220113_a(p_235627_5_, p_235627_5_.func_224755_d(p_235627_1_, p_235627_4_, direction), direction) : func_235629_a_(p_235627_3_, field_235612_b_);
      boolean flag2 = p_235627_6_ == Direction.SOUTH ? this.func_220113_a(p_235627_5_, p_235627_5_.func_224755_d(p_235627_1_, p_235627_4_, direction), direction) : func_235629_a_(p_235627_3_, field_235614_d_);
      boolean flag3 = p_235627_6_ == Direction.WEST ? this.func_220113_a(p_235627_5_, p_235627_5_.func_224755_d(p_235627_1_, p_235627_4_, direction), direction) : func_235629_a_(p_235627_3_, field_235615_e_);
      BlockPos blockpos = p_235627_2_.func_177984_a();
      BlockState blockstate = p_235627_1_.func_180495_p(blockpos);
      return this.func_235626_a_(p_235627_1_, p_235627_3_, blockpos, blockstate, flag, flag1, flag2, flag3);
   }

   private BlockState func_235626_a_(IWorldReader p_235626_1_, BlockState p_235626_2_, BlockPos p_235626_3_, BlockState p_235626_4_, boolean p_235626_5_, boolean p_235626_6_, boolean p_235626_7_, boolean p_235626_8_) {
      VoxelShape voxelshape = p_235626_4_.func_196952_d(p_235626_1_, p_235626_3_).func_212434_a(Direction.DOWN);
      BlockState blockstate = this.func_235630_a_(p_235626_2_, p_235626_5_, p_235626_6_, p_235626_7_, p_235626_8_, voxelshape);
      return blockstate.func_206870_a(field_176256_a, Boolean.valueOf(this.func_235628_a_(blockstate, p_235626_4_, voxelshape)));
   }

   private boolean func_235628_a_(BlockState p_235628_1_, BlockState p_235628_2_, VoxelShape p_235628_3_) {
      boolean flag = p_235628_2_.func_177230_c() instanceof WallBlock && p_235628_2_.func_177229_b(field_176256_a);
      if (flag) {
         return true;
      } else {
         WallHeight wallheight = p_235628_1_.func_177229_b(field_235613_c_);
         WallHeight wallheight1 = p_235628_1_.func_177229_b(field_235614_d_);
         WallHeight wallheight2 = p_235628_1_.func_177229_b(field_235612_b_);
         WallHeight wallheight3 = p_235628_1_.func_177229_b(field_235615_e_);
         boolean flag1 = wallheight1 == WallHeight.NONE;
         boolean flag2 = wallheight3 == WallHeight.NONE;
         boolean flag3 = wallheight2 == WallHeight.NONE;
         boolean flag4 = wallheight == WallHeight.NONE;
         boolean flag5 = flag4 && flag1 && flag2 && flag3 || flag4 != flag1 || flag2 != flag3;
         if (flag5) {
            return true;
         } else {
            boolean flag6 = wallheight == WallHeight.TALL && wallheight1 == WallHeight.TALL || wallheight2 == WallHeight.TALL && wallheight3 == WallHeight.TALL;
            if (flag6) {
               return false;
            } else {
               return p_235628_2_.func_177230_c().func_203417_a(BlockTags.field_232877_ar_) || func_235632_a_(p_235628_3_, field_235619_i_);
            }
         }
      }
   }

   private BlockState func_235630_a_(BlockState p_235630_1_, boolean p_235630_2_, boolean p_235630_3_, boolean p_235630_4_, boolean p_235630_5_, VoxelShape p_235630_6_) {
      return p_235630_1_.func_206870_a(field_235613_c_, this.func_235633_a_(p_235630_2_, p_235630_6_, field_235620_j_)).func_206870_a(field_235612_b_, this.func_235633_a_(p_235630_3_, p_235630_6_, field_235623_p_)).func_206870_a(field_235614_d_, this.func_235633_a_(p_235630_4_, p_235630_6_, field_235621_k_)).func_206870_a(field_235615_e_, this.func_235633_a_(p_235630_5_, p_235630_6_, field_235622_o_));
   }

   private WallHeight func_235633_a_(boolean p_235633_1_, VoxelShape p_235633_2_, VoxelShape p_235633_3_) {
      if (p_235633_1_) {
         return func_235632_a_(p_235633_2_, p_235633_3_) ? WallHeight.TALL : WallHeight.LOW;
      } else {
         return WallHeight.NONE;
      }
   }

   public FluidState func_204507_t(BlockState p_204507_1_) {
      return p_204507_1_.func_177229_b(field_235616_f_) ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(p_204507_1_);
   }

   public boolean func_200123_i(BlockState p_200123_1_, IBlockReader p_200123_2_, BlockPos p_200123_3_) {
      return !p_200123_1_.func_177229_b(field_235616_f_);
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176256_a, field_235613_c_, field_235612_b_, field_235615_e_, field_235614_d_, field_235616_f_);
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      switch(p_185499_2_) {
      case CLOCKWISE_180:
         return p_185499_1_.func_206870_a(field_235613_c_, p_185499_1_.func_177229_b(field_235614_d_)).func_206870_a(field_235612_b_, p_185499_1_.func_177229_b(field_235615_e_)).func_206870_a(field_235614_d_, p_185499_1_.func_177229_b(field_235613_c_)).func_206870_a(field_235615_e_, p_185499_1_.func_177229_b(field_235612_b_));
      case COUNTERCLOCKWISE_90:
         return p_185499_1_.func_206870_a(field_235613_c_, p_185499_1_.func_177229_b(field_235612_b_)).func_206870_a(field_235612_b_, p_185499_1_.func_177229_b(field_235614_d_)).func_206870_a(field_235614_d_, p_185499_1_.func_177229_b(field_235615_e_)).func_206870_a(field_235615_e_, p_185499_1_.func_177229_b(field_235613_c_));
      case CLOCKWISE_90:
         return p_185499_1_.func_206870_a(field_235613_c_, p_185499_1_.func_177229_b(field_235615_e_)).func_206870_a(field_235612_b_, p_185499_1_.func_177229_b(field_235613_c_)).func_206870_a(field_235614_d_, p_185499_1_.func_177229_b(field_235612_b_)).func_206870_a(field_235615_e_, p_185499_1_.func_177229_b(field_235614_d_));
      default:
         return p_185499_1_;
      }
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      switch(p_185471_2_) {
      case LEFT_RIGHT:
         return p_185471_1_.func_206870_a(field_235613_c_, p_185471_1_.func_177229_b(field_235614_d_)).func_206870_a(field_235614_d_, p_185471_1_.func_177229_b(field_235613_c_));
      case FRONT_BACK:
         return p_185471_1_.func_206870_a(field_235612_b_, p_185471_1_.func_177229_b(field_235615_e_)).func_206870_a(field_235615_e_, p_185471_1_.func_177229_b(field_235612_b_));
      default:
         return super.func_185471_a(p_185471_1_, p_185471_2_);
      }
   }
}
