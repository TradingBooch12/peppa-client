package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;

public class AbstractCoralPlantBlock extends Block implements IWaterLoggable {
   public static final BooleanProperty field_212560_b = BlockStateProperties.field_208198_y;
   private static final VoxelShape field_212559_a = Block.func_208617_a(2.0D, 0.0D, 2.0D, 14.0D, 4.0D, 14.0D);

   protected AbstractCoralPlantBlock(AbstractBlock.Properties p_i49810_1_) {
      super(p_i49810_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_212560_b, Boolean.valueOf(true)));
   }

   protected void func_212558_a(BlockState p_212558_1_, IWorld p_212558_2_, BlockPos p_212558_3_) {
      if (!func_212557_b_(p_212558_1_, p_212558_2_, p_212558_3_)) {
         p_212558_2_.func_205220_G_().func_205360_a(p_212558_3_, this, 60 + p_212558_2_.func_201674_k().nextInt(40));
      }

   }

   protected static boolean func_212557_b_(BlockState p_212557_0_, IBlockReader p_212557_1_, BlockPos p_212557_2_) {
      if (p_212557_0_.func_177229_b(field_212560_b)) {
         return true;
      } else {
         for(Direction direction : Direction.values()) {
            if (p_212557_1_.func_204610_c(p_212557_2_.func_177972_a(direction)).func_206884_a(FluidTags.field_206959_a)) {
               return true;
            }
         }

         return false;
      }
   }

   @Nullable
   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      FluidState fluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
      return this.func_176223_P().func_206870_a(field_212560_b, Boolean.valueOf(fluidstate.func_206884_a(FluidTags.field_206959_a) && fluidstate.func_206882_g() == 8));
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_212559_a;
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_1_.func_177229_b(field_212560_b)) {
         p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
      }

      return p_196271_2_ == Direction.DOWN && !this.func_196260_a(p_196271_1_, p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      BlockPos blockpos = p_196260_3_.func_177977_b();
      return p_196260_2_.func_180495_p(blockpos).func_224755_d(p_196260_2_, blockpos, Direction.UP);
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_212560_b);
   }

   public FluidState func_204507_t(BlockState p_204507_1_) {
      return p_204507_1_.func_177229_b(field_212560_b) ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(p_204507_1_);
   }
}
