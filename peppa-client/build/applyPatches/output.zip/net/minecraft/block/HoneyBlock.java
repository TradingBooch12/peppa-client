package net.minecraft.block;

import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.item.BoatEntity;
import net.minecraft.entity.item.TNTEntity;
import net.minecraft.entity.item.minecart.AbstractMinecartEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.particles.BlockParticleData;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class HoneyBlock extends BreakableBlock {
   protected static final VoxelShape field_226930_a_ = Block.func_208617_a(1.0D, 0.0D, 1.0D, 15.0D, 15.0D, 15.0D);

   public HoneyBlock(AbstractBlock.Properties p_i225762_1_) {
      super(p_i225762_1_);
   }

   private static boolean func_226937_c_(Entity p_226937_0_) {
      return p_226937_0_ instanceof LivingEntity || p_226937_0_ instanceof AbstractMinecartEntity || p_226937_0_ instanceof TNTEntity || p_226937_0_ instanceof BoatEntity;
   }

   public VoxelShape func_220071_b(BlockState p_220071_1_, IBlockReader p_220071_2_, BlockPos p_220071_3_, ISelectionContext p_220071_4_) {
      return field_226930_a_;
   }

   public void func_180658_a(World p_180658_1_, BlockPos p_180658_2_, Entity p_180658_3_, float p_180658_4_) {
      p_180658_3_.func_184185_a(SoundEvents.field_226139_eT_, 1.0F, 1.0F);
      if (!p_180658_1_.field_72995_K) {
         p_180658_1_.func_72960_a(p_180658_3_, (byte)54);
      }

      if (p_180658_3_.func_225503_b_(p_180658_4_, 0.2F)) {
         p_180658_3_.func_184185_a(this.field_149762_H.func_185842_g(), this.field_149762_H.func_185843_a() * 0.5F, this.field_149762_H.func_185847_b() * 0.75F);
      }

   }

   public void func_196262_a(BlockState p_196262_1_, World p_196262_2_, BlockPos p_196262_3_, Entity p_196262_4_) {
      if (this.func_226935_a_(p_196262_3_, p_196262_4_)) {
         this.func_226933_a_(p_196262_4_, p_196262_3_);
         this.func_226938_d_(p_196262_4_);
         this.func_226934_a_(p_196262_2_, p_196262_4_);
      }

      super.func_196262_a(p_196262_1_, p_196262_2_, p_196262_3_, p_196262_4_);
   }

   private boolean func_226935_a_(BlockPos p_226935_1_, Entity p_226935_2_) {
      if (p_226935_2_.func_233570_aj_()) {
         return false;
      } else if (p_226935_2_.func_226278_cu_() > (double)p_226935_1_.func_177956_o() + 0.9375D - 1.0E-7D) {
         return false;
      } else if (p_226935_2_.func_213322_ci().field_72448_b >= -0.08D) {
         return false;
      } else {
         double d0 = Math.abs((double)p_226935_1_.func_177958_n() + 0.5D - p_226935_2_.func_226277_ct_());
         double d1 = Math.abs((double)p_226935_1_.func_177952_p() + 0.5D - p_226935_2_.func_226281_cx_());
         double d2 = 0.4375D + (double)(p_226935_2_.func_213311_cf() / 2.0F);
         return d0 + 1.0E-7D > d2 || d1 + 1.0E-7D > d2;
      }
   }

   private void func_226933_a_(Entity p_226933_1_, BlockPos p_226933_2_) {
      if (p_226933_1_ instanceof ServerPlayerEntity && p_226933_1_.field_70170_p.func_82737_E() % 20L == 0L) {
         CriteriaTriggers.field_229864_K_.func_227152_a_((ServerPlayerEntity)p_226933_1_, p_226933_1_.field_70170_p.func_180495_p(p_226933_2_));
      }

   }

   private void func_226938_d_(Entity p_226938_1_) {
      Vector3d vector3d = p_226938_1_.func_213322_ci();
      if (vector3d.field_72448_b < -0.13D) {
         double d0 = -0.05D / vector3d.field_72448_b;
         p_226938_1_.func_213317_d(new Vector3d(vector3d.field_72450_a * d0, -0.05D, vector3d.field_72449_c * d0));
      } else {
         p_226938_1_.func_213317_d(new Vector3d(vector3d.field_72450_a, -0.05D, vector3d.field_72449_c));
      }

      p_226938_1_.field_70143_R = 0.0F;
   }

   private void func_226934_a_(World p_226934_1_, Entity p_226934_2_) {
      if (func_226937_c_(p_226934_2_)) {
         if (p_226934_1_.field_73012_v.nextInt(5) == 0) {
            p_226934_2_.func_184185_a(SoundEvents.field_226139_eT_, 1.0F, 1.0F);
         }

         if (!p_226934_1_.field_72995_K && p_226934_1_.field_73012_v.nextInt(5) == 0) {
            p_226934_1_.func_72960_a(p_226934_2_, (byte)53);
         }
      }

   }

   @OnlyIn(Dist.CLIENT)
   public static void func_226931_a_(Entity p_226931_0_) {
      func_226932_a_(p_226931_0_, 5);
   }

   @OnlyIn(Dist.CLIENT)
   public static void func_226936_b_(Entity p_226936_0_) {
      func_226932_a_(p_226936_0_, 10);
   }

   @OnlyIn(Dist.CLIENT)
   private static void func_226932_a_(Entity p_226932_0_, int p_226932_1_) {
      if (p_226932_0_.field_70170_p.field_72995_K) {
         BlockState blockstate = Blocks.field_226907_mc_.func_176223_P();

         for(int i = 0; i < p_226932_1_; ++i) {
            p_226932_0_.field_70170_p.func_195594_a(new BlockParticleData(ParticleTypes.field_197611_d, blockstate), p_226932_0_.func_226277_ct_(), p_226932_0_.func_226278_cu_(), p_226932_0_.func_226281_cx_(), 0.0D, 0.0D, 0.0D);
         }

      }
   }
}
