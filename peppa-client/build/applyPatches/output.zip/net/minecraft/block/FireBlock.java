package net.minecraft.block;

import com.google.common.collect.ImmutableMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import java.util.Map;
import java.util.Random;
import java.util.function.Function;
import java.util.stream.Collectors;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Direction;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.GameRules;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class FireBlock extends AbstractFireBlock {
   public static final IntegerProperty field_176543_a = BlockStateProperties.field_208171_X;
   public static final BooleanProperty field_176545_N = SixWayBlock.field_196488_a;
   public static final BooleanProperty field_176546_O = SixWayBlock.field_196490_b;
   public static final BooleanProperty field_176541_P = SixWayBlock.field_196492_c;
   public static final BooleanProperty field_176539_Q = SixWayBlock.field_196495_y;
   public static final BooleanProperty field_176542_R = SixWayBlock.field_196496_z;
   private static final Map<Direction, BooleanProperty> field_196449_B = SixWayBlock.field_196491_B.entrySet().stream().filter((p_199776_0_) -> {
      return p_199776_0_.getKey() != Direction.DOWN;
   }).collect(Util.func_199749_a());
   private static final VoxelShape field_242667_i = Block.func_208617_a(0.0D, 15.0D, 0.0D, 16.0D, 16.0D, 16.0D);
   private static final VoxelShape field_242668_j = Block.func_208617_a(0.0D, 0.0D, 0.0D, 1.0D, 16.0D, 16.0D);
   private static final VoxelShape field_242669_k = Block.func_208617_a(15.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D);
   private static final VoxelShape field_242670_o = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 1.0D);
   private static final VoxelShape field_242671_p = Block.func_208617_a(0.0D, 0.0D, 15.0D, 16.0D, 16.0D, 16.0D);
   private final Map<BlockState, VoxelShape> field_242672_q;
   private final Object2IntMap<Block> field_149849_a = new Object2IntOpenHashMap<>();
   private final Object2IntMap<Block> field_149848_b = new Object2IntOpenHashMap<>();

   public FireBlock(AbstractBlock.Properties p_i48397_1_) {
      super(p_i48397_1_, 1.0F);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176543_a, Integer.valueOf(0)).func_206870_a(field_176545_N, Boolean.valueOf(false)).func_206870_a(field_176546_O, Boolean.valueOf(false)).func_206870_a(field_176541_P, Boolean.valueOf(false)).func_206870_a(field_176539_Q, Boolean.valueOf(false)).func_206870_a(field_176542_R, Boolean.valueOf(false)));
      this.field_242672_q = ImmutableMap.copyOf(this.field_176227_L.func_177619_a().stream().filter((p_242674_0_) -> {
         return p_242674_0_.func_177229_b(field_176543_a) == 0;
      }).collect(Collectors.toMap(Function.identity(), FireBlock::func_242673_h)));
   }

   private static VoxelShape func_242673_h(BlockState p_242673_0_) {
      VoxelShape voxelshape = VoxelShapes.func_197880_a();
      if (p_242673_0_.func_177229_b(field_176542_R)) {
         voxelshape = field_242667_i;
      }

      if (p_242673_0_.func_177229_b(field_176545_N)) {
         voxelshape = VoxelShapes.func_197872_a(voxelshape, field_242670_o);
      }

      if (p_242673_0_.func_177229_b(field_176541_P)) {
         voxelshape = VoxelShapes.func_197872_a(voxelshape, field_242671_p);
      }

      if (p_242673_0_.func_177229_b(field_176546_O)) {
         voxelshape = VoxelShapes.func_197872_a(voxelshape, field_242669_k);
      }

      if (p_242673_0_.func_177229_b(field_176539_Q)) {
         voxelshape = VoxelShapes.func_197872_a(voxelshape, field_242668_j);
      }

      return voxelshape.func_197766_b() ? field_235320_b_ : voxelshape;
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return this.func_196260_a(p_196271_1_, p_196271_4_, p_196271_5_) ? this.func_235494_a_(p_196271_4_, p_196271_5_, p_196271_1_.func_177229_b(field_176543_a)) : Blocks.field_150350_a.func_176223_P();
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return this.field_242672_q.get(p_220053_1_.func_206870_a(field_176543_a, Integer.valueOf(0)));
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_196448_a(p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a());
   }

   protected BlockState func_196448_a(IBlockReader p_196448_1_, BlockPos p_196448_2_) {
      BlockPos blockpos = p_196448_2_.func_177977_b();
      BlockState blockstate = p_196448_1_.func_180495_p(blockpos);
      if (!this.func_196446_i(blockstate) && !blockstate.func_224755_d(p_196448_1_, blockpos, Direction.UP)) {
         BlockState blockstate1 = this.func_176223_P();

         for(Direction direction : Direction.values()) {
            BooleanProperty booleanproperty = field_196449_B.get(direction);
            if (booleanproperty != null) {
               blockstate1 = blockstate1.func_206870_a(booleanproperty, Boolean.valueOf(this.func_196446_i(p_196448_1_.func_180495_p(p_196448_2_.func_177972_a(direction)))));
            }
         }

         return blockstate1;
      } else {
         return this.func_176223_P();
      }
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      BlockPos blockpos = p_196260_3_.func_177977_b();
      return p_196260_2_.func_180495_p(blockpos).func_224755_d(p_196260_2_, blockpos, Direction.UP) || this.func_196447_a(p_196260_2_, p_196260_3_);
   }

   public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
      p_225534_2_.func_205220_G_().func_205360_a(p_225534_3_, this, func_235495_a_(p_225534_2_.field_73012_v));
      if (p_225534_2_.func_82736_K().func_223586_b(GameRules.field_223598_a)) {
         if (!p_225534_1_.func_196955_c(p_225534_2_, p_225534_3_)) {
            p_225534_2_.func_217377_a(p_225534_3_, false);
         }

         BlockState blockstate = p_225534_2_.func_180495_p(p_225534_3_.func_177977_b());
         boolean flag = blockstate.func_235714_a_(p_225534_2_.func_230315_m_().func_241515_q_());
         int i = p_225534_1_.func_177229_b(field_176543_a);
         if (!flag && p_225534_2_.func_72896_J() && this.func_176537_d(p_225534_2_, p_225534_3_) && p_225534_4_.nextFloat() < 0.2F + (float)i * 0.03F) {
            p_225534_2_.func_217377_a(p_225534_3_, false);
         } else {
            int j = Math.min(15, i + p_225534_4_.nextInt(3) / 2);
            if (i != j) {
               p_225534_1_ = p_225534_1_.func_206870_a(field_176543_a, Integer.valueOf(j));
               p_225534_2_.func_180501_a(p_225534_3_, p_225534_1_, 4);
            }

            if (!flag) {
               if (!this.func_196447_a(p_225534_2_, p_225534_3_)) {
                  BlockPos blockpos = p_225534_3_.func_177977_b();
                  if (!p_225534_2_.func_180495_p(blockpos).func_224755_d(p_225534_2_, blockpos, Direction.UP) || i > 3) {
                     p_225534_2_.func_217377_a(p_225534_3_, false);
                  }

                  return;
               }

               if (i == 15 && p_225534_4_.nextInt(4) == 0 && !this.func_196446_i(p_225534_2_.func_180495_p(p_225534_3_.func_177977_b()))) {
                  p_225534_2_.func_217377_a(p_225534_3_, false);
                  return;
               }
            }

            boolean flag1 = p_225534_2_.func_180502_D(p_225534_3_);
            int k = flag1 ? -50 : 0;
            this.func_176536_a(p_225534_2_, p_225534_3_.func_177974_f(), 300 + k, p_225534_4_, i);
            this.func_176536_a(p_225534_2_, p_225534_3_.func_177976_e(), 300 + k, p_225534_4_, i);
            this.func_176536_a(p_225534_2_, p_225534_3_.func_177977_b(), 250 + k, p_225534_4_, i);
            this.func_176536_a(p_225534_2_, p_225534_3_.func_177984_a(), 250 + k, p_225534_4_, i);
            this.func_176536_a(p_225534_2_, p_225534_3_.func_177978_c(), 300 + k, p_225534_4_, i);
            this.func_176536_a(p_225534_2_, p_225534_3_.func_177968_d(), 300 + k, p_225534_4_, i);
            BlockPos.Mutable blockpos$mutable = new BlockPos.Mutable();

            for(int l = -1; l <= 1; ++l) {
               for(int i1 = -1; i1 <= 1; ++i1) {
                  for(int j1 = -1; j1 <= 4; ++j1) {
                     if (l != 0 || j1 != 0 || i1 != 0) {
                        int k1 = 100;
                        if (j1 > 1) {
                           k1 += (j1 - 1) * 100;
                        }

                        blockpos$mutable.func_239621_a_(p_225534_3_, l, j1, i1);
                        int l1 = this.func_176538_m(p_225534_2_, blockpos$mutable);
                        if (l1 > 0) {
                           int i2 = (l1 + 40 + p_225534_2_.func_175659_aa().func_151525_a() * 7) / (i + 30);
                           if (flag1) {
                              i2 /= 2;
                           }

                           if (i2 > 0 && p_225534_4_.nextInt(k1) <= i2 && (!p_225534_2_.func_72896_J() || !this.func_176537_d(p_225534_2_, blockpos$mutable))) {
                              int j2 = Math.min(15, i + p_225534_4_.nextInt(5) / 4);
                              p_225534_2_.func_180501_a(blockpos$mutable, this.func_235494_a_(p_225534_2_, blockpos$mutable, j2), 3);
                           }
                        }
                     }
                  }
               }
            }

         }
      }
   }

   protected boolean func_176537_d(World p_176537_1_, BlockPos p_176537_2_) {
      return p_176537_1_.func_175727_C(p_176537_2_) || p_176537_1_.func_175727_C(p_176537_2_.func_177976_e()) || p_176537_1_.func_175727_C(p_176537_2_.func_177974_f()) || p_176537_1_.func_175727_C(p_176537_2_.func_177978_c()) || p_176537_1_.func_175727_C(p_176537_2_.func_177968_d());
   }

   private int func_220274_q(BlockState p_220274_1_) {
      return p_220274_1_.func_235901_b_(BlockStateProperties.field_208198_y) && p_220274_1_.func_177229_b(BlockStateProperties.field_208198_y) ? 0 : this.field_149848_b.getInt(p_220274_1_.func_177230_c());
   }

   private int func_220275_r(BlockState p_220275_1_) {
      return p_220275_1_.func_235901_b_(BlockStateProperties.field_208198_y) && p_220275_1_.func_177229_b(BlockStateProperties.field_208198_y) ? 0 : this.field_149849_a.getInt(p_220275_1_.func_177230_c());
   }

   private void func_176536_a(World p_176536_1_, BlockPos p_176536_2_, int p_176536_3_, Random p_176536_4_, int p_176536_5_) {
      int i = this.func_220274_q(p_176536_1_.func_180495_p(p_176536_2_));
      if (p_176536_4_.nextInt(p_176536_3_) < i) {
         BlockState blockstate = p_176536_1_.func_180495_p(p_176536_2_);
         if (p_176536_4_.nextInt(p_176536_5_ + 10) < 5 && !p_176536_1_.func_175727_C(p_176536_2_)) {
            int j = Math.min(p_176536_5_ + p_176536_4_.nextInt(5) / 4, 15);
            p_176536_1_.func_180501_a(p_176536_2_, this.func_235494_a_(p_176536_1_, p_176536_2_, j), 3);
         } else {
            p_176536_1_.func_217377_a(p_176536_2_, false);
         }

         Block block = blockstate.func_177230_c();
         if (block instanceof TNTBlock) {
            TNTBlock tntblock = (TNTBlock)block;
            TNTBlock.func_196534_a(p_176536_1_, p_176536_2_);
         }
      }

   }

   private BlockState func_235494_a_(IWorld p_235494_1_, BlockPos p_235494_2_, int p_235494_3_) {
      BlockState blockstate = func_235326_a_(p_235494_1_, p_235494_2_);
      return blockstate.func_203425_a(Blocks.field_150480_ab) ? blockstate.func_206870_a(field_176543_a, Integer.valueOf(p_235494_3_)) : blockstate;
   }

   private boolean func_196447_a(IBlockReader p_196447_1_, BlockPos p_196447_2_) {
      for(Direction direction : Direction.values()) {
         if (this.func_196446_i(p_196447_1_.func_180495_p(p_196447_2_.func_177972_a(direction)))) {
            return true;
         }
      }

      return false;
   }

   private int func_176538_m(IWorldReader p_176538_1_, BlockPos p_176538_2_) {
      if (!p_176538_1_.func_175623_d(p_176538_2_)) {
         return 0;
      } else {
         int i = 0;

         for(Direction direction : Direction.values()) {
            BlockState blockstate = p_176538_1_.func_180495_p(p_176538_2_.func_177972_a(direction));
            i = Math.max(this.func_220275_r(blockstate), i);
         }

         return i;
      }
   }

   protected boolean func_196446_i(BlockState p_196446_1_) {
      return this.func_220275_r(p_196446_1_) > 0;
   }

   public void func_220082_b(BlockState p_220082_1_, World p_220082_2_, BlockPos p_220082_3_, BlockState p_220082_4_, boolean p_220082_5_) {
      super.func_220082_b(p_220082_1_, p_220082_2_, p_220082_3_, p_220082_4_, p_220082_5_);
      p_220082_2_.func_205220_G_().func_205360_a(p_220082_3_, this, func_235495_a_(p_220082_2_.field_73012_v));
   }

   private static int func_235495_a_(Random p_235495_0_) {
      return 30 + p_235495_0_.nextInt(10);
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176543_a, field_176545_N, field_176546_O, field_176541_P, field_176539_Q, field_176542_R);
   }

   private void func_180686_a(Block p_180686_1_, int p_180686_2_, int p_180686_3_) {
      this.field_149849_a.put(p_180686_1_, p_180686_2_);
      this.field_149848_b.put(p_180686_1_, p_180686_3_);
   }

   public static void func_149843_e() {
      FireBlock fireblock = (FireBlock)Blocks.field_150480_ab;
      fireblock.func_180686_a(Blocks.field_196662_n, 5, 20);
      fireblock.func_180686_a(Blocks.field_196664_o, 5, 20);
      fireblock.func_180686_a(Blocks.field_196666_p, 5, 20);
      fireblock.func_180686_a(Blocks.field_196668_q, 5, 20);
      fireblock.func_180686_a(Blocks.field_196670_r, 5, 20);
      fireblock.func_180686_a(Blocks.field_196672_s, 5, 20);
      fireblock.func_180686_a(Blocks.field_196622_bq, 5, 20);
      fireblock.func_180686_a(Blocks.field_196624_br, 5, 20);
      fireblock.func_180686_a(Blocks.field_196627_bs, 5, 20);
      fireblock.func_180686_a(Blocks.field_196630_bt, 5, 20);
      fireblock.func_180686_a(Blocks.field_196632_bu, 5, 20);
      fireblock.func_180686_a(Blocks.field_196635_bv, 5, 20);
      fireblock.func_180686_a(Blocks.field_180390_bo, 5, 20);
      fireblock.func_180686_a(Blocks.field_180391_bp, 5, 20);
      fireblock.func_180686_a(Blocks.field_180392_bq, 5, 20);
      fireblock.func_180686_a(Blocks.field_180386_br, 5, 20);
      fireblock.func_180686_a(Blocks.field_180385_bs, 5, 20);
      fireblock.func_180686_a(Blocks.field_180387_bt, 5, 20);
      fireblock.func_180686_a(Blocks.field_180407_aO, 5, 20);
      fireblock.func_180686_a(Blocks.field_180408_aP, 5, 20);
      fireblock.func_180686_a(Blocks.field_180404_aQ, 5, 20);
      fireblock.func_180686_a(Blocks.field_180403_aR, 5, 20);
      fireblock.func_180686_a(Blocks.field_180406_aS, 5, 20);
      fireblock.func_180686_a(Blocks.field_180405_aT, 5, 20);
      fireblock.func_180686_a(Blocks.field_150476_ad, 5, 20);
      fireblock.func_180686_a(Blocks.field_150487_bG, 5, 20);
      fireblock.func_180686_a(Blocks.field_150485_bF, 5, 20);
      fireblock.func_180686_a(Blocks.field_150481_bH, 5, 20);
      fireblock.func_180686_a(Blocks.field_150400_ck, 5, 20);
      fireblock.func_180686_a(Blocks.field_150401_cl, 5, 20);
      fireblock.func_180686_a(Blocks.field_196617_K, 5, 5);
      fireblock.func_180686_a(Blocks.field_196618_L, 5, 5);
      fireblock.func_180686_a(Blocks.field_196619_M, 5, 5);
      fireblock.func_180686_a(Blocks.field_196620_N, 5, 5);
      fireblock.func_180686_a(Blocks.field_196621_O, 5, 5);
      fireblock.func_180686_a(Blocks.field_196623_P, 5, 5);
      fireblock.func_180686_a(Blocks.field_203204_R, 5, 5);
      fireblock.func_180686_a(Blocks.field_203205_S, 5, 5);
      fireblock.func_180686_a(Blocks.field_203206_T, 5, 5);
      fireblock.func_180686_a(Blocks.field_203207_U, 5, 5);
      fireblock.func_180686_a(Blocks.field_203208_V, 5, 5);
      fireblock.func_180686_a(Blocks.field_203209_W, 5, 5);
      fireblock.func_180686_a(Blocks.field_209389_ab, 5, 5);
      fireblock.func_180686_a(Blocks.field_209390_ac, 5, 5);
      fireblock.func_180686_a(Blocks.field_209391_ad, 5, 5);
      fireblock.func_180686_a(Blocks.field_209392_ae, 5, 5);
      fireblock.func_180686_a(Blocks.field_209393_af, 5, 5);
      fireblock.func_180686_a(Blocks.field_209394_ag, 5, 5);
      fireblock.func_180686_a(Blocks.field_196626_Q, 5, 5);
      fireblock.func_180686_a(Blocks.field_196629_R, 5, 5);
      fireblock.func_180686_a(Blocks.field_196631_S, 5, 5);
      fireblock.func_180686_a(Blocks.field_196634_T, 5, 5);
      fireblock.func_180686_a(Blocks.field_196637_U, 5, 5);
      fireblock.func_180686_a(Blocks.field_196639_V, 5, 5);
      fireblock.func_180686_a(Blocks.field_196642_W, 30, 60);
      fireblock.func_180686_a(Blocks.field_196645_X, 30, 60);
      fireblock.func_180686_a(Blocks.field_196647_Y, 30, 60);
      fireblock.func_180686_a(Blocks.field_196648_Z, 30, 60);
      fireblock.func_180686_a(Blocks.field_196572_aa, 30, 60);
      fireblock.func_180686_a(Blocks.field_196574_ab, 30, 60);
      fireblock.func_180686_a(Blocks.field_150342_X, 30, 20);
      fireblock.func_180686_a(Blocks.field_150335_W, 15, 100);
      fireblock.func_180686_a(Blocks.field_150349_c, 60, 100);
      fireblock.func_180686_a(Blocks.field_196554_aH, 60, 100);
      fireblock.func_180686_a(Blocks.field_196555_aI, 60, 100);
      fireblock.func_180686_a(Blocks.field_196800_gd, 60, 100);
      fireblock.func_180686_a(Blocks.field_196801_ge, 60, 100);
      fireblock.func_180686_a(Blocks.field_196802_gf, 60, 100);
      fireblock.func_180686_a(Blocks.field_196803_gg, 60, 100);
      fireblock.func_180686_a(Blocks.field_196804_gh, 60, 100);
      fireblock.func_180686_a(Blocks.field_196805_gi, 60, 100);
      fireblock.func_180686_a(Blocks.field_196605_bc, 60, 100);
      fireblock.func_180686_a(Blocks.field_196606_bd, 60, 100);
      fireblock.func_180686_a(Blocks.field_196607_be, 60, 100);
      fireblock.func_180686_a(Blocks.field_196609_bf, 60, 100);
      fireblock.func_180686_a(Blocks.field_196610_bg, 60, 100);
      fireblock.func_180686_a(Blocks.field_196612_bh, 60, 100);
      fireblock.func_180686_a(Blocks.field_196613_bi, 60, 100);
      fireblock.func_180686_a(Blocks.field_196614_bj, 60, 100);
      fireblock.func_180686_a(Blocks.field_196615_bk, 60, 100);
      fireblock.func_180686_a(Blocks.field_196616_bl, 60, 100);
      fireblock.func_180686_a(Blocks.field_222387_by, 60, 100);
      fireblock.func_180686_a(Blocks.field_222383_bA, 60, 100);
      fireblock.func_180686_a(Blocks.field_222388_bz, 60, 100);
      fireblock.func_180686_a(Blocks.field_196556_aL, 30, 60);
      fireblock.func_180686_a(Blocks.field_196557_aM, 30, 60);
      fireblock.func_180686_a(Blocks.field_196558_aN, 30, 60);
      fireblock.func_180686_a(Blocks.field_196559_aO, 30, 60);
      fireblock.func_180686_a(Blocks.field_196560_aP, 30, 60);
      fireblock.func_180686_a(Blocks.field_196561_aQ, 30, 60);
      fireblock.func_180686_a(Blocks.field_196562_aR, 30, 60);
      fireblock.func_180686_a(Blocks.field_196563_aS, 30, 60);
      fireblock.func_180686_a(Blocks.field_196564_aT, 30, 60);
      fireblock.func_180686_a(Blocks.field_196565_aU, 30, 60);
      fireblock.func_180686_a(Blocks.field_196566_aV, 30, 60);
      fireblock.func_180686_a(Blocks.field_196567_aW, 30, 60);
      fireblock.func_180686_a(Blocks.field_196568_aX, 30, 60);
      fireblock.func_180686_a(Blocks.field_196569_aY, 30, 60);
      fireblock.func_180686_a(Blocks.field_196570_aZ, 30, 60);
      fireblock.func_180686_a(Blocks.field_196602_ba, 30, 60);
      fireblock.func_180686_a(Blocks.field_150395_bd, 15, 100);
      fireblock.func_180686_a(Blocks.field_150402_ci, 5, 5);
      fireblock.func_180686_a(Blocks.field_150407_cf, 60, 20);
      fireblock.func_180686_a(Blocks.field_235396_nb_, 15, 20);
      fireblock.func_180686_a(Blocks.field_196724_fH, 60, 20);
      fireblock.func_180686_a(Blocks.field_196725_fI, 60, 20);
      fireblock.func_180686_a(Blocks.field_196727_fJ, 60, 20);
      fireblock.func_180686_a(Blocks.field_196729_fK, 60, 20);
      fireblock.func_180686_a(Blocks.field_196731_fL, 60, 20);
      fireblock.func_180686_a(Blocks.field_196733_fM, 60, 20);
      fireblock.func_180686_a(Blocks.field_196735_fN, 60, 20);
      fireblock.func_180686_a(Blocks.field_196737_fO, 60, 20);
      fireblock.func_180686_a(Blocks.field_196739_fP, 60, 20);
      fireblock.func_180686_a(Blocks.field_196741_fQ, 60, 20);
      fireblock.func_180686_a(Blocks.field_196743_fR, 60, 20);
      fireblock.func_180686_a(Blocks.field_196745_fS, 60, 20);
      fireblock.func_180686_a(Blocks.field_196747_fT, 60, 20);
      fireblock.func_180686_a(Blocks.field_196749_fU, 60, 20);
      fireblock.func_180686_a(Blocks.field_196751_fV, 60, 20);
      fireblock.func_180686_a(Blocks.field_196753_fW, 60, 20);
      fireblock.func_180686_a(Blocks.field_203216_jz, 30, 60);
      fireblock.func_180686_a(Blocks.field_222405_kQ, 60, 60);
      fireblock.func_180686_a(Blocks.field_222420_lI, 60, 60);
      fireblock.func_180686_a(Blocks.field_222428_lQ, 30, 20);
      fireblock.func_180686_a(Blocks.field_222436_lZ, 5, 20);
      fireblock.func_180686_a(Blocks.field_222434_lW, 60, 100);
      fireblock.func_180686_a(Blocks.field_226906_mb_, 5, 20);
      fireblock.func_180686_a(Blocks.field_226905_ma_, 30, 20);
   }
}
