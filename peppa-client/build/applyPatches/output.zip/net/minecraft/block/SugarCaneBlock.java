package net.minecraft.block;

import java.util.Random;
import net.minecraft.fluid.FluidState;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.server.ServerWorld;

public class SugarCaneBlock extends Block {
   public static final IntegerProperty field_176355_a = BlockStateProperties.field_208171_X;
   protected static final VoxelShape field_196503_b = Block.func_208617_a(2.0D, 0.0D, 2.0D, 14.0D, 16.0D, 14.0D);

   protected SugarCaneBlock(AbstractBlock.Properties p_i48312_1_) {
      super(p_i48312_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176355_a, Integer.valueOf(0)));
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196503_b;
   }

   public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
      if (!p_225534_1_.func_196955_c(p_225534_2_, p_225534_3_)) {
         p_225534_2_.func_175655_b(p_225534_3_, true);
      }

   }

   public void func_225542_b_(BlockState p_225542_1_, ServerWorld p_225542_2_, BlockPos p_225542_3_, Random p_225542_4_) {
      if (p_225542_2_.func_175623_d(p_225542_3_.func_177984_a())) {
         int i;
         for(i = 1; p_225542_2_.func_180495_p(p_225542_3_.func_177979_c(i)).func_203425_a(this); ++i) {
         }

         if (i < 3) {
            int j = p_225542_1_.func_177229_b(field_176355_a);
            if (j == 15) {
               p_225542_2_.func_175656_a(p_225542_3_.func_177984_a(), this.func_176223_P());
               p_225542_2_.func_180501_a(p_225542_3_, p_225542_1_.func_206870_a(field_176355_a, Integer.valueOf(0)), 4);
            } else {
               p_225542_2_.func_180501_a(p_225542_3_, p_225542_1_.func_206870_a(field_176355_a, Integer.valueOf(j + 1)), 4);
            }
         }
      }

   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (!p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_)) {
         p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, 1);
      }

      return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      BlockState blockstate = p_196260_2_.func_180495_p(p_196260_3_.func_177977_b());
      if (blockstate.func_177230_c() == this) {
         return true;
      } else {
         if (blockstate.func_203425_a(Blocks.field_196658_i) || blockstate.func_203425_a(Blocks.field_150346_d) || blockstate.func_203425_a(Blocks.field_196660_k) || blockstate.func_203425_a(Blocks.field_196661_l) || blockstate.func_203425_a(Blocks.field_150354_m) || blockstate.func_203425_a(Blocks.field_196611_F)) {
            BlockPos blockpos = p_196260_3_.func_177977_b();

            for(Direction direction : Direction.Plane.HORIZONTAL) {
               BlockState blockstate1 = p_196260_2_.func_180495_p(blockpos.func_177972_a(direction));
               FluidState fluidstate = p_196260_2_.func_204610_c(blockpos.func_177972_a(direction));
               if (fluidstate.func_206884_a(FluidTags.field_206959_a) || blockstate1.func_203425_a(Blocks.field_185778_de)) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176355_a);
   }
}
