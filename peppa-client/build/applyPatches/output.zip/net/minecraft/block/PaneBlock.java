package net.minecraft.block;

import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.StateContainer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class PaneBlock extends FourWayBlock {
   protected PaneBlock(AbstractBlock.Properties p_i48373_1_) {
      super(1.0F, 1.0F, 16.0F, 16.0F, 16.0F, p_i48373_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196409_a, Boolean.valueOf(false)).func_206870_a(field_196411_b, Boolean.valueOf(false)).func_206870_a(field_196413_c, Boolean.valueOf(false)).func_206870_a(field_196414_y, Boolean.valueOf(false)).func_206870_a(field_204514_u, Boolean.valueOf(false)));
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      IBlockReader iblockreader = p_196258_1_.func_195991_k();
      BlockPos blockpos = p_196258_1_.func_195995_a();
      FluidState fluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
      BlockPos blockpos1 = blockpos.func_177978_c();
      BlockPos blockpos2 = blockpos.func_177968_d();
      BlockPos blockpos3 = blockpos.func_177976_e();
      BlockPos blockpos4 = blockpos.func_177974_f();
      BlockState blockstate = iblockreader.func_180495_p(blockpos1);
      BlockState blockstate1 = iblockreader.func_180495_p(blockpos2);
      BlockState blockstate2 = iblockreader.func_180495_p(blockpos3);
      BlockState blockstate3 = iblockreader.func_180495_p(blockpos4);
      return this.func_176223_P().func_206870_a(field_196409_a, Boolean.valueOf(this.func_220112_a(blockstate, blockstate.func_224755_d(iblockreader, blockpos1, Direction.SOUTH)))).func_206870_a(field_196413_c, Boolean.valueOf(this.func_220112_a(blockstate1, blockstate1.func_224755_d(iblockreader, blockpos2, Direction.NORTH)))).func_206870_a(field_196414_y, Boolean.valueOf(this.func_220112_a(blockstate2, blockstate2.func_224755_d(iblockreader, blockpos3, Direction.EAST)))).func_206870_a(field_196411_b, Boolean.valueOf(this.func_220112_a(blockstate3, blockstate3.func_224755_d(iblockreader, blockpos4, Direction.WEST)))).func_206870_a(field_204514_u, Boolean.valueOf(fluidstate.func_206886_c() == Fluids.field_204546_a));
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_1_.func_177229_b(field_204514_u)) {
         p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
      }

      return p_196271_2_.func_176740_k().func_176722_c() ? p_196271_1_.func_206870_a(field_196415_z.get(p_196271_2_), Boolean.valueOf(this.func_220112_a(p_196271_3_, p_196271_3_.func_224755_d(p_196271_4_, p_196271_6_, p_196271_2_.func_176734_d())))) : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public VoxelShape func_230322_a_(BlockState p_230322_1_, IBlockReader p_230322_2_, BlockPos p_230322_3_, ISelectionContext p_230322_4_) {
      return VoxelShapes.func_197880_a();
   }

   @OnlyIn(Dist.CLIENT)
   public boolean func_200122_a(BlockState p_200122_1_, BlockState p_200122_2_, Direction p_200122_3_) {
      if (p_200122_2_.func_203425_a(this)) {
         if (!p_200122_3_.func_176740_k().func_176722_c()) {
            return true;
         }

         if (p_200122_1_.func_177229_b(field_196415_z.get(p_200122_3_)) && p_200122_2_.func_177229_b(field_196415_z.get(p_200122_3_.func_176734_d()))) {
            return true;
         }
      }

      return super.func_200122_a(p_200122_1_, p_200122_2_, p_200122_3_);
   }

   public final boolean func_220112_a(BlockState p_220112_1_, boolean p_220112_2_) {
      Block block = p_220112_1_.func_177230_c();
      return !func_220073_a(block) && p_220112_2_ || block instanceof PaneBlock || block.func_203417_a(BlockTags.field_219757_z);
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196409_a, field_196411_b, field_196414_y, field_196413_c, field_204514_u);
   }
}
