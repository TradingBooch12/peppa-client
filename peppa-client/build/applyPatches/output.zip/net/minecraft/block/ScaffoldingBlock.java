package net.minecraft.block;

import java.util.Random;
import net.minecraft.entity.item.FallingBlockEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class ScaffoldingBlock extends Block implements IWaterLoggable {
   private static final VoxelShape field_220121_d;
   private static final VoxelShape field_220122_e;
   private static final VoxelShape field_220123_f = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D);
   private static final VoxelShape field_220124_g = VoxelShapes.func_197868_b().func_197751_a(0.0D, -1.0D, 0.0D);
   public static final IntegerProperty field_220118_a = BlockStateProperties.field_222510_au;
   public static final BooleanProperty field_220119_b = BlockStateProperties.field_208198_y;
   public static final BooleanProperty field_220120_c = BlockStateProperties.field_222513_b;

   protected ScaffoldingBlock(AbstractBlock.Properties p_i49976_1_) {
      super(p_i49976_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_220118_a, Integer.valueOf(7)).func_206870_a(field_220119_b, Boolean.valueOf(false)).func_206870_a(field_220120_c, Boolean.valueOf(false)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_220118_a, field_220119_b, field_220120_c);
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      if (!p_220053_4_.func_216375_a(p_220053_1_.func_177230_c().func_199767_j())) {
         return p_220053_1_.func_177229_b(field_220120_c) ? field_220122_e : field_220121_d;
      } else {
         return VoxelShapes.func_197868_b();
      }
   }

   public VoxelShape func_199600_g(BlockState p_199600_1_, IBlockReader p_199600_2_, BlockPos p_199600_3_) {
      return VoxelShapes.func_197868_b();
   }

   public boolean func_196253_a(BlockState p_196253_1_, BlockItemUseContext p_196253_2_) {
      return p_196253_2_.func_195996_i().func_77973_b() == this.func_199767_j();
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      BlockPos blockpos = p_196258_1_.func_195995_a();
      World world = p_196258_1_.func_195991_k();
      int i = func_220117_a(world, blockpos);
      return this.func_176223_P().func_206870_a(field_220119_b, Boolean.valueOf(world.func_204610_c(blockpos).func_206886_c() == Fluids.field_204546_a)).func_206870_a(field_220118_a, Integer.valueOf(i)).func_206870_a(field_220120_c, Boolean.valueOf(this.func_220116_a(world, blockpos, i)));
   }

   public void func_220082_b(BlockState p_220082_1_, World p_220082_2_, BlockPos p_220082_3_, BlockState p_220082_4_, boolean p_220082_5_) {
      if (!p_220082_2_.field_72995_K) {
         p_220082_2_.func_205220_G_().func_205360_a(p_220082_3_, this, 1);
      }

   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_1_.func_177229_b(field_220119_b)) {
         p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
      }

      if (!p_196271_4_.func_201670_d()) {
         p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, 1);
      }

      return p_196271_1_;
   }

   public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
      int i = func_220117_a(p_225534_2_, p_225534_3_);
      BlockState blockstate = p_225534_1_.func_206870_a(field_220118_a, Integer.valueOf(i)).func_206870_a(field_220120_c, Boolean.valueOf(this.func_220116_a(p_225534_2_, p_225534_3_, i)));
      if (blockstate.func_177229_b(field_220118_a) == 7) {
         if (p_225534_1_.func_177229_b(field_220118_a) == 7) {
            p_225534_2_.func_217376_c(new FallingBlockEntity(p_225534_2_, (double)p_225534_3_.func_177958_n() + 0.5D, (double)p_225534_3_.func_177956_o(), (double)p_225534_3_.func_177952_p() + 0.5D, blockstate.func_206870_a(field_220119_b, Boolean.valueOf(false))));
         } else {
            p_225534_2_.func_175655_b(p_225534_3_, true);
         }
      } else if (p_225534_1_ != blockstate) {
         p_225534_2_.func_180501_a(p_225534_3_, blockstate, 3);
      }

   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      return func_220117_a(p_196260_2_, p_196260_3_) < 7;
   }

   public VoxelShape func_220071_b(BlockState p_220071_1_, IBlockReader p_220071_2_, BlockPos p_220071_3_, ISelectionContext p_220071_4_) {
      if (p_220071_4_.func_216378_a(VoxelShapes.func_197868_b(), p_220071_3_, true) && !p_220071_4_.func_225581_b_()) {
         return field_220121_d;
      } else {
         return p_220071_1_.func_177229_b(field_220118_a) != 0 && p_220071_1_.func_177229_b(field_220120_c) && p_220071_4_.func_216378_a(field_220124_g, p_220071_3_, true) ? field_220123_f : VoxelShapes.func_197880_a();
      }
   }

   public FluidState func_204507_t(BlockState p_204507_1_) {
      return p_204507_1_.func_177229_b(field_220119_b) ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(p_204507_1_);
   }

   private boolean func_220116_a(IBlockReader p_220116_1_, BlockPos p_220116_2_, int p_220116_3_) {
      return p_220116_3_ > 0 && !p_220116_1_.func_180495_p(p_220116_2_.func_177977_b()).func_203425_a(this);
   }

   public static int func_220117_a(IBlockReader p_220117_0_, BlockPos p_220117_1_) {
      BlockPos.Mutable blockpos$mutable = p_220117_1_.func_239590_i_().func_189536_c(Direction.DOWN);
      BlockState blockstate = p_220117_0_.func_180495_p(blockpos$mutable);
      int i = 7;
      if (blockstate.func_203425_a(Blocks.field_222420_lI)) {
         i = blockstate.func_177229_b(field_220118_a);
      } else if (blockstate.func_224755_d(p_220117_0_, blockpos$mutable, Direction.UP)) {
         return 0;
      }

      for(Direction direction : Direction.Plane.HORIZONTAL) {
         BlockState blockstate1 = p_220117_0_.func_180495_p(blockpos$mutable.func_239622_a_(p_220117_1_, direction));
         if (blockstate1.func_203425_a(Blocks.field_222420_lI)) {
            i = Math.min(i, blockstate1.func_177229_b(field_220118_a) + 1);
            if (i == 1) {
               break;
            }
         }
      }

      return i;
   }

   static {
      VoxelShape voxelshape = Block.func_208617_a(0.0D, 14.0D, 0.0D, 16.0D, 16.0D, 16.0D);
      VoxelShape voxelshape1 = Block.func_208617_a(0.0D, 0.0D, 0.0D, 2.0D, 16.0D, 2.0D);
      VoxelShape voxelshape2 = Block.func_208617_a(14.0D, 0.0D, 0.0D, 16.0D, 16.0D, 2.0D);
      VoxelShape voxelshape3 = Block.func_208617_a(0.0D, 0.0D, 14.0D, 2.0D, 16.0D, 16.0D);
      VoxelShape voxelshape4 = Block.func_208617_a(14.0D, 0.0D, 14.0D, 16.0D, 16.0D, 16.0D);
      field_220121_d = VoxelShapes.func_216384_a(voxelshape, voxelshape1, voxelshape2, voxelshape3, voxelshape4);
      VoxelShape voxelshape5 = Block.func_208617_a(0.0D, 0.0D, 0.0D, 2.0D, 2.0D, 16.0D);
      VoxelShape voxelshape6 = Block.func_208617_a(14.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D);
      VoxelShape voxelshape7 = Block.func_208617_a(0.0D, 0.0D, 14.0D, 16.0D, 2.0D, 16.0D);
      VoxelShape voxelshape8 = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 2.0D);
      field_220122_e = VoxelShapes.func_216384_a(ScaffoldingBlock.field_220123_f, field_220121_d, voxelshape6, voxelshape5, voxelshape8, voxelshape7);
   }
}
