package net.minecraft.block;

import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.monster.SilverfishEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Explosion;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class SilverfishBlock extends Block {
   private final Block field_196469_a;
   private static final Map<Block, Block> field_196470_b = Maps.newIdentityHashMap();

   public SilverfishBlock(Block p_i48374_1_, AbstractBlock.Properties p_i48374_2_) {
      super(p_i48374_2_);
      this.field_196469_a = p_i48374_1_;
      field_196470_b.put(p_i48374_1_, this);
   }

   public Block func_196468_d() {
      return this.field_196469_a;
   }

   public static boolean func_196466_i(BlockState p_196466_0_) {
      return field_196470_b.containsKey(p_196466_0_.func_177230_c());
   }

   private void func_235505_a_(ServerWorld p_235505_1_, BlockPos p_235505_2_) {
      SilverfishEntity silverfishentity = EntityType.field_200740_af.func_200721_a(p_235505_1_);
      silverfishentity.func_70012_b((double)p_235505_2_.func_177958_n() + 0.5D, (double)p_235505_2_.func_177956_o(), (double)p_235505_2_.func_177952_p() + 0.5D, 0.0F, 0.0F);
      p_235505_1_.func_217376_c(silverfishentity);
      silverfishentity.func_70656_aK();
   }

   public void func_220062_a(BlockState p_220062_1_, ServerWorld p_220062_2_, BlockPos p_220062_3_, ItemStack p_220062_4_) {
      super.func_220062_a(p_220062_1_, p_220062_2_, p_220062_3_, p_220062_4_);
      if (p_220062_2_.func_82736_K().func_223586_b(GameRules.field_223603_f) && EnchantmentHelper.func_77506_a(Enchantments.field_185306_r, p_220062_4_) == 0) {
         this.func_235505_a_(p_220062_2_, p_220062_3_);
      }

   }

   public void func_180652_a(World p_180652_1_, BlockPos p_180652_2_, Explosion p_180652_3_) {
      if (p_180652_1_ instanceof ServerWorld) {
         this.func_235505_a_((ServerWorld)p_180652_1_, p_180652_2_);
      }

   }

   public static BlockState func_196467_h(Block p_196467_0_) {
      return field_196470_b.get(p_196467_0_).func_176223_P();
   }
}
