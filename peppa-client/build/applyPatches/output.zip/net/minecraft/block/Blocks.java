package net.minecraft.block;

import java.util.function.ToIntFunction;
import net.minecraft.block.material.Material;
import net.minecraft.block.material.MaterialColor;
import net.minecraft.block.trees.AcaciaTree;
import net.minecraft.block.trees.BirchTree;
import net.minecraft.block.trees.DarkOakTree;
import net.minecraft.block.trees.JungleTree;
import net.minecraft.block.trees.OakTree;
import net.minecraft.block.trees.SpruceTree;
import net.minecraft.entity.EntityType;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.DyeColor;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.potion.Effects;
import net.minecraft.state.properties.BedPart;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tileentity.ShulkerBoxTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityType;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.gen.feature.Features;

public class Blocks {
   public static final Block field_150350_a = func_222382_a("air", new AirBlock(AbstractBlock.Properties.func_200945_a(Material.field_151579_a).func_200942_a().func_222380_e().func_235859_g_()));
   public static final Block field_150348_b = func_222382_a("stone", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151665_m).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_196650_c = func_222382_a("granite", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151664_l).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_196652_d = func_222382_a("polished_granite", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151664_l).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_196654_e = func_222382_a("diorite", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151677_p).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_196655_f = func_222382_a("polished_diorite", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151677_p).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_196656_g = func_222382_a("andesite", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151665_m).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_196657_h = func_222382_a("polished_andesite", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151665_m).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_196658_i = func_222382_a("grass_block", new GrassBlock(AbstractBlock.Properties.func_200945_a(Material.field_151577_b).func_200944_c().func_200943_b(0.6F).func_200947_a(SoundType.field_185850_c)));
   public static final Block field_150346_d = func_222382_a("dirt", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151578_c, MaterialColor.field_151664_l).func_200943_b(0.5F).func_200947_a(SoundType.field_185849_b)));
   public static final Block field_196660_k = func_222382_a("coarse_dirt", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151578_c, MaterialColor.field_151664_l).func_200943_b(0.5F).func_200947_a(SoundType.field_185849_b)));
   public static final Block field_196661_l = func_222382_a("podzol", new SnowyDirtBlock(AbstractBlock.Properties.func_200949_a(Material.field_151578_c, MaterialColor.field_151654_J).func_200943_b(0.5F).func_200947_a(SoundType.field_185849_b)));
   public static final Block field_150347_e = func_222382_a("cobblestone", new Block(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200948_a(2.0F, 6.0F)));
   public static final Block field_196662_n = func_222382_a("oak_planks", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151663_o).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196664_o = func_222382_a("spruce_planks", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151654_J).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196666_p = func_222382_a("birch_planks", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151658_d).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196668_q = func_222382_a("jungle_planks", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151664_l).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196670_r = func_222382_a("acacia_planks", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151676_q).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196672_s = func_222382_a("dark_oak_planks", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151650_B).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196674_t = func_222382_a("oak_sapling", new SaplingBlock(new OakTree(), AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200944_c().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196675_u = func_222382_a("spruce_sapling", new SaplingBlock(new SpruceTree(), AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200944_c().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196676_v = func_222382_a("birch_sapling", new SaplingBlock(new BirchTree(), AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200944_c().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196678_w = func_222382_a("jungle_sapling", new SaplingBlock(new JungleTree(), AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200944_c().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196679_x = func_222382_a("acacia_sapling", new SaplingBlock(new AcaciaTree(), AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200944_c().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196680_y = func_222382_a("dark_oak_sapling", new SaplingBlock(new DarkOakTree(), AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200944_c().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_150357_h = func_222382_a("bedrock", new Block(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_200948_a(-1.0F, 3600000.0F).func_222380_e().func_235827_a_(Blocks::func_235427_a_)));
   public static final Block field_150355_j = func_222382_a("water", new FlowingFluidBlock(Fluids.field_204546_a, AbstractBlock.Properties.func_200945_a(Material.field_151586_h).func_200942_a().func_200943_b(100.0F).func_222380_e()));
   public static final Block field_150353_l = func_222382_a("lava", new FlowingFluidBlock(Fluids.field_204547_b, AbstractBlock.Properties.func_200945_a(Material.field_151587_i).func_200942_a().func_200944_c().func_200943_b(100.0F).func_235838_a_((p_235418_0_) -> {
      return 15;
   }).func_222380_e()));
   public static final Block field_150354_m = func_222382_a("sand", new SandBlock(14406560, AbstractBlock.Properties.func_200949_a(Material.field_151595_p, MaterialColor.field_151658_d).func_200943_b(0.5F).func_200947_a(SoundType.field_185855_h)));
   public static final Block field_196611_F = func_222382_a("red_sand", new SandBlock(11098145, AbstractBlock.Properties.func_200949_a(Material.field_151595_p, MaterialColor.field_151676_q).func_200943_b(0.5F).func_200947_a(SoundType.field_185855_h)));
   public static final Block field_150351_n = func_222382_a("gravel", new GravelBlock(AbstractBlock.Properties.func_200949_a(Material.field_151595_p, MaterialColor.field_151665_m).func_200943_b(0.6F).func_200947_a(SoundType.field_185849_b)));
   public static final Block field_150352_o = func_222382_a("gold_ore", new OreBlock(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200948_a(3.0F, 3.0F)));
   public static final Block field_150366_p = func_222382_a("iron_ore", new OreBlock(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200948_a(3.0F, 3.0F)));
   public static final Block field_150365_q = func_222382_a("coal_ore", new OreBlock(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200948_a(3.0F, 3.0F)));
   public static final Block field_235334_I_ = func_222382_a("nether_gold_ore", new OreBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151655_K).func_235861_h_().func_200948_a(3.0F, 3.0F).func_200947_a(SoundType.field_235598_T_)));
   public static final Block field_196617_K = func_222382_a("oak_log", func_235430_a_(MaterialColor.field_151663_o, MaterialColor.field_151654_J));
   public static final Block field_196618_L = func_222382_a("spruce_log", func_235430_a_(MaterialColor.field_151654_J, MaterialColor.field_151650_B));
   public static final Block field_196619_M = func_222382_a("birch_log", func_235430_a_(MaterialColor.field_151658_d, MaterialColor.field_151677_p));
   public static final Block field_196620_N = func_222382_a("jungle_log", func_235430_a_(MaterialColor.field_151664_l, MaterialColor.field_151654_J));
   public static final Block field_196621_O = func_222382_a("acacia_log", func_235430_a_(MaterialColor.field_151676_q, MaterialColor.field_151665_m));
   public static final Block field_196623_P = func_222382_a("dark_oak_log", func_235430_a_(MaterialColor.field_151650_B, MaterialColor.field_151650_B));
   public static final Block field_203205_S = func_222382_a("stripped_spruce_log", func_235430_a_(MaterialColor.field_151654_J, MaterialColor.field_151654_J));
   public static final Block field_203206_T = func_222382_a("stripped_birch_log", func_235430_a_(MaterialColor.field_151658_d, MaterialColor.field_151658_d));
   public static final Block field_203207_U = func_222382_a("stripped_jungle_log", func_235430_a_(MaterialColor.field_151664_l, MaterialColor.field_151664_l));
   public static final Block field_203208_V = func_222382_a("stripped_acacia_log", func_235430_a_(MaterialColor.field_151676_q, MaterialColor.field_151676_q));
   public static final Block field_203209_W = func_222382_a("stripped_dark_oak_log", func_235430_a_(MaterialColor.field_151650_B, MaterialColor.field_151650_B));
   public static final Block field_203204_R = func_222382_a("stripped_oak_log", func_235430_a_(MaterialColor.field_151663_o, MaterialColor.field_151663_o));
   public static final Block field_196626_Q = func_222382_a("oak_wood", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151663_o).func_200943_b(2.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196629_R = func_222382_a("spruce_wood", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151654_J).func_200943_b(2.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196631_S = func_222382_a("birch_wood", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151658_d).func_200943_b(2.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196634_T = func_222382_a("jungle_wood", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151664_l).func_200943_b(2.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196637_U = func_222382_a("acacia_wood", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151670_w).func_200943_b(2.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196639_V = func_222382_a("dark_oak_wood", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151650_B).func_200943_b(2.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_209389_ab = func_222382_a("stripped_oak_wood", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151663_o).func_200943_b(2.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_209390_ac = func_222382_a("stripped_spruce_wood", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151654_J).func_200943_b(2.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_209391_ad = func_222382_a("stripped_birch_wood", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151658_d).func_200943_b(2.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_209392_ae = func_222382_a("stripped_jungle_wood", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151664_l).func_200943_b(2.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_209393_af = func_222382_a("stripped_acacia_wood", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151676_q).func_200943_b(2.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_209394_ag = func_222382_a("stripped_dark_oak_wood", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151650_B).func_200943_b(2.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196642_W = func_222382_a("oak_leaves", func_235433_b_());
   public static final Block field_196645_X = func_222382_a("spruce_leaves", func_235433_b_());
   public static final Block field_196647_Y = func_222382_a("birch_leaves", func_235433_b_());
   public static final Block field_196648_Z = func_222382_a("jungle_leaves", func_235433_b_());
   public static final Block field_196572_aa = func_222382_a("acacia_leaves", func_235433_b_());
   public static final Block field_196574_ab = func_222382_a("dark_oak_leaves", func_235433_b_());
   public static final Block field_150360_v = func_222382_a("sponge", new SpongeBlock(AbstractBlock.Properties.func_200945_a(Material.field_151583_m).func_200943_b(0.6F).func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196577_ad = func_222382_a("wet_sponge", new WetSpongeBlock(AbstractBlock.Properties.func_200945_a(Material.field_151583_m).func_200943_b(0.6F).func_200947_a(SoundType.field_185850_c)));
   public static final Block field_150359_w = func_222382_a("glass", new GlassBlock(AbstractBlock.Properties.func_200945_a(Material.field_151592_s).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_226896_b_().func_235827_a_(Blocks::func_235427_a_).func_235828_a_(Blocks::func_235436_b_).func_235842_b_(Blocks::func_235436_b_).func_235847_c_(Blocks::func_235436_b_)));
   public static final Block field_150369_x = func_222382_a("lapis_ore", new OreBlock(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200948_a(3.0F, 3.0F)));
   public static final Block field_150368_y = func_222382_a("lapis_block", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_151652_H).func_235861_h_().func_200948_a(3.0F, 3.0F)));
   public static final Block field_150367_z = func_222382_a("dispenser", new DispenserBlock(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200943_b(3.5F)));
   public static final Block field_150322_A = func_222382_a("sandstone", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151658_d).func_235861_h_().func_200943_b(0.8F)));
   public static final Block field_196583_aj = func_222382_a("chiseled_sandstone", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151658_d).func_235861_h_().func_200943_b(0.8F)));
   public static final Block field_196585_ak = func_222382_a("cut_sandstone", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151658_d).func_235861_h_().func_200943_b(0.8F)));
   public static final Block field_196586_al = func_222382_a("note_block", new NoteBlock(AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200947_a(SoundType.field_185848_a).func_200943_b(0.8F)));
   public static final Block field_196587_am = func_222382_a("white_bed", func_235422_a_(DyeColor.WHITE));
   public static final Block field_196588_an = func_222382_a("orange_bed", func_235422_a_(DyeColor.ORANGE));
   public static final Block field_196589_ao = func_222382_a("magenta_bed", func_235422_a_(DyeColor.MAGENTA));
   public static final Block field_196590_ap = func_222382_a("light_blue_bed", func_235422_a_(DyeColor.LIGHT_BLUE));
   public static final Block field_196592_aq = func_222382_a("yellow_bed", func_235422_a_(DyeColor.YELLOW));
   public static final Block field_196593_ar = func_222382_a("lime_bed", func_235422_a_(DyeColor.LIME));
   public static final Block field_196594_as = func_222382_a("pink_bed", func_235422_a_(DyeColor.PINK));
   public static final Block field_196595_at = func_222382_a("gray_bed", func_235422_a_(DyeColor.GRAY));
   public static final Block field_196596_au = func_222382_a("light_gray_bed", func_235422_a_(DyeColor.LIGHT_GRAY));
   public static final Block field_196597_av = func_222382_a("cyan_bed", func_235422_a_(DyeColor.CYAN));
   public static final Block field_196598_aw = func_222382_a("purple_bed", func_235422_a_(DyeColor.PURPLE));
   public static final Block field_196599_ax = func_222382_a("blue_bed", func_235422_a_(DyeColor.BLUE));
   public static final Block field_196600_ay = func_222382_a("brown_bed", func_235422_a_(DyeColor.BROWN));
   public static final Block field_196601_az = func_222382_a("green_bed", func_235422_a_(DyeColor.GREEN));
   public static final Block field_196550_aA = func_222382_a("red_bed", func_235422_a_(DyeColor.RED));
   public static final Block field_196551_aB = func_222382_a("black_bed", func_235422_a_(DyeColor.BLACK));
   public static final Block field_196552_aC = func_222382_a("powered_rail", new PoweredRailBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200943_b(0.7F).func_200947_a(SoundType.field_185852_e)));
   public static final Block field_150319_E = func_222382_a("detector_rail", new DetectorRailBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200943_b(0.7F).func_200947_a(SoundType.field_185852_e)));
   public static final Block field_150320_F = func_222382_a("sticky_piston", func_235432_a_(true));
   public static final Block field_196553_aF = func_222382_a("cobweb", new WebBlock(AbstractBlock.Properties.func_200945_a(Material.field_151569_G).func_200942_a().func_235861_h_().func_200943_b(4.0F)));
   public static final Block field_150349_c = func_222382_a("grass", new TallGrassBlock(AbstractBlock.Properties.func_200945_a(Material.field_151582_l).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196554_aH = func_222382_a("fern", new TallGrassBlock(AbstractBlock.Properties.func_200945_a(Material.field_151582_l).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196555_aI = func_222382_a("dead_bush", new DeadBushBlock(AbstractBlock.Properties.func_200949_a(Material.field_151582_l, MaterialColor.field_151663_o).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_203198_aQ = func_222382_a("seagrass", new SeaGrassBlock(AbstractBlock.Properties.func_200945_a(Material.field_204868_h).func_200942_a().func_200946_b().func_200947_a(SoundType.field_211382_m)));
   public static final Block field_203199_aR = func_222382_a("tall_seagrass", new TallSeaGrassBlock(AbstractBlock.Properties.func_200945_a(Material.field_204868_h).func_200942_a().func_200946_b().func_200947_a(SoundType.field_211382_m)));
   public static final Block field_150331_J = func_222382_a("piston", func_235432_a_(false));
   public static final Block field_150332_K = func_222382_a("piston_head", new PistonHeadBlock(AbstractBlock.Properties.func_200945_a(Material.field_76233_E).func_200943_b(1.5F).func_222380_e()));
   public static final Block field_196556_aL = func_222382_a("white_wool", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151580_n, MaterialColor.field_151666_j).func_200943_b(0.8F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196557_aM = func_222382_a("orange_wool", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151580_n, MaterialColor.field_151676_q).func_200943_b(0.8F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196558_aN = func_222382_a("magenta_wool", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151580_n, MaterialColor.field_151675_r).func_200943_b(0.8F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196559_aO = func_222382_a("light_blue_wool", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151580_n, MaterialColor.field_151674_s).func_200943_b(0.8F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196560_aP = func_222382_a("yellow_wool", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151580_n, MaterialColor.field_151673_t).func_200943_b(0.8F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196561_aQ = func_222382_a("lime_wool", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151580_n, MaterialColor.field_151672_u).func_200943_b(0.8F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196562_aR = func_222382_a("pink_wool", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151580_n, MaterialColor.field_151671_v).func_200943_b(0.8F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196563_aS = func_222382_a("gray_wool", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151580_n, MaterialColor.field_151670_w).func_200943_b(0.8F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196564_aT = func_222382_a("light_gray_wool", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151580_n, MaterialColor.field_197656_x).func_200943_b(0.8F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196565_aU = func_222382_a("cyan_wool", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151580_n, MaterialColor.field_151679_y).func_200943_b(0.8F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196566_aV = func_222382_a("purple_wool", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151580_n, MaterialColor.field_151678_z).func_200943_b(0.8F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196567_aW = func_222382_a("blue_wool", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151580_n, MaterialColor.field_151649_A).func_200943_b(0.8F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196568_aX = func_222382_a("brown_wool", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151580_n, MaterialColor.field_151650_B).func_200943_b(0.8F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196569_aY = func_222382_a("green_wool", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151580_n, MaterialColor.field_151651_C).func_200943_b(0.8F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196570_aZ = func_222382_a("red_wool", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151580_n, MaterialColor.field_151645_D).func_200943_b(0.8F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196602_ba = func_222382_a("black_wool", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151580_n, MaterialColor.field_151646_E).func_200943_b(0.8F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196603_bb = func_222382_a("moving_piston", new MovingPistonBlock(AbstractBlock.Properties.func_200945_a(Material.field_76233_E).func_200943_b(-1.0F).func_208770_d().func_222380_e().func_226896_b_().func_235828_a_(Blocks::func_235436_b_).func_235842_b_(Blocks::func_235436_b_).func_235847_c_(Blocks::func_235436_b_)));
   public static final Block field_196605_bc = func_222382_a("dandelion", new FlowerBlock(Effects.field_76443_y, 7, AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196606_bd = func_222382_a("poppy", new FlowerBlock(Effects.field_76439_r, 5, AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196607_be = func_222382_a("blue_orchid", new FlowerBlock(Effects.field_76443_y, 7, AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196609_bf = func_222382_a("allium", new FlowerBlock(Effects.field_76426_n, 4, AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196610_bg = func_222382_a("azure_bluet", new FlowerBlock(Effects.field_76440_q, 8, AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196612_bh = func_222382_a("red_tulip", new FlowerBlock(Effects.field_76437_t, 9, AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196613_bi = func_222382_a("orange_tulip", new FlowerBlock(Effects.field_76437_t, 9, AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196614_bj = func_222382_a("white_tulip", new FlowerBlock(Effects.field_76437_t, 9, AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196615_bk = func_222382_a("pink_tulip", new FlowerBlock(Effects.field_76437_t, 9, AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196616_bl = func_222382_a("oxeye_daisy", new FlowerBlock(Effects.field_76428_l, 8, AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_222387_by = func_222382_a("cornflower", new FlowerBlock(Effects.field_76430_j, 6, AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_222388_bz = func_222382_a("wither_rose", new WitherRoseBlock(Effects.field_82731_v, AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_222383_bA = func_222382_a("lily_of_the_valley", new FlowerBlock(Effects.field_76436_u, 12, AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_150338_P = func_222382_a("brown_mushroom", new MushroomBlock(AbstractBlock.Properties.func_200949_a(Material.field_151585_k, MaterialColor.field_151650_B).func_200942_a().func_200944_c().func_200946_b().func_200947_a(SoundType.field_185850_c).func_235838_a_((p_235417_0_) -> {
      return 1;
   }).func_235852_d_(Blocks::func_235426_a_)));
   public static final Block field_150337_Q = func_222382_a("red_mushroom", new MushroomBlock(AbstractBlock.Properties.func_200949_a(Material.field_151585_k, MaterialColor.field_151645_D).func_200942_a().func_200944_c().func_200946_b().func_200947_a(SoundType.field_185850_c).func_235852_d_(Blocks::func_235426_a_)));
   public static final Block field_150340_R = func_222382_a("gold_block", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_151647_F).func_235861_h_().func_200948_a(3.0F, 6.0F).func_200947_a(SoundType.field_185852_e)));
   public static final Block field_150339_S = func_222382_a("iron_block", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_151668_h).func_235861_h_().func_200948_a(5.0F, 6.0F).func_200947_a(SoundType.field_185852_e)));
   public static final Block field_196584_bK = func_222382_a("bricks", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151645_D).func_235861_h_().func_200948_a(2.0F, 6.0F)));
   public static final Block field_150335_W = func_222382_a("tnt", new TNTBlock(AbstractBlock.Properties.func_200945_a(Material.field_151590_u).func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_150342_X = func_222382_a("bookshelf", new Block(AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200943_b(1.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_150341_Y = func_222382_a("mossy_cobblestone", new Block(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200948_a(2.0F, 6.0F)));
   public static final Block field_150343_Z = func_222382_a("obsidian", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151646_E).func_235861_h_().func_200948_a(50.0F, 1200.0F)));
   public static final Block field_150478_aa = func_222382_a("torch", new TorchBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200946_b().func_235838_a_((p_235470_0_) -> {
      return 14;
   }).func_200947_a(SoundType.field_185848_a), ParticleTypes.field_197631_x));
   public static final Block field_196591_bQ = func_222382_a("wall_torch", new WallTorchBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200946_b().func_235838_a_((p_235469_0_) -> {
      return 14;
   }).func_200947_a(SoundType.field_185848_a).func_222379_b(field_150478_aa), ParticleTypes.field_197631_x));
   public static final Block field_150480_ab = func_222382_a("fire", new FireBlock(AbstractBlock.Properties.func_200949_a(Material.field_151581_o, MaterialColor.field_151656_f).func_200942_a().func_200946_b().func_235838_a_((p_235468_0_) -> {
      return 15;
   }).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_235335_bO_ = func_222382_a("soul_fire", new SoulFireBlock(AbstractBlock.Properties.func_200949_a(Material.field_151581_o, MaterialColor.field_151674_s).func_200942_a().func_200946_b().func_235838_a_((p_235467_0_) -> {
      return 10;
   }).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_150474_ac = func_222382_a("spawner", new SpawnerBlock(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200943_b(5.0F).func_200947_a(SoundType.field_185852_e).func_226896_b_()));
   public static final Block field_150476_ad = func_222382_a("oak_stairs", new StairsBlock(field_196662_n.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196662_n)));
   public static final Block field_150486_ae = func_222382_a("chest", new ChestBlock(AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200943_b(2.5F).func_200947_a(SoundType.field_185848_a), () -> {
      return TileEntityType.field_200972_c;
   }));
   public static final Block field_150488_af = func_222382_a("redstone_wire", new RedstoneWireBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200946_b()));
   public static final Block field_150482_ag = func_222382_a("diamond_ore", new OreBlock(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200948_a(3.0F, 3.0F)));
   public static final Block field_150484_ah = func_222382_a("diamond_block", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_151648_G).func_235861_h_().func_200948_a(5.0F, 6.0F).func_200947_a(SoundType.field_185852_e)));
   public static final Block field_150462_ai = func_222382_a("crafting_table", new CraftingTableBlock(AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200943_b(2.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_150464_aj = func_222382_a("wheat", new CropsBlock(AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200944_c().func_200946_b().func_200947_a(SoundType.field_222472_s)));
   public static final Block field_150458_ak = func_222382_a("farmland", new FarmlandBlock(AbstractBlock.Properties.func_200945_a(Material.field_151578_c).func_200944_c().func_200943_b(0.6F).func_200947_a(SoundType.field_185849_b).func_235847_c_(Blocks::func_235426_a_).func_235842_b_(Blocks::func_235426_a_)));
   public static final Block field_150460_al = func_222382_a("furnace", new FurnaceBlock(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200943_b(3.5F).func_235838_a_(func_235420_a_(13))));
   public static final Block field_222384_bX = func_222382_a("oak_sign", new StandingSignBlock(AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a), WoodType.field_227038_a_));
   public static final Block field_222385_bY = func_222382_a("spruce_sign", new StandingSignBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196618_L.func_235697_s_()).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a), WoodType.field_227039_b_));
   public static final Block field_222386_bZ = func_222382_a("birch_sign", new StandingSignBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151658_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a), WoodType.field_227040_c_));
   public static final Block field_222389_ca = func_222382_a("acacia_sign", new StandingSignBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151676_q).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a), WoodType.field_227041_d_));
   public static final Block field_222390_cb = func_222382_a("jungle_sign", new StandingSignBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196620_N.func_235697_s_()).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a), WoodType.field_227042_e_));
   public static final Block field_222391_cc = func_222382_a("dark_oak_sign", new StandingSignBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196623_P.func_235697_s_()).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a), WoodType.field_227043_f_));
   public static final Block field_180413_ao = func_222382_a("oak_door", new DoorBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196662_n.func_235697_s_()).func_200943_b(3.0F).func_200947_a(SoundType.field_185848_a).func_226896_b_()));
   public static final Block field_150468_ap = func_222382_a("ladder", new LadderBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200943_b(0.4F).func_200947_a(SoundType.field_185857_j).func_226896_b_()));
   public static final Block field_150448_aq = func_222382_a("rail", new RailBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200943_b(0.7F).func_200947_a(SoundType.field_185852_e)));
   public static final Block field_196659_cl = func_222382_a("cobblestone_stairs", new StairsBlock(field_150347_e.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_150347_e)));
   public static final Block field_222392_ch = func_222382_a("oak_wall_sign", new WallSignBlock(AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_222384_bX), WoodType.field_227038_a_));
   public static final Block field_222393_ci = func_222382_a("spruce_wall_sign", new WallSignBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196618_L.func_235697_s_()).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_222385_bY), WoodType.field_227039_b_));
   public static final Block field_222394_cj = func_222382_a("birch_wall_sign", new WallSignBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151658_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_222386_bZ), WoodType.field_227040_c_));
   public static final Block field_222395_ck = func_222382_a("acacia_wall_sign", new WallSignBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151676_q).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_222389_ca), WoodType.field_227041_d_));
   public static final Block field_222396_cl = func_222382_a("jungle_wall_sign", new WallSignBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196620_N.func_235697_s_()).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_222390_cb), WoodType.field_227042_e_));
   public static final Block field_222397_cm = func_222382_a("dark_oak_wall_sign", new WallSignBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196623_P.func_235697_s_()).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_222391_cc), WoodType.field_227043_f_));
   public static final Block field_150442_at = func_222382_a("lever", new LeverBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200943_b(0.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_150456_au = func_222382_a("stone_pressure_plate", new PressurePlateBlock(PressurePlateBlock.Sensitivity.MOBS, AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200942_a().func_200943_b(0.5F)));
   public static final Block field_150454_av = func_222382_a("iron_door", new DoorBlock(AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_151668_h).func_235861_h_().func_200943_b(5.0F).func_200947_a(SoundType.field_185852_e).func_226896_b_()));
   public static final Block field_196663_cq = func_222382_a("oak_pressure_plate", new PressurePlateBlock(PressurePlateBlock.Sensitivity.EVERYTHING, AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196662_n.func_235697_s_()).func_200942_a().func_200943_b(0.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196665_cr = func_222382_a("spruce_pressure_plate", new PressurePlateBlock(PressurePlateBlock.Sensitivity.EVERYTHING, AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196664_o.func_235697_s_()).func_200942_a().func_200943_b(0.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196667_cs = func_222382_a("birch_pressure_plate", new PressurePlateBlock(PressurePlateBlock.Sensitivity.EVERYTHING, AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196666_p.func_235697_s_()).func_200942_a().func_200943_b(0.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196669_ct = func_222382_a("jungle_pressure_plate", new PressurePlateBlock(PressurePlateBlock.Sensitivity.EVERYTHING, AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196668_q.func_235697_s_()).func_200942_a().func_200943_b(0.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196671_cu = func_222382_a("acacia_pressure_plate", new PressurePlateBlock(PressurePlateBlock.Sensitivity.EVERYTHING, AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196670_r.func_235697_s_()).func_200942_a().func_200943_b(0.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196673_cv = func_222382_a("dark_oak_pressure_plate", new PressurePlateBlock(PressurePlateBlock.Sensitivity.EVERYTHING, AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196672_s.func_235697_s_()).func_200942_a().func_200943_b(0.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_150450_ax = func_222382_a("redstone_ore", new RedstoneOreBlock(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200944_c().func_235838_a_(func_235420_a_(9)).func_200948_a(3.0F, 3.0F)));
   public static final Block field_150429_aA = func_222382_a("redstone_torch", new RedstoneTorchBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200946_b().func_235838_a_(func_235420_a_(7)).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196677_cy = func_222382_a("redstone_wall_torch", new RedstoneWallTorchBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200946_b().func_235838_a_(func_235420_a_(7)).func_200947_a(SoundType.field_185848_a).func_222379_b(field_150429_aA)));
   public static final Block field_150430_aB = func_222382_a("stone_button", new StoneButtonBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200943_b(0.5F)));
   public static final Block field_150433_aE = func_222382_a("snow", new SnowBlock(AbstractBlock.Properties.func_200945_a(Material.field_151597_y).func_200944_c().func_200943_b(0.1F).func_235861_h_().func_200947_a(SoundType.field_185856_i)));
   public static final Block field_150432_aD = func_222382_a("ice", new IceBlock(AbstractBlock.Properties.func_200945_a(Material.field_151588_w).func_200941_a(0.98F).func_200944_c().func_200943_b(0.5F).func_200947_a(SoundType.field_185853_f).func_226896_b_().func_235827_a_((p_235450_0_, p_235450_1_, p_235450_2_, p_235450_3_) -> {
      return p_235450_3_ == EntityType.field_200786_Z;
   })));
   public static final Block field_196604_cC = func_222382_a("snow_block", new Block(AbstractBlock.Properties.func_200945_a(Material.field_151596_z).func_235861_h_().func_200943_b(0.2F).func_200947_a(SoundType.field_185856_i)));
   public static final Block field_150434_aF = func_222382_a("cactus", new CactusBlock(AbstractBlock.Properties.func_200945_a(Material.field_151570_A).func_200944_c().func_200943_b(0.4F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_150435_aG = func_222382_a("clay", new Block(AbstractBlock.Properties.func_200945_a(Material.field_151571_B).func_200943_b(0.6F).func_200947_a(SoundType.field_185849_b)));
   public static final Block field_196608_cF = func_222382_a("sugar_cane", new SugarCaneBlock(AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200944_c().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_150421_aI = func_222382_a("jukebox", new JukeboxBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151664_l).func_200948_a(2.0F, 6.0F)));
   public static final Block field_180407_aO = func_222382_a("oak_fence", new FenceBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196662_n.func_235697_s_()).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_150423_aK = func_222382_a("pumpkin", new PumpkinBlock(AbstractBlock.Properties.func_200949_a(Material.field_151572_C, MaterialColor.field_151676_q).func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_150424_aL = func_222382_a("netherrack", new NetherrackBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151655_K).func_235861_h_().func_200943_b(0.4F).func_200947_a(SoundType.field_235589_K_)));
   public static final Block field_150425_aM = func_222382_a("soul_sand", new SoulSandBlock(AbstractBlock.Properties.func_200949_a(Material.field_151595_p, MaterialColor.field_151650_B).func_200943_b(0.5F).func_226897_b_(0.4F).func_200947_a(SoundType.field_235585_G_).func_235827_a_(Blocks::func_235437_b_).func_235828_a_(Blocks::func_235426_a_).func_235847_c_(Blocks::func_235426_a_).func_235842_b_(Blocks::func_235426_a_)));
   public static final Block field_235336_cN_ = func_222382_a("soul_soil", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151578_c, MaterialColor.field_151650_B).func_200943_b(0.5F).func_200947_a(SoundType.field_235586_H_)));
   public static final Block field_235337_cO_ = func_222382_a("basalt", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151646_E).func_235861_h_().func_200948_a(1.25F, 4.2F).func_200947_a(SoundType.field_235587_I_)));
   public static final Block field_235338_cP_ = func_222382_a("polished_basalt", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151646_E).func_235861_h_().func_200948_a(1.25F, 4.2F).func_200947_a(SoundType.field_235587_I_)));
   public static final Block field_235339_cQ_ = func_222382_a("soul_torch", new TorchBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200946_b().func_235838_a_((p_235466_0_) -> {
      return 10;
   }).func_200947_a(SoundType.field_185848_a), ParticleTypes.field_239811_B_));
   public static final Block field_235340_cR_ = func_222382_a("soul_wall_torch", new WallTorchBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200946_b().func_235838_a_((p_235465_0_) -> {
      return 10;
   }).func_200947_a(SoundType.field_185848_a).func_222379_b(field_235339_cQ_), ParticleTypes.field_239811_B_));
   public static final Block field_150426_aN = func_222382_a("glowstone", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151592_s, MaterialColor.field_151658_d).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_235838_a_((p_235464_0_) -> {
      return 15;
   })));
   public static final Block field_150427_aO = func_222382_a("nether_portal", new NetherPortalBlock(AbstractBlock.Properties.func_200945_a(Material.field_151567_E).func_200942_a().func_200944_c().func_200943_b(-1.0F).func_200947_a(SoundType.field_185853_f).func_235838_a_((p_235463_0_) -> {
      return 11;
   })));
   public static final Block field_196625_cS = func_222382_a("carved_pumpkin", new CarvedPumpkinBlock(AbstractBlock.Properties.func_200949_a(Material.field_151572_C, MaterialColor.field_151676_q).func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_235827_a_(Blocks::func_235437_b_)));
   public static final Block field_196628_cT = func_222382_a("jack_o_lantern", new CarvedPumpkinBlock(AbstractBlock.Properties.func_200949_a(Material.field_151572_C, MaterialColor.field_151676_q).func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_235838_a_((p_235462_0_) -> {
      return 15;
   }).func_235827_a_(Blocks::func_235437_b_)));
   public static final Block field_150414_aQ = func_222382_a("cake", new CakeBlock(AbstractBlock.Properties.func_200945_a(Material.field_151568_F).func_200943_b(0.5F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196633_cV = func_222382_a("repeater", new RepeaterBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196807_gj = func_222382_a("white_stained_glass", func_235434_b_(DyeColor.WHITE));
   public static final Block field_196808_gk = func_222382_a("orange_stained_glass", func_235434_b_(DyeColor.ORANGE));
   public static final Block field_196809_gl = func_222382_a("magenta_stained_glass", func_235434_b_(DyeColor.MAGENTA));
   public static final Block field_196810_gm = func_222382_a("light_blue_stained_glass", func_235434_b_(DyeColor.LIGHT_BLUE));
   public static final Block field_196811_gn = func_222382_a("yellow_stained_glass", func_235434_b_(DyeColor.YELLOW));
   public static final Block field_196812_go = func_222382_a("lime_stained_glass", func_235434_b_(DyeColor.LIME));
   public static final Block field_196813_gp = func_222382_a("pink_stained_glass", func_235434_b_(DyeColor.PINK));
   public static final Block field_196815_gq = func_222382_a("gray_stained_glass", func_235434_b_(DyeColor.GRAY));
   public static final Block field_196816_gr = func_222382_a("light_gray_stained_glass", func_235434_b_(DyeColor.LIGHT_GRAY));
   public static final Block field_196818_gs = func_222382_a("cyan_stained_glass", func_235434_b_(DyeColor.CYAN));
   public static final Block field_196819_gt = func_222382_a("purple_stained_glass", func_235434_b_(DyeColor.PURPLE));
   public static final Block field_196820_gu = func_222382_a("blue_stained_glass", func_235434_b_(DyeColor.BLUE));
   public static final Block field_196821_gv = func_222382_a("brown_stained_glass", func_235434_b_(DyeColor.BROWN));
   public static final Block field_196822_gw = func_222382_a("green_stained_glass", func_235434_b_(DyeColor.GREEN));
   public static final Block field_196823_gx = func_222382_a("red_stained_glass", func_235434_b_(DyeColor.RED));
   public static final Block field_196824_gy = func_222382_a("black_stained_glass", func_235434_b_(DyeColor.BLACK));
   public static final Block field_196636_cW = func_222382_a("oak_trapdoor", new TrapDoorBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151663_o).func_200943_b(3.0F).func_200947_a(SoundType.field_185848_a).func_226896_b_().func_235827_a_(Blocks::func_235427_a_)));
   public static final Block field_196638_cX = func_222382_a("spruce_trapdoor", new TrapDoorBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151654_J).func_200943_b(3.0F).func_200947_a(SoundType.field_185848_a).func_226896_b_().func_235827_a_(Blocks::func_235427_a_)));
   public static final Block field_196641_cY = func_222382_a("birch_trapdoor", new TrapDoorBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151658_d).func_200943_b(3.0F).func_200947_a(SoundType.field_185848_a).func_226896_b_().func_235827_a_(Blocks::func_235427_a_)));
   public static final Block field_196644_cZ = func_222382_a("jungle_trapdoor", new TrapDoorBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151664_l).func_200943_b(3.0F).func_200947_a(SoundType.field_185848_a).func_226896_b_().func_235827_a_(Blocks::func_235427_a_)));
   public static final Block field_196682_da = func_222382_a("acacia_trapdoor", new TrapDoorBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151676_q).func_200943_b(3.0F).func_200947_a(SoundType.field_185848_a).func_226896_b_().func_235827_a_(Blocks::func_235427_a_)));
   public static final Block field_196684_db = func_222382_a("dark_oak_trapdoor", new TrapDoorBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151650_B).func_200943_b(3.0F).func_200947_a(SoundType.field_185848_a).func_226896_b_().func_235827_a_(Blocks::func_235427_a_)));
   public static final Block field_196696_di = func_222382_a("stone_bricks", new Block(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_196698_dj = func_222382_a("mossy_stone_bricks", new Block(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_196700_dk = func_222382_a("cracked_stone_bricks", new Block(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_196702_dl = func_222382_a("chiseled_stone_bricks", new Block(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_196686_dc = func_222382_a("infested_stone", new SilverfishBlock(field_150348_b, AbstractBlock.Properties.func_200945_a(Material.field_151571_B).func_200948_a(0.0F, 0.75F)));
   public static final Block field_196687_dd = func_222382_a("infested_cobblestone", new SilverfishBlock(field_150347_e, AbstractBlock.Properties.func_200945_a(Material.field_151571_B).func_200948_a(0.0F, 0.75F)));
   public static final Block field_196688_de = func_222382_a("infested_stone_bricks", new SilverfishBlock(field_196696_di, AbstractBlock.Properties.func_200945_a(Material.field_151571_B).func_200948_a(0.0F, 0.75F)));
   public static final Block field_196690_df = func_222382_a("infested_mossy_stone_bricks", new SilverfishBlock(field_196698_dj, AbstractBlock.Properties.func_200945_a(Material.field_151571_B).func_200948_a(0.0F, 0.75F)));
   public static final Block field_196692_dg = func_222382_a("infested_cracked_stone_bricks", new SilverfishBlock(field_196700_dk, AbstractBlock.Properties.func_200945_a(Material.field_151571_B).func_200948_a(0.0F, 0.75F)));
   public static final Block field_196694_dh = func_222382_a("infested_chiseled_stone_bricks", new SilverfishBlock(field_196702_dl, AbstractBlock.Properties.func_200945_a(Material.field_151571_B).func_200948_a(0.0F, 0.75F)));
   public static final Block field_150420_aW = func_222382_a("brown_mushroom_block", new HugeMushroomBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151664_l).func_200943_b(0.2F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_150419_aX = func_222382_a("red_mushroom_block", new HugeMushroomBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151645_D).func_200943_b(0.2F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196706_do = func_222382_a("mushroom_stem", new HugeMushroomBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151659_e).func_200943_b(0.2F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_150411_aY = func_222382_a("iron_bars", new PaneBlock(AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_151660_b).func_235861_h_().func_200948_a(5.0F, 6.0F).func_200947_a(SoundType.field_185852_e).func_226896_b_()));
   public static final Block field_235341_dI_ = func_222382_a("chain", new ChainBlock(AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_151660_b).func_235861_h_().func_200948_a(5.0F, 6.0F).func_200947_a(SoundType.field_235597_S_).func_226896_b_()));
   public static final Block field_150410_aZ = func_222382_a("glass_pane", new PaneBlock(AbstractBlock.Properties.func_200945_a(Material.field_151592_s).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_226896_b_()));
   public static final Block field_150440_ba = func_222382_a("melon", new MelonBlock(AbstractBlock.Properties.func_200949_a(Material.field_151572_C, MaterialColor.field_151672_u).func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196711_ds = func_222382_a("attached_pumpkin_stem", new AttachedStemBlock((StemGrownBlock)field_150423_aK, AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196713_dt = func_222382_a("attached_melon_stem", new AttachedStemBlock((StemGrownBlock)field_150440_ba, AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185848_a)));
   public static final Block field_150393_bb = func_222382_a("pumpkin_stem", new StemBlock((StemGrownBlock)field_150423_aK, AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200944_c().func_200946_b().func_200947_a(SoundType.field_222473_t)));
   public static final Block field_150394_bc = func_222382_a("melon_stem", new StemBlock((StemGrownBlock)field_150440_ba, AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200944_c().func_200946_b().func_200947_a(SoundType.field_222473_t)));
   public static final Block field_150395_bd = func_222382_a("vine", new VineBlock(AbstractBlock.Properties.func_200945_a(Material.field_151582_l).func_200942_a().func_200944_c().func_200943_b(0.2F).func_200947_a(SoundType.field_235601_w_)));
   public static final Block field_180390_bo = func_222382_a("oak_fence_gate", new FenceGateBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196662_n.func_235697_s_()).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_150389_bf = func_222382_a("brick_stairs", new StairsBlock(field_196584_bK.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196584_bK)));
   public static final Block field_150390_bg = func_222382_a("stone_brick_stairs", new StairsBlock(field_196696_di.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196696_di)));
   public static final Block field_150391_bh = func_222382_a("mycelium", new MyceliumBlock(AbstractBlock.Properties.func_200949_a(Material.field_151577_b, MaterialColor.field_151678_z).func_200944_c().func_200943_b(0.6F).func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196651_dG = func_222382_a("lily_pad", new LilyPadBlock(AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200946_b().func_200947_a(SoundType.field_235600_d_).func_226896_b_()));
   public static final Block field_196653_dH = func_222382_a("nether_bricks", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151655_K).func_235861_h_().func_200948_a(2.0F, 6.0F).func_200947_a(SoundType.field_235590_L_)));
   public static final Block field_150386_bk = func_222382_a("nether_brick_fence", new FenceBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151655_K).func_235861_h_().func_200948_a(2.0F, 6.0F).func_200947_a(SoundType.field_235590_L_)));
   public static final Block field_150387_bl = func_222382_a("nether_brick_stairs", new StairsBlock(field_196653_dH.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196653_dH)));
   public static final Block field_150388_bm = func_222382_a("nether_wart", new NetherWartBlock(AbstractBlock.Properties.func_200949_a(Material.field_151585_k, MaterialColor.field_151645_D).func_200942_a().func_200944_c().func_200947_a(SoundType.field_222474_u)));
   public static final Block field_150381_bn = func_222382_a("enchanting_table", new EnchantingTableBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151645_D).func_235861_h_().func_200948_a(5.0F, 1200.0F)));
   public static final Block field_150382_bo = func_222382_a("brewing_stand", new BrewingStandBlock(AbstractBlock.Properties.func_200945_a(Material.field_151573_f).func_235861_h_().func_200943_b(0.5F).func_235838_a_((p_235461_0_) -> {
      return 1;
   }).func_226896_b_()));
   public static final Block field_150383_bp = func_222382_a("cauldron", new CauldronBlock(AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_151665_m).func_235861_h_().func_200943_b(2.0F).func_226896_b_()));
   public static final Block field_150384_bq = func_222382_a("end_portal", new EndPortalBlock(AbstractBlock.Properties.func_200949_a(Material.field_151567_E, MaterialColor.field_151646_E).func_200942_a().func_235838_a_((p_235460_0_) -> {
      return 15;
   }).func_200948_a(-1.0F, 3600000.0F).func_222380_e()));
   public static final Block field_150378_br = func_222382_a("end_portal_frame", new EndPortalFrameBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151651_C).func_200947_a(SoundType.field_185853_f).func_235838_a_((p_235459_0_) -> {
      return 1;
   }).func_200948_a(-1.0F, 3600000.0F).func_222380_e()));
   public static final Block field_150377_bs = func_222382_a("end_stone", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151658_d).func_235861_h_().func_200948_a(3.0F, 9.0F)));
   public static final Block field_150380_bt = func_222382_a("dragon_egg", new DragonEggBlock(AbstractBlock.Properties.func_200949_a(Material.field_151566_D, MaterialColor.field_151646_E).func_200948_a(3.0F, 9.0F).func_235838_a_((p_235458_0_) -> {
      return 1;
   }).func_226896_b_()));
   public static final Block field_150379_bu = func_222382_a("redstone_lamp", new RedstoneLampBlock(AbstractBlock.Properties.func_200945_a(Material.field_151591_t).func_235838_a_(func_235420_a_(15)).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_235827_a_(Blocks::func_235437_b_)));
   public static final Block field_150375_by = func_222382_a("cocoa", new CocoaBlock(AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200944_c().func_200948_a(0.2F, 3.0F).func_200947_a(SoundType.field_185848_a).func_226896_b_()));
   public static final Block field_150372_bz = func_222382_a("sandstone_stairs", new StairsBlock(field_150322_A.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_150322_A)));
   public static final Block field_150412_bA = func_222382_a("emerald_ore", new OreBlock(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200948_a(3.0F, 3.0F)));
   public static final Block field_150477_bB = func_222382_a("ender_chest", new EnderChestBlock(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200948_a(22.5F, 600.0F).func_235838_a_((p_235457_0_) -> {
      return 7;
   })));
   public static final Block field_150479_bC = func_222382_a("tripwire_hook", new TripWireHookBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a()));
   public static final Block field_150473_bD = func_222382_a("tripwire", new TripWireBlock((TripWireHookBlock)field_150479_bC, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a()));
   public static final Block field_150475_bE = func_222382_a("emerald_block", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_151653_I).func_235861_h_().func_200948_a(5.0F, 6.0F).func_200947_a(SoundType.field_185852_e)));
   public static final Block field_150485_bF = func_222382_a("spruce_stairs", new StairsBlock(field_196664_o.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196664_o)));
   public static final Block field_150487_bG = func_222382_a("birch_stairs", new StairsBlock(field_196666_p.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196666_p)));
   public static final Block field_150481_bH = func_222382_a("jungle_stairs", new StairsBlock(field_196668_q.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196668_q)));
   public static final Block field_150483_bI = func_222382_a("command_block", new CommandBlockBlock(AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_151650_B).func_235861_h_().func_200948_a(-1.0F, 3600000.0F).func_222380_e()));
   public static final Block field_150461_bJ = func_222382_a("beacon", new BeaconBlock(AbstractBlock.Properties.func_200949_a(Material.field_151592_s, MaterialColor.field_151648_G).func_200943_b(3.0F).func_235838_a_((p_235456_0_) -> {
      return 15;
   }).func_226896_b_().func_235828_a_(Blocks::func_235436_b_)));
   public static final Block field_150463_bK = func_222382_a("cobblestone_wall", new WallBlock(AbstractBlock.Properties.func_200950_a(field_150347_e)));
   public static final Block field_196723_eg = func_222382_a("mossy_cobblestone_wall", new WallBlock(AbstractBlock.Properties.func_200950_a(field_150347_e)));
   public static final Block field_150457_bL = func_222382_a("flower_pot", new FlowerPotBlock(field_150350_a, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196746_es = func_222382_a("potted_oak_sapling", new FlowerPotBlock(field_196674_t, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196748_et = func_222382_a("potted_spruce_sapling", new FlowerPotBlock(field_196675_u, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196750_eu = func_222382_a("potted_birch_sapling", new FlowerPotBlock(field_196676_v, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196752_ev = func_222382_a("potted_jungle_sapling", new FlowerPotBlock(field_196678_w, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196754_ew = func_222382_a("potted_acacia_sapling", new FlowerPotBlock(field_196679_x, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196755_ex = func_222382_a("potted_dark_oak_sapling", new FlowerPotBlock(field_196680_y, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196683_eB = func_222382_a("potted_fern", new FlowerPotBlock(field_196554_aH, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196744_er = func_222382_a("potted_dandelion", new FlowerPotBlock(field_196605_bc, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196726_ei = func_222382_a("potted_poppy", new FlowerPotBlock(field_196606_bd, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196728_ej = func_222382_a("potted_blue_orchid", new FlowerPotBlock(field_196607_be, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196730_ek = func_222382_a("potted_allium", new FlowerPotBlock(field_196609_bf, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196732_el = func_222382_a("potted_azure_bluet", new FlowerPotBlock(field_196610_bg, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196734_em = func_222382_a("potted_red_tulip", new FlowerPotBlock(field_196612_bh, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196736_en = func_222382_a("potted_orange_tulip", new FlowerPotBlock(field_196613_bi, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196738_eo = func_222382_a("potted_white_tulip", new FlowerPotBlock(field_196614_bj, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196740_ep = func_222382_a("potted_pink_tulip", new FlowerPotBlock(field_196615_bk, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196742_eq = func_222382_a("potted_oxeye_daisy", new FlowerPotBlock(field_196616_bl, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_222398_eF = func_222382_a("potted_cornflower", new FlowerPotBlock(field_222387_by, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_222399_eG = func_222382_a("potted_lily_of_the_valley", new FlowerPotBlock(field_222383_bA, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_222400_eH = func_222382_a("potted_wither_rose", new FlowerPotBlock(field_222388_bz, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196756_ey = func_222382_a("potted_red_mushroom", new FlowerPotBlock(field_150337_Q, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196757_ez = func_222382_a("potted_brown_mushroom", new FlowerPotBlock(field_150338_P, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196681_eA = func_222382_a("potted_dead_bush", new FlowerPotBlock(field_196555_aI, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_196685_eC = func_222382_a("potted_cactus", new FlowerPotBlock(field_150434_aF, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_150459_bM = func_222382_a("carrots", new CarrotBlock(AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200944_c().func_200946_b().func_200947_a(SoundType.field_222472_s)));
   public static final Block field_150469_bN = func_222382_a("potatoes", new PotatoBlock(AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200944_c().func_200946_b().func_200947_a(SoundType.field_222472_s)));
   public static final Block field_196689_eF = func_222382_a("oak_button", new WoodButtonBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200943_b(0.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196691_eG = func_222382_a("spruce_button", new WoodButtonBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200943_b(0.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196693_eH = func_222382_a("birch_button", new WoodButtonBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200943_b(0.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196695_eI = func_222382_a("jungle_button", new WoodButtonBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200943_b(0.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196697_eJ = func_222382_a("acacia_button", new WoodButtonBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200943_b(0.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196699_eK = func_222382_a("dark_oak_button", new WoodButtonBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200943_b(0.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196703_eM = func_222382_a("skeleton_skull", new SkullBlock(SkullBlock.Types.SKELETON, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200943_b(1.0F)));
   public static final Block field_196701_eL = func_222382_a("skeleton_wall_skull", new WallSkullBlock(SkullBlock.Types.SKELETON, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200943_b(1.0F).func_222379_b(field_196703_eM)));
   public static final Block field_196705_eO = func_222382_a("wither_skeleton_skull", new WitherSkeletonSkullBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200943_b(1.0F)));
   public static final Block field_196704_eN = func_222382_a("wither_skeleton_wall_skull", new WitherSkeletonWallSkullBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200943_b(1.0F).func_222379_b(field_196705_eO)));
   public static final Block field_196708_eQ = func_222382_a("zombie_head", new SkullBlock(SkullBlock.Types.ZOMBIE, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200943_b(1.0F)));
   public static final Block field_196707_eP = func_222382_a("zombie_wall_head", new WallSkullBlock(SkullBlock.Types.ZOMBIE, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200943_b(1.0F).func_222379_b(field_196708_eQ)));
   public static final Block field_196710_eS = func_222382_a("player_head", new SkullPlayerBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200943_b(1.0F)));
   public static final Block field_196709_eR = func_222382_a("player_wall_head", new SkullWallPlayerBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200943_b(1.0F).func_222379_b(field_196710_eS)));
   public static final Block field_196714_eU = func_222382_a("creeper_head", new SkullBlock(SkullBlock.Types.CREEPER, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200943_b(1.0F)));
   public static final Block field_196712_eT = func_222382_a("creeper_wall_head", new WallSkullBlock(SkullBlock.Types.CREEPER, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200943_b(1.0F).func_222379_b(field_196714_eU)));
   public static final Block field_196716_eW = func_222382_a("dragon_head", new SkullBlock(SkullBlock.Types.DRAGON, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200943_b(1.0F)));
   public static final Block field_196715_eV = func_222382_a("dragon_wall_head", new WallSkullBlock(SkullBlock.Types.DRAGON, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200943_b(1.0F).func_222379_b(field_196716_eW)));
   public static final Block field_150467_bQ = func_222382_a("anvil", new AnvilBlock(AbstractBlock.Properties.func_200949_a(Material.field_151574_g, MaterialColor.field_151668_h).func_235861_h_().func_200948_a(5.0F, 1200.0F).func_200947_a(SoundType.field_185858_k)));
   public static final Block field_196717_eY = func_222382_a("chipped_anvil", new AnvilBlock(AbstractBlock.Properties.func_200949_a(Material.field_151574_g, MaterialColor.field_151668_h).func_235861_h_().func_200948_a(5.0F, 1200.0F).func_200947_a(SoundType.field_185858_k)));
   public static final Block field_196718_eZ = func_222382_a("damaged_anvil", new AnvilBlock(AbstractBlock.Properties.func_200949_a(Material.field_151574_g, MaterialColor.field_151668_h).func_235861_h_().func_200948_a(5.0F, 1200.0F).func_200947_a(SoundType.field_185858_k)));
   public static final Block field_150447_bR = func_222382_a("trapped_chest", new TrappedChestBlock(AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200943_b(2.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_150445_bS = func_222382_a("light_weighted_pressure_plate", new WeightedPressurePlateBlock(15, AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_151647_F).func_235861_h_().func_200942_a().func_200943_b(0.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_150443_bT = func_222382_a("heavy_weighted_pressure_plate", new WeightedPressurePlateBlock(150, AbstractBlock.Properties.func_200945_a(Material.field_151573_f).func_235861_h_().func_200942_a().func_200943_b(0.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196762_fd = func_222382_a("comparator", new ComparatorBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_200947_a(SoundType.field_185848_a)));
   public static final Block field_150453_bW = func_222382_a("daylight_detector", new DaylightDetectorBlock(AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200943_b(0.2F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_150451_bX = func_222382_a("redstone_block", new RedstoneBlock(AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_151656_f).func_235861_h_().func_200948_a(5.0F, 6.0F).func_200947_a(SoundType.field_185852_e).func_235828_a_(Blocks::func_235436_b_)));
   public static final Block field_196766_fg = func_222382_a("nether_quartz_ore", new OreBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151655_K).func_235861_h_().func_200948_a(3.0F, 3.0F).func_200947_a(SoundType.field_235592_N_)));
   public static final Block field_150438_bZ = func_222382_a("hopper", new HopperBlock(AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_151665_m).func_235861_h_().func_200948_a(3.0F, 4.8F).func_200947_a(SoundType.field_185852_e).func_226896_b_()));
   public static final Block field_150371_ca = func_222382_a("quartz_block", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151677_p).func_235861_h_().func_200943_b(0.8F)));
   public static final Block field_196772_fk = func_222382_a("chiseled_quartz_block", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151677_p).func_235861_h_().func_200943_b(0.8F)));
   public static final Block field_196770_fj = func_222382_a("quartz_pillar", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151677_p).func_235861_h_().func_200943_b(0.8F)));
   public static final Block field_150370_cb = func_222382_a("quartz_stairs", new StairsBlock(field_150371_ca.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_150371_ca)));
   public static final Block field_150408_cc = func_222382_a("activator_rail", new PoweredRailBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200943_b(0.7F).func_200947_a(SoundType.field_185852_e)));
   public static final Block field_150409_cd = func_222382_a("dropper", new DropperBlock(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200943_b(3.5F)));
   public static final Block field_196777_fo = func_222382_a("white_terracotta", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_193561_M).func_235861_h_().func_200948_a(1.25F, 4.2F)));
   public static final Block field_196778_fp = func_222382_a("orange_terracotta", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_193562_N).func_235861_h_().func_200948_a(1.25F, 4.2F)));
   public static final Block field_196780_fq = func_222382_a("magenta_terracotta", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_193563_O).func_235861_h_().func_200948_a(1.25F, 4.2F)));
   public static final Block field_196782_fr = func_222382_a("light_blue_terracotta", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_193564_P).func_235861_h_().func_200948_a(1.25F, 4.2F)));
   public static final Block field_196783_fs = func_222382_a("yellow_terracotta", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_193565_Q).func_235861_h_().func_200948_a(1.25F, 4.2F)));
   public static final Block field_196785_ft = func_222382_a("lime_terracotta", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_193566_R).func_235861_h_().func_200948_a(1.25F, 4.2F)));
   public static final Block field_196787_fu = func_222382_a("pink_terracotta", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_193567_S).func_235861_h_().func_200948_a(1.25F, 4.2F)));
   public static final Block field_196789_fv = func_222382_a("gray_terracotta", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_193568_T).func_235861_h_().func_200948_a(1.25F, 4.2F)));
   public static final Block field_196791_fw = func_222382_a("light_gray_terracotta", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_197655_T).func_235861_h_().func_200948_a(1.25F, 4.2F)));
   public static final Block field_196793_fx = func_222382_a("cyan_terracotta", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_193570_V).func_235861_h_().func_200948_a(1.25F, 4.2F)));
   public static final Block field_196795_fy = func_222382_a("purple_terracotta", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_193571_W).func_235861_h_().func_200948_a(1.25F, 4.2F)));
   public static final Block field_196797_fz = func_222382_a("blue_terracotta", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_193572_X).func_235861_h_().func_200948_a(1.25F, 4.2F)));
   public static final Block field_196719_fA = func_222382_a("brown_terracotta", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_193573_Y).func_235861_h_().func_200948_a(1.25F, 4.2F)));
   public static final Block field_196720_fB = func_222382_a("green_terracotta", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_193574_Z).func_235861_h_().func_200948_a(1.25F, 4.2F)));
   public static final Block field_196721_fC = func_222382_a("red_terracotta", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_193559_aa).func_235861_h_().func_200948_a(1.25F, 4.2F)));
   public static final Block field_196722_fD = func_222382_a("black_terracotta", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_193560_ab).func_235861_h_().func_200948_a(1.25F, 4.2F)));
   public static final Block field_196825_gz = func_222382_a("white_stained_glass_pane", new StainedGlassPaneBlock(DyeColor.WHITE, AbstractBlock.Properties.func_200945_a(Material.field_151592_s).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_226896_b_()));
   public static final Block field_196758_gA = func_222382_a("orange_stained_glass_pane", new StainedGlassPaneBlock(DyeColor.ORANGE, AbstractBlock.Properties.func_200945_a(Material.field_151592_s).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_226896_b_()));
   public static final Block field_196759_gB = func_222382_a("magenta_stained_glass_pane", new StainedGlassPaneBlock(DyeColor.MAGENTA, AbstractBlock.Properties.func_200945_a(Material.field_151592_s).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_226896_b_()));
   public static final Block field_196760_gC = func_222382_a("light_blue_stained_glass_pane", new StainedGlassPaneBlock(DyeColor.LIGHT_BLUE, AbstractBlock.Properties.func_200945_a(Material.field_151592_s).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_226896_b_()));
   public static final Block field_196761_gD = func_222382_a("yellow_stained_glass_pane", new StainedGlassPaneBlock(DyeColor.YELLOW, AbstractBlock.Properties.func_200945_a(Material.field_151592_s).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_226896_b_()));
   public static final Block field_196763_gE = func_222382_a("lime_stained_glass_pane", new StainedGlassPaneBlock(DyeColor.LIME, AbstractBlock.Properties.func_200945_a(Material.field_151592_s).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_226896_b_()));
   public static final Block field_196764_gF = func_222382_a("pink_stained_glass_pane", new StainedGlassPaneBlock(DyeColor.PINK, AbstractBlock.Properties.func_200945_a(Material.field_151592_s).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_226896_b_()));
   public static final Block field_196765_gG = func_222382_a("gray_stained_glass_pane", new StainedGlassPaneBlock(DyeColor.GRAY, AbstractBlock.Properties.func_200945_a(Material.field_151592_s).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_226896_b_()));
   public static final Block field_196767_gH = func_222382_a("light_gray_stained_glass_pane", new StainedGlassPaneBlock(DyeColor.LIGHT_GRAY, AbstractBlock.Properties.func_200945_a(Material.field_151592_s).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_226896_b_()));
   public static final Block field_196768_gI = func_222382_a("cyan_stained_glass_pane", new StainedGlassPaneBlock(DyeColor.CYAN, AbstractBlock.Properties.func_200945_a(Material.field_151592_s).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_226896_b_()));
   public static final Block field_196769_gJ = func_222382_a("purple_stained_glass_pane", new StainedGlassPaneBlock(DyeColor.PURPLE, AbstractBlock.Properties.func_200945_a(Material.field_151592_s).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_226896_b_()));
   public static final Block field_196771_gK = func_222382_a("blue_stained_glass_pane", new StainedGlassPaneBlock(DyeColor.BLUE, AbstractBlock.Properties.func_200945_a(Material.field_151592_s).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_226896_b_()));
   public static final Block field_196773_gL = func_222382_a("brown_stained_glass_pane", new StainedGlassPaneBlock(DyeColor.BROWN, AbstractBlock.Properties.func_200945_a(Material.field_151592_s).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_226896_b_()));
   public static final Block field_196774_gM = func_222382_a("green_stained_glass_pane", new StainedGlassPaneBlock(DyeColor.GREEN, AbstractBlock.Properties.func_200945_a(Material.field_151592_s).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_226896_b_()));
   public static final Block field_196775_gN = func_222382_a("red_stained_glass_pane", new StainedGlassPaneBlock(DyeColor.RED, AbstractBlock.Properties.func_200945_a(Material.field_151592_s).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_226896_b_()));
   public static final Block field_196776_gO = func_222382_a("black_stained_glass_pane", new StainedGlassPaneBlock(DyeColor.BLACK, AbstractBlock.Properties.func_200945_a(Material.field_151592_s).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_226896_b_()));
   public static final Block field_150400_ck = func_222382_a("acacia_stairs", new StairsBlock(field_196670_r.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196670_r)));
   public static final Block field_150401_cl = func_222382_a("dark_oak_stairs", new StairsBlock(field_196672_s.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196672_s)));
   public static final Block field_180399_cE = func_222382_a("slime_block", new SlimeBlock(AbstractBlock.Properties.func_200949_a(Material.field_151571_B, MaterialColor.field_151661_c).func_200941_a(0.8F).func_200947_a(SoundType.field_185859_l).func_226896_b_()));
   public static final Block field_180401_cv = func_222382_a("barrier", new BarrierBlock(AbstractBlock.Properties.func_200945_a(Material.field_175972_I).func_200948_a(-1.0F, 3600000.8F).func_222380_e().func_226896_b_().func_235827_a_(Blocks::func_235427_a_)));
   public static final Block field_180400_cw = func_222382_a("iron_trapdoor", new TrapDoorBlock(AbstractBlock.Properties.func_200945_a(Material.field_151573_f).func_235861_h_().func_200943_b(5.0F).func_200947_a(SoundType.field_185852_e).func_226896_b_().func_235827_a_(Blocks::func_235427_a_)));
   public static final Block field_180397_cI = func_222382_a("prismarine", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151679_y).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_196779_gQ = func_222382_a("prismarine_bricks", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151648_G).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_196781_gR = func_222382_a("dark_prismarine", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151648_G).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_203210_he = func_222382_a("prismarine_stairs", new StairsBlock(field_180397_cI.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_180397_cI)));
   public static final Block field_203211_hf = func_222382_a("prismarine_brick_stairs", new StairsBlock(field_196779_gQ.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196779_gQ)));
   public static final Block field_203212_hg = func_222382_a("dark_prismarine_stairs", new StairsBlock(field_196781_gR.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196781_gR)));
   public static final Block field_203200_bP = func_222382_a("prismarine_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151679_y).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_203201_bQ = func_222382_a("prismarine_brick_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151648_G).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_203202_bR = func_222382_a("dark_prismarine_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151648_G).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_180398_cJ = func_222382_a("sea_lantern", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151592_s, MaterialColor.field_151677_p).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_235838_a_((p_235455_0_) -> {
      return 15;
   })));
   public static final Block field_150407_cf = func_222382_a("hay_block", new HayBlock(AbstractBlock.Properties.func_200949_a(Material.field_151577_b, MaterialColor.field_151673_t).func_200943_b(0.5F).func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196724_fH = func_222382_a("white_carpet", new CarpetBlock(DyeColor.WHITE, AbstractBlock.Properties.func_200949_a(Material.field_151593_r, MaterialColor.field_151666_j).func_200943_b(0.1F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196725_fI = func_222382_a("orange_carpet", new CarpetBlock(DyeColor.ORANGE, AbstractBlock.Properties.func_200949_a(Material.field_151593_r, MaterialColor.field_151676_q).func_200943_b(0.1F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196727_fJ = func_222382_a("magenta_carpet", new CarpetBlock(DyeColor.MAGENTA, AbstractBlock.Properties.func_200949_a(Material.field_151593_r, MaterialColor.field_151675_r).func_200943_b(0.1F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196729_fK = func_222382_a("light_blue_carpet", new CarpetBlock(DyeColor.LIGHT_BLUE, AbstractBlock.Properties.func_200949_a(Material.field_151593_r, MaterialColor.field_151674_s).func_200943_b(0.1F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196731_fL = func_222382_a("yellow_carpet", new CarpetBlock(DyeColor.YELLOW, AbstractBlock.Properties.func_200949_a(Material.field_151593_r, MaterialColor.field_151673_t).func_200943_b(0.1F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196733_fM = func_222382_a("lime_carpet", new CarpetBlock(DyeColor.LIME, AbstractBlock.Properties.func_200949_a(Material.field_151593_r, MaterialColor.field_151672_u).func_200943_b(0.1F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196735_fN = func_222382_a("pink_carpet", new CarpetBlock(DyeColor.PINK, AbstractBlock.Properties.func_200949_a(Material.field_151593_r, MaterialColor.field_151671_v).func_200943_b(0.1F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196737_fO = func_222382_a("gray_carpet", new CarpetBlock(DyeColor.GRAY, AbstractBlock.Properties.func_200949_a(Material.field_151593_r, MaterialColor.field_151670_w).func_200943_b(0.1F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196739_fP = func_222382_a("light_gray_carpet", new CarpetBlock(DyeColor.LIGHT_GRAY, AbstractBlock.Properties.func_200949_a(Material.field_151593_r, MaterialColor.field_197656_x).func_200943_b(0.1F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196741_fQ = func_222382_a("cyan_carpet", new CarpetBlock(DyeColor.CYAN, AbstractBlock.Properties.func_200949_a(Material.field_151593_r, MaterialColor.field_151679_y).func_200943_b(0.1F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196743_fR = func_222382_a("purple_carpet", new CarpetBlock(DyeColor.PURPLE, AbstractBlock.Properties.func_200949_a(Material.field_151593_r, MaterialColor.field_151678_z).func_200943_b(0.1F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196745_fS = func_222382_a("blue_carpet", new CarpetBlock(DyeColor.BLUE, AbstractBlock.Properties.func_200949_a(Material.field_151593_r, MaterialColor.field_151649_A).func_200943_b(0.1F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196747_fT = func_222382_a("brown_carpet", new CarpetBlock(DyeColor.BROWN, AbstractBlock.Properties.func_200949_a(Material.field_151593_r, MaterialColor.field_151650_B).func_200943_b(0.1F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196749_fU = func_222382_a("green_carpet", new CarpetBlock(DyeColor.GREEN, AbstractBlock.Properties.func_200949_a(Material.field_151593_r, MaterialColor.field_151651_C).func_200943_b(0.1F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196751_fV = func_222382_a("red_carpet", new CarpetBlock(DyeColor.RED, AbstractBlock.Properties.func_200949_a(Material.field_151593_r, MaterialColor.field_151645_D).func_200943_b(0.1F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_196753_fW = func_222382_a("black_carpet", new CarpetBlock(DyeColor.BLACK, AbstractBlock.Properties.func_200949_a(Material.field_151593_r, MaterialColor.field_151646_E).func_200943_b(0.1F).func_200947_a(SoundType.field_185854_g)));
   public static final Block field_150405_ch = func_222382_a("terracotta", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151676_q).func_235861_h_().func_200948_a(1.25F, 4.2F)));
   public static final Block field_150402_ci = func_222382_a("coal_block", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151646_E).func_235861_h_().func_200948_a(5.0F, 6.0F)));
   public static final Block field_150403_cj = func_222382_a("packed_ice", new Block(AbstractBlock.Properties.func_200945_a(Material.field_151598_x).func_200941_a(0.98F).func_200943_b(0.5F).func_200947_a(SoundType.field_185853_f)));
   public static final Block field_196800_gd = func_222382_a("sunflower", new TallFlowerBlock(AbstractBlock.Properties.func_200945_a(Material.field_151582_l).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196801_ge = func_222382_a("lilac", new TallFlowerBlock(AbstractBlock.Properties.func_200945_a(Material.field_151582_l).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196802_gf = func_222382_a("rose_bush", new TallFlowerBlock(AbstractBlock.Properties.func_200945_a(Material.field_151582_l).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196803_gg = func_222382_a("peony", new TallFlowerBlock(AbstractBlock.Properties.func_200945_a(Material.field_151582_l).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196804_gh = func_222382_a("tall_grass", new DoublePlantBlock(AbstractBlock.Properties.func_200945_a(Material.field_151582_l).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196805_gi = func_222382_a("large_fern", new DoublePlantBlock(AbstractBlock.Properties.func_200945_a(Material.field_151582_l).func_200942_a().func_200946_b().func_200947_a(SoundType.field_185850_c)));
   public static final Block field_196784_gT = func_222382_a("white_banner", new BannerBlock(DyeColor.WHITE, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196786_gU = func_222382_a("orange_banner", new BannerBlock(DyeColor.ORANGE, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196788_gV = func_222382_a("magenta_banner", new BannerBlock(DyeColor.MAGENTA, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196790_gW = func_222382_a("light_blue_banner", new BannerBlock(DyeColor.LIGHT_BLUE, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196792_gX = func_222382_a("yellow_banner", new BannerBlock(DyeColor.YELLOW, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196794_gY = func_222382_a("lime_banner", new BannerBlock(DyeColor.LIME, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196796_gZ = func_222382_a("pink_banner", new BannerBlock(DyeColor.PINK, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196826_ha = func_222382_a("gray_banner", new BannerBlock(DyeColor.GRAY, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196827_hb = func_222382_a("light_gray_banner", new BannerBlock(DyeColor.LIGHT_GRAY, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196829_hc = func_222382_a("cyan_banner", new BannerBlock(DyeColor.CYAN, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196831_hd = func_222382_a("purple_banner", new BannerBlock(DyeColor.PURPLE, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196833_he = func_222382_a("blue_banner", new BannerBlock(DyeColor.BLUE, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196835_hf = func_222382_a("brown_banner", new BannerBlock(DyeColor.BROWN, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196837_hg = func_222382_a("green_banner", new BannerBlock(DyeColor.GREEN, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196839_hh = func_222382_a("red_banner", new BannerBlock(DyeColor.RED, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196841_hi = func_222382_a("black_banner", new BannerBlock(DyeColor.BLACK, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196843_hj = func_222382_a("white_wall_banner", new WallBannerBlock(DyeColor.WHITE, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_196784_gT)));
   public static final Block field_196845_hk = func_222382_a("orange_wall_banner", new WallBannerBlock(DyeColor.ORANGE, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_196786_gU)));
   public static final Block field_196847_hl = func_222382_a("magenta_wall_banner", new WallBannerBlock(DyeColor.MAGENTA, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_196788_gV)));
   public static final Block field_196849_hm = func_222382_a("light_blue_wall_banner", new WallBannerBlock(DyeColor.LIGHT_BLUE, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_196790_gW)));
   public static final Block field_196851_hn = func_222382_a("yellow_wall_banner", new WallBannerBlock(DyeColor.YELLOW, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_196792_gX)));
   public static final Block field_196853_ho = func_222382_a("lime_wall_banner", new WallBannerBlock(DyeColor.LIME, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_196794_gY)));
   public static final Block field_196855_hp = func_222382_a("pink_wall_banner", new WallBannerBlock(DyeColor.PINK, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_196796_gZ)));
   public static final Block field_196857_hq = func_222382_a("gray_wall_banner", new WallBannerBlock(DyeColor.GRAY, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_196826_ha)));
   public static final Block field_196859_hr = func_222382_a("light_gray_wall_banner", new WallBannerBlock(DyeColor.LIGHT_GRAY, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_196827_hb)));
   public static final Block field_196861_hs = func_222382_a("cyan_wall_banner", new WallBannerBlock(DyeColor.CYAN, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_196829_hc)));
   public static final Block field_196863_ht = func_222382_a("purple_wall_banner", new WallBannerBlock(DyeColor.PURPLE, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_196831_hd)));
   public static final Block field_196865_hu = func_222382_a("blue_wall_banner", new WallBannerBlock(DyeColor.BLUE, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_196833_he)));
   public static final Block field_196867_hv = func_222382_a("brown_wall_banner", new WallBannerBlock(DyeColor.BROWN, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_196835_hf)));
   public static final Block field_196869_hw = func_222382_a("green_wall_banner", new WallBannerBlock(DyeColor.GREEN, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_196837_hg)));
   public static final Block field_196871_hx = func_222382_a("red_wall_banner", new WallBannerBlock(DyeColor.RED, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_196839_hh)));
   public static final Block field_196873_hy = func_222382_a("black_wall_banner", new WallBannerBlock(DyeColor.BLACK, AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_196841_hi)));
   public static final Block field_180395_cM = func_222382_a("red_sandstone", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151676_q).func_235861_h_().func_200943_b(0.8F)));
   public static final Block field_196798_hA = func_222382_a("chiseled_red_sandstone", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151676_q).func_235861_h_().func_200943_b(0.8F)));
   public static final Block field_196799_hB = func_222382_a("cut_red_sandstone", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151676_q).func_235861_h_().func_200943_b(0.8F)));
   public static final Block field_180396_cN = func_222382_a("red_sandstone_stairs", new StairsBlock(field_180395_cM.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_180395_cM)));
   public static final Block field_196622_bq = func_222382_a("oak_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151663_o).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196624_br = func_222382_a("spruce_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151654_J).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196627_bs = func_222382_a("birch_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151658_d).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196630_bt = func_222382_a("jungle_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151664_l).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196632_bu = func_222382_a("acacia_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151676_q).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_196635_bv = func_222382_a("dark_oak_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151650_B).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_150333_U = func_222382_a("stone_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151665_m).func_235861_h_().func_200948_a(2.0F, 6.0F)));
   public static final Block field_222401_hJ = func_222382_a("smooth_stone_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151665_m).func_235861_h_().func_200948_a(2.0F, 6.0F)));
   public static final Block field_196640_bx = func_222382_a("sandstone_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151658_d).func_235861_h_().func_200948_a(2.0F, 6.0F)));
   public static final Block field_222402_hL = func_222382_a("cut_sandstone_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151658_d).func_235861_h_().func_200948_a(2.0F, 6.0F)));
   public static final Block field_196643_by = func_222382_a("petrified_oak_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151663_o).func_235861_h_().func_200948_a(2.0F, 6.0F)));
   public static final Block field_196646_bz = func_222382_a("cobblestone_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151665_m).func_235861_h_().func_200948_a(2.0F, 6.0F)));
   public static final Block field_196571_bA = func_222382_a("brick_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151645_D).func_235861_h_().func_200948_a(2.0F, 6.0F)));
   public static final Block field_196573_bB = func_222382_a("stone_brick_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151665_m).func_235861_h_().func_200948_a(2.0F, 6.0F)));
   public static final Block field_196575_bC = func_222382_a("nether_brick_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151655_K).func_235861_h_().func_200948_a(2.0F, 6.0F).func_200947_a(SoundType.field_235590_L_)));
   public static final Block field_196576_bD = func_222382_a("quartz_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151677_p).func_235861_h_().func_200948_a(2.0F, 6.0F)));
   public static final Block field_196578_bE = func_222382_a("red_sandstone_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151676_q).func_235861_h_().func_200948_a(2.0F, 6.0F)));
   public static final Block field_222403_hT = func_222382_a("cut_red_sandstone_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151676_q).func_235861_h_().func_200948_a(2.0F, 6.0F)));
   public static final Block field_185771_cX = func_222382_a("purpur_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151675_r).func_235861_h_().func_200948_a(2.0F, 6.0F)));
   public static final Block field_196579_bG = func_222382_a("smooth_stone", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151665_m).func_235861_h_().func_200948_a(2.0F, 6.0F)));
   public static final Block field_196580_bH = func_222382_a("smooth_sandstone", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151658_d).func_235861_h_().func_200948_a(2.0F, 6.0F)));
   public static final Block field_196581_bI = func_222382_a("smooth_quartz", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151677_p).func_235861_h_().func_200948_a(2.0F, 6.0F)));
   public static final Block field_196582_bJ = func_222382_a("smooth_red_sandstone", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151676_q).func_235861_h_().func_200948_a(2.0F, 6.0F)));
   public static final Block field_180391_bp = func_222382_a("spruce_fence_gate", new FenceGateBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196664_o.func_235697_s_()).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_180392_bq = func_222382_a("birch_fence_gate", new FenceGateBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196666_p.func_235697_s_()).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_180386_br = func_222382_a("jungle_fence_gate", new FenceGateBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196668_q.func_235697_s_()).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_180387_bt = func_222382_a("acacia_fence_gate", new FenceGateBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196670_r.func_235697_s_()).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_180385_bs = func_222382_a("dark_oak_fence_gate", new FenceGateBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196672_s.func_235697_s_()).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_180408_aP = func_222382_a("spruce_fence", new FenceBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196664_o.func_235697_s_()).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_180404_aQ = func_222382_a("birch_fence", new FenceBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196666_p.func_235697_s_()).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_180403_aR = func_222382_a("jungle_fence", new FenceBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196668_q.func_235697_s_()).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_180405_aT = func_222382_a("acacia_fence", new FenceBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196670_r.func_235697_s_()).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_180406_aS = func_222382_a("dark_oak_fence", new FenceBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196672_s.func_235697_s_()).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_180414_ap = func_222382_a("spruce_door", new DoorBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196664_o.func_235697_s_()).func_200943_b(3.0F).func_200947_a(SoundType.field_185848_a).func_226896_b_()));
   public static final Block field_180412_aq = func_222382_a("birch_door", new DoorBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196666_p.func_235697_s_()).func_200943_b(3.0F).func_200947_a(SoundType.field_185848_a).func_226896_b_()));
   public static final Block field_180411_ar = func_222382_a("jungle_door", new DoorBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196668_q.func_235697_s_()).func_200943_b(3.0F).func_200947_a(SoundType.field_185848_a).func_226896_b_()));
   public static final Block field_180410_as = func_222382_a("acacia_door", new DoorBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196670_r.func_235697_s_()).func_200943_b(3.0F).func_200947_a(SoundType.field_185848_a).func_226896_b_()));
   public static final Block field_180409_at = func_222382_a("dark_oak_door", new DoorBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, field_196672_s.func_235697_s_()).func_200943_b(3.0F).func_200947_a(SoundType.field_185848_a).func_226896_b_()));
   public static final Block field_185764_cQ = func_222382_a("end_rod", new EndRodBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_235838_a_((p_235454_0_) -> {
      return 14;
   }).func_200947_a(SoundType.field_185848_a).func_226896_b_()));
   public static final Block field_185765_cR = func_222382_a("chorus_plant", new ChorusPlantBlock(AbstractBlock.Properties.func_200949_a(Material.field_151585_k, MaterialColor.field_151678_z).func_200943_b(0.4F).func_200947_a(SoundType.field_185848_a).func_226896_b_()));
   public static final Block field_185766_cS = func_222382_a("chorus_flower", new ChorusFlowerBlock((ChorusPlantBlock)field_185765_cR, AbstractBlock.Properties.func_200949_a(Material.field_151585_k, MaterialColor.field_151678_z).func_200944_c().func_200943_b(0.4F).func_200947_a(SoundType.field_185848_a).func_226896_b_()));
   public static final Block field_185767_cT = func_222382_a("purpur_block", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151675_r).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_185768_cU = func_222382_a("purpur_pillar", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151675_r).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_185769_cV = func_222382_a("purpur_stairs", new StairsBlock(field_185767_cT.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_185767_cT)));
   public static final Block field_196806_hJ = func_222382_a("end_stone_bricks", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151658_d).func_235861_h_().func_200948_a(3.0F, 9.0F)));
   public static final Block field_185773_cZ = func_222382_a("beetroots", new BeetrootBlock(AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200942_a().func_200944_c().func_200946_b().func_200947_a(SoundType.field_222472_s)));
   public static final Block field_185774_da = func_222382_a("grass_path", new GrassPathBlock(AbstractBlock.Properties.func_200945_a(Material.field_151578_c).func_200943_b(0.65F).func_200947_a(SoundType.field_185850_c).func_235847_c_(Blocks::func_235426_a_).func_235842_b_(Blocks::func_235426_a_)));
   public static final Block field_185775_db = func_222382_a("end_gateway", new EndGatewayBlock(AbstractBlock.Properties.func_200949_a(Material.field_151567_E, MaterialColor.field_151646_E).func_200942_a().func_235838_a_((p_235453_0_) -> {
      return 15;
   }).func_200948_a(-1.0F, 3600000.0F).func_222380_e()));
   public static final Block field_185776_dc = func_222382_a("repeating_command_block", new CommandBlockBlock(AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_151678_z).func_235861_h_().func_200948_a(-1.0F, 3600000.0F).func_222380_e()));
   public static final Block field_185777_dd = func_222382_a("chain_command_block", new CommandBlockBlock(AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_151651_C).func_235861_h_().func_200948_a(-1.0F, 3600000.0F).func_222380_e()));
   public static final Block field_185778_de = func_222382_a("frosted_ice", new FrostedIceBlock(AbstractBlock.Properties.func_200945_a(Material.field_151588_w).func_200941_a(0.98F).func_200944_c().func_200943_b(0.5F).func_200947_a(SoundType.field_185853_f).func_226896_b_().func_235827_a_((p_235448_0_, p_235448_1_, p_235448_2_, p_235448_3_) -> {
      return p_235448_3_ == EntityType.field_200786_Z;
   })));
   public static final Block field_196814_hQ = func_222382_a("magma_block", new MagmaBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151655_K).func_235861_h_().func_235838_a_((p_235452_0_) -> {
      return 3;
   }).func_200944_c().func_200943_b(0.5F).func_235827_a_((p_235445_0_, p_235445_1_, p_235445_2_, p_235445_3_) -> {
      return p_235445_3_.func_220338_c();
   }).func_235852_d_(Blocks::func_235426_a_).func_235856_e_(Blocks::func_235426_a_)));
   public static final Block field_189878_dg = func_222382_a("nether_wart_block", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151577_b, MaterialColor.field_151645_D).func_200943_b(1.0F).func_200947_a(SoundType.field_235588_J_)));
   public static final Block field_196817_hS = func_222382_a("red_nether_bricks", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151655_K).func_235861_h_().func_200948_a(2.0F, 6.0F).func_200947_a(SoundType.field_235590_L_)));
   public static final Block field_189880_di = func_222382_a("bone_block", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151658_d).func_235861_h_().func_200943_b(2.0F).func_200947_a(SoundType.field_235593_O_)));
   public static final Block field_189881_dj = func_222382_a("structure_void", new StructureVoidBlock(AbstractBlock.Properties.func_200945_a(Material.field_189963_J).func_200942_a().func_222380_e()));
   public static final Block field_190976_dk = func_222382_a("observer", new ObserverBlock(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_200943_b(3.0F).func_235861_h_().func_235828_a_(Blocks::func_235436_b_)));
   public static final Block field_204409_il = func_222382_a("shulker_box", func_235423_a_((DyeColor)null, AbstractBlock.Properties.func_200945_a(Material.field_215711_w)));
   public static final Block field_190977_dl = func_222382_a("white_shulker_box", func_235423_a_(DyeColor.WHITE, AbstractBlock.Properties.func_200949_a(Material.field_215711_w, MaterialColor.field_151666_j)));
   public static final Block field_190978_dm = func_222382_a("orange_shulker_box", func_235423_a_(DyeColor.ORANGE, AbstractBlock.Properties.func_200949_a(Material.field_215711_w, MaterialColor.field_151676_q)));
   public static final Block field_190979_dn = func_222382_a("magenta_shulker_box", func_235423_a_(DyeColor.MAGENTA, AbstractBlock.Properties.func_200949_a(Material.field_215711_w, MaterialColor.field_151675_r)));
   public static final Block field_190980_do = func_222382_a("light_blue_shulker_box", func_235423_a_(DyeColor.LIGHT_BLUE, AbstractBlock.Properties.func_200949_a(Material.field_215711_w, MaterialColor.field_151674_s)));
   public static final Block field_190981_dp = func_222382_a("yellow_shulker_box", func_235423_a_(DyeColor.YELLOW, AbstractBlock.Properties.func_200949_a(Material.field_215711_w, MaterialColor.field_151673_t)));
   public static final Block field_190982_dq = func_222382_a("lime_shulker_box", func_235423_a_(DyeColor.LIME, AbstractBlock.Properties.func_200949_a(Material.field_215711_w, MaterialColor.field_151672_u)));
   public static final Block field_190983_dr = func_222382_a("pink_shulker_box", func_235423_a_(DyeColor.PINK, AbstractBlock.Properties.func_200949_a(Material.field_215711_w, MaterialColor.field_151671_v)));
   public static final Block field_190984_ds = func_222382_a("gray_shulker_box", func_235423_a_(DyeColor.GRAY, AbstractBlock.Properties.func_200949_a(Material.field_215711_w, MaterialColor.field_151670_w)));
   public static final Block field_196875_ie = func_222382_a("light_gray_shulker_box", func_235423_a_(DyeColor.LIGHT_GRAY, AbstractBlock.Properties.func_200949_a(Material.field_215711_w, MaterialColor.field_197656_x)));
   public static final Block field_190986_du = func_222382_a("cyan_shulker_box", func_235423_a_(DyeColor.CYAN, AbstractBlock.Properties.func_200949_a(Material.field_215711_w, MaterialColor.field_151679_y)));
   public static final Block field_190987_dv = func_222382_a("purple_shulker_box", func_235423_a_(DyeColor.PURPLE, AbstractBlock.Properties.func_200949_a(Material.field_215711_w, MaterialColor.field_193571_W)));
   public static final Block field_190988_dw = func_222382_a("blue_shulker_box", func_235423_a_(DyeColor.BLUE, AbstractBlock.Properties.func_200949_a(Material.field_215711_w, MaterialColor.field_151649_A)));
   public static final Block field_190989_dx = func_222382_a("brown_shulker_box", func_235423_a_(DyeColor.BROWN, AbstractBlock.Properties.func_200949_a(Material.field_215711_w, MaterialColor.field_151650_B)));
   public static final Block field_190990_dy = func_222382_a("green_shulker_box", func_235423_a_(DyeColor.GREEN, AbstractBlock.Properties.func_200949_a(Material.field_215711_w, MaterialColor.field_151651_C)));
   public static final Block field_190991_dz = func_222382_a("red_shulker_box", func_235423_a_(DyeColor.RED, AbstractBlock.Properties.func_200949_a(Material.field_215711_w, MaterialColor.field_151645_D)));
   public static final Block field_190975_dA = func_222382_a("black_shulker_box", func_235423_a_(DyeColor.BLACK, AbstractBlock.Properties.func_200949_a(Material.field_215711_w, MaterialColor.field_151646_E)));
   public static final Block field_192427_dB = func_222382_a("white_glazed_terracotta", new GlazedTerracottaBlock(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.WHITE).func_235861_h_().func_200943_b(1.4F)));
   public static final Block field_192428_dC = func_222382_a("orange_glazed_terracotta", new GlazedTerracottaBlock(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.ORANGE).func_235861_h_().func_200943_b(1.4F)));
   public static final Block field_192429_dD = func_222382_a("magenta_glazed_terracotta", new GlazedTerracottaBlock(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.MAGENTA).func_235861_h_().func_200943_b(1.4F)));
   public static final Block field_192430_dE = func_222382_a("light_blue_glazed_terracotta", new GlazedTerracottaBlock(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.LIGHT_BLUE).func_235861_h_().func_200943_b(1.4F)));
   public static final Block field_192431_dF = func_222382_a("yellow_glazed_terracotta", new GlazedTerracottaBlock(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.YELLOW).func_235861_h_().func_200943_b(1.4F)));
   public static final Block field_192432_dG = func_222382_a("lime_glazed_terracotta", new GlazedTerracottaBlock(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.LIME).func_235861_h_().func_200943_b(1.4F)));
   public static final Block field_192433_dH = func_222382_a("pink_glazed_terracotta", new GlazedTerracottaBlock(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.PINK).func_235861_h_().func_200943_b(1.4F)));
   public static final Block field_192434_dI = func_222382_a("gray_glazed_terracotta", new GlazedTerracottaBlock(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.GRAY).func_235861_h_().func_200943_b(1.4F)));
   public static final Block field_196876_iu = func_222382_a("light_gray_glazed_terracotta", new GlazedTerracottaBlock(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.LIGHT_GRAY).func_235861_h_().func_200943_b(1.4F)));
   public static final Block field_192436_dK = func_222382_a("cyan_glazed_terracotta", new GlazedTerracottaBlock(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.CYAN).func_235861_h_().func_200943_b(1.4F)));
   public static final Block field_192437_dL = func_222382_a("purple_glazed_terracotta", new GlazedTerracottaBlock(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.PURPLE).func_235861_h_().func_200943_b(1.4F)));
   public static final Block field_192438_dM = func_222382_a("blue_glazed_terracotta", new GlazedTerracottaBlock(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.BLUE).func_235861_h_().func_200943_b(1.4F)));
   public static final Block field_192439_dN = func_222382_a("brown_glazed_terracotta", new GlazedTerracottaBlock(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.BROWN).func_235861_h_().func_200943_b(1.4F)));
   public static final Block field_192440_dO = func_222382_a("green_glazed_terracotta", new GlazedTerracottaBlock(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.GREEN).func_235861_h_().func_200943_b(1.4F)));
   public static final Block field_192441_dP = func_222382_a("red_glazed_terracotta", new GlazedTerracottaBlock(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.RED).func_235861_h_().func_200943_b(1.4F)));
   public static final Block field_192442_dQ = func_222382_a("black_glazed_terracotta", new GlazedTerracottaBlock(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.BLACK).func_235861_h_().func_200943_b(1.4F)));
   public static final Block field_196828_iC = func_222382_a("white_concrete", new Block(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.WHITE).func_235861_h_().func_200943_b(1.8F)));
   public static final Block field_196830_iD = func_222382_a("orange_concrete", new Block(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.ORANGE).func_235861_h_().func_200943_b(1.8F)));
   public static final Block field_196832_iE = func_222382_a("magenta_concrete", new Block(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.MAGENTA).func_235861_h_().func_200943_b(1.8F)));
   public static final Block field_196834_iF = func_222382_a("light_blue_concrete", new Block(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.LIGHT_BLUE).func_235861_h_().func_200943_b(1.8F)));
   public static final Block field_196836_iG = func_222382_a("yellow_concrete", new Block(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.YELLOW).func_235861_h_().func_200943_b(1.8F)));
   public static final Block field_196838_iH = func_222382_a("lime_concrete", new Block(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.LIME).func_235861_h_().func_200943_b(1.8F)));
   public static final Block field_196840_iI = func_222382_a("pink_concrete", new Block(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.PINK).func_235861_h_().func_200943_b(1.8F)));
   public static final Block field_196842_iJ = func_222382_a("gray_concrete", new Block(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.GRAY).func_235861_h_().func_200943_b(1.8F)));
   public static final Block field_196844_iK = func_222382_a("light_gray_concrete", new Block(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.LIGHT_GRAY).func_235861_h_().func_200943_b(1.8F)));
   public static final Block field_196846_iL = func_222382_a("cyan_concrete", new Block(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.CYAN).func_235861_h_().func_200943_b(1.8F)));
   public static final Block field_196848_iM = func_222382_a("purple_concrete", new Block(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.PURPLE).func_235861_h_().func_200943_b(1.8F)));
   public static final Block field_196850_iN = func_222382_a("blue_concrete", new Block(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.BLUE).func_235861_h_().func_200943_b(1.8F)));
   public static final Block field_196852_iO = func_222382_a("brown_concrete", new Block(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.BROWN).func_235861_h_().func_200943_b(1.8F)));
   public static final Block field_196854_iP = func_222382_a("green_concrete", new Block(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.GREEN).func_235861_h_().func_200943_b(1.8F)));
   public static final Block field_196856_iQ = func_222382_a("red_concrete", new Block(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.RED).func_235861_h_().func_200943_b(1.8F)));
   public static final Block field_196858_iR = func_222382_a("black_concrete", new Block(AbstractBlock.Properties.func_200952_a(Material.field_151576_e, DyeColor.BLACK).func_235861_h_().func_200943_b(1.8F)));
   public static final Block field_196860_iS = func_222382_a("white_concrete_powder", new ConcretePowderBlock(field_196828_iC, AbstractBlock.Properties.func_200952_a(Material.field_151595_p, DyeColor.WHITE).func_200943_b(0.5F).func_200947_a(SoundType.field_185855_h)));
   public static final Block field_196862_iT = func_222382_a("orange_concrete_powder", new ConcretePowderBlock(field_196830_iD, AbstractBlock.Properties.func_200952_a(Material.field_151595_p, DyeColor.ORANGE).func_200943_b(0.5F).func_200947_a(SoundType.field_185855_h)));
   public static final Block field_196864_iU = func_222382_a("magenta_concrete_powder", new ConcretePowderBlock(field_196832_iE, AbstractBlock.Properties.func_200952_a(Material.field_151595_p, DyeColor.MAGENTA).func_200943_b(0.5F).func_200947_a(SoundType.field_185855_h)));
   public static final Block field_196866_iV = func_222382_a("light_blue_concrete_powder", new ConcretePowderBlock(field_196834_iF, AbstractBlock.Properties.func_200952_a(Material.field_151595_p, DyeColor.LIGHT_BLUE).func_200943_b(0.5F).func_200947_a(SoundType.field_185855_h)));
   public static final Block field_196868_iW = func_222382_a("yellow_concrete_powder", new ConcretePowderBlock(field_196836_iG, AbstractBlock.Properties.func_200952_a(Material.field_151595_p, DyeColor.YELLOW).func_200943_b(0.5F).func_200947_a(SoundType.field_185855_h)));
   public static final Block field_196870_iX = func_222382_a("lime_concrete_powder", new ConcretePowderBlock(field_196838_iH, AbstractBlock.Properties.func_200952_a(Material.field_151595_p, DyeColor.LIME).func_200943_b(0.5F).func_200947_a(SoundType.field_185855_h)));
   public static final Block field_196872_iY = func_222382_a("pink_concrete_powder", new ConcretePowderBlock(field_196840_iI, AbstractBlock.Properties.func_200952_a(Material.field_151595_p, DyeColor.PINK).func_200943_b(0.5F).func_200947_a(SoundType.field_185855_h)));
   public static final Block field_196874_iZ = func_222382_a("gray_concrete_powder", new ConcretePowderBlock(field_196842_iJ, AbstractBlock.Properties.func_200952_a(Material.field_151595_p, DyeColor.GRAY).func_200943_b(0.5F).func_200947_a(SoundType.field_185855_h)));
   public static final Block field_196877_ja = func_222382_a("light_gray_concrete_powder", new ConcretePowderBlock(field_196844_iK, AbstractBlock.Properties.func_200952_a(Material.field_151595_p, DyeColor.LIGHT_GRAY).func_200943_b(0.5F).func_200947_a(SoundType.field_185855_h)));
   public static final Block field_196878_jb = func_222382_a("cyan_concrete_powder", new ConcretePowderBlock(field_196846_iL, AbstractBlock.Properties.func_200952_a(Material.field_151595_p, DyeColor.CYAN).func_200943_b(0.5F).func_200947_a(SoundType.field_185855_h)));
   public static final Block field_196879_jc = func_222382_a("purple_concrete_powder", new ConcretePowderBlock(field_196848_iM, AbstractBlock.Properties.func_200952_a(Material.field_151595_p, DyeColor.PURPLE).func_200943_b(0.5F).func_200947_a(SoundType.field_185855_h)));
   public static final Block field_196880_jd = func_222382_a("blue_concrete_powder", new ConcretePowderBlock(field_196850_iN, AbstractBlock.Properties.func_200952_a(Material.field_151595_p, DyeColor.BLUE).func_200943_b(0.5F).func_200947_a(SoundType.field_185855_h)));
   public static final Block field_196881_je = func_222382_a("brown_concrete_powder", new ConcretePowderBlock(field_196852_iO, AbstractBlock.Properties.func_200952_a(Material.field_151595_p, DyeColor.BROWN).func_200943_b(0.5F).func_200947_a(SoundType.field_185855_h)));
   public static final Block field_196882_jf = func_222382_a("green_concrete_powder", new ConcretePowderBlock(field_196854_iP, AbstractBlock.Properties.func_200952_a(Material.field_151595_p, DyeColor.GREEN).func_200943_b(0.5F).func_200947_a(SoundType.field_185855_h)));
   public static final Block field_196883_jg = func_222382_a("red_concrete_powder", new ConcretePowderBlock(field_196856_iQ, AbstractBlock.Properties.func_200952_a(Material.field_151595_p, DyeColor.RED).func_200943_b(0.5F).func_200947_a(SoundType.field_185855_h)));
   public static final Block field_196884_jh = func_222382_a("black_concrete_powder", new ConcretePowderBlock(field_196858_iR, AbstractBlock.Properties.func_200952_a(Material.field_151595_p, DyeColor.BLACK).func_200943_b(0.5F).func_200947_a(SoundType.field_185855_h)));
   public static final Block field_203214_jx = func_222382_a("kelp", new KelpTopBlock(AbstractBlock.Properties.func_200945_a(Material.field_203243_f).func_200942_a().func_200944_c().func_200946_b().func_200947_a(SoundType.field_211382_m)));
   public static final Block field_203215_jy = func_222382_a("kelp_plant", new KelpBlock(AbstractBlock.Properties.func_200945_a(Material.field_203243_f).func_200942_a().func_200946_b().func_200947_a(SoundType.field_211382_m)));
   public static final Block field_203216_jz = func_222382_a("dried_kelp_block", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151577_b, MaterialColor.field_151651_C).func_200948_a(0.5F, 2.5F).func_200947_a(SoundType.field_185850_c)));
   public static final Block field_203213_jA = func_222382_a("turtle_egg", new TurtleEggBlock(AbstractBlock.Properties.func_200949_a(Material.field_151566_D, MaterialColor.field_151658_d).func_200943_b(0.5F).func_200947_a(SoundType.field_185852_e).func_200944_c().func_226896_b_()));
   public static final Block field_204404_jE = func_222382_a("dead_tube_coral_block", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_204405_jF = func_222382_a("dead_brain_coral_block", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_204406_jG = func_222382_a("dead_bubble_coral_block", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_204407_jH = func_222382_a("dead_fire_coral_block", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_204408_jI = func_222382_a("dead_horn_coral_block", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_203963_jE = func_222382_a("tube_coral_block", new CoralBlock(field_204404_jE, AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151649_A).func_235861_h_().func_200948_a(1.5F, 6.0F).func_200947_a(SoundType.field_211383_n)));
   public static final Block field_203964_jF = func_222382_a("brain_coral_block", new CoralBlock(field_204405_jF, AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151671_v).func_235861_h_().func_200948_a(1.5F, 6.0F).func_200947_a(SoundType.field_211383_n)));
   public static final Block field_203965_jG = func_222382_a("bubble_coral_block", new CoralBlock(field_204406_jG, AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151678_z).func_235861_h_().func_200948_a(1.5F, 6.0F).func_200947_a(SoundType.field_211383_n)));
   public static final Block field_203966_jH = func_222382_a("fire_coral_block", new CoralBlock(field_204407_jH, AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151645_D).func_235861_h_().func_200948_a(1.5F, 6.0F).func_200947_a(SoundType.field_211383_n)));
   public static final Block field_203967_jI = func_222382_a("horn_coral_block", new CoralBlock(field_204408_jI, AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151673_t).func_235861_h_().func_200948_a(1.5F, 6.0F).func_200947_a(SoundType.field_211383_n)));
   public static final Block field_212585_jY = func_222382_a("dead_tube_coral", new DeadCoralPlantBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200942_a().func_200946_b()));
   public static final Block field_212586_jZ = func_222382_a("dead_brain_coral", new DeadCoralPlantBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200942_a().func_200946_b()));
   public static final Block field_212587_ka = func_222382_a("dead_bubble_coral", new DeadCoralPlantBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200942_a().func_200946_b()));
   public static final Block field_212588_kb = func_222382_a("dead_fire_coral", new DeadCoralPlantBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200942_a().func_200946_b()));
   public static final Block field_212589_kc = func_222382_a("dead_horn_coral", new DeadCoralPlantBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200942_a().func_200946_b()));
   public static final Block field_204278_jJ = func_222382_a("tube_coral", new CoralPlantBlock(field_212585_jY, AbstractBlock.Properties.func_200949_a(Material.field_203243_f, MaterialColor.field_151649_A).func_200942_a().func_200946_b().func_200947_a(SoundType.field_211382_m)));
   public static final Block field_204279_jK = func_222382_a("brain_coral", new CoralPlantBlock(field_212586_jZ, AbstractBlock.Properties.func_200949_a(Material.field_203243_f, MaterialColor.field_151671_v).func_200942_a().func_200946_b().func_200947_a(SoundType.field_211382_m)));
   public static final Block field_204280_jL = func_222382_a("bubble_coral", new CoralPlantBlock(field_212587_ka, AbstractBlock.Properties.func_200949_a(Material.field_203243_f, MaterialColor.field_151678_z).func_200942_a().func_200946_b().func_200947_a(SoundType.field_211382_m)));
   public static final Block field_204281_jM = func_222382_a("fire_coral", new CoralPlantBlock(field_212588_kb, AbstractBlock.Properties.func_200949_a(Material.field_203243_f, MaterialColor.field_151645_D).func_200942_a().func_200946_b().func_200947_a(SoundType.field_211382_m)));
   public static final Block field_204282_jN = func_222382_a("horn_coral", new CoralPlantBlock(field_212589_kc, AbstractBlock.Properties.func_200949_a(Material.field_203243_f, MaterialColor.field_151673_t).func_200942_a().func_200946_b().func_200947_a(SoundType.field_211382_m)));
   public static final Block field_211901_kp = func_222382_a("dead_tube_coral_fan", new CoralFanBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200942_a().func_200946_b()));
   public static final Block field_211902_kq = func_222382_a("dead_brain_coral_fan", new CoralFanBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200942_a().func_200946_b()));
   public static final Block field_211903_kr = func_222382_a("dead_bubble_coral_fan", new CoralFanBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200942_a().func_200946_b()));
   public static final Block field_211904_ks = func_222382_a("dead_fire_coral_fan", new CoralFanBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200942_a().func_200946_b()));
   public static final Block field_211905_kt = func_222382_a("dead_horn_coral_fan", new CoralFanBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200942_a().func_200946_b()));
   public static final Block field_204743_jR = func_222382_a("tube_coral_fan", new CoralFinBlock(field_211901_kp, AbstractBlock.Properties.func_200949_a(Material.field_203243_f, MaterialColor.field_151649_A).func_200942_a().func_200946_b().func_200947_a(SoundType.field_211382_m)));
   public static final Block field_204744_jS = func_222382_a("brain_coral_fan", new CoralFinBlock(field_211902_kq, AbstractBlock.Properties.func_200949_a(Material.field_203243_f, MaterialColor.field_151671_v).func_200942_a().func_200946_b().func_200947_a(SoundType.field_211382_m)));
   public static final Block field_204745_jT = func_222382_a("bubble_coral_fan", new CoralFinBlock(field_211903_kr, AbstractBlock.Properties.func_200949_a(Material.field_203243_f, MaterialColor.field_151678_z).func_200942_a().func_200946_b().func_200947_a(SoundType.field_211382_m)));
   public static final Block field_204746_jU = func_222382_a("fire_coral_fan", new CoralFinBlock(field_211904_ks, AbstractBlock.Properties.func_200949_a(Material.field_203243_f, MaterialColor.field_151645_D).func_200942_a().func_200946_b().func_200947_a(SoundType.field_211382_m)));
   public static final Block field_204747_jV = func_222382_a("horn_coral_fan", new CoralFinBlock(field_211905_kt, AbstractBlock.Properties.func_200949_a(Material.field_203243_f, MaterialColor.field_151673_t).func_200942_a().func_200946_b().func_200947_a(SoundType.field_211382_m)));
   public static final Block field_211896_kk = func_222382_a("dead_tube_coral_wall_fan", new DeadCoralWallFanBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200942_a().func_200946_b().func_222379_b(field_211901_kp)));
   public static final Block field_211897_kl = func_222382_a("dead_brain_coral_wall_fan", new DeadCoralWallFanBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200942_a().func_200946_b().func_222379_b(field_211902_kq)));
   public static final Block field_211898_km = func_222382_a("dead_bubble_coral_wall_fan", new DeadCoralWallFanBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200942_a().func_200946_b().func_222379_b(field_211903_kr)));
   public static final Block field_211899_kn = func_222382_a("dead_fire_coral_wall_fan", new DeadCoralWallFanBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200942_a().func_200946_b().func_222379_b(field_211904_ks)));
   public static final Block field_211900_ko = func_222382_a("dead_horn_coral_wall_fan", new DeadCoralWallFanBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151670_w).func_235861_h_().func_200942_a().func_200946_b().func_222379_b(field_211905_kt)));
   public static final Block field_211891_jY = func_222382_a("tube_coral_wall_fan", new CoralWallFanBlock(field_211896_kk, AbstractBlock.Properties.func_200949_a(Material.field_203243_f, MaterialColor.field_151649_A).func_200942_a().func_200946_b().func_200947_a(SoundType.field_211382_m).func_222379_b(field_204743_jR)));
   public static final Block field_211892_jZ = func_222382_a("brain_coral_wall_fan", new CoralWallFanBlock(field_211897_kl, AbstractBlock.Properties.func_200949_a(Material.field_203243_f, MaterialColor.field_151671_v).func_200942_a().func_200946_b().func_200947_a(SoundType.field_211382_m).func_222379_b(field_204744_jS)));
   public static final Block field_211893_ka = func_222382_a("bubble_coral_wall_fan", new CoralWallFanBlock(field_211898_km, AbstractBlock.Properties.func_200949_a(Material.field_203243_f, MaterialColor.field_151678_z).func_200942_a().func_200946_b().func_200947_a(SoundType.field_211382_m).func_222379_b(field_204745_jT)));
   public static final Block field_211894_kb = func_222382_a("fire_coral_wall_fan", new CoralWallFanBlock(field_211899_kn, AbstractBlock.Properties.func_200949_a(Material.field_203243_f, MaterialColor.field_151645_D).func_200942_a().func_200946_b().func_200947_a(SoundType.field_211382_m).func_222379_b(field_204746_jU)));
   public static final Block field_211895_kc = func_222382_a("horn_coral_wall_fan", new CoralWallFanBlock(field_211900_ko, AbstractBlock.Properties.func_200949_a(Material.field_203243_f, MaterialColor.field_151673_t).func_200942_a().func_200946_b().func_200947_a(SoundType.field_211382_m).func_222379_b(field_204747_jV)));
   public static final Block field_204913_jW = func_222382_a("sea_pickle", new SeaPickleBlock(AbstractBlock.Properties.func_200949_a(Material.field_203243_f, MaterialColor.field_151651_C).func_235838_a_((p_235451_0_) -> {
      return SeaPickleBlock.func_204901_j(p_235451_0_) ? 0 : 3 + 3 * p_235451_0_.func_177229_b(SeaPickleBlock.field_204902_a);
   }).func_200947_a(SoundType.field_185859_l).func_226896_b_()));
   public static final Block field_205164_gk = func_222382_a("blue_ice", new BreakableBlock(AbstractBlock.Properties.func_200945_a(Material.field_151598_x).func_200943_b(2.8F).func_200941_a(0.989F).func_200947_a(SoundType.field_185853_f)));
   public static final Block field_205165_jY = func_222382_a("conduit", new ConduitBlock(AbstractBlock.Properties.func_200949_a(Material.field_151592_s, MaterialColor.field_151648_G).func_200943_b(3.0F).func_235838_a_((p_235449_0_) -> {
      return 15;
   }).func_226896_b_()));
   public static final Block field_222404_kP = func_222382_a("bamboo_sapling", new BambooSaplingBlock(AbstractBlock.Properties.func_200945_a(Material.field_215712_y).func_200944_c().func_200946_b().func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_222469_p)));
   public static final Block field_222405_kQ = func_222382_a("bamboo", new BambooBlock(AbstractBlock.Properties.func_200949_a(Material.field_215713_z, MaterialColor.field_151669_i).func_200944_c().func_200946_b().func_200943_b(1.0F).func_200947_a(SoundType.field_222468_o).func_226896_b_()));
   public static final Block field_222406_kR = func_222382_a("potted_bamboo", new FlowerPotBlock(field_222405_kQ, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_201940_ji = func_222382_a("void_air", new AirBlock(AbstractBlock.Properties.func_200945_a(Material.field_151579_a).func_200942_a().func_222380_e().func_235859_g_()));
   public static final Block field_201941_jj = func_222382_a("cave_air", new AirBlock(AbstractBlock.Properties.func_200945_a(Material.field_151579_a).func_200942_a().func_222380_e().func_235859_g_()));
   public static final Block field_203203_C = func_222382_a("bubble_column", new BubbleColumnBlock(AbstractBlock.Properties.func_200945_a(Material.field_203244_i).func_200942_a().func_222380_e()));
   public static final Block field_222407_kV = func_222382_a("polished_granite_stairs", new StairsBlock(field_196652_d.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196652_d)));
   public static final Block field_222408_kW = func_222382_a("smooth_red_sandstone_stairs", new StairsBlock(field_196582_bJ.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196582_bJ)));
   public static final Block field_222409_kX = func_222382_a("mossy_stone_brick_stairs", new StairsBlock(field_196698_dj.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196698_dj)));
   public static final Block field_222410_kY = func_222382_a("polished_diorite_stairs", new StairsBlock(field_196655_f.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196655_f)));
   public static final Block field_222411_kZ = func_222382_a("mossy_cobblestone_stairs", new StairsBlock(field_150341_Y.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_150341_Y)));
   public static final Block field_222437_la = func_222382_a("end_stone_brick_stairs", new StairsBlock(field_196806_hJ.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196806_hJ)));
   public static final Block field_222438_lb = func_222382_a("stone_stairs", new StairsBlock(field_150348_b.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_150348_b)));
   public static final Block field_222439_lc = func_222382_a("smooth_sandstone_stairs", new StairsBlock(field_196580_bH.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196580_bH)));
   public static final Block field_222440_ld = func_222382_a("smooth_quartz_stairs", new StairsBlock(field_196581_bI.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196581_bI)));
   public static final Block field_222441_le = func_222382_a("granite_stairs", new StairsBlock(field_196650_c.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196650_c)));
   public static final Block field_222442_lf = func_222382_a("andesite_stairs", new StairsBlock(field_196656_g.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196656_g)));
   public static final Block field_222443_lg = func_222382_a("red_nether_brick_stairs", new StairsBlock(field_196817_hS.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196817_hS)));
   public static final Block field_222444_lh = func_222382_a("polished_andesite_stairs", new StairsBlock(field_196657_h.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196657_h)));
   public static final Block field_222445_li = func_222382_a("diorite_stairs", new StairsBlock(field_196654_e.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_196654_e)));
   public static final Block field_222446_lj = func_222382_a("polished_granite_slab", new SlabBlock(AbstractBlock.Properties.func_200950_a(field_196652_d)));
   public static final Block field_222447_lk = func_222382_a("smooth_red_sandstone_slab", new SlabBlock(AbstractBlock.Properties.func_200950_a(field_196582_bJ)));
   public static final Block field_222448_ll = func_222382_a("mossy_stone_brick_slab", new SlabBlock(AbstractBlock.Properties.func_200950_a(field_196698_dj)));
   public static final Block field_222449_lm = func_222382_a("polished_diorite_slab", new SlabBlock(AbstractBlock.Properties.func_200950_a(field_196655_f)));
   public static final Block field_222450_ln = func_222382_a("mossy_cobblestone_slab", new SlabBlock(AbstractBlock.Properties.func_200950_a(field_150341_Y)));
   public static final Block field_222451_lo = func_222382_a("end_stone_brick_slab", new SlabBlock(AbstractBlock.Properties.func_200950_a(field_196806_hJ)));
   public static final Block field_222452_lp = func_222382_a("smooth_sandstone_slab", new SlabBlock(AbstractBlock.Properties.func_200950_a(field_196580_bH)));
   public static final Block field_222453_lq = func_222382_a("smooth_quartz_slab", new SlabBlock(AbstractBlock.Properties.func_200950_a(field_196581_bI)));
   public static final Block field_222454_lr = func_222382_a("granite_slab", new SlabBlock(AbstractBlock.Properties.func_200950_a(field_196650_c)));
   public static final Block field_222455_ls = func_222382_a("andesite_slab", new SlabBlock(AbstractBlock.Properties.func_200950_a(field_196656_g)));
   public static final Block field_222456_lt = func_222382_a("red_nether_brick_slab", new SlabBlock(AbstractBlock.Properties.func_200950_a(field_196817_hS)));
   public static final Block field_222457_lu = func_222382_a("polished_andesite_slab", new SlabBlock(AbstractBlock.Properties.func_200950_a(field_196657_h)));
   public static final Block field_222458_lv = func_222382_a("diorite_slab", new SlabBlock(AbstractBlock.Properties.func_200950_a(field_196654_e)));
   public static final Block field_222459_lw = func_222382_a("brick_wall", new WallBlock(AbstractBlock.Properties.func_200950_a(field_196584_bK)));
   public static final Block field_222460_lx = func_222382_a("prismarine_wall", new WallBlock(AbstractBlock.Properties.func_200950_a(field_180397_cI)));
   public static final Block field_222461_ly = func_222382_a("red_sandstone_wall", new WallBlock(AbstractBlock.Properties.func_200950_a(field_180395_cM)));
   public static final Block field_222462_lz = func_222382_a("mossy_stone_brick_wall", new WallBlock(AbstractBlock.Properties.func_200950_a(field_196698_dj)));
   public static final Block field_222412_lA = func_222382_a("granite_wall", new WallBlock(AbstractBlock.Properties.func_200950_a(field_196650_c)));
   public static final Block field_222413_lB = func_222382_a("stone_brick_wall", new WallBlock(AbstractBlock.Properties.func_200950_a(field_196696_di)));
   public static final Block field_222414_lC = func_222382_a("nether_brick_wall", new WallBlock(AbstractBlock.Properties.func_200950_a(field_196653_dH)));
   public static final Block field_222415_lD = func_222382_a("andesite_wall", new WallBlock(AbstractBlock.Properties.func_200950_a(field_196656_g)));
   public static final Block field_222416_lE = func_222382_a("red_nether_brick_wall", new WallBlock(AbstractBlock.Properties.func_200950_a(field_196817_hS)));
   public static final Block field_222417_lF = func_222382_a("sandstone_wall", new WallBlock(AbstractBlock.Properties.func_200950_a(field_150322_A)));
   public static final Block field_222418_lG = func_222382_a("end_stone_brick_wall", new WallBlock(AbstractBlock.Properties.func_200950_a(field_196806_hJ)));
   public static final Block field_222419_lH = func_222382_a("diorite_wall", new WallBlock(AbstractBlock.Properties.func_200950_a(field_196654_e)));
   public static final Block field_222420_lI = func_222382_a("scaffolding", new ScaffoldingBlock(AbstractBlock.Properties.func_200949_a(Material.field_151594_q, MaterialColor.field_151658_d).func_200942_a().func_200947_a(SoundType.field_222470_q).func_208770_d()));
   public static final Block field_222421_lJ = func_222382_a("loom", new LoomBlock(AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200943_b(2.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_222422_lK = func_222382_a("barrel", new BarrelBlock(AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200943_b(2.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_222423_lL = func_222382_a("smoker", new SmokerBlock(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200943_b(3.5F).func_235838_a_(func_235420_a_(13))));
   public static final Block field_222424_lM = func_222382_a("blast_furnace", new BlastFurnaceBlock(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200943_b(3.5F).func_235838_a_(func_235420_a_(13))));
   public static final Block field_222425_lN = func_222382_a("cartography_table", new CartographyTableBlock(AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200943_b(2.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_222426_lO = func_222382_a("fletching_table", new FletchingTableBlock(AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200943_b(2.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_222427_lP = func_222382_a("grindstone", new GrindstoneBlock(AbstractBlock.Properties.func_200949_a(Material.field_151574_g, MaterialColor.field_151668_h).func_235861_h_().func_200948_a(2.0F, 6.0F).func_200947_a(SoundType.field_185851_d)));
   public static final Block field_222428_lQ = func_222382_a("lectern", new LecternBlock(AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200943_b(2.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_222429_lR = func_222382_a("smithing_table", new SmithingTableBlock(AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200943_b(2.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_222430_lS = func_222382_a("stonecutter", new StonecutterBlock(AbstractBlock.Properties.func_200945_a(Material.field_151576_e).func_235861_h_().func_200943_b(3.5F)));
   public static final Block field_222431_lT = func_222382_a("bell", new BellBlock(AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_151647_F).func_235861_h_().func_200943_b(5.0F).func_200947_a(SoundType.field_185858_k)));
   public static final Block field_222432_lU = func_222382_a("lantern", new LanternBlock(AbstractBlock.Properties.func_200945_a(Material.field_151573_f).func_235861_h_().func_200943_b(3.5F).func_200947_a(SoundType.field_222475_v).func_235838_a_((p_235447_0_) -> {
      return 15;
   }).func_226896_b_()));
   public static final Block field_235366_md_ = func_222382_a("soul_lantern", new LanternBlock(AbstractBlock.Properties.func_200945_a(Material.field_151573_f).func_235861_h_().func_200943_b(3.5F).func_200947_a(SoundType.field_222475_v).func_235838_a_((p_235443_0_) -> {
      return 10;
   }).func_226896_b_()));
   public static final Block field_222433_lV = func_222382_a("campfire", new CampfireBlock(true, 1, AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151654_J).func_200943_b(2.0F).func_200947_a(SoundType.field_185848_a).func_235838_a_(func_235420_a_(15)).func_226896_b_()));
   public static final Block field_235367_mf_ = func_222382_a("soul_campfire", new CampfireBlock(false, 2, AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151654_J).func_200943_b(2.0F).func_200947_a(SoundType.field_185848_a).func_235838_a_(func_235420_a_(10)).func_226896_b_()));
   public static final Block field_222434_lW = func_222382_a("sweet_berry_bush", new SweetBerryBushBlock(AbstractBlock.Properties.func_200945_a(Material.field_151585_k).func_200944_c().func_200942_a().func_200947_a(SoundType.field_222471_r)));
   public static final Block field_235368_mh_ = func_222382_a("warped_stem", func_235428_a_(MaterialColor.field_241543_af_));
   public static final Block field_235369_mi_ = func_222382_a("stripped_warped_stem", func_235428_a_(MaterialColor.field_241543_af_));
   public static final Block field_235370_mj_ = func_222382_a("warped_hyphae", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, MaterialColor.field_241544_ag_).func_200943_b(2.0F).func_200947_a(SoundType.field_235602_z_)));
   public static final Block field_235371_mk_ = func_222382_a("stripped_warped_hyphae", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, MaterialColor.field_241544_ag_).func_200943_b(2.0F).func_200947_a(SoundType.field_235602_z_)));
   public static final Block field_235372_ml_ = func_222382_a("warped_nylium", new NyliumBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_241542_ae_).func_235861_h_().func_200943_b(0.4F).func_200947_a(SoundType.field_235579_A_).func_200944_c()));
   public static final Block field_235373_mm_ = func_222382_a("warped_fungus", new FungusBlock(AbstractBlock.Properties.func_200949_a(Material.field_151585_k, MaterialColor.field_151679_y).func_200946_b().func_200942_a().func_200947_a(SoundType.field_235580_B_), () -> {
      return Features.field_243859_bE;
   }));
   public static final Block field_235374_mn_ = func_222382_a("warped_wart_block", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151577_b, MaterialColor.field_241545_ah_).func_200943_b(1.0F).func_200947_a(SoundType.field_235588_J_)));
   public static final Block field_235375_mo_ = func_222382_a("warped_roots", new NetherRootsBlock(AbstractBlock.Properties.func_200949_a(Material.field_242934_h, MaterialColor.field_151679_y).func_200942_a().func_200946_b().func_200947_a(SoundType.field_235581_C_)));
   public static final Block field_235376_mp_ = func_222382_a("nether_sprouts", new NetherSproutsBlock(AbstractBlock.Properties.func_200949_a(Material.field_242934_h, MaterialColor.field_151679_y).func_200942_a().func_200946_b().func_200947_a(SoundType.field_235591_M_)));
   public static final Block field_235377_mq_ = func_222382_a("crimson_stem", func_235428_a_(MaterialColor.field_241540_ac_));
   public static final Block field_235378_mr_ = func_222382_a("stripped_crimson_stem", func_235428_a_(MaterialColor.field_241540_ac_));
   public static final Block field_235379_ms_ = func_222382_a("crimson_hyphae", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, MaterialColor.field_241541_ad_).func_200943_b(2.0F).func_200947_a(SoundType.field_235602_z_)));
   public static final Block field_235380_mt_ = func_222382_a("stripped_crimson_hyphae", new RotatedPillarBlock(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, MaterialColor.field_241541_ad_).func_200943_b(2.0F).func_200947_a(SoundType.field_235602_z_)));
   public static final Block field_235381_mu_ = func_222382_a("crimson_nylium", new NyliumBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_241539_ab_).func_235861_h_().func_200943_b(0.4F).func_200947_a(SoundType.field_235579_A_).func_200944_c()));
   public static final Block field_235382_mv_ = func_222382_a("crimson_fungus", new FungusBlock(AbstractBlock.Properties.func_200949_a(Material.field_151585_k, MaterialColor.field_151655_K).func_200946_b().func_200942_a().func_200947_a(SoundType.field_235580_B_), () -> {
      return Features.field_243857_bC;
   }));
   public static final Block field_235383_mw_ = func_222382_a("shroomlight", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151577_b, MaterialColor.field_151645_D).func_200943_b(1.0F).func_200947_a(SoundType.field_235582_D_).func_235838_a_((p_235439_0_) -> {
      return 15;
   })));
   public static final Block field_235384_mx_ = func_222382_a("weeping_vines", new WeepingVinesTopBlock(AbstractBlock.Properties.func_200949_a(Material.field_151585_k, MaterialColor.field_151655_K).func_200944_c().func_200942_a().func_200946_b().func_200947_a(SoundType.field_235583_E_)));
   public static final Block field_235385_my_ = func_222382_a("weeping_vines_plant", new WeepingVinesBlock(AbstractBlock.Properties.func_200949_a(Material.field_151585_k, MaterialColor.field_151655_K).func_200942_a().func_200946_b().func_200947_a(SoundType.field_235583_E_)));
   public static final Block field_235386_mz_ = func_222382_a("twisting_vines", new TwistingVinesTopBlock(AbstractBlock.Properties.func_200949_a(Material.field_151585_k, MaterialColor.field_151679_y).func_200944_c().func_200942_a().func_200946_b().func_200947_a(SoundType.field_235583_E_)));
   public static final Block field_235342_mA_ = func_222382_a("twisting_vines_plant", new TwistingVinesBlock(AbstractBlock.Properties.func_200949_a(Material.field_151585_k, MaterialColor.field_151679_y).func_200942_a().func_200946_b().func_200947_a(SoundType.field_235583_E_)));
   public static final Block field_235343_mB_ = func_222382_a("crimson_roots", new NetherRootsBlock(AbstractBlock.Properties.func_200949_a(Material.field_242934_h, MaterialColor.field_151655_K).func_200942_a().func_200946_b().func_200947_a(SoundType.field_235581_C_)));
   public static final Block field_235344_mC_ = func_222382_a("crimson_planks", new Block(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, MaterialColor.field_241540_ac_).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_235345_mD_ = func_222382_a("warped_planks", new Block(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, MaterialColor.field_241543_af_).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_235346_mE_ = func_222382_a("crimson_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, field_235344_mC_.func_235697_s_()).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_235347_mF_ = func_222382_a("warped_slab", new SlabBlock(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, field_235345_mD_.func_235697_s_()).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_235348_mG_ = func_222382_a("crimson_pressure_plate", new PressurePlateBlock(PressurePlateBlock.Sensitivity.EVERYTHING, AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, field_235344_mC_.func_235697_s_()).func_200942_a().func_200943_b(0.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_235349_mH_ = func_222382_a("warped_pressure_plate", new PressurePlateBlock(PressurePlateBlock.Sensitivity.EVERYTHING, AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, field_235345_mD_.func_235697_s_()).func_200942_a().func_200943_b(0.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_235350_mI_ = func_222382_a("crimson_fence", new FenceBlock(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, field_235344_mC_.func_235697_s_()).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_235351_mJ_ = func_222382_a("warped_fence", new FenceBlock(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, field_235345_mD_.func_235697_s_()).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_235352_mK_ = func_222382_a("crimson_trapdoor", new TrapDoorBlock(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, field_235344_mC_.func_235697_s_()).func_200943_b(3.0F).func_200947_a(SoundType.field_185848_a).func_226896_b_().func_235827_a_(Blocks::func_235427_a_)));
   public static final Block field_235353_mL_ = func_222382_a("warped_trapdoor", new TrapDoorBlock(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, field_235345_mD_.func_235697_s_()).func_200943_b(3.0F).func_200947_a(SoundType.field_185848_a).func_226896_b_().func_235827_a_(Blocks::func_235427_a_)));
   public static final Block field_235354_mM_ = func_222382_a("crimson_fence_gate", new FenceGateBlock(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, field_235344_mC_.func_235697_s_()).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_235355_mN_ = func_222382_a("warped_fence_gate", new FenceGateBlock(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, field_235345_mD_.func_235697_s_()).func_200948_a(2.0F, 3.0F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_235356_mO_ = func_222382_a("crimson_stairs", new StairsBlock(field_235344_mC_.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_235344_mC_)));
   public static final Block field_235357_mP_ = func_222382_a("warped_stairs", new StairsBlock(field_235345_mD_.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_235345_mD_)));
   public static final Block field_235358_mQ_ = func_222382_a("crimson_button", new WoodButtonBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200943_b(0.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_235359_mR_ = func_222382_a("warped_button", new WoodButtonBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200943_b(0.5F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_235360_mS_ = func_222382_a("crimson_door", new DoorBlock(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, field_235344_mC_.func_235697_s_()).func_200943_b(3.0F).func_200947_a(SoundType.field_185848_a).func_226896_b_()));
   public static final Block field_235361_mT_ = func_222382_a("warped_door", new DoorBlock(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, field_235345_mD_.func_235697_s_()).func_200943_b(3.0F).func_200947_a(SoundType.field_185848_a).func_226896_b_()));
   public static final Block field_235362_mU_ = func_222382_a("crimson_sign", new StandingSignBlock(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, field_235344_mC_.func_235697_s_()).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a), WoodType.field_235923_g_));
   public static final Block field_235363_mV_ = func_222382_a("warped_sign", new StandingSignBlock(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, field_235345_mD_.func_235697_s_()).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a), WoodType.field_235924_h_));
   public static final Block field_235364_mW_ = func_222382_a("crimson_wall_sign", new WallSignBlock(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, field_235344_mC_.func_235697_s_()).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_235362_mU_), WoodType.field_235923_g_));
   public static final Block field_235365_mX_ = func_222382_a("warped_wall_sign", new WallSignBlock(AbstractBlock.Properties.func_200949_a(Material.field_237214_y_, field_235345_mD_.func_235697_s_()).func_200942_a().func_200943_b(1.0F).func_200947_a(SoundType.field_185848_a).func_222379_b(field_235363_mV_), WoodType.field_235924_h_));
   public static final Block field_185779_df = func_222382_a("structure_block", new StructureBlock(AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_197656_x).func_235861_h_().func_200948_a(-1.0F, 3600000.0F).func_222380_e()));
   public static final Block field_226904_lY_ = func_222382_a("jigsaw", new JigsawBlock(AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_197656_x).func_235861_h_().func_200948_a(-1.0F, 3600000.0F).func_222380_e()));
   public static final Block field_222436_lZ = func_222382_a("composter", new ComposterBlock(AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200943_b(0.6F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_235396_nb_ = func_222382_a("target", new TargetBlock(AbstractBlock.Properties.func_200949_a(Material.field_151577_b, MaterialColor.field_151677_p).func_200943_b(0.5F).func_200947_a(SoundType.field_185850_c)));
   public static final Block field_226905_ma_ = func_222382_a("bee_nest", new BeehiveBlock(AbstractBlock.Properties.func_200949_a(Material.field_151575_d, MaterialColor.field_151673_t).func_200943_b(0.3F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_226906_mb_ = func_222382_a("beehive", new BeehiveBlock(AbstractBlock.Properties.func_200945_a(Material.field_151575_d).func_200943_b(0.6F).func_200947_a(SoundType.field_185848_a)));
   public static final Block field_226907_mc_ = func_222382_a("honey_block", new HoneyBlock(AbstractBlock.Properties.func_200949_a(Material.field_151571_B, MaterialColor.field_151676_q).func_226897_b_(0.4F).func_226898_c_(0.5F).func_226896_b_().func_200947_a(SoundType.field_226947_m_)));
   public static final Block field_226908_md_ = func_222382_a("honeycomb_block", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151571_B, MaterialColor.field_151676_q).func_200943_b(0.6F).func_200947_a(SoundType.field_211383_n)));
   public static final Block field_235397_ng_ = func_222382_a("netherite_block", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_151646_E).func_235861_h_().func_200948_a(50.0F, 1200.0F).func_200947_a(SoundType.field_235594_P_)));
   public static final Block field_235398_nh_ = func_222382_a("ancient_debris", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151573_f, MaterialColor.field_151646_E).func_235861_h_().func_200948_a(30.0F, 1200.0F).func_200947_a(SoundType.field_235595_Q_)));
   public static final Block field_235399_ni_ = func_222382_a("crying_obsidian", new CryingObsidianBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151646_E).func_235861_h_().func_200948_a(50.0F, 1200.0F).func_235838_a_((p_235435_0_) -> {
      return 10;
   })));
   public static final Block field_235400_nj_ = func_222382_a("respawn_anchor", new RespawnAnchorBlock(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151646_E).func_235861_h_().func_200948_a(50.0F, 1200.0F).func_235838_a_((p_235425_0_) -> {
      return RespawnAnchorBlock.func_235565_a_(p_235425_0_, 15);
   })));
   public static final Block field_235401_nk_ = func_222382_a("potted_crimson_fungus", new FlowerPotBlock(field_235382_mv_, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_235402_nl_ = func_222382_a("potted_warped_fungus", new FlowerPotBlock(field_235373_mm_, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_235403_nm_ = func_222382_a("potted_crimson_roots", new FlowerPotBlock(field_235343_mB_, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_235404_nn_ = func_222382_a("potted_warped_roots", new FlowerPotBlock(field_235375_mo_, AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200946_b().func_226896_b_()));
   public static final Block field_235405_no_ = func_222382_a("lodestone", new Block(AbstractBlock.Properties.func_200945_a(Material.field_151574_g).func_235861_h_().func_200943_b(3.5F).func_200947_a(SoundType.field_235596_R_)));
   public static final Block field_235406_np_ = func_222382_a("blackstone", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151646_E).func_235861_h_().func_200948_a(1.5F, 6.0F)));
   public static final Block field_235407_nq_ = func_222382_a("blackstone_stairs", new StairsBlock(field_235406_np_.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_235406_np_)));
   public static final Block field_235408_nr_ = func_222382_a("blackstone_wall", new WallBlock(AbstractBlock.Properties.func_200950_a(field_235406_np_)));
   public static final Block field_235409_ns_ = func_222382_a("blackstone_slab", new SlabBlock(AbstractBlock.Properties.func_200950_a(field_235406_np_).func_200948_a(2.0F, 6.0F)));
   public static final Block field_235410_nt_ = func_222382_a("polished_blackstone", new Block(AbstractBlock.Properties.func_200950_a(field_235406_np_).func_200948_a(2.0F, 6.0F)));
   public static final Block field_235411_nu_ = func_222382_a("polished_blackstone_bricks", new Block(AbstractBlock.Properties.func_200950_a(field_235410_nt_).func_200948_a(1.5F, 6.0F)));
   public static final Block field_235412_nv_ = func_222382_a("cracked_polished_blackstone_bricks", new Block(AbstractBlock.Properties.func_200950_a(field_235411_nu_)));
   public static final Block field_235413_nw_ = func_222382_a("chiseled_polished_blackstone", new Block(AbstractBlock.Properties.func_200950_a(field_235410_nt_).func_200948_a(1.5F, 6.0F)));
   public static final Block field_235414_nx_ = func_222382_a("polished_blackstone_brick_slab", new SlabBlock(AbstractBlock.Properties.func_200950_a(field_235411_nu_).func_200948_a(2.0F, 6.0F)));
   public static final Block field_235415_ny_ = func_222382_a("polished_blackstone_brick_stairs", new StairsBlock(field_235411_nu_.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_235411_nu_)));
   public static final Block field_235416_nz_ = func_222382_a("polished_blackstone_brick_wall", new WallBlock(AbstractBlock.Properties.func_200950_a(field_235411_nu_)));
   public static final Block field_235387_nA_ = func_222382_a("gilded_blackstone", new Block(AbstractBlock.Properties.func_200950_a(field_235406_np_).func_200947_a(SoundType.field_235599_U_)));
   public static final Block field_235388_nB_ = func_222382_a("polished_blackstone_stairs", new StairsBlock(field_235410_nt_.func_176223_P(), AbstractBlock.Properties.func_200950_a(field_235410_nt_)));
   public static final Block field_235389_nC_ = func_222382_a("polished_blackstone_slab", new SlabBlock(AbstractBlock.Properties.func_200950_a(field_235410_nt_)));
   public static final Block field_235390_nD_ = func_222382_a("polished_blackstone_pressure_plate", new PressurePlateBlock(PressurePlateBlock.Sensitivity.MOBS, AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151646_E).func_235861_h_().func_200942_a().func_200943_b(0.5F)));
   public static final Block field_235391_nE_ = func_222382_a("polished_blackstone_button", new StoneButtonBlock(AbstractBlock.Properties.func_200945_a(Material.field_151594_q).func_200942_a().func_200943_b(0.5F)));
   public static final Block field_235392_nF_ = func_222382_a("polished_blackstone_wall", new WallBlock(AbstractBlock.Properties.func_200950_a(field_235410_nt_)));
   public static final Block field_235393_nG_ = func_222382_a("chiseled_nether_bricks", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151655_K).func_235861_h_().func_200948_a(2.0F, 6.0F).func_200947_a(SoundType.field_235590_L_)));
   public static final Block field_235394_nH_ = func_222382_a("cracked_nether_bricks", new Block(AbstractBlock.Properties.func_200949_a(Material.field_151576_e, MaterialColor.field_151655_K).func_235861_h_().func_200948_a(2.0F, 6.0F).func_200947_a(SoundType.field_235590_L_)));
   public static final Block field_235395_nI_ = func_222382_a("quartz_bricks", new Block(AbstractBlock.Properties.func_200950_a(field_150371_ca)));

   private static ToIntFunction<BlockState> func_235420_a_(int p_235420_0_) {
      return (p_235421_1_) -> {
         return p_235421_1_.func_177229_b(BlockStateProperties.field_208190_q) ? p_235420_0_ : 0;
      };
   }

   private static Boolean func_235427_a_(BlockState p_235427_0_, IBlockReader p_235427_1_, BlockPos p_235427_2_, EntityType<?> p_235427_3_) {
      return (boolean)false;
   }

   private static Boolean func_235437_b_(BlockState p_235437_0_, IBlockReader p_235437_1_, BlockPos p_235437_2_, EntityType<?> p_235437_3_) {
      return (boolean)true;
   }

   private static Boolean func_235441_c_(BlockState p_235441_0_, IBlockReader p_235441_1_, BlockPos p_235441_2_, EntityType<?> p_235441_3_) {
      return p_235441_3_ == EntityType.field_200781_U || p_235441_3_ == EntityType.field_200783_W;
   }

   private static BedBlock func_235422_a_(DyeColor p_235422_0_) {
      return new BedBlock(p_235422_0_, AbstractBlock.Properties.func_235836_a_(Material.field_151580_n, (p_235424_1_) -> {
         return p_235424_1_.func_177229_b(BedBlock.field_176472_a) == BedPart.FOOT ? p_235422_0_.func_196055_e() : MaterialColor.field_151659_e;
      }).func_200947_a(SoundType.field_185848_a).func_200943_b(0.2F).func_226896_b_());
   }

   private static RotatedPillarBlock func_235430_a_(MaterialColor p_235430_0_, MaterialColor p_235430_1_) {
      return new RotatedPillarBlock(AbstractBlock.Properties.func_235836_a_(Material.field_151575_d, (p_235431_2_) -> {
         return p_235431_2_.func_177229_b(RotatedPillarBlock.field_176298_M) == Direction.Axis.Y ? p_235430_0_ : p_235430_1_;
      }).func_200943_b(2.0F).func_200947_a(SoundType.field_185848_a));
   }

   private static Block func_235428_a_(MaterialColor p_235428_0_) {
      return new RotatedPillarBlock(AbstractBlock.Properties.func_235836_a_(Material.field_237214_y_, (p_235429_1_) -> {
         return p_235428_0_;
      }).func_200943_b(2.0F).func_200947_a(SoundType.field_235602_z_));
   }

   private static boolean func_235426_a_(BlockState p_235426_0_, IBlockReader p_235426_1_, BlockPos p_235426_2_) {
      return true;
   }

   private static boolean func_235436_b_(BlockState p_235436_0_, IBlockReader p_235436_1_, BlockPos p_235436_2_) {
      return false;
   }

   private static StainedGlassBlock func_235434_b_(DyeColor p_235434_0_) {
      return new StainedGlassBlock(p_235434_0_, AbstractBlock.Properties.func_200952_a(Material.field_151592_s, p_235434_0_).func_200943_b(0.3F).func_200947_a(SoundType.field_185853_f).func_226896_b_().func_235827_a_(Blocks::func_235427_a_).func_235828_a_(Blocks::func_235436_b_).func_235842_b_(Blocks::func_235436_b_).func_235847_c_(Blocks::func_235436_b_));
   }

   private static LeavesBlock func_235433_b_() {
      return new LeavesBlock(AbstractBlock.Properties.func_200945_a(Material.field_151584_j).func_200943_b(0.2F).func_200944_c().func_200947_a(SoundType.field_185850_c).func_226896_b_().func_235827_a_(Blocks::func_235441_c_).func_235842_b_(Blocks::func_235436_b_).func_235847_c_(Blocks::func_235436_b_));
   }

   private static ShulkerBoxBlock func_235423_a_(DyeColor p_235423_0_, AbstractBlock.Properties p_235423_1_) {
      AbstractBlock.IPositionPredicate abstractblock$ipositionpredicate = (p_235444_0_, p_235444_1_, p_235444_2_) -> {
         TileEntity tileentity = p_235444_1_.func_175625_s(p_235444_2_);
         if (!(tileentity instanceof ShulkerBoxTileEntity)) {
            return true;
         } else {
            ShulkerBoxTileEntity shulkerboxtileentity = (ShulkerBoxTileEntity)tileentity;
            return shulkerboxtileentity.func_235676_l_();
         }
      };
      return new ShulkerBoxBlock(p_235423_0_, p_235423_1_.func_200943_b(2.0F).func_208770_d().func_226896_b_().func_235842_b_(abstractblock$ipositionpredicate).func_235847_c_(abstractblock$ipositionpredicate));
   }

   private static PistonBlock func_235432_a_(boolean p_235432_0_) {
      AbstractBlock.IPositionPredicate abstractblock$ipositionpredicate = (p_235440_0_, p_235440_1_, p_235440_2_) -> {
         return !p_235440_0_.func_177229_b(PistonBlock.field_176320_b);
      };
      return new PistonBlock(p_235432_0_, AbstractBlock.Properties.func_200945_a(Material.field_76233_E).func_200943_b(1.5F).func_235828_a_(Blocks::func_235436_b_).func_235842_b_(abstractblock$ipositionpredicate).func_235847_c_(abstractblock$ipositionpredicate));
   }

   private static Block func_222382_a(String p_222382_0_, Block p_222382_1_) {
      return Registry.func_218325_a(Registry.field_212618_g, p_222382_0_, p_222382_1_);
   }

   public static void func_235419_a_() {
      Block.field_176229_d.forEach(AbstractBlock.AbstractBlockState::func_215692_c);
   }

   static {
      for(Block block : Registry.field_212618_g) {
         for(BlockState blockstate : block.func_176194_O().func_177619_a()) {
            Block.field_176229_d.func_195867_b(blockstate);
         }

         block.func_220068_i();
      }

   }
}
