package net.minecraft.block;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.DyeColor;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.Direction;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;

public class WallBannerBlock extends AbstractBannerBlock {
   public static final DirectionProperty field_196290_a = HorizontalBlock.field_185512_D;
   private static final Map<Direction, VoxelShape> field_196291_b = Maps.newEnumMap(ImmutableMap.of(Direction.NORTH, Block.func_208617_a(0.0D, 0.0D, 14.0D, 16.0D, 12.5D, 16.0D), Direction.SOUTH, Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 12.5D, 2.0D), Direction.WEST, Block.func_208617_a(14.0D, 0.0D, 0.0D, 16.0D, 12.5D, 16.0D), Direction.EAST, Block.func_208617_a(0.0D, 0.0D, 0.0D, 2.0D, 12.5D, 16.0D)));

   public WallBannerBlock(DyeColor p_i48302_1_, AbstractBlock.Properties p_i48302_2_) {
      super(p_i48302_1_, p_i48302_2_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196290_a, Direction.NORTH));
   }

   public String func_149739_a() {
      return this.func_199767_j().func_77658_a();
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      return p_196260_2_.func_180495_p(p_196260_3_.func_177972_a(p_196260_1_.func_177229_b(field_196290_a).func_176734_d())).func_185904_a().func_76220_a();
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return p_196271_2_ == p_196271_1_.func_177229_b(field_196290_a).func_176734_d() && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196291_b.get(p_220053_1_.func_177229_b(field_196290_a));
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      BlockState blockstate = this.func_176223_P();
      IWorldReader iworldreader = p_196258_1_.func_195991_k();
      BlockPos blockpos = p_196258_1_.func_195995_a();
      Direction[] adirection = p_196258_1_.func_196009_e();

      for(Direction direction : adirection) {
         if (direction.func_176740_k().func_176722_c()) {
            Direction direction1 = direction.func_176734_d();
            blockstate = blockstate.func_206870_a(field_196290_a, direction1);
            if (blockstate.func_196955_c(iworldreader, blockpos)) {
               return blockstate;
            }
         }
      }

      return null;
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_196290_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_196290_a)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_196290_a)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196290_a);
   }
}
