package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.PushReaction;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.StateContainer;
import net.minecraft.util.Direction;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class EndRodBlock extends DirectionalBlock {
   protected static final VoxelShape field_185630_a = Block.func_208617_a(6.0D, 0.0D, 6.0D, 10.0D, 16.0D, 10.0D);
   protected static final VoxelShape field_185631_b = Block.func_208617_a(6.0D, 6.0D, 0.0D, 10.0D, 10.0D, 16.0D);
   protected static final VoxelShape field_185632_c = Block.func_208617_a(0.0D, 6.0D, 6.0D, 16.0D, 10.0D, 10.0D);

   protected EndRodBlock(AbstractBlock.Properties p_i48404_1_) {
      super(p_i48404_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176387_N, Direction.UP));
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_176387_N, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_176387_N)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_206870_a(field_176387_N, p_185471_2_.func_185803_b(p_185471_1_.func_177229_b(field_176387_N)));
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      switch(p_220053_1_.func_177229_b(field_176387_N).func_176740_k()) {
      case X:
      default:
         return field_185632_c;
      case Z:
         return field_185631_b;
      case Y:
         return field_185630_a;
      }
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      Direction direction = p_196258_1_.func_196000_l();
      BlockState blockstate = p_196258_1_.func_195991_k().func_180495_p(p_196258_1_.func_195995_a().func_177972_a(direction.func_176734_d()));
      return blockstate.func_203425_a(this) && blockstate.func_177229_b(field_176387_N) == direction ? this.func_176223_P().func_206870_a(field_176387_N, direction.func_176734_d()) : this.func_176223_P().func_206870_a(field_176387_N, direction);
   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(BlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      Direction direction = p_180655_1_.func_177229_b(field_176387_N);
      double d0 = (double)p_180655_3_.func_177958_n() + 0.55D - (double)(p_180655_4_.nextFloat() * 0.1F);
      double d1 = (double)p_180655_3_.func_177956_o() + 0.55D - (double)(p_180655_4_.nextFloat() * 0.1F);
      double d2 = (double)p_180655_3_.func_177952_p() + 0.55D - (double)(p_180655_4_.nextFloat() * 0.1F);
      double d3 = (double)(0.4F - (p_180655_4_.nextFloat() + p_180655_4_.nextFloat()) * 0.4F);
      if (p_180655_4_.nextInt(5) == 0) {
         p_180655_2_.func_195594_a(ParticleTypes.field_197624_q, d0 + (double)direction.func_82601_c() * d3, d1 + (double)direction.func_96559_d() * d3, d2 + (double)direction.func_82599_e() * d3, p_180655_4_.nextGaussian() * 0.005D, p_180655_4_.nextGaussian() * 0.005D, p_180655_4_.nextGaussian() * 0.005D);
      }

   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176387_N);
   }

   public PushReaction func_149656_h(BlockState p_149656_1_) {
      return PushReaction.NORMAL;
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
