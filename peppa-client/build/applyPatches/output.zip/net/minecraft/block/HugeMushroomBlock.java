package net.minecraft.block;

import java.util.Map;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.Direction;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;

public class HugeMushroomBlock extends Block {
   public static final BooleanProperty field_196459_a = SixWayBlock.field_196488_a;
   public static final BooleanProperty field_196461_b = SixWayBlock.field_196490_b;
   public static final BooleanProperty field_196463_c = SixWayBlock.field_196492_c;
   public static final BooleanProperty field_196464_y = SixWayBlock.field_196495_y;
   public static final BooleanProperty field_196465_z = SixWayBlock.field_196496_z;
   public static final BooleanProperty field_196460_A = SixWayBlock.field_196489_A;
   private static final Map<Direction, BooleanProperty> field_196462_B = SixWayBlock.field_196491_B;

   public HugeMushroomBlock(AbstractBlock.Properties p_i49982_1_) {
      super(p_i49982_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196459_a, Boolean.valueOf(true)).func_206870_a(field_196461_b, Boolean.valueOf(true)).func_206870_a(field_196463_c, Boolean.valueOf(true)).func_206870_a(field_196464_y, Boolean.valueOf(true)).func_206870_a(field_196465_z, Boolean.valueOf(true)).func_206870_a(field_196460_A, Boolean.valueOf(true)));
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      IBlockReader iblockreader = p_196258_1_.func_195991_k();
      BlockPos blockpos = p_196258_1_.func_195995_a();
      return this.func_176223_P().func_206870_a(field_196460_A, Boolean.valueOf(this != iblockreader.func_180495_p(blockpos.func_177977_b()).func_177230_c())).func_206870_a(field_196465_z, Boolean.valueOf(this != iblockreader.func_180495_p(blockpos.func_177984_a()).func_177230_c())).func_206870_a(field_196459_a, Boolean.valueOf(this != iblockreader.func_180495_p(blockpos.func_177978_c()).func_177230_c())).func_206870_a(field_196461_b, Boolean.valueOf(this != iblockreader.func_180495_p(blockpos.func_177974_f()).func_177230_c())).func_206870_a(field_196463_c, Boolean.valueOf(this != iblockreader.func_180495_p(blockpos.func_177968_d()).func_177230_c())).func_206870_a(field_196464_y, Boolean.valueOf(this != iblockreader.func_180495_p(blockpos.func_177976_e()).func_177230_c()));
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return p_196271_3_.func_203425_a(this) ? p_196271_1_.func_206870_a(field_196462_B.get(p_196271_2_), Boolean.valueOf(false)) : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_196462_B.get(p_185499_2_.func_185831_a(Direction.NORTH)), p_185499_1_.func_177229_b(field_196459_a)).func_206870_a(field_196462_B.get(p_185499_2_.func_185831_a(Direction.SOUTH)), p_185499_1_.func_177229_b(field_196463_c)).func_206870_a(field_196462_B.get(p_185499_2_.func_185831_a(Direction.EAST)), p_185499_1_.func_177229_b(field_196461_b)).func_206870_a(field_196462_B.get(p_185499_2_.func_185831_a(Direction.WEST)), p_185499_1_.func_177229_b(field_196464_y)).func_206870_a(field_196462_B.get(p_185499_2_.func_185831_a(Direction.UP)), p_185499_1_.func_177229_b(field_196465_z)).func_206870_a(field_196462_B.get(p_185499_2_.func_185831_a(Direction.DOWN)), p_185499_1_.func_177229_b(field_196460_A));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_206870_a(field_196462_B.get(p_185471_2_.func_185803_b(Direction.NORTH)), p_185471_1_.func_177229_b(field_196459_a)).func_206870_a(field_196462_B.get(p_185471_2_.func_185803_b(Direction.SOUTH)), p_185471_1_.func_177229_b(field_196463_c)).func_206870_a(field_196462_B.get(p_185471_2_.func_185803_b(Direction.EAST)), p_185471_1_.func_177229_b(field_196461_b)).func_206870_a(field_196462_B.get(p_185471_2_.func_185803_b(Direction.WEST)), p_185471_1_.func_177229_b(field_196464_y)).func_206870_a(field_196462_B.get(p_185471_2_.func_185803_b(Direction.UP)), p_185471_1_.func_177229_b(field_196465_z)).func_206870_a(field_196462_B.get(p_185471_2_.func_185803_b(Direction.DOWN)), p_185471_1_.func_177229_b(field_196460_A));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196465_z, field_196460_A, field_196459_a, field_196461_b, field_196463_c, field_196464_y);
   }
}
