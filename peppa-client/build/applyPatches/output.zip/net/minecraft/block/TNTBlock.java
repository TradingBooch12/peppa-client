package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.item.TNTEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;

public class TNTBlock extends Block {
   public static final BooleanProperty field_212569_a = BlockStateProperties.field_212646_x;

   public TNTBlock(AbstractBlock.Properties p_i48309_1_) {
      super(p_i48309_1_);
      this.func_180632_j(this.func_176223_P().func_206870_a(field_212569_a, Boolean.valueOf(false)));
   }

   public void func_220082_b(BlockState p_220082_1_, World p_220082_2_, BlockPos p_220082_3_, BlockState p_220082_4_, boolean p_220082_5_) {
      if (!p_220082_4_.func_203425_a(p_220082_1_.func_177230_c())) {
         if (p_220082_2_.func_175640_z(p_220082_3_)) {
            func_196534_a(p_220082_2_, p_220082_3_);
            p_220082_2_.func_217377_a(p_220082_3_, false);
         }

      }
   }

   public void func_220069_a(BlockState p_220069_1_, World p_220069_2_, BlockPos p_220069_3_, Block p_220069_4_, BlockPos p_220069_5_, boolean p_220069_6_) {
      if (p_220069_2_.func_175640_z(p_220069_3_)) {
         func_196534_a(p_220069_2_, p_220069_3_);
         p_220069_2_.func_217377_a(p_220069_3_, false);
      }

   }

   public void func_176208_a(World p_176208_1_, BlockPos p_176208_2_, BlockState p_176208_3_, PlayerEntity p_176208_4_) {
      if (!p_176208_1_.func_201670_d() && !p_176208_4_.func_184812_l_() && p_176208_3_.func_177229_b(field_212569_a)) {
         func_196534_a(p_176208_1_, p_176208_2_);
      }

      super.func_176208_a(p_176208_1_, p_176208_2_, p_176208_3_, p_176208_4_);
   }

   public void func_180652_a(World p_180652_1_, BlockPos p_180652_2_, Explosion p_180652_3_) {
      if (!p_180652_1_.field_72995_K) {
         TNTEntity tntentity = new TNTEntity(p_180652_1_, (double)p_180652_2_.func_177958_n() + 0.5D, (double)p_180652_2_.func_177956_o(), (double)p_180652_2_.func_177952_p() + 0.5D, p_180652_3_.func_94613_c());
         tntentity.func_184534_a((short)(p_180652_1_.field_73012_v.nextInt(tntentity.func_184536_l() / 4) + tntentity.func_184536_l() / 8));
         p_180652_1_.func_217376_c(tntentity);
      }
   }

   public static void func_196534_a(World p_196534_0_, BlockPos p_196534_1_) {
      func_196535_a(p_196534_0_, p_196534_1_, (LivingEntity)null);
   }

   private static void func_196535_a(World p_196535_0_, BlockPos p_196535_1_, @Nullable LivingEntity p_196535_2_) {
      if (!p_196535_0_.field_72995_K) {
         TNTEntity tntentity = new TNTEntity(p_196535_0_, (double)p_196535_1_.func_177958_n() + 0.5D, (double)p_196535_1_.func_177956_o(), (double)p_196535_1_.func_177952_p() + 0.5D, p_196535_2_);
         p_196535_0_.func_217376_c(tntentity);
         p_196535_0_.func_184148_a((PlayerEntity)null, tntentity.func_226277_ct_(), tntentity.func_226278_cu_(), tntentity.func_226281_cx_(), SoundEvents.field_187904_gd, SoundCategory.BLOCKS, 1.0F, 1.0F);
      }
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      ItemStack itemstack = p_225533_4_.func_184586_b(p_225533_5_);
      Item item = itemstack.func_77973_b();
      if (item != Items.field_151033_d && item != Items.field_151059_bz) {
         return super.func_225533_a_(p_225533_1_, p_225533_2_, p_225533_3_, p_225533_4_, p_225533_5_, p_225533_6_);
      } else {
         func_196535_a(p_225533_2_, p_225533_3_, p_225533_4_);
         p_225533_2_.func_180501_a(p_225533_3_, Blocks.field_150350_a.func_176223_P(), 11);
         if (!p_225533_4_.func_184812_l_()) {
            if (item == Items.field_151033_d) {
               itemstack.func_222118_a(1, p_225533_4_, (p_220287_1_) -> {
                  p_220287_1_.func_213334_d(p_225533_5_);
               });
            } else {
               itemstack.func_190918_g(1);
            }
         }

         return ActionResultType.func_233537_a_(p_225533_2_.field_72995_K);
      }
   }

   public void func_220066_a(World p_220066_1_, BlockState p_220066_2_, BlockRayTraceResult p_220066_3_, ProjectileEntity p_220066_4_) {
      if (!p_220066_1_.field_72995_K) {
         Entity entity = p_220066_4_.func_234616_v_();
         if (p_220066_4_.func_70027_ad()) {
            BlockPos blockpos = p_220066_3_.func_216350_a();
            func_196535_a(p_220066_1_, blockpos, entity instanceof LivingEntity ? (LivingEntity)entity : null);
            p_220066_1_.func_217377_a(blockpos, false);
         }
      }

   }

   public boolean func_149659_a(Explosion p_149659_1_) {
      return false;
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_212569_a);
   }
}
