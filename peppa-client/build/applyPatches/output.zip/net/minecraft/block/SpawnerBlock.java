package net.minecraft.block;

import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.MobSpawnerTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class SpawnerBlock extends ContainerBlock {
   protected SpawnerBlock(AbstractBlock.Properties p_i48364_1_) {
      super(p_i48364_1_);
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new MobSpawnerTileEntity();
   }

   public void func_220062_a(BlockState p_220062_1_, ServerWorld p_220062_2_, BlockPos p_220062_3_, ItemStack p_220062_4_) {
      super.func_220062_a(p_220062_1_, p_220062_2_, p_220062_3_, p_220062_4_);
      int i = 15 + p_220062_2_.field_73012_v.nextInt(15) + p_220062_2_.field_73012_v.nextInt(15);
      this.func_180637_b(p_220062_2_, p_220062_3_, i);
   }

   public BlockRenderType func_149645_b(BlockState p_149645_1_) {
      return BlockRenderType.MODEL;
   }

   @OnlyIn(Dist.CLIENT)
   public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, BlockState p_185473_3_) {
      return ItemStack.field_190927_a;
   }
}
