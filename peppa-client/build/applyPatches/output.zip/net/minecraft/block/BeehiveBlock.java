package net.minecraft.block;

import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.item.TNTEntity;
import net.minecraft.entity.item.minecart.TNTMinecartEntity;
import net.minecraft.entity.monster.CreeperEntity;
import net.minecraft.entity.passive.BeeEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.projectile.WitherSkullEntity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.loot.LootContext;
import net.minecraft.loot.LootParameters;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tags.BlockTags;
import net.minecraft.tileentity.BeehiveTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.Util;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.GameRules;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BeehiveBlock extends ContainerBlock {
   private static final Direction[] field_226871_a_ = new Direction[]{Direction.WEST, Direction.EAST, Direction.SOUTH};
   public static final DirectionProperty field_226872_b_ = HorizontalBlock.field_185512_D;
   public static final IntegerProperty field_226873_c_ = BlockStateProperties.field_227036_ao_;

   public BeehiveBlock(AbstractBlock.Properties p_i225756_1_) {
      super(p_i225756_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_226873_c_, Integer.valueOf(0)).func_206870_a(field_226872_b_, Direction.NORTH));
   }

   public boolean func_149740_M(BlockState p_149740_1_) {
      return true;
   }

   public int func_180641_l(BlockState p_180641_1_, World p_180641_2_, BlockPos p_180641_3_) {
      return p_180641_1_.func_177229_b(field_226873_c_);
   }

   public void func_180657_a(World p_180657_1_, PlayerEntity p_180657_2_, BlockPos p_180657_3_, BlockState p_180657_4_, @Nullable TileEntity p_180657_5_, ItemStack p_180657_6_) {
      super.func_180657_a(p_180657_1_, p_180657_2_, p_180657_3_, p_180657_4_, p_180657_5_, p_180657_6_);
      if (!p_180657_1_.field_72995_K && p_180657_5_ instanceof BeehiveTileEntity) {
         BeehiveTileEntity beehivetileentity = (BeehiveTileEntity)p_180657_5_;
         if (EnchantmentHelper.func_77506_a(Enchantments.field_185306_r, p_180657_6_) == 0) {
            beehivetileentity.func_226963_a_(p_180657_2_, p_180657_4_, BeehiveTileEntity.State.EMERGENCY);
            p_180657_1_.func_175666_e(p_180657_3_, this);
            this.func_226881_b_(p_180657_1_, p_180657_3_);
         }

         CriteriaTriggers.field_229865_L_.func_226223_a_((ServerPlayerEntity)p_180657_2_, p_180657_4_.func_177230_c(), p_180657_6_, beehivetileentity.func_226971_j_());
      }

   }

   private void func_226881_b_(World p_226881_1_, BlockPos p_226881_2_) {
      List<BeeEntity> list = p_226881_1_.func_217357_a(BeeEntity.class, (new AxisAlignedBB(p_226881_2_)).func_72314_b(8.0D, 6.0D, 8.0D));
      if (!list.isEmpty()) {
         List<PlayerEntity> list1 = p_226881_1_.func_217357_a(PlayerEntity.class, (new AxisAlignedBB(p_226881_2_)).func_72314_b(8.0D, 6.0D, 8.0D));
         int i = list1.size();

         for(BeeEntity beeentity : list) {
            if (beeentity.func_70638_az() == null) {
               beeentity.func_70624_b(list1.get(p_226881_1_.field_73012_v.nextInt(i)));
            }
         }
      }

   }

   public static void func_226878_a_(World p_226878_0_, BlockPos p_226878_1_) {
      func_180635_a(p_226878_0_, p_226878_1_, new ItemStack(Items.field_226635_pU_, 3));
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      ItemStack itemstack = p_225533_4_.func_184586_b(p_225533_5_);
      int i = p_225533_1_.func_177229_b(field_226873_c_);
      boolean flag = false;
      if (i >= 5) {
         if (itemstack.func_77973_b() == Items.field_151097_aZ) {
            p_225533_2_.func_184148_a(p_225533_4_, p_225533_4_.func_226277_ct_(), p_225533_4_.func_226278_cu_(), p_225533_4_.func_226281_cx_(), SoundEvents.field_226133_ah_, SoundCategory.NEUTRAL, 1.0F, 1.0F);
            func_226878_a_(p_225533_2_, p_225533_3_);
            itemstack.func_222118_a(1, p_225533_4_, (p_226874_1_) -> {
               p_226874_1_.func_213334_d(p_225533_5_);
            });
            flag = true;
         } else if (itemstack.func_77973_b() == Items.field_151069_bo) {
            itemstack.func_190918_g(1);
            p_225533_2_.func_184148_a(p_225533_4_, p_225533_4_.func_226277_ct_(), p_225533_4_.func_226278_cu_(), p_225533_4_.func_226281_cx_(), SoundEvents.field_187615_H, SoundCategory.NEUTRAL, 1.0F, 1.0F);
            if (itemstack.func_190926_b()) {
               p_225533_4_.func_184611_a(p_225533_5_, new ItemStack(Items.field_226638_pX_));
            } else if (!p_225533_4_.field_71071_by.func_70441_a(new ItemStack(Items.field_226638_pX_))) {
               p_225533_4_.func_71019_a(new ItemStack(Items.field_226638_pX_), false);
            }

            flag = true;
         }
      }

      if (flag) {
         if (!CampfireBlock.func_235474_a_(p_225533_2_, p_225533_3_)) {
            if (this.func_226882_d_(p_225533_2_, p_225533_3_)) {
               this.func_226881_b_(p_225533_2_, p_225533_3_);
            }

            this.func_226877_a_(p_225533_2_, p_225533_1_, p_225533_3_, p_225533_4_, BeehiveTileEntity.State.EMERGENCY);
         } else {
            this.func_226876_a_(p_225533_2_, p_225533_1_, p_225533_3_);
         }

         return ActionResultType.func_233537_a_(p_225533_2_.field_72995_K);
      } else {
         return super.func_225533_a_(p_225533_1_, p_225533_2_, p_225533_3_, p_225533_4_, p_225533_5_, p_225533_6_);
      }
   }

   private boolean func_226882_d_(World p_226882_1_, BlockPos p_226882_2_) {
      TileEntity tileentity = p_226882_1_.func_175625_s(p_226882_2_);
      if (tileentity instanceof BeehiveTileEntity) {
         BeehiveTileEntity beehivetileentity = (BeehiveTileEntity)tileentity;
         return !beehivetileentity.func_226969_f_();
      } else {
         return false;
      }
   }

   public void func_226877_a_(World p_226877_1_, BlockState p_226877_2_, BlockPos p_226877_3_, @Nullable PlayerEntity p_226877_4_, BeehiveTileEntity.State p_226877_5_) {
      this.func_226876_a_(p_226877_1_, p_226877_2_, p_226877_3_);
      TileEntity tileentity = p_226877_1_.func_175625_s(p_226877_3_);
      if (tileentity instanceof BeehiveTileEntity) {
         BeehiveTileEntity beehivetileentity = (BeehiveTileEntity)tileentity;
         beehivetileentity.func_226963_a_(p_226877_4_, p_226877_2_, p_226877_5_);
      }

   }

   public void func_226876_a_(World p_226876_1_, BlockState p_226876_2_, BlockPos p_226876_3_) {
      p_226876_1_.func_180501_a(p_226876_3_, p_226876_2_.func_206870_a(field_226873_c_, Integer.valueOf(0)), 3);
   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(BlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      if (p_180655_1_.func_177229_b(field_226873_c_) >= 5) {
         for(int i = 0; i < p_180655_4_.nextInt(1) + 1; ++i) {
            this.func_226879_a_(p_180655_2_, p_180655_3_, p_180655_1_);
         }
      }

   }

   @OnlyIn(Dist.CLIENT)
   private void func_226879_a_(World p_226879_1_, BlockPos p_226879_2_, BlockState p_226879_3_) {
      if (p_226879_3_.func_204520_s().func_206888_e() && !(p_226879_1_.field_73012_v.nextFloat() < 0.3F)) {
         VoxelShape voxelshape = p_226879_3_.func_196952_d(p_226879_1_, p_226879_2_);
         double d0 = voxelshape.func_197758_c(Direction.Axis.Y);
         if (d0 >= 1.0D && !p_226879_3_.func_235714_a_(BlockTags.field_211923_H)) {
            double d1 = voxelshape.func_197762_b(Direction.Axis.Y);
            if (d1 > 0.0D) {
               this.func_226880_a_(p_226879_1_, p_226879_2_, voxelshape, (double)p_226879_2_.func_177956_o() + d1 - 0.05D);
            } else {
               BlockPos blockpos = p_226879_2_.func_177977_b();
               BlockState blockstate = p_226879_1_.func_180495_p(blockpos);
               VoxelShape voxelshape1 = blockstate.func_196952_d(p_226879_1_, blockpos);
               double d2 = voxelshape1.func_197758_c(Direction.Axis.Y);
               if ((d2 < 1.0D || !blockstate.func_235785_r_(p_226879_1_, blockpos)) && blockstate.func_204520_s().func_206888_e()) {
                  this.func_226880_a_(p_226879_1_, p_226879_2_, voxelshape, (double)p_226879_2_.func_177956_o() - 0.05D);
               }
            }
         }

      }
   }

   @OnlyIn(Dist.CLIENT)
   private void func_226880_a_(World p_226880_1_, BlockPos p_226880_2_, VoxelShape p_226880_3_, double p_226880_4_) {
      this.func_226875_a_(p_226880_1_, (double)p_226880_2_.func_177958_n() + p_226880_3_.func_197762_b(Direction.Axis.X), (double)p_226880_2_.func_177958_n() + p_226880_3_.func_197758_c(Direction.Axis.X), (double)p_226880_2_.func_177952_p() + p_226880_3_.func_197762_b(Direction.Axis.Z), (double)p_226880_2_.func_177952_p() + p_226880_3_.func_197758_c(Direction.Axis.Z), p_226880_4_);
   }

   @OnlyIn(Dist.CLIENT)
   private void func_226875_a_(World p_226875_1_, double p_226875_2_, double p_226875_4_, double p_226875_6_, double p_226875_8_, double p_226875_10_) {
      p_226875_1_.func_195594_a(ParticleTypes.field_229427_ag_, MathHelper.func_219803_d(p_226875_1_.field_73012_v.nextDouble(), p_226875_2_, p_226875_4_), p_226875_10_, MathHelper.func_219803_d(p_226875_1_.field_73012_v.nextDouble(), p_226875_6_, p_226875_8_), 0.0D, 0.0D, 0.0D);
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_226872_b_, p_196258_1_.func_195992_f().func_176734_d());
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_226873_c_, field_226872_b_);
   }

   public BlockRenderType func_149645_b(BlockState p_149645_1_) {
      return BlockRenderType.MODEL;
   }

   @Nullable
   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new BeehiveTileEntity();
   }

   public void func_176208_a(World p_176208_1_, BlockPos p_176208_2_, BlockState p_176208_3_, PlayerEntity p_176208_4_) {
      if (!p_176208_1_.field_72995_K && p_176208_4_.func_184812_l_() && p_176208_1_.func_82736_K().func_223586_b(GameRules.field_223603_f)) {
         TileEntity tileentity = p_176208_1_.func_175625_s(p_176208_2_);
         if (tileentity instanceof BeehiveTileEntity) {
            BeehiveTileEntity beehivetileentity = (BeehiveTileEntity)tileentity;
            ItemStack itemstack = new ItemStack(this);
            int i = p_176208_3_.func_177229_b(field_226873_c_);
            boolean flag = !beehivetileentity.func_226969_f_();
            if (!flag && i == 0) {
               return;
            }

            if (flag) {
               CompoundNBT compoundnbt = new CompoundNBT();
               compoundnbt.func_218657_a("Bees", beehivetileentity.func_226974_m_());
               itemstack.func_77983_a("BlockEntityTag", compoundnbt);
            }

            CompoundNBT compoundnbt1 = new CompoundNBT();
            compoundnbt1.func_74768_a("honey_level", i);
            itemstack.func_77983_a("BlockStateTag", compoundnbt1);
            ItemEntity itementity = new ItemEntity(p_176208_1_, (double)p_176208_2_.func_177958_n(), (double)p_176208_2_.func_177956_o(), (double)p_176208_2_.func_177952_p(), itemstack);
            itementity.func_174869_p();
            p_176208_1_.func_217376_c(itementity);
         }
      }

      super.func_176208_a(p_176208_1_, p_176208_2_, p_176208_3_, p_176208_4_);
   }

   public List<ItemStack> func_220076_a(BlockState p_220076_1_, LootContext.Builder p_220076_2_) {
      Entity entity = p_220076_2_.func_216019_b(LootParameters.field_216281_a);
      if (entity instanceof TNTEntity || entity instanceof CreeperEntity || entity instanceof WitherSkullEntity || entity instanceof WitherEntity || entity instanceof TNTMinecartEntity) {
         TileEntity tileentity = p_220076_2_.func_216019_b(LootParameters.field_216288_h);
         if (tileentity instanceof BeehiveTileEntity) {
            BeehiveTileEntity beehivetileentity = (BeehiveTileEntity)tileentity;
            beehivetileentity.func_226963_a_((PlayerEntity)null, p_220076_1_, BeehiveTileEntity.State.EMERGENCY);
         }
      }

      return super.func_220076_a(p_220076_1_, p_220076_2_);
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_4_.func_180495_p(p_196271_6_).func_177230_c() instanceof FireBlock) {
         TileEntity tileentity = p_196271_4_.func_175625_s(p_196271_5_);
         if (tileentity instanceof BeehiveTileEntity) {
            BeehiveTileEntity beehivetileentity = (BeehiveTileEntity)tileentity;
            beehivetileentity.func_226963_a_((PlayerEntity)null, p_196271_1_, BeehiveTileEntity.State.EMERGENCY);
         }
      }

      return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public static Direction func_235331_a_(Random p_235331_0_) {
      return Util.func_240989_a_(field_226871_a_, p_235331_0_);
   }
}
