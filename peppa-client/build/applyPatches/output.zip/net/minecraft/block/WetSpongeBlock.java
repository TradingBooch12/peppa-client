package net.minecraft.block;

import java.util.Random;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.Direction;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class WetSpongeBlock extends Block {
   protected WetSpongeBlock(AbstractBlock.Properties p_i48294_1_) {
      super(p_i48294_1_);
   }

   public void func_220082_b(BlockState p_220082_1_, World p_220082_2_, BlockPos p_220082_3_, BlockState p_220082_4_, boolean p_220082_5_) {
      if (p_220082_2_.func_230315_m_().func_236040_e_()) {
         p_220082_2_.func_180501_a(p_220082_3_, Blocks.field_150360_v.func_176223_P(), 3);
         p_220082_2_.func_217379_c(2009, p_220082_3_, 0);
         p_220082_2_.func_184133_a((PlayerEntity)null, p_220082_3_, SoundEvents.field_187646_bt, SoundCategory.BLOCKS, 1.0F, (1.0F + p_220082_2_.func_201674_k().nextFloat() * 0.2F) * 0.7F);
      }

   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(BlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      Direction direction = Direction.func_239631_a_(p_180655_4_);
      if (direction != Direction.UP) {
         BlockPos blockpos = p_180655_3_.func_177972_a(direction);
         BlockState blockstate = p_180655_2_.func_180495_p(blockpos);
         if (!p_180655_1_.func_200132_m() || !blockstate.func_224755_d(p_180655_2_, blockpos, direction.func_176734_d())) {
            double d0 = (double)p_180655_3_.func_177958_n();
            double d1 = (double)p_180655_3_.func_177956_o();
            double d2 = (double)p_180655_3_.func_177952_p();
            if (direction == Direction.DOWN) {
               d1 = d1 - 0.05D;
               d0 += p_180655_4_.nextDouble();
               d2 += p_180655_4_.nextDouble();
            } else {
               d1 = d1 + p_180655_4_.nextDouble() * 0.8D;
               if (direction.func_176740_k() == Direction.Axis.X) {
                  d2 += p_180655_4_.nextDouble();
                  if (direction == Direction.EAST) {
                     ++d0;
                  } else {
                     d0 += 0.05D;
                  }
               } else {
                  d0 += p_180655_4_.nextDouble();
                  if (direction == Direction.SOUTH) {
                     ++d2;
                  } else {
                     d2 += 0.05D;
                  }
               }
            }

            p_180655_2_.func_195594_a(ParticleTypes.field_197618_k, d0, d1, d2, 0.0D, 0.0D, 0.0D);
         }
      }
   }
}
