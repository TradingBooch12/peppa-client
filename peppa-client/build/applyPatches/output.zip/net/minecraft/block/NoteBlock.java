package net.minecraft.block;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.NoteBlockInstrument;
import net.minecraft.stats.Stats;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class NoteBlock extends Block {
   public static final EnumProperty<NoteBlockInstrument> field_196483_a = BlockStateProperties.field_208143_ar;
   public static final BooleanProperty field_196484_b = BlockStateProperties.field_208194_u;
   public static final IntegerProperty field_196485_c = BlockStateProperties.field_208134_ai;

   public NoteBlock(AbstractBlock.Properties p_i48359_1_) {
      super(p_i48359_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196483_a, NoteBlockInstrument.HARP).func_206870_a(field_196485_c, Integer.valueOf(0)).func_206870_a(field_196484_b, Boolean.valueOf(false)));
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_196483_a, NoteBlockInstrument.func_208087_a(p_196258_1_.func_195991_k().func_180495_p(p_196258_1_.func_195995_a().func_177977_b())));
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return p_196271_2_ == Direction.DOWN ? p_196271_1_.func_206870_a(field_196483_a, NoteBlockInstrument.func_208087_a(p_196271_3_)) : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public void func_220069_a(BlockState p_220069_1_, World p_220069_2_, BlockPos p_220069_3_, Block p_220069_4_, BlockPos p_220069_5_, boolean p_220069_6_) {
      boolean flag = p_220069_2_.func_175640_z(p_220069_3_);
      if (flag != p_220069_1_.func_177229_b(field_196484_b)) {
         if (flag) {
            this.func_196482_a(p_220069_2_, p_220069_3_);
         }

         p_220069_2_.func_180501_a(p_220069_3_, p_220069_1_.func_206870_a(field_196484_b, Boolean.valueOf(flag)), 3);
      }

   }

   private void func_196482_a(World p_196482_1_, BlockPos p_196482_2_) {
      if (p_196482_1_.func_180495_p(p_196482_2_.func_177984_a()).func_196958_f()) {
         p_196482_1_.func_175641_c(p_196482_2_, this, 0, 0);
      }

   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      if (p_225533_2_.field_72995_K) {
         return ActionResultType.SUCCESS;
      } else {
         p_225533_1_ = p_225533_1_.func_235896_a_(field_196485_c);
         p_225533_2_.func_180501_a(p_225533_3_, p_225533_1_, 3);
         this.func_196482_a(p_225533_2_, p_225533_3_);
         p_225533_4_.func_195066_a(Stats.field_188087_U);
         return ActionResultType.CONSUME;
      }
   }

   public void func_196270_a(BlockState p_196270_1_, World p_196270_2_, BlockPos p_196270_3_, PlayerEntity p_196270_4_) {
      if (!p_196270_2_.field_72995_K) {
         this.func_196482_a(p_196270_2_, p_196270_3_);
         p_196270_4_.func_195066_a(Stats.field_188086_T);
      }
   }

   public boolean func_189539_a(BlockState p_189539_1_, World p_189539_2_, BlockPos p_189539_3_, int p_189539_4_, int p_189539_5_) {
      int i = p_189539_1_.func_177229_b(field_196485_c);
      float f = (float)Math.pow(2.0D, (double)(i - 12) / 12.0D);
      p_189539_2_.func_184133_a((PlayerEntity)null, p_189539_3_, p_189539_1_.func_177229_b(field_196483_a).func_208088_a(), SoundCategory.RECORDS, 3.0F, f);
      p_189539_2_.func_195594_a(ParticleTypes.field_197597_H, (double)p_189539_3_.func_177958_n() + 0.5D, (double)p_189539_3_.func_177956_o() + 1.2D, (double)p_189539_3_.func_177952_p() + 0.5D, (double)i / 24.0D, 0.0D, 0.0D);
      return true;
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196483_a, field_196484_b, field_196485_c);
   }
}
