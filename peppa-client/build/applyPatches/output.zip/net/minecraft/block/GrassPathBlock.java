package net.minecraft.block;

import java.util.Random;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.pathfinding.PathType;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.server.ServerWorld;

public class GrassPathBlock extends Block {
   protected static final VoxelShape field_196453_a = FarmlandBlock.field_196432_b;

   protected GrassPathBlock(AbstractBlock.Properties p_i48386_1_) {
      super(p_i48386_1_);
   }

   public boolean func_220074_n(BlockState p_220074_1_) {
      return true;
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return !this.func_176223_P().func_196955_c(p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a()) ? Block.func_199601_a(this.func_176223_P(), Blocks.field_150346_d.func_176223_P(), p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a()) : super.func_196258_a(p_196258_1_);
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_2_ == Direction.UP && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_)) {
         p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, 1);
      }

      return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
      FarmlandBlock.func_199610_d(p_225534_1_, p_225534_2_, p_225534_3_);
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      BlockState blockstate = p_196260_2_.func_180495_p(p_196260_3_.func_177984_a());
      return !blockstate.func_185904_a().func_76220_a() || blockstate.func_177230_c() instanceof FenceGateBlock;
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196453_a;
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
