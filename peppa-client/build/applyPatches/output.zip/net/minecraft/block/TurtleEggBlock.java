package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.monster.ZombieEntity;
import net.minecraft.entity.passive.BatEntity;
import net.minecraft.entity.passive.TurtleEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tags.BlockTags;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.GameRules;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class TurtleEggBlock extends Block {
   private static final VoxelShape field_203172_c = Block.func_208617_a(3.0D, 0.0D, 3.0D, 12.0D, 7.0D, 12.0D);
   private static final VoxelShape field_206843_t = Block.func_208617_a(1.0D, 0.0D, 1.0D, 15.0D, 7.0D, 15.0D);
   public static final IntegerProperty field_203170_a = BlockStateProperties.field_208128_ac;
   public static final IntegerProperty field_203171_b = BlockStateProperties.field_208127_ab;

   public TurtleEggBlock(AbstractBlock.Properties p_i48778_1_) {
      super(p_i48778_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_203170_a, Integer.valueOf(0)).func_206870_a(field_203171_b, Integer.valueOf(1)));
   }

   public void func_176199_a(World p_176199_1_, BlockPos p_176199_2_, Entity p_176199_3_) {
      this.func_203167_a(p_176199_1_, p_176199_2_, p_176199_3_, 100);
      super.func_176199_a(p_176199_1_, p_176199_2_, p_176199_3_);
   }

   public void func_180658_a(World p_180658_1_, BlockPos p_180658_2_, Entity p_180658_3_, float p_180658_4_) {
      if (!(p_180658_3_ instanceof ZombieEntity)) {
         this.func_203167_a(p_180658_1_, p_180658_2_, p_180658_3_, 3);
      }

      super.func_180658_a(p_180658_1_, p_180658_2_, p_180658_3_, p_180658_4_);
   }

   private void func_203167_a(World p_203167_1_, BlockPos p_203167_2_, Entity p_203167_3_, int p_203167_4_) {
      if (this.func_212570_a(p_203167_1_, p_203167_3_)) {
         if (!p_203167_1_.field_72995_K && p_203167_1_.field_73012_v.nextInt(p_203167_4_) == 0) {
            BlockState blockstate = p_203167_1_.func_180495_p(p_203167_2_);
            if (blockstate.func_203425_a(Blocks.field_203213_jA)) {
               this.func_203166_c(p_203167_1_, p_203167_2_, blockstate);
            }
         }

      }
   }

   private void func_203166_c(World p_203166_1_, BlockPos p_203166_2_, BlockState p_203166_3_) {
      p_203166_1_.func_184133_a((PlayerEntity)null, p_203166_2_, SoundEvents.field_203281_iz, SoundCategory.BLOCKS, 0.7F, 0.9F + p_203166_1_.field_73012_v.nextFloat() * 0.2F);
      int i = p_203166_3_.func_177229_b(field_203171_b);
      if (i <= 1) {
         p_203166_1_.func_175655_b(p_203166_2_, false);
      } else {
         p_203166_1_.func_180501_a(p_203166_2_, p_203166_3_.func_206870_a(field_203171_b, Integer.valueOf(i - 1)), 2);
         p_203166_1_.func_217379_c(2001, p_203166_2_, Block.func_196246_j(p_203166_3_));
      }

   }

   public void func_225542_b_(BlockState p_225542_1_, ServerWorld p_225542_2_, BlockPos p_225542_3_, Random p_225542_4_) {
      if (this.func_203169_a(p_225542_2_) && func_203168_a(p_225542_2_, p_225542_3_)) {
         int i = p_225542_1_.func_177229_b(field_203170_a);
         if (i < 2) {
            p_225542_2_.func_184133_a((PlayerEntity)null, p_225542_3_, SoundEvents.field_203280_iy, SoundCategory.BLOCKS, 0.7F, 0.9F + p_225542_4_.nextFloat() * 0.2F);
            p_225542_2_.func_180501_a(p_225542_3_, p_225542_1_.func_206870_a(field_203170_a, Integer.valueOf(i + 1)), 2);
         } else {
            p_225542_2_.func_184133_a((PlayerEntity)null, p_225542_3_, SoundEvents.field_203279_ix, SoundCategory.BLOCKS, 0.7F, 0.9F + p_225542_4_.nextFloat() * 0.2F);
            p_225542_2_.func_217377_a(p_225542_3_, false);

            for(int j = 0; j < p_225542_1_.func_177229_b(field_203171_b); ++j) {
               p_225542_2_.func_217379_c(2001, p_225542_3_, Block.func_196246_j(p_225542_1_));
               TurtleEntity turtleentity = EntityType.field_203099_aq.func_200721_a(p_225542_2_);
               turtleentity.func_70873_a(-24000);
               turtleentity.func_203011_g(p_225542_3_);
               turtleentity.func_70012_b((double)p_225542_3_.func_177958_n() + 0.3D + (double)j * 0.2D, (double)p_225542_3_.func_177956_o(), (double)p_225542_3_.func_177952_p() + 0.3D, 0.0F, 0.0F);
               p_225542_2_.func_217376_c(turtleentity);
            }
         }
      }

   }

   public static boolean func_203168_a(IBlockReader p_203168_0_, BlockPos p_203168_1_) {
      return func_241473_b_(p_203168_0_, p_203168_1_.func_177977_b());
   }

   public static boolean func_241473_b_(IBlockReader p_241473_0_, BlockPos p_241473_1_) {
      return p_241473_0_.func_180495_p(p_241473_1_).func_235714_a_(BlockTags.field_203436_u);
   }

   public void func_220082_b(BlockState p_220082_1_, World p_220082_2_, BlockPos p_220082_3_, BlockState p_220082_4_, boolean p_220082_5_) {
      if (func_203168_a(p_220082_2_, p_220082_3_) && !p_220082_2_.field_72995_K) {
         p_220082_2_.func_217379_c(2005, p_220082_3_, 0);
      }

   }

   private boolean func_203169_a(World p_203169_1_) {
      float f = p_203169_1_.func_242415_f(1.0F);
      if ((double)f < 0.69D && (double)f > 0.65D) {
         return true;
      } else {
         return p_203169_1_.field_73012_v.nextInt(500) == 0;
      }
   }

   public void func_180657_a(World p_180657_1_, PlayerEntity p_180657_2_, BlockPos p_180657_3_, BlockState p_180657_4_, @Nullable TileEntity p_180657_5_, ItemStack p_180657_6_) {
      super.func_180657_a(p_180657_1_, p_180657_2_, p_180657_3_, p_180657_4_, p_180657_5_, p_180657_6_);
      this.func_203166_c(p_180657_1_, p_180657_3_, p_180657_4_);
   }

   public boolean func_196253_a(BlockState p_196253_1_, BlockItemUseContext p_196253_2_) {
      return p_196253_2_.func_195996_i().func_77973_b() == this.func_199767_j() && p_196253_1_.func_177229_b(field_203171_b) < 4 ? true : super.func_196253_a(p_196253_1_, p_196253_2_);
   }

   @Nullable
   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      BlockState blockstate = p_196258_1_.func_195991_k().func_180495_p(p_196258_1_.func_195995_a());
      return blockstate.func_203425_a(this) ? blockstate.func_206870_a(field_203171_b, Integer.valueOf(Math.min(4, blockstate.func_177229_b(field_203171_b) + 1))) : super.func_196258_a(p_196258_1_);
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return p_220053_1_.func_177229_b(field_203171_b) > 1 ? field_206843_t : field_203172_c;
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_203170_a, field_203171_b);
   }

   private boolean func_212570_a(World p_212570_1_, Entity p_212570_2_) {
      if (!(p_212570_2_ instanceof TurtleEntity) && !(p_212570_2_ instanceof BatEntity)) {
         if (!(p_212570_2_ instanceof LivingEntity)) {
            return false;
         } else {
            return p_212570_2_ instanceof PlayerEntity || p_212570_1_.func_82736_K().func_223586_b(GameRules.field_223599_b);
         }
      } else {
         return false;
      }
   }
}
