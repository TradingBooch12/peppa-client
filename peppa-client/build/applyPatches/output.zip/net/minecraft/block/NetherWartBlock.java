package net.minecraft.block;

import java.util.Random;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class NetherWartBlock extends BushBlock {
   public static final IntegerProperty field_176486_a = BlockStateProperties.field_208168_U;
   private static final VoxelShape[] field_196399_b = new VoxelShape[]{Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 5.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 11.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 14.0D, 16.0D)};

   protected NetherWartBlock(AbstractBlock.Properties p_i48361_1_) {
      super(p_i48361_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176486_a, Integer.valueOf(0)));
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196399_b[p_220053_1_.func_177229_b(field_176486_a)];
   }

   protected boolean func_200014_a_(BlockState p_200014_1_, IBlockReader p_200014_2_, BlockPos p_200014_3_) {
      return p_200014_1_.func_203425_a(Blocks.field_150425_aM);
   }

   public boolean func_149653_t(BlockState p_149653_1_) {
      return p_149653_1_.func_177229_b(field_176486_a) < 3;
   }

   public void func_225542_b_(BlockState p_225542_1_, ServerWorld p_225542_2_, BlockPos p_225542_3_, Random p_225542_4_) {
      int i = p_225542_1_.func_177229_b(field_176486_a);
      if (i < 3 && p_225542_4_.nextInt(10) == 0) {
         p_225542_1_ = p_225542_1_.func_206870_a(field_176486_a, Integer.valueOf(i + 1));
         p_225542_2_.func_180501_a(p_225542_3_, p_225542_1_, 2);
      }

   }

   @OnlyIn(Dist.CLIENT)
   public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, BlockState p_185473_3_) {
      return new ItemStack(Items.field_151075_bm);
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176486_a);
   }
}
