package net.minecraft.block;

import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class SandBlock extends FallingBlock {
   private final int field_196445_a;

   public SandBlock(int p_i48338_1_, AbstractBlock.Properties p_i48338_2_) {
      super(p_i48338_2_);
      this.field_196445_a = p_i48338_1_;
   }

   @OnlyIn(Dist.CLIENT)
   public int func_189876_x(BlockState p_189876_1_, IBlockReader p_189876_2_, BlockPos p_189876_3_) {
      return this.field_196445_a;
   }
}
