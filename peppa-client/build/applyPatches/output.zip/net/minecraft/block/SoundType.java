package net.minecraft.block;

import net.minecraft.util.SoundEvent;
import net.minecraft.util.SoundEvents;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class SoundType {
   public static final SoundType field_185848_a = new SoundType(1.0F, 1.0F, SoundEvents.field_187881_gQ, SoundEvents.field_187897_gY, SoundEvents.field_187891_gV, SoundEvents.field_187889_gU, SoundEvents.field_187887_gT);
   public static final SoundType field_185849_b = new SoundType(1.0F, 1.0F, SoundEvents.field_187581_bW, SoundEvents.field_187668_ca, SoundEvents.field_187587_bZ, SoundEvents.field_187585_bY, SoundEvents.field_187583_bX);
   public static final SoundType field_185850_c = new SoundType(1.0F, 1.0F, SoundEvents.field_187571_bR, SoundEvents.field_187579_bV, SoundEvents.field_187577_bU, SoundEvents.field_187575_bT, SoundEvents.field_187573_bS);
   public static final SoundType field_235600_d_ = new SoundType(1.0F, 1.0F, SoundEvents.field_187571_bR, SoundEvents.field_187579_bV, SoundEvents.field_187916_gp, SoundEvents.field_187575_bT, SoundEvents.field_187573_bS);
   public static final SoundType field_185851_d = new SoundType(1.0F, 1.0F, SoundEvents.field_187835_fT, SoundEvents.field_187902_gb, SoundEvents.field_187845_fY, SoundEvents.field_187843_fX, SoundEvents.field_187841_fW);
   public static final SoundType field_185852_e = new SoundType(1.0F, 1.5F, SoundEvents.field_187766_dk, SoundEvents.field_187778_dq, SoundEvents.field_187772_dn, SoundEvents.field_187770_dm, SoundEvents.field_187768_dl);
   public static final SoundType field_185853_f = new SoundType(1.0F, 1.0F, SoundEvents.field_187561_bM, SoundEvents.field_187569_bQ, SoundEvents.field_187567_bP, SoundEvents.field_187565_bO, SoundEvents.field_187563_bN);
   public static final SoundType field_185854_g = new SoundType(1.0F, 1.0F, SoundEvents.field_187546_ae, SoundEvents.field_187554_ai, SoundEvents.field_187552_ah, SoundEvents.field_187550_ag, SoundEvents.field_187548_af);
   public static final SoundType field_185855_h = new SoundType(1.0F, 1.0F, SoundEvents.field_187747_eB, SoundEvents.field_187755_eF, SoundEvents.field_187753_eE, SoundEvents.field_187751_eD, SoundEvents.field_187749_eC);
   public static final SoundType field_185856_i = new SoundType(1.0F, 1.0F, SoundEvents.field_187807_fF, SoundEvents.field_187815_fJ, SoundEvents.field_187813_fI, SoundEvents.field_187811_fH, SoundEvents.field_187809_fG);
   public static final SoundType field_185857_j = new SoundType(1.0F, 1.0F, SoundEvents.field_187641_cS, SoundEvents.field_187653_cW, SoundEvents.field_187650_cV, SoundEvents.field_187647_cU, SoundEvents.field_187644_cT);
   public static final SoundType field_185858_k = new SoundType(0.3F, 1.0F, SoundEvents.field_187677_b, SoundEvents.field_187695_h, SoundEvents.field_187692_g, SoundEvents.field_187686_e, SoundEvents.field_187683_d);
   public static final SoundType field_185859_l = new SoundType(1.0F, 1.0F, SoundEvents.field_187872_fl, SoundEvents.field_187888_ft, SoundEvents.field_187884_fr, SoundEvents.field_187878_fo, SoundEvents.field_187876_fn);
   public static final SoundType field_226947_m_ = new SoundType(1.0F, 1.0F, SoundEvents.field_226135_eP_, SoundEvents.field_226140_eU_, SoundEvents.field_226138_eS_, SoundEvents.field_226137_eR_, SoundEvents.field_226136_eQ_);
   public static final SoundType field_211382_m = new SoundType(1.0F, 1.0F, SoundEvents.field_211414_dn, SoundEvents.field_211418_dr, SoundEvents.field_211417_dq, SoundEvents.field_211416_dp, SoundEvents.field_211415_do);
   public static final SoundType field_211383_n = new SoundType(1.0F, 1.0F, SoundEvents.field_211419_ds, SoundEvents.field_211423_dw, SoundEvents.field_211422_dv, SoundEvents.field_211421_du, SoundEvents.field_211420_dt);
   public static final SoundType field_222468_o = new SoundType(1.0F, 1.0F, SoundEvents.field_219593_F, SoundEvents.field_219597_J, SoundEvents.field_219596_I, SoundEvents.field_219595_H, SoundEvents.field_219594_G);
   public static final SoundType field_222469_p = new SoundType(1.0F, 1.0F, SoundEvents.field_219598_K, SoundEvents.field_219597_J, SoundEvents.field_219600_M, SoundEvents.field_219599_L, SoundEvents.field_219594_G);
   public static final SoundType field_222470_q = new SoundType(1.0F, 1.0F, SoundEvents.field_219681_jK, SoundEvents.field_219685_jO, SoundEvents.field_219684_jN, SoundEvents.field_219683_jM, SoundEvents.field_219682_jL);
   public static final SoundType field_222471_r = new SoundType(1.0F, 1.0F, SoundEvents.field_219715_lz, SoundEvents.field_187579_bV, SoundEvents.field_219692_lA, SoundEvents.field_187575_bT, SoundEvents.field_187573_bS);
   public static final SoundType field_222472_s = new SoundType(1.0F, 1.0F, SoundEvents.field_219625_by, SoundEvents.field_187579_bV, SoundEvents.field_219626_bz, SoundEvents.field_187575_bT, SoundEvents.field_187573_bS);
   public static final SoundType field_222473_t = new SoundType(1.0F, 1.0F, SoundEvents.field_187881_gQ, SoundEvents.field_187897_gY, SoundEvents.field_219626_bz, SoundEvents.field_187889_gU, SoundEvents.field_187887_gT);
   public static final SoundType field_235601_w_ = new SoundType(1.0F, 1.0F, SoundEvents.field_187571_bR, SoundEvents.field_232845_qj_, SoundEvents.field_187577_bU, SoundEvents.field_187575_bT, SoundEvents.field_187573_bS);
   public static final SoundType field_222474_u = new SoundType(1.0F, 1.0F, SoundEvents.field_219651_gM, SoundEvents.field_187902_gb, SoundEvents.field_219652_gN, SoundEvents.field_187843_fX, SoundEvents.field_187841_fW);
   public static final SoundType field_222475_v = new SoundType(1.0F, 1.0F, SoundEvents.field_219637_fL, SoundEvents.field_219641_fP, SoundEvents.field_219640_fO, SoundEvents.field_219639_fN, SoundEvents.field_219638_fM);
   public static final SoundType field_235602_z_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232733_iB_, SoundEvents.field_232734_iC_, SoundEvents.field_232735_iD_, SoundEvents.field_232736_iE_, SoundEvents.field_232737_iF_);
   public static final SoundType field_235579_A_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232738_iG_, SoundEvents.field_232739_iH_, SoundEvents.field_232740_iI_, SoundEvents.field_232741_iJ_, SoundEvents.field_232742_iK_);
   public static final SoundType field_235580_B_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232748_iQ_, SoundEvents.field_232749_iR_, SoundEvents.field_232750_iS_, SoundEvents.field_232751_iT_, SoundEvents.field_232752_iU_);
   public static final SoundType field_235581_C_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232702_eA_, SoundEvents.field_232703_eB_, SoundEvents.field_232704_eC_, SoundEvents.field_232705_eD_, SoundEvents.field_232706_eE_);
   public static final SoundType field_235582_D_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232801_mP_, SoundEvents.field_232802_mQ_, SoundEvents.field_232803_mR_, SoundEvents.field_232804_mS_, SoundEvents.field_232805_mT_);
   public static final SoundType field_235583_E_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232753_iV_, SoundEvents.field_232754_iW_, SoundEvents.field_232755_iX_, SoundEvents.field_232756_iY_, SoundEvents.field_232757_iZ_);
   public static final SoundType field_235584_F_ = new SoundType(1.0F, 0.5F, SoundEvents.field_232753_iV_, SoundEvents.field_232754_iW_, SoundEvents.field_232755_iX_, SoundEvents.field_232756_iY_, SoundEvents.field_232757_iZ_);
   public static final SoundType field_235585_G_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232821_nI_, SoundEvents.field_232822_nJ_, SoundEvents.field_232823_nK_, SoundEvents.field_232824_nL_, SoundEvents.field_232825_nM_);
   public static final SoundType field_235586_H_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232826_nN_, SoundEvents.field_232827_nO_, SoundEvents.field_232828_nP_, SoundEvents.field_232829_nQ_, SoundEvents.field_232830_nR_);
   public static final SoundType field_235587_I_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232687_ak_, SoundEvents.field_232688_al_, SoundEvents.field_232689_am_, SoundEvents.field_232690_an_, SoundEvents.field_232691_ao_);
   public static final SoundType field_235588_J_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232770_ja_, SoundEvents.field_232771_jb_, SoundEvents.field_232772_jc_, SoundEvents.field_232773_jd_, SoundEvents.field_232774_je_);
   public static final SoundType field_235589_K_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232780_jk_, SoundEvents.field_232781_jl_, SoundEvents.field_232782_jm_, SoundEvents.field_232783_jn_, SoundEvents.field_232784_jo_);
   public static final SoundType field_235590_L_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232764_iu_, SoundEvents.field_232765_iv_, SoundEvents.field_232766_iw_, SoundEvents.field_232767_ix_, SoundEvents.field_232768_iy_);
   public static final SoundType field_235591_M_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232743_iL_, SoundEvents.field_232744_iM_, SoundEvents.field_232745_iN_, SoundEvents.field_232746_iO_, SoundEvents.field_232747_iP_);
   public static final SoundType field_235592_N_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232811_mk_, SoundEvents.field_232815_mo_, SoundEvents.field_232814_mn_, SoundEvents.field_232813_mm_, SoundEvents.field_232812_ml_);
   public static final SoundType field_235593_O_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232682_aS_, SoundEvents.field_232686_aW_, SoundEvents.field_232685_aV_, SoundEvents.field_232684_aU_, SoundEvents.field_232683_aT_);
   public static final SoundType field_235594_P_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232775_jf_, SoundEvents.field_232776_jg_, SoundEvents.field_232777_jh_, SoundEvents.field_232778_ji_, SoundEvents.field_232779_jj_);
   public static final SoundType field_235595_Q_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232856_w_, SoundEvents.field_232857_x_, SoundEvents.field_232858_y_, SoundEvents.field_232859_z_, SoundEvents.field_232680_A_);
   public static final SoundType field_235596_R_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232726_hp_, SoundEvents.field_232727_hq_, SoundEvents.field_232728_hr_, SoundEvents.field_232729_hs_, SoundEvents.field_232730_ht_);
   public static final SoundType field_235597_S_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232697_bz_, SoundEvents.field_232696_bD_, SoundEvents.field_232695_bC_, SoundEvents.field_232694_bB_, SoundEvents.field_232693_bA_);
   public static final SoundType field_235598_T_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232806_mf_, SoundEvents.field_232810_mj_, SoundEvents.field_232809_mi_, SoundEvents.field_232808_mh_, SoundEvents.field_232807_mg_);
   public static final SoundType field_235599_U_ = new SoundType(1.0F, 1.0F, SoundEvents.field_232707_eX_, SoundEvents.field_232721_fb_, SoundEvents.field_232720_fa_, SoundEvents.field_232709_eZ_, SoundEvents.field_232708_eY_);
   public final float field_185860_m;
   public final float field_185861_n;
   private final SoundEvent field_185862_o;
   private final SoundEvent field_185863_p;
   private final SoundEvent field_185864_q;
   private final SoundEvent field_185865_r;
   private final SoundEvent field_185866_s;

   public SoundType(float p_i46679_1_, float p_i46679_2_, SoundEvent p_i46679_3_, SoundEvent p_i46679_4_, SoundEvent p_i46679_5_, SoundEvent p_i46679_6_, SoundEvent p_i46679_7_) {
      this.field_185860_m = p_i46679_1_;
      this.field_185861_n = p_i46679_2_;
      this.field_185862_o = p_i46679_3_;
      this.field_185863_p = p_i46679_4_;
      this.field_185864_q = p_i46679_5_;
      this.field_185865_r = p_i46679_6_;
      this.field_185866_s = p_i46679_7_;
   }

   public float func_185843_a() {
      return this.field_185860_m;
   }

   public float func_185847_b() {
      return this.field_185861_n;
   }

   @OnlyIn(Dist.CLIENT)
   public SoundEvent func_185845_c() {
      return this.field_185862_o;
   }

   public SoundEvent func_185844_d() {
      return this.field_185863_p;
   }

   public SoundEvent func_185841_e() {
      return this.field_185864_q;
   }

   @OnlyIn(Dist.CLIENT)
   public SoundEvent func_185846_f() {
      return this.field_185865_r;
   }

   public SoundEvent func_185842_g() {
      return this.field_185866_s;
   }
}
