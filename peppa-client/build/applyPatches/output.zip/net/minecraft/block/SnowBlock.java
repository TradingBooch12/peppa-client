package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.LightType;
import net.minecraft.world.server.ServerWorld;

public class SnowBlock extends Block {
   public static final IntegerProperty field_176315_a = BlockStateProperties.field_208129_ad;
   protected static final VoxelShape[] field_196508_b = new VoxelShape[]{VoxelShapes.func_197880_a(), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 4.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 6.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 8.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 10.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 12.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 14.0D, 16.0D), Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D)};

   protected SnowBlock(AbstractBlock.Properties p_i48328_1_) {
      super(p_i48328_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176315_a, Integer.valueOf(1)));
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      switch(p_196266_4_) {
      case LAND:
         return p_196266_1_.func_177229_b(field_176315_a) < 5;
      case WATER:
         return false;
      case AIR:
         return false;
      default:
         return false;
      }
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196508_b[p_220053_1_.func_177229_b(field_176315_a)];
   }

   public VoxelShape func_220071_b(BlockState p_220071_1_, IBlockReader p_220071_2_, BlockPos p_220071_3_, ISelectionContext p_220071_4_) {
      return field_196508_b[p_220071_1_.func_177229_b(field_176315_a) - 1];
   }

   public VoxelShape func_230335_e_(BlockState p_230335_1_, IBlockReader p_230335_2_, BlockPos p_230335_3_) {
      return field_196508_b[p_230335_1_.func_177229_b(field_176315_a)];
   }

   public VoxelShape func_230322_a_(BlockState p_230322_1_, IBlockReader p_230322_2_, BlockPos p_230322_3_, ISelectionContext p_230322_4_) {
      return field_196508_b[p_230322_1_.func_177229_b(field_176315_a)];
   }

   public boolean func_220074_n(BlockState p_220074_1_) {
      return true;
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      BlockState blockstate = p_196260_2_.func_180495_p(p_196260_3_.func_177977_b());
      if (!blockstate.func_203425_a(Blocks.field_150432_aD) && !blockstate.func_203425_a(Blocks.field_150403_cj) && !blockstate.func_203425_a(Blocks.field_180401_cv)) {
         if (!blockstate.func_203425_a(Blocks.field_226907_mc_) && !blockstate.func_203425_a(Blocks.field_150425_aM)) {
            return Block.func_208061_a(blockstate.func_196952_d(p_196260_2_, p_196260_3_.func_177977_b()), Direction.UP) || blockstate.func_177230_c() == this && blockstate.func_177229_b(field_176315_a) == 8;
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public void func_225542_b_(BlockState p_225542_1_, ServerWorld p_225542_2_, BlockPos p_225542_3_, Random p_225542_4_) {
      if (p_225542_2_.func_226658_a_(LightType.BLOCK, p_225542_3_) > 11) {
         func_220075_c(p_225542_1_, p_225542_2_, p_225542_3_);
         p_225542_2_.func_217377_a(p_225542_3_, false);
      }

   }

   public boolean func_196253_a(BlockState p_196253_1_, BlockItemUseContext p_196253_2_) {
      int i = p_196253_1_.func_177229_b(field_176315_a);
      if (p_196253_2_.func_195996_i().func_77973_b() == this.func_199767_j() && i < 8) {
         if (p_196253_2_.func_196012_c()) {
            return p_196253_2_.func_196000_l() == Direction.UP;
         } else {
            return true;
         }
      } else {
         return i == 1;
      }
   }

   @Nullable
   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      BlockState blockstate = p_196258_1_.func_195991_k().func_180495_p(p_196258_1_.func_195995_a());
      if (blockstate.func_203425_a(this)) {
         int i = blockstate.func_177229_b(field_176315_a);
         return blockstate.func_206870_a(field_176315_a, Integer.valueOf(Math.min(8, i + 1)));
      } else {
         return super.func_196258_a(p_196258_1_);
      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176315_a);
   }
}
