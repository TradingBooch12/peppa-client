package net.minecraft.block;

import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.DyeColor;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Direction;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BannerBlock extends AbstractBannerBlock {
   public static final IntegerProperty field_176448_b = BlockStateProperties.field_208138_am;
   private static final Map<DyeColor, Block> field_196288_b = Maps.newHashMap();
   private static final VoxelShape field_196289_c = Block.func_208617_a(4.0D, 0.0D, 4.0D, 12.0D, 16.0D, 12.0D);

   public BannerBlock(DyeColor p_i48448_1_, AbstractBlock.Properties p_i48448_2_) {
      super(p_i48448_1_, p_i48448_2_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176448_b, Integer.valueOf(0)));
      field_196288_b.put(p_i48448_1_, this);
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      return p_196260_2_.func_180495_p(p_196260_3_.func_177977_b()).func_185904_a().func_76220_a();
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196289_c;
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_176448_b, Integer.valueOf(MathHelper.func_76128_c((double)((180.0F + p_196258_1_.func_195990_h()) * 16.0F / 360.0F) + 0.5D) & 15));
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      return p_196271_2_ == Direction.DOWN && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_176448_b, Integer.valueOf(p_185499_2_.func_185833_a(p_185499_1_.func_177229_b(field_176448_b), 16)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_206870_a(field_176448_b, Integer.valueOf(p_185471_2_.func_185802_a(p_185471_1_.func_177229_b(field_176448_b), 16)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176448_b);
   }

   @OnlyIn(Dist.CLIENT)
   public static Block func_196287_a(DyeColor p_196287_0_) {
      return field_196288_b.getOrDefault(p_196287_0_, Blocks.field_196784_gT);
   }
}
