package net.minecraft.block;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.DyeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tileentity.SignTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public abstract class AbstractSignBlock extends ContainerBlock implements IWaterLoggable {
   public static final BooleanProperty field_204613_a = BlockStateProperties.field_208198_y;
   protected static final VoxelShape field_196340_a = Block.func_208617_a(4.0D, 0.0D, 4.0D, 12.0D, 16.0D, 12.0D);
   private final WoodType field_226943_c_;

   protected AbstractSignBlock(AbstractBlock.Properties p_i225763_1_, WoodType p_i225763_2_) {
      super(p_i225763_1_);
      this.field_226943_c_ = p_i225763_2_;
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_1_.func_177229_b(field_204613_a)) {
         p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
      }

      return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196340_a;
   }

   public boolean func_181623_g() {
      return true;
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new SignTileEntity();
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      ItemStack itemstack = p_225533_4_.func_184586_b(p_225533_5_);
      boolean flag = itemstack.func_77973_b() instanceof DyeItem && p_225533_4_.field_71075_bZ.field_75099_e;
      if (p_225533_2_.field_72995_K) {
         return flag ? ActionResultType.SUCCESS : ActionResultType.CONSUME;
      } else {
         TileEntity tileentity = p_225533_2_.func_175625_s(p_225533_3_);
         if (tileentity instanceof SignTileEntity) {
            SignTileEntity signtileentity = (SignTileEntity)tileentity;
            if (flag) {
               boolean flag1 = signtileentity.func_214068_a(((DyeItem)itemstack.func_77973_b()).func_195962_g());
               if (flag1 && !p_225533_4_.func_184812_l_()) {
                  itemstack.func_190918_g(1);
               }
            }

            return signtileentity.func_174882_b(p_225533_4_) ? ActionResultType.SUCCESS : ActionResultType.PASS;
         } else {
            return ActionResultType.PASS;
         }
      }
   }

   public FluidState func_204507_t(BlockState p_204507_1_) {
      return p_204507_1_.func_177229_b(field_204613_a) ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(p_204507_1_);
   }

   @OnlyIn(Dist.CLIENT)
   public WoodType func_226944_c_() {
      return this.field_226943_c_;
   }
}
