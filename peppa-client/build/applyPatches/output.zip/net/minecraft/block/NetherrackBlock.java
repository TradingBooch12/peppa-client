package net.minecraft.block;

import java.util.Random;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class NetherrackBlock extends Block implements IGrowable {
   public NetherrackBlock(AbstractBlock.Properties p_i241183_1_) {
      super(p_i241183_1_);
   }

   public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, BlockState p_176473_3_, boolean p_176473_4_) {
      if (!p_176473_1_.func_180495_p(p_176473_2_.func_177984_a()).func_200131_a(p_176473_1_, p_176473_2_)) {
         return false;
      } else {
         for(BlockPos blockpos : BlockPos.func_218278_a(p_176473_2_.func_177982_a(-1, -1, -1), p_176473_2_.func_177982_a(1, 1, 1))) {
            if (p_176473_1_.func_180495_p(blockpos).func_235714_a_(BlockTags.field_232873_an_)) {
               return true;
            }
         }

         return false;
      }
   }

   public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, BlockState p_180670_4_) {
      return true;
   }

   public void func_225535_a_(ServerWorld p_225535_1_, Random p_225535_2_, BlockPos p_225535_3_, BlockState p_225535_4_) {
      boolean flag = false;
      boolean flag1 = false;

      for(BlockPos blockpos : BlockPos.func_218278_a(p_225535_3_.func_177982_a(-1, -1, -1), p_225535_3_.func_177982_a(1, 1, 1))) {
         BlockState blockstate = p_225535_1_.func_180495_p(blockpos);
         if (blockstate.func_203425_a(Blocks.field_235372_ml_)) {
            flag1 = true;
         }

         if (blockstate.func_203425_a(Blocks.field_235381_mu_)) {
            flag = true;
         }

         if (flag1 && flag) {
            break;
         }
      }

      if (flag1 && flag) {
         p_225535_1_.func_180501_a(p_225535_3_, p_225535_2_.nextBoolean() ? Blocks.field_235372_ml_.func_176223_P() : Blocks.field_235381_mu_.func_176223_P(), 3);
      } else if (flag1) {
         p_225535_1_.func_180501_a(p_225535_3_, Blocks.field_235372_ml_.func_176223_P(), 3);
      } else if (flag) {
         p_225535_1_.func_180501_a(p_225535_3_, Blocks.field_235381_mu_.func_176223_P(), 3);
      }

   }
}
