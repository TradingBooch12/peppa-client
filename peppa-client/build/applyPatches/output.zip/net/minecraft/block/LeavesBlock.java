package net.minecraft.block;

import java.util.Random;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class LeavesBlock extends Block {
   public static final IntegerProperty field_208494_a = BlockStateProperties.field_208514_aa;
   public static final BooleanProperty field_208495_b = BlockStateProperties.field_208515_s;

   public LeavesBlock(AbstractBlock.Properties p_i48370_1_) {
      super(p_i48370_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_208494_a, Integer.valueOf(7)).func_206870_a(field_208495_b, Boolean.valueOf(false)));
   }

   public VoxelShape func_230335_e_(BlockState p_230335_1_, IBlockReader p_230335_2_, BlockPos p_230335_3_) {
      return VoxelShapes.func_197880_a();
   }

   public boolean func_149653_t(BlockState p_149653_1_) {
      return p_149653_1_.func_177229_b(field_208494_a) == 7 && !p_149653_1_.func_177229_b(field_208495_b);
   }

   public void func_225542_b_(BlockState p_225542_1_, ServerWorld p_225542_2_, BlockPos p_225542_3_, Random p_225542_4_) {
      if (!p_225542_1_.func_177229_b(field_208495_b) && p_225542_1_.func_177229_b(field_208494_a) == 7) {
         func_220075_c(p_225542_1_, p_225542_2_, p_225542_3_);
         p_225542_2_.func_217377_a(p_225542_3_, false);
      }

   }

   public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
      p_225534_2_.func_180501_a(p_225534_3_, func_208493_b(p_225534_1_, p_225534_2_, p_225534_3_), 3);
   }

   public int func_200011_d(BlockState p_200011_1_, IBlockReader p_200011_2_, BlockPos p_200011_3_) {
      return 1;
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      int i = func_208492_w(p_196271_3_) + 1;
      if (i != 1 || p_196271_1_.func_177229_b(field_208494_a) != i) {
         p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, 1);
      }

      return p_196271_1_;
   }

   private static BlockState func_208493_b(BlockState p_208493_0_, IWorld p_208493_1_, BlockPos p_208493_2_) {
      int i = 7;
      BlockPos.Mutable blockpos$mutable = new BlockPos.Mutable();

      for(Direction direction : Direction.values()) {
         blockpos$mutable.func_239622_a_(p_208493_2_, direction);
         i = Math.min(i, func_208492_w(p_208493_1_.func_180495_p(blockpos$mutable)) + 1);
         if (i == 1) {
            break;
         }
      }

      return p_208493_0_.func_206870_a(field_208494_a, Integer.valueOf(i));
   }

   private static int func_208492_w(BlockState p_208492_0_) {
      if (BlockTags.field_200031_h.func_230235_a_(p_208492_0_.func_177230_c())) {
         return 0;
      } else {
         return p_208492_0_.func_177230_c() instanceof LeavesBlock ? p_208492_0_.func_177229_b(field_208494_a) : 7;
      }
   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(BlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      if (p_180655_2_.func_175727_C(p_180655_3_.func_177984_a())) {
         if (p_180655_4_.nextInt(15) == 1) {
            BlockPos blockpos = p_180655_3_.func_177977_b();
            BlockState blockstate = p_180655_2_.func_180495_p(blockpos);
            if (!blockstate.func_200132_m() || !blockstate.func_224755_d(p_180655_2_, blockpos, Direction.UP)) {
               double d0 = (double)p_180655_3_.func_177958_n() + p_180655_4_.nextDouble();
               double d1 = (double)p_180655_3_.func_177956_o() - 0.05D;
               double d2 = (double)p_180655_3_.func_177952_p() + p_180655_4_.nextDouble();
               p_180655_2_.func_195594_a(ParticleTypes.field_197618_k, d0, d1, d2, 0.0D, 0.0D, 0.0D);
            }
         }
      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_208494_a, field_208495_b);
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return func_208493_b(this.func_176223_P().func_206870_a(field_208495_b, Boolean.valueOf(true)), p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a());
   }
}
