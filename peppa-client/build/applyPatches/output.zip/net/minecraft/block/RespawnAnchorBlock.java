package net.minecraft.block;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import java.util.Optional;
import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.DamageSource;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.TransportationHelper;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.math.vector.Vector3i;
import net.minecraft.world.Explosion;
import net.minecraft.world.ExplosionContext;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.ICollisionReader;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class RespawnAnchorBlock extends Block {
   public static final IntegerProperty field_235559_a_ = BlockStateProperties.field_235912_aC_;
   private static final ImmutableList<Vector3i> field_242676_b = ImmutableList.of(new Vector3i(0, 0, -1), new Vector3i(-1, 0, 0), new Vector3i(0, 0, 1), new Vector3i(1, 0, 0), new Vector3i(-1, 0, -1), new Vector3i(1, 0, -1), new Vector3i(-1, 0, 1), new Vector3i(1, 0, 1));
   private static final ImmutableList<Vector3i> field_242677_c = (new Builder<Vector3i>()).addAll(field_242676_b).addAll(field_242676_b.stream().map(Vector3i::func_177977_b).iterator()).addAll(field_242676_b.stream().map(Vector3i::func_177984_a).iterator()).add(new Vector3i(0, 1, 0)).build();

   public RespawnAnchorBlock(AbstractBlock.Properties p_i241185_1_) {
      super(p_i241185_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_235559_a_, Integer.valueOf(0)));
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      ItemStack itemstack = p_225533_4_.func_184586_b(p_225533_5_);
      if (p_225533_5_ == Hand.MAIN_HAND && !func_235561_a_(itemstack) && func_235561_a_(p_225533_4_.func_184586_b(Hand.OFF_HAND))) {
         return ActionResultType.PASS;
      } else if (func_235561_a_(itemstack) && func_235568_h_(p_225533_1_)) {
         func_235564_a_(p_225533_2_, p_225533_3_, p_225533_1_);
         if (!p_225533_4_.field_71075_bZ.field_75098_d) {
            itemstack.func_190918_g(1);
         }

         return ActionResultType.func_233537_a_(p_225533_2_.field_72995_K);
      } else if (p_225533_1_.func_177229_b(field_235559_a_) == 0) {
         return ActionResultType.PASS;
      } else if (!func_235562_a_(p_225533_2_)) {
         if (!p_225533_2_.field_72995_K) {
            this.func_235567_d_(p_225533_1_, p_225533_2_, p_225533_3_);
         }

         return ActionResultType.func_233537_a_(p_225533_2_.field_72995_K);
      } else {
         if (!p_225533_2_.field_72995_K) {
            ServerPlayerEntity serverplayerentity = (ServerPlayerEntity)p_225533_4_;
            if (serverplayerentity.func_241141_L_() != p_225533_2_.func_234923_W_() || !serverplayerentity.func_241140_K_().equals(p_225533_3_)) {
               serverplayerentity.func_242111_a(p_225533_2_.func_234923_W_(), p_225533_3_, 0.0F, false, true);
               p_225533_2_.func_184148_a((PlayerEntity)null, (double)p_225533_3_.func_177958_n() + 0.5D, (double)p_225533_3_.func_177956_o() + 0.5D, (double)p_225533_3_.func_177952_p() + 0.5D, SoundEvents.field_232819_mt_, SoundCategory.BLOCKS, 1.0F, 1.0F);
               return ActionResultType.SUCCESS;
            }
         }

         return ActionResultType.CONSUME;
      }
   }

   private static boolean func_235561_a_(ItemStack p_235561_0_) {
      return p_235561_0_.func_77973_b() == Items.field_221695_cJ;
   }

   private static boolean func_235568_h_(BlockState p_235568_0_) {
      return p_235568_0_.func_177229_b(field_235559_a_) < 4;
   }

   private static boolean func_235566_a_(BlockPos p_235566_0_, World p_235566_1_) {
      FluidState fluidstate = p_235566_1_.func_204610_c(p_235566_0_);
      if (!fluidstate.func_206884_a(FluidTags.field_206959_a)) {
         return false;
      } else if (fluidstate.func_206889_d()) {
         return true;
      } else {
         float f = (float)fluidstate.func_206882_g();
         if (f < 2.0F) {
            return false;
         } else {
            FluidState fluidstate1 = p_235566_1_.func_204610_c(p_235566_0_.func_177977_b());
            return !fluidstate1.func_206884_a(FluidTags.field_206959_a);
         }
      }
   }

   private void func_235567_d_(BlockState p_235567_1_, World p_235567_2_, final BlockPos p_235567_3_) {
      p_235567_2_.func_217377_a(p_235567_3_, false);
      boolean flag = Direction.Plane.HORIZONTAL.func_239636_a_().map(p_235567_3_::func_177972_a).anyMatch((p_235563_1_) -> {
         return func_235566_a_(p_235563_1_, p_235567_2_);
      });
      final boolean flag1 = flag || p_235567_2_.func_204610_c(p_235567_3_.func_177984_a()).func_206884_a(FluidTags.field_206959_a);
      ExplosionContext explosioncontext = new ExplosionContext() {
         public Optional<Float> func_230312_a_(Explosion p_230312_1_, IBlockReader p_230312_2_, BlockPos p_230312_3_, BlockState p_230312_4_, FluidState p_230312_5_) {
            return p_230312_3_.equals(p_235567_3_) && flag1 ? Optional.of(Blocks.field_150355_j.func_149638_a()) : super.func_230312_a_(p_230312_1_, p_230312_2_, p_230312_3_, p_230312_4_, p_230312_5_);
         }
      };
      p_235567_2_.func_230546_a_((Entity)null, DamageSource.func_233546_a_(), explosioncontext, (double)p_235567_3_.func_177958_n() + 0.5D, (double)p_235567_3_.func_177956_o() + 0.5D, (double)p_235567_3_.func_177952_p() + 0.5D, 5.0F, true, Explosion.Mode.DESTROY);
   }

   public static boolean func_235562_a_(World p_235562_0_) {
      return p_235562_0_.func_230315_m_().func_241511_k_();
   }

   public static void func_235564_a_(World p_235564_0_, BlockPos p_235564_1_, BlockState p_235564_2_) {
      p_235564_0_.func_180501_a(p_235564_1_, p_235564_2_.func_206870_a(field_235559_a_, Integer.valueOf(p_235564_2_.func_177229_b(field_235559_a_) + 1)), 3);
      p_235564_0_.func_184148_a((PlayerEntity)null, (double)p_235564_1_.func_177958_n() + 0.5D, (double)p_235564_1_.func_177956_o() + 0.5D, (double)p_235564_1_.func_177952_p() + 0.5D, SoundEvents.field_232817_mr_, SoundCategory.BLOCKS, 1.0F, 1.0F);
   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(BlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      if (p_180655_1_.func_177229_b(field_235559_a_) != 0) {
         if (p_180655_4_.nextInt(100) == 0) {
            p_180655_2_.func_184148_a((PlayerEntity)null, (double)p_180655_3_.func_177958_n() + 0.5D, (double)p_180655_3_.func_177956_o() + 0.5D, (double)p_180655_3_.func_177952_p() + 0.5D, SoundEvents.field_232816_mq_, SoundCategory.BLOCKS, 1.0F, 1.0F);
         }

         double d0 = (double)p_180655_3_.func_177958_n() + 0.5D + (0.5D - p_180655_4_.nextDouble());
         double d1 = (double)p_180655_3_.func_177956_o() + 1.0D;
         double d2 = (double)p_180655_3_.func_177952_p() + 0.5D + (0.5D - p_180655_4_.nextDouble());
         double d3 = (double)p_180655_4_.nextFloat() * 0.04D;
         p_180655_2_.func_195594_a(ParticleTypes.field_239819_as_, d0, d1, d2, 0.0D, d3, 0.0D);
      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_235559_a_);
   }

   public boolean func_149740_M(BlockState p_149740_1_) {
      return true;
   }

   public static int func_235565_a_(BlockState p_235565_0_, int p_235565_1_) {
      return MathHelper.func_76141_d((float)(p_235565_0_.func_177229_b(field_235559_a_) - 0) / 4.0F * (float)p_235565_1_);
   }

   public int func_180641_l(BlockState p_180641_1_, World p_180641_2_, BlockPos p_180641_3_) {
      return func_235565_a_(p_180641_1_, 15);
   }

   public static Optional<Vector3d> func_235560_a_(EntityType<?> p_235560_0_, ICollisionReader p_235560_1_, BlockPos p_235560_2_) {
      Optional<Vector3d> optional = func_242678_a(p_235560_0_, p_235560_1_, p_235560_2_, true);
      return optional.isPresent() ? optional : func_242678_a(p_235560_0_, p_235560_1_, p_235560_2_, false);
   }

   private static Optional<Vector3d> func_242678_a(EntityType<?> p_242678_0_, ICollisionReader p_242678_1_, BlockPos p_242678_2_, boolean p_242678_3_) {
      BlockPos.Mutable blockpos$mutable = new BlockPos.Mutable();

      for(Vector3i vector3i : field_242677_c) {
         blockpos$mutable.func_189533_g(p_242678_2_).func_243531_h(vector3i);
         Vector3d vector3d = TransportationHelper.func_242379_a(p_242678_0_, p_242678_1_, blockpos$mutable, p_242678_3_);
         if (vector3d != null) {
            return Optional.of(vector3d);
         }
      }

      return Optional.empty();
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
