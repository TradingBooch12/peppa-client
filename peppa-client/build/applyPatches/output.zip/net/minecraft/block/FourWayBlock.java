package net.minecraft.block;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import java.util.Map;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Direction;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;

public class FourWayBlock extends Block implements IWaterLoggable {
   public static final BooleanProperty field_196409_a = SixWayBlock.field_196488_a;
   public static final BooleanProperty field_196411_b = SixWayBlock.field_196490_b;
   public static final BooleanProperty field_196413_c = SixWayBlock.field_196492_c;
   public static final BooleanProperty field_196414_y = SixWayBlock.field_196495_y;
   public static final BooleanProperty field_204514_u = BlockStateProperties.field_208198_y;
   protected static final Map<Direction, BooleanProperty> field_196415_z = SixWayBlock.field_196491_B.entrySet().stream().filter((p_199775_0_) -> {
      return p_199775_0_.getKey().func_176740_k().func_176722_c();
   }).collect(Util.func_199749_a());
   protected final VoxelShape[] field_196410_A;
   protected final VoxelShape[] field_196412_B;
   private final Object2IntMap<BlockState> field_223008_i = new Object2IntOpenHashMap<>();

   protected FourWayBlock(float p_i48420_1_, float p_i48420_2_, float p_i48420_3_, float p_i48420_4_, float p_i48420_5_, AbstractBlock.Properties p_i48420_6_) {
      super(p_i48420_6_);
      this.field_196410_A = this.func_196408_a(p_i48420_1_, p_i48420_2_, p_i48420_5_, 0.0F, p_i48420_5_);
      this.field_196412_B = this.func_196408_a(p_i48420_1_, p_i48420_2_, p_i48420_3_, 0.0F, p_i48420_4_);

      for(BlockState blockstate : this.field_176227_L.func_177619_a()) {
         this.func_196406_i(blockstate);
      }

   }

   protected VoxelShape[] func_196408_a(float p_196408_1_, float p_196408_2_, float p_196408_3_, float p_196408_4_, float p_196408_5_) {
      float f = 8.0F - p_196408_1_;
      float f1 = 8.0F + p_196408_1_;
      float f2 = 8.0F - p_196408_2_;
      float f3 = 8.0F + p_196408_2_;
      VoxelShape voxelshape = Block.func_208617_a((double)f, 0.0D, (double)f, (double)f1, (double)p_196408_3_, (double)f1);
      VoxelShape voxelshape1 = Block.func_208617_a((double)f2, (double)p_196408_4_, 0.0D, (double)f3, (double)p_196408_5_, (double)f3);
      VoxelShape voxelshape2 = Block.func_208617_a((double)f2, (double)p_196408_4_, (double)f2, (double)f3, (double)p_196408_5_, 16.0D);
      VoxelShape voxelshape3 = Block.func_208617_a(0.0D, (double)p_196408_4_, (double)f2, (double)f3, (double)p_196408_5_, (double)f3);
      VoxelShape voxelshape4 = Block.func_208617_a((double)f2, (double)p_196408_4_, (double)f2, 16.0D, (double)p_196408_5_, (double)f3);
      VoxelShape voxelshape5 = VoxelShapes.func_197872_a(voxelshape1, voxelshape4);
      VoxelShape voxelshape6 = VoxelShapes.func_197872_a(voxelshape2, voxelshape3);
      VoxelShape[] avoxelshape = new VoxelShape[]{VoxelShapes.func_197880_a(), voxelshape2, voxelshape3, voxelshape6, voxelshape1, VoxelShapes.func_197872_a(voxelshape2, voxelshape1), VoxelShapes.func_197872_a(voxelshape3, voxelshape1), VoxelShapes.func_197872_a(voxelshape6, voxelshape1), voxelshape4, VoxelShapes.func_197872_a(voxelshape2, voxelshape4), VoxelShapes.func_197872_a(voxelshape3, voxelshape4), VoxelShapes.func_197872_a(voxelshape6, voxelshape4), voxelshape5, VoxelShapes.func_197872_a(voxelshape2, voxelshape5), VoxelShapes.func_197872_a(voxelshape3, voxelshape5), VoxelShapes.func_197872_a(voxelshape6, voxelshape5)};

      for(int i = 0; i < 16; ++i) {
         avoxelshape[i] = VoxelShapes.func_197872_a(voxelshape, avoxelshape[i]);
      }

      return avoxelshape;
   }

   public boolean func_200123_i(BlockState p_200123_1_, IBlockReader p_200123_2_, BlockPos p_200123_3_) {
      return !p_200123_1_.func_177229_b(field_204514_u);
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return this.field_196412_B[this.func_196406_i(p_220053_1_)];
   }

   public VoxelShape func_220071_b(BlockState p_220071_1_, IBlockReader p_220071_2_, BlockPos p_220071_3_, ISelectionContext p_220071_4_) {
      return this.field_196410_A[this.func_196406_i(p_220071_1_)];
   }

   private static int func_196407_a(Direction p_196407_0_) {
      return 1 << p_196407_0_.func_176736_b();
   }

   protected int func_196406_i(BlockState p_196406_1_) {
      return this.field_223008_i.computeIntIfAbsent(p_196406_1_, (p_223007_0_) -> {
         int i = 0;
         if (p_223007_0_.func_177229_b(field_196409_a)) {
            i |= func_196407_a(Direction.NORTH);
         }

         if (p_223007_0_.func_177229_b(field_196411_b)) {
            i |= func_196407_a(Direction.EAST);
         }

         if (p_223007_0_.func_177229_b(field_196413_c)) {
            i |= func_196407_a(Direction.SOUTH);
         }

         if (p_223007_0_.func_177229_b(field_196414_y)) {
            i |= func_196407_a(Direction.WEST);
         }

         return i;
      });
   }

   public FluidState func_204507_t(BlockState p_204507_1_) {
      return p_204507_1_.func_177229_b(field_204514_u) ? Fluids.field_204546_a.func_207204_a(false) : super.func_204507_t(p_204507_1_);
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      switch(p_185499_2_) {
      case CLOCKWISE_180:
         return p_185499_1_.func_206870_a(field_196409_a, p_185499_1_.func_177229_b(field_196413_c)).func_206870_a(field_196411_b, p_185499_1_.func_177229_b(field_196414_y)).func_206870_a(field_196413_c, p_185499_1_.func_177229_b(field_196409_a)).func_206870_a(field_196414_y, p_185499_1_.func_177229_b(field_196411_b));
      case COUNTERCLOCKWISE_90:
         return p_185499_1_.func_206870_a(field_196409_a, p_185499_1_.func_177229_b(field_196411_b)).func_206870_a(field_196411_b, p_185499_1_.func_177229_b(field_196413_c)).func_206870_a(field_196413_c, p_185499_1_.func_177229_b(field_196414_y)).func_206870_a(field_196414_y, p_185499_1_.func_177229_b(field_196409_a));
      case CLOCKWISE_90:
         return p_185499_1_.func_206870_a(field_196409_a, p_185499_1_.func_177229_b(field_196414_y)).func_206870_a(field_196411_b, p_185499_1_.func_177229_b(field_196409_a)).func_206870_a(field_196413_c, p_185499_1_.func_177229_b(field_196411_b)).func_206870_a(field_196414_y, p_185499_1_.func_177229_b(field_196413_c));
      default:
         return p_185499_1_;
      }
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      switch(p_185471_2_) {
      case LEFT_RIGHT:
         return p_185471_1_.func_206870_a(field_196409_a, p_185471_1_.func_177229_b(field_196413_c)).func_206870_a(field_196413_c, p_185471_1_.func_177229_b(field_196409_a));
      case FRONT_BACK:
         return p_185471_1_.func_206870_a(field_196411_b, p_185471_1_.func_177229_b(field_196414_y)).func_206870_a(field_196414_y, p_185471_1_.func_177229_b(field_196411_b));
      default:
         return super.func_185471_a(p_185471_1_, p_185471_2_);
      }
   }
}
