package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.server.ServerWorld;

public abstract class AbstractPlantBlock extends Block {
   protected final Direction field_235498_a_;
   protected final boolean field_235499_b_;
   protected final VoxelShape field_235500_c_;

   protected AbstractPlantBlock(AbstractBlock.Properties p_i241178_1_, Direction p_i241178_2_, VoxelShape p_i241178_3_, boolean p_i241178_4_) {
      super(p_i241178_1_);
      this.field_235498_a_ = p_i241178_2_;
      this.field_235500_c_ = p_i241178_3_;
      this.field_235499_b_ = p_i241178_4_;
   }

   @Nullable
   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      BlockState blockstate = p_196258_1_.func_195991_k().func_180495_p(p_196258_1_.func_195995_a().func_177972_a(this.field_235498_a_));
      return !blockstate.func_203425_a(this.func_230331_c_()) && !blockstate.func_203425_a(this.func_230330_d_()) ? this.func_235504_a_(p_196258_1_.func_195991_k()) : this.func_230330_d_().func_176223_P();
   }

   public BlockState func_235504_a_(IWorld p_235504_1_) {
      return this.func_176223_P();
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      BlockPos blockpos = p_196260_3_.func_177972_a(this.field_235498_a_.func_176734_d());
      BlockState blockstate = p_196260_2_.func_180495_p(blockpos);
      Block block = blockstate.func_177230_c();
      if (!this.func_230333_c_(block)) {
         return false;
      } else {
         return block == this.func_230331_c_() || block == this.func_230330_d_() || blockstate.func_224755_d(p_196260_2_, blockpos, this.field_235498_a_);
      }
   }

   public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
      if (!p_225534_1_.func_196955_c(p_225534_2_, p_225534_3_)) {
         p_225534_2_.func_175655_b(p_225534_3_, true);
      }

   }

   protected boolean func_230333_c_(Block p_230333_1_) {
      return true;
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return this.field_235500_c_;
   }

   protected abstract AbstractTopPlantBlock func_230331_c_();

   protected abstract Block func_230330_d_();
}
