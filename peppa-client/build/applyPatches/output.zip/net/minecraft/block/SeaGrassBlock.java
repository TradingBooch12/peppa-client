package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.properties.DoubleBlockHalf;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class SeaGrassBlock extends BushBlock implements IGrowable, ILiquidContainer {
   protected static final VoxelShape field_207798_a = Block.func_208617_a(2.0D, 0.0D, 2.0D, 14.0D, 12.0D, 14.0D);

   protected SeaGrassBlock(AbstractBlock.Properties p_i48780_1_) {
      super(p_i48780_1_);
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_207798_a;
   }

   protected boolean func_200014_a_(BlockState p_200014_1_, IBlockReader p_200014_2_, BlockPos p_200014_3_) {
      return p_200014_1_.func_224755_d(p_200014_2_, p_200014_3_, Direction.UP) && !p_200014_1_.func_203425_a(Blocks.field_196814_hQ);
   }

   @Nullable
   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      FluidState fluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
      return fluidstate.func_206884_a(FluidTags.field_206959_a) && fluidstate.func_206882_g() == 8 ? super.func_196258_a(p_196258_1_) : null;
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      BlockState blockstate = super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      if (!blockstate.func_196958_f()) {
         p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
      }

      return blockstate;
   }

   public boolean func_176473_a(IBlockReader p_176473_1_, BlockPos p_176473_2_, BlockState p_176473_3_, boolean p_176473_4_) {
      return true;
   }

   public boolean func_180670_a(World p_180670_1_, Random p_180670_2_, BlockPos p_180670_3_, BlockState p_180670_4_) {
      return true;
   }

   public FluidState func_204507_t(BlockState p_204507_1_) {
      return Fluids.field_204546_a.func_207204_a(false);
   }

   public void func_225535_a_(ServerWorld p_225535_1_, Random p_225535_2_, BlockPos p_225535_3_, BlockState p_225535_4_) {
      BlockState blockstate = Blocks.field_203199_aR.func_176223_P();
      BlockState blockstate1 = blockstate.func_206870_a(TallSeaGrassBlock.field_208065_c, DoubleBlockHalf.UPPER);
      BlockPos blockpos = p_225535_3_.func_177984_a();
      if (p_225535_1_.func_180495_p(blockpos).func_203425_a(Blocks.field_150355_j)) {
         p_225535_1_.func_180501_a(p_225535_3_, blockstate, 2);
         p_225535_1_.func_180501_a(blockpos, blockstate1, 2);
      }

   }

   public boolean func_204510_a(IBlockReader p_204510_1_, BlockPos p_204510_2_, BlockState p_204510_3_, Fluid p_204510_4_) {
      return false;
   }

   public boolean func_204509_a(IWorld p_204509_1_, BlockPos p_204509_2_, BlockState p_204509_3_, FluidState p_204509_4_) {
      return false;
   }
}
