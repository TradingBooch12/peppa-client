package net.minecraft.block;

import net.minecraft.util.math.vector.Vector3d;

public class PortalInfo {
   public final Vector3d field_222505_a;
   public final Vector3d field_222506_b;
   public final float field_242960_c;
   public final float field_242961_d;

   public PortalInfo(Vector3d p_i242042_1_, Vector3d p_i242042_2_, float p_i242042_3_, float p_i242042_4_) {
      this.field_222505_a = p_i242042_1_;
      this.field_222506_b = p_i242042_2_;
      this.field_242960_c = p_i242042_3_;
      this.field_242961_d = p_i242042_4_;
   }
}
