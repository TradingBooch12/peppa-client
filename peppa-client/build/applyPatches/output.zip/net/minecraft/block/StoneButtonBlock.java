package net.minecraft.block;

import net.minecraft.util.SoundEvent;
import net.minecraft.util.SoundEvents;

public class StoneButtonBlock extends AbstractButtonBlock {
   protected StoneButtonBlock(AbstractBlock.Properties p_i48315_1_) {
      super(false, p_i48315_1_);
   }

   protected SoundEvent func_196369_b(boolean p_196369_1_) {
      return p_196369_1_ ? SoundEvents.field_187839_fV : SoundEvents.field_187837_fU;
   }
}
