package net.minecraft.block;

import com.google.common.collect.ImmutableMap;
import java.util.Map;
import java.util.Random;
import java.util.function.Function;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.Direction;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.server.ServerWorld;

public class VineBlock extends Block {
   public static final BooleanProperty field_176277_a = SixWayBlock.field_196496_z;
   public static final BooleanProperty field_176273_b = SixWayBlock.field_196488_a;
   public static final BooleanProperty field_176278_M = SixWayBlock.field_196490_b;
   public static final BooleanProperty field_176279_N = SixWayBlock.field_196492_c;
   public static final BooleanProperty field_176280_O = SixWayBlock.field_196495_y;
   public static final Map<Direction, BooleanProperty> field_196546_A = SixWayBlock.field_196491_B.entrySet().stream().filter((p_199782_0_) -> {
      return p_199782_0_.getKey() != Direction.DOWN;
   }).collect(Util.func_199749_a());
   private static final VoxelShape field_185757_g = Block.func_208617_a(0.0D, 15.0D, 0.0D, 16.0D, 16.0D, 16.0D);
   private static final VoxelShape field_185754_C = Block.func_208617_a(0.0D, 0.0D, 0.0D, 1.0D, 16.0D, 16.0D);
   private static final VoxelShape field_185753_B = Block.func_208617_a(15.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D);
   private static final VoxelShape field_185756_E = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 1.0D);
   private static final VoxelShape field_185755_D = Block.func_208617_a(0.0D, 0.0D, 15.0D, 16.0D, 16.0D, 16.0D);
   private final Map<BlockState, VoxelShape> field_242684_o;

   public VineBlock(AbstractBlock.Properties p_i48303_1_) {
      super(p_i48303_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176277_a, Boolean.valueOf(false)).func_206870_a(field_176273_b, Boolean.valueOf(false)).func_206870_a(field_176278_M, Boolean.valueOf(false)).func_206870_a(field_176279_N, Boolean.valueOf(false)).func_206870_a(field_176280_O, Boolean.valueOf(false)));
      this.field_242684_o = ImmutableMap.copyOf(this.field_176227_L.func_177619_a().stream().collect(Collectors.toMap(Function.identity(), VineBlock::func_242685_h)));
   }

   private static VoxelShape func_242685_h(BlockState p_242685_0_) {
      VoxelShape voxelshape = VoxelShapes.func_197880_a();
      if (p_242685_0_.func_177229_b(field_176277_a)) {
         voxelshape = field_185757_g;
      }

      if (p_242685_0_.func_177229_b(field_176273_b)) {
         voxelshape = VoxelShapes.func_197872_a(voxelshape, field_185756_E);
      }

      if (p_242685_0_.func_177229_b(field_176279_N)) {
         voxelshape = VoxelShapes.func_197872_a(voxelshape, field_185755_D);
      }

      if (p_242685_0_.func_177229_b(field_176278_M)) {
         voxelshape = VoxelShapes.func_197872_a(voxelshape, field_185753_B);
      }

      if (p_242685_0_.func_177229_b(field_176280_O)) {
         voxelshape = VoxelShapes.func_197872_a(voxelshape, field_185754_C);
      }

      return voxelshape;
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return this.field_242684_o.get(p_220053_1_);
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      return this.func_196543_i(this.func_196545_h(p_196260_1_, p_196260_2_, p_196260_3_));
   }

   private boolean func_196543_i(BlockState p_196543_1_) {
      return this.func_208496_w(p_196543_1_) > 0;
   }

   private int func_208496_w(BlockState p_208496_1_) {
      int i = 0;

      for(BooleanProperty booleanproperty : field_196546_A.values()) {
         if (p_208496_1_.func_177229_b(booleanproperty)) {
            ++i;
         }
      }

      return i;
   }

   private boolean func_196541_a(IBlockReader p_196541_1_, BlockPos p_196541_2_, Direction p_196541_3_) {
      if (p_196541_3_ == Direction.DOWN) {
         return false;
      } else {
         BlockPos blockpos = p_196541_2_.func_177972_a(p_196541_3_);
         if (func_196542_b(p_196541_1_, blockpos, p_196541_3_)) {
            return true;
         } else if (p_196541_3_.func_176740_k() == Direction.Axis.Y) {
            return false;
         } else {
            BooleanProperty booleanproperty = field_196546_A.get(p_196541_3_);
            BlockState blockstate = p_196541_1_.func_180495_p(p_196541_2_.func_177984_a());
            return blockstate.func_203425_a(this) && blockstate.func_177229_b(booleanproperty);
         }
      }
   }

   public static boolean func_196542_b(IBlockReader p_196542_0_, BlockPos p_196542_1_, Direction p_196542_2_) {
      BlockState blockstate = p_196542_0_.func_180495_p(p_196542_1_);
      return Block.func_208061_a(blockstate.func_196952_d(p_196542_0_, p_196542_1_), p_196542_2_.func_176734_d());
   }

   private BlockState func_196545_h(BlockState p_196545_1_, IBlockReader p_196545_2_, BlockPos p_196545_3_) {
      BlockPos blockpos = p_196545_3_.func_177984_a();
      if (p_196545_1_.func_177229_b(field_176277_a)) {
         p_196545_1_ = p_196545_1_.func_206870_a(field_176277_a, Boolean.valueOf(func_196542_b(p_196545_2_, blockpos, Direction.DOWN)));
      }

      BlockState blockstate = null;

      for(Direction direction : Direction.Plane.HORIZONTAL) {
         BooleanProperty booleanproperty = func_176267_a(direction);
         if (p_196545_1_.func_177229_b(booleanproperty)) {
            boolean flag = this.func_196541_a(p_196545_2_, p_196545_3_, direction);
            if (!flag) {
               if (blockstate == null) {
                  blockstate = p_196545_2_.func_180495_p(blockpos);
               }

               flag = blockstate.func_203425_a(this) && blockstate.func_177229_b(booleanproperty);
            }

            p_196545_1_ = p_196545_1_.func_206870_a(booleanproperty, Boolean.valueOf(flag));
         }
      }

      return p_196545_1_;
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_2_ == Direction.DOWN) {
         return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      } else {
         BlockState blockstate = this.func_196545_h(p_196271_1_, p_196271_4_, p_196271_5_);
         return !this.func_196543_i(blockstate) ? Blocks.field_150350_a.func_176223_P() : blockstate;
      }
   }

   public void func_225542_b_(BlockState p_225542_1_, ServerWorld p_225542_2_, BlockPos p_225542_3_, Random p_225542_4_) {
      if (p_225542_2_.field_73012_v.nextInt(4) == 0) {
         Direction direction = Direction.func_239631_a_(p_225542_4_);
         BlockPos blockpos = p_225542_3_.func_177984_a();
         if (direction.func_176740_k().func_176722_c() && !p_225542_1_.func_177229_b(func_176267_a(direction))) {
            if (this.func_196539_a(p_225542_2_, p_225542_3_)) {
               BlockPos blockpos4 = p_225542_3_.func_177972_a(direction);
               BlockState blockstate4 = p_225542_2_.func_180495_p(blockpos4);
               if (blockstate4.func_196958_f()) {
                  Direction direction3 = direction.func_176746_e();
                  Direction direction4 = direction.func_176735_f();
                  boolean flag = p_225542_1_.func_177229_b(func_176267_a(direction3));
                  boolean flag1 = p_225542_1_.func_177229_b(func_176267_a(direction4));
                  BlockPos blockpos2 = blockpos4.func_177972_a(direction3);
                  BlockPos blockpos3 = blockpos4.func_177972_a(direction4);
                  if (flag && func_196542_b(p_225542_2_, blockpos2, direction3)) {
                     p_225542_2_.func_180501_a(blockpos4, this.func_176223_P().func_206870_a(func_176267_a(direction3), Boolean.valueOf(true)), 2);
                  } else if (flag1 && func_196542_b(p_225542_2_, blockpos3, direction4)) {
                     p_225542_2_.func_180501_a(blockpos4, this.func_176223_P().func_206870_a(func_176267_a(direction4), Boolean.valueOf(true)), 2);
                  } else {
                     Direction direction1 = direction.func_176734_d();
                     if (flag && p_225542_2_.func_175623_d(blockpos2) && func_196542_b(p_225542_2_, p_225542_3_.func_177972_a(direction3), direction1)) {
                        p_225542_2_.func_180501_a(blockpos2, this.func_176223_P().func_206870_a(func_176267_a(direction1), Boolean.valueOf(true)), 2);
                     } else if (flag1 && p_225542_2_.func_175623_d(blockpos3) && func_196542_b(p_225542_2_, p_225542_3_.func_177972_a(direction4), direction1)) {
                        p_225542_2_.func_180501_a(blockpos3, this.func_176223_P().func_206870_a(func_176267_a(direction1), Boolean.valueOf(true)), 2);
                     } else if ((double)p_225542_2_.field_73012_v.nextFloat() < 0.05D && func_196542_b(p_225542_2_, blockpos4.func_177984_a(), Direction.UP)) {
                        p_225542_2_.func_180501_a(blockpos4, this.func_176223_P().func_206870_a(field_176277_a, Boolean.valueOf(true)), 2);
                     }
                  }
               } else if (func_196542_b(p_225542_2_, blockpos4, direction)) {
                  p_225542_2_.func_180501_a(p_225542_3_, p_225542_1_.func_206870_a(func_176267_a(direction), Boolean.valueOf(true)), 2);
               }

            }
         } else {
            if (direction == Direction.UP && p_225542_3_.func_177956_o() < 255) {
               if (this.func_196541_a(p_225542_2_, p_225542_3_, direction)) {
                  p_225542_2_.func_180501_a(p_225542_3_, p_225542_1_.func_206870_a(field_176277_a, Boolean.valueOf(true)), 2);
                  return;
               }

               if (p_225542_2_.func_175623_d(blockpos)) {
                  if (!this.func_196539_a(p_225542_2_, p_225542_3_)) {
                     return;
                  }

                  BlockState blockstate3 = p_225542_1_;

                  for(Direction direction2 : Direction.Plane.HORIZONTAL) {
                     if (p_225542_4_.nextBoolean() || !func_196542_b(p_225542_2_, blockpos.func_177972_a(direction2), Direction.UP)) {
                        blockstate3 = blockstate3.func_206870_a(func_176267_a(direction2), Boolean.valueOf(false));
                     }
                  }

                  if (this.func_196540_x(blockstate3)) {
                     p_225542_2_.func_180501_a(blockpos, blockstate3, 2);
                  }

                  return;
               }
            }

            if (p_225542_3_.func_177956_o() > 0) {
               BlockPos blockpos1 = p_225542_3_.func_177977_b();
               BlockState blockstate = p_225542_2_.func_180495_p(blockpos1);
               if (blockstate.func_196958_f() || blockstate.func_203425_a(this)) {
                  BlockState blockstate1 = blockstate.func_196958_f() ? this.func_176223_P() : blockstate;
                  BlockState blockstate2 = this.func_196544_a(p_225542_1_, blockstate1, p_225542_4_);
                  if (blockstate1 != blockstate2 && this.func_196540_x(blockstate2)) {
                     p_225542_2_.func_180501_a(blockpos1, blockstate2, 2);
                  }
               }
            }

         }
      }
   }

   private BlockState func_196544_a(BlockState p_196544_1_, BlockState p_196544_2_, Random p_196544_3_) {
      for(Direction direction : Direction.Plane.HORIZONTAL) {
         if (p_196544_3_.nextBoolean()) {
            BooleanProperty booleanproperty = func_176267_a(direction);
            if (p_196544_1_.func_177229_b(booleanproperty)) {
               p_196544_2_ = p_196544_2_.func_206870_a(booleanproperty, Boolean.valueOf(true));
            }
         }
      }

      return p_196544_2_;
   }

   private boolean func_196540_x(BlockState p_196540_1_) {
      return p_196540_1_.func_177229_b(field_176273_b) || p_196540_1_.func_177229_b(field_176278_M) || p_196540_1_.func_177229_b(field_176279_N) || p_196540_1_.func_177229_b(field_176280_O);
   }

   private boolean func_196539_a(IBlockReader p_196539_1_, BlockPos p_196539_2_) {
      int i = 4;
      Iterable<BlockPos> iterable = BlockPos.func_191531_b(p_196539_2_.func_177958_n() - 4, p_196539_2_.func_177956_o() - 1, p_196539_2_.func_177952_p() - 4, p_196539_2_.func_177958_n() + 4, p_196539_2_.func_177956_o() + 1, p_196539_2_.func_177952_p() + 4);
      int j = 5;

      for(BlockPos blockpos : iterable) {
         if (p_196539_1_.func_180495_p(blockpos).func_203425_a(this)) {
            --j;
            if (j <= 0) {
               return false;
            }
         }
      }

      return true;
   }

   public boolean func_196253_a(BlockState p_196253_1_, BlockItemUseContext p_196253_2_) {
      BlockState blockstate = p_196253_2_.func_195991_k().func_180495_p(p_196253_2_.func_195995_a());
      if (blockstate.func_203425_a(this)) {
         return this.func_208496_w(blockstate) < field_196546_A.size();
      } else {
         return super.func_196253_a(p_196253_1_, p_196253_2_);
      }
   }

   @Nullable
   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      BlockState blockstate = p_196258_1_.func_195991_k().func_180495_p(p_196258_1_.func_195995_a());
      boolean flag = blockstate.func_203425_a(this);
      BlockState blockstate1 = flag ? blockstate : this.func_176223_P();

      for(Direction direction : p_196258_1_.func_196009_e()) {
         if (direction != Direction.DOWN) {
            BooleanProperty booleanproperty = func_176267_a(direction);
            boolean flag1 = flag && blockstate.func_177229_b(booleanproperty);
            if (!flag1 && this.func_196541_a(p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a(), direction)) {
               return blockstate1.func_206870_a(booleanproperty, Boolean.valueOf(true));
            }
         }
      }

      return flag ? blockstate1 : null;
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176277_a, field_176273_b, field_176278_M, field_176279_N, field_176280_O);
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      switch(p_185499_2_) {
      case CLOCKWISE_180:
         return p_185499_1_.func_206870_a(field_176273_b, p_185499_1_.func_177229_b(field_176279_N)).func_206870_a(field_176278_M, p_185499_1_.func_177229_b(field_176280_O)).func_206870_a(field_176279_N, p_185499_1_.func_177229_b(field_176273_b)).func_206870_a(field_176280_O, p_185499_1_.func_177229_b(field_176278_M));
      case COUNTERCLOCKWISE_90:
         return p_185499_1_.func_206870_a(field_176273_b, p_185499_1_.func_177229_b(field_176278_M)).func_206870_a(field_176278_M, p_185499_1_.func_177229_b(field_176279_N)).func_206870_a(field_176279_N, p_185499_1_.func_177229_b(field_176280_O)).func_206870_a(field_176280_O, p_185499_1_.func_177229_b(field_176273_b));
      case CLOCKWISE_90:
         return p_185499_1_.func_206870_a(field_176273_b, p_185499_1_.func_177229_b(field_176280_O)).func_206870_a(field_176278_M, p_185499_1_.func_177229_b(field_176273_b)).func_206870_a(field_176279_N, p_185499_1_.func_177229_b(field_176278_M)).func_206870_a(field_176280_O, p_185499_1_.func_177229_b(field_176279_N));
      default:
         return p_185499_1_;
      }
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      switch(p_185471_2_) {
      case LEFT_RIGHT:
         return p_185471_1_.func_206870_a(field_176273_b, p_185471_1_.func_177229_b(field_176279_N)).func_206870_a(field_176279_N, p_185471_1_.func_177229_b(field_176273_b));
      case FRONT_BACK:
         return p_185471_1_.func_206870_a(field_176278_M, p_185471_1_.func_177229_b(field_176280_O)).func_206870_a(field_176280_O, p_185471_1_.func_177229_b(field_176278_M));
      default:
         return super.func_185471_a(p_185471_1_, p_185471_2_);
      }
   }

   public static BooleanProperty func_176267_a(Direction p_176267_0_) {
      return field_196546_A.get(p_176267_0_);
   }
}
