package net.minecraft.block;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.Direction;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;

public class DeadCoralWallFanBlock extends CoralFanBlock {
   public static final DirectionProperty field_211884_b = HorizontalBlock.field_185512_D;
   private static final Map<Direction, VoxelShape> field_211885_c = Maps.newEnumMap(ImmutableMap.of(Direction.NORTH, Block.func_208617_a(0.0D, 4.0D, 5.0D, 16.0D, 12.0D, 16.0D), Direction.SOUTH, Block.func_208617_a(0.0D, 4.0D, 0.0D, 16.0D, 12.0D, 11.0D), Direction.WEST, Block.func_208617_a(5.0D, 4.0D, 0.0D, 16.0D, 12.0D, 16.0D), Direction.EAST, Block.func_208617_a(0.0D, 4.0D, 0.0D, 11.0D, 12.0D, 16.0D)));

   protected DeadCoralWallFanBlock(AbstractBlock.Properties p_i49776_1_) {
      super(p_i49776_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_211884_b, Direction.NORTH).func_206870_a(field_212560_b, Boolean.valueOf(true)));
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_211885_c.get(p_220053_1_.func_177229_b(field_211884_b));
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_211884_b, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_211884_b)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_211884_b)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_211884_b, field_212560_b);
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_1_.func_177229_b(field_212560_b)) {
         p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
      }

      return p_196271_2_.func_176734_d() == p_196271_1_.func_177229_b(field_211884_b) && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : p_196271_1_;
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      Direction direction = p_196260_1_.func_177229_b(field_211884_b);
      BlockPos blockpos = p_196260_3_.func_177972_a(direction.func_176734_d());
      BlockState blockstate = p_196260_2_.func_180495_p(blockpos);
      return blockstate.func_224755_d(p_196260_2_, blockpos, direction);
   }

   @Nullable
   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      BlockState blockstate = super.func_196258_a(p_196258_1_);
      IWorldReader iworldreader = p_196258_1_.func_195991_k();
      BlockPos blockpos = p_196258_1_.func_195995_a();
      Direction[] adirection = p_196258_1_.func_196009_e();

      for(Direction direction : adirection) {
         if (direction.func_176740_k().func_176722_c()) {
            blockstate = blockstate.func_206870_a(field_211884_b, direction.func_176734_d());
            if (blockstate.func_196955_c(iworldreader, blockpos)) {
               return blockstate;
            }
         }
      }

      return null;
   }
}
