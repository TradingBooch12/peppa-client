package net.minecraft.block;

import java.util.Random;
import net.minecraft.item.ItemStack;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class FrostedIceBlock extends IceBlock {
   public static final IntegerProperty field_185682_a = BlockStateProperties.field_208168_U;

   public FrostedIceBlock(AbstractBlock.Properties p_i48394_1_) {
      super(p_i48394_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_185682_a, Integer.valueOf(0)));
   }

   public void func_225542_b_(BlockState p_225542_1_, ServerWorld p_225542_2_, BlockPos p_225542_3_, Random p_225542_4_) {
      this.func_225534_a_(p_225542_1_, p_225542_2_, p_225542_3_, p_225542_4_);
   }

   public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
      if ((p_225534_4_.nextInt(3) == 0 || this.func_196456_a(p_225534_2_, p_225534_3_, 4)) && p_225534_2_.func_201696_r(p_225534_3_) > 11 - p_225534_1_.func_177229_b(field_185682_a) - p_225534_1_.func_200016_a(p_225534_2_, p_225534_3_) && this.func_196455_e(p_225534_1_, p_225534_2_, p_225534_3_)) {
         BlockPos.Mutable blockpos$mutable = new BlockPos.Mutable();

         for(Direction direction : Direction.values()) {
            blockpos$mutable.func_239622_a_(p_225534_3_, direction);
            BlockState blockstate = p_225534_2_.func_180495_p(blockpos$mutable);
            if (blockstate.func_203425_a(this) && !this.func_196455_e(blockstate, p_225534_2_, blockpos$mutable)) {
               p_225534_2_.func_205220_G_().func_205360_a(blockpos$mutable, this, MathHelper.func_76136_a(p_225534_4_, 20, 40));
            }
         }

      } else {
         p_225534_2_.func_205220_G_().func_205360_a(p_225534_3_, this, MathHelper.func_76136_a(p_225534_4_, 20, 40));
      }
   }

   private boolean func_196455_e(BlockState p_196455_1_, World p_196455_2_, BlockPos p_196455_3_) {
      int i = p_196455_1_.func_177229_b(field_185682_a);
      if (i < 3) {
         p_196455_2_.func_180501_a(p_196455_3_, p_196455_1_.func_206870_a(field_185682_a, Integer.valueOf(i + 1)), 2);
         return false;
      } else {
         this.func_196454_d(p_196455_1_, p_196455_2_, p_196455_3_);
         return true;
      }
   }

   public void func_220069_a(BlockState p_220069_1_, World p_220069_2_, BlockPos p_220069_3_, Block p_220069_4_, BlockPos p_220069_5_, boolean p_220069_6_) {
      if (p_220069_4_ == this && this.func_196456_a(p_220069_2_, p_220069_3_, 2)) {
         this.func_196454_d(p_220069_1_, p_220069_2_, p_220069_3_);
      }

      super.func_220069_a(p_220069_1_, p_220069_2_, p_220069_3_, p_220069_4_, p_220069_5_, p_220069_6_);
   }

   private boolean func_196456_a(IBlockReader p_196456_1_, BlockPos p_196456_2_, int p_196456_3_) {
      int i = 0;
      BlockPos.Mutable blockpos$mutable = new BlockPos.Mutable();

      for(Direction direction : Direction.values()) {
         blockpos$mutable.func_239622_a_(p_196456_2_, direction);
         if (p_196456_1_.func_180495_p(blockpos$mutable).func_203425_a(this)) {
            ++i;
            if (i >= p_196456_3_) {
               return false;
            }
         }
      }

      return true;
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_185682_a);
   }

   @OnlyIn(Dist.CLIENT)
   public ItemStack func_185473_a(IBlockReader p_185473_1_, BlockPos p_185473_2_, BlockState p_185473_3_) {
      return ItemStack.field_190927_a;
   }
}
