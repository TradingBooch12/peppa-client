package net.minecraft.block;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class FenceGateBlock extends HorizontalBlock {
   public static final BooleanProperty field_176466_a = BlockStateProperties.field_208193_t;
   public static final BooleanProperty field_176465_b = BlockStateProperties.field_208194_u;
   public static final BooleanProperty field_176467_M = BlockStateProperties.field_208189_p;
   protected static final VoxelShape field_185541_d = Block.func_208617_a(0.0D, 0.0D, 6.0D, 16.0D, 16.0D, 10.0D);
   protected static final VoxelShape field_185542_e = Block.func_208617_a(6.0D, 0.0D, 0.0D, 10.0D, 16.0D, 16.0D);
   protected static final VoxelShape field_185543_f = Block.func_208617_a(0.0D, 0.0D, 6.0D, 16.0D, 13.0D, 10.0D);
   protected static final VoxelShape field_185544_g = Block.func_208617_a(6.0D, 0.0D, 0.0D, 10.0D, 13.0D, 16.0D);
   protected static final VoxelShape field_208068_x = Block.func_208617_a(0.0D, 0.0D, 6.0D, 16.0D, 24.0D, 10.0D);
   protected static final VoxelShape field_185540_C = Block.func_208617_a(6.0D, 0.0D, 0.0D, 10.0D, 24.0D, 16.0D);
   protected static final VoxelShape field_208069_z = VoxelShapes.func_197872_a(Block.func_208617_a(0.0D, 5.0D, 7.0D, 2.0D, 16.0D, 9.0D), Block.func_208617_a(14.0D, 5.0D, 7.0D, 16.0D, 16.0D, 9.0D));
   protected static final VoxelShape field_185539_B = VoxelShapes.func_197872_a(Block.func_208617_a(7.0D, 5.0D, 0.0D, 9.0D, 16.0D, 2.0D), Block.func_208617_a(7.0D, 5.0D, 14.0D, 9.0D, 16.0D, 16.0D));
   protected static final VoxelShape field_208066_B = VoxelShapes.func_197872_a(Block.func_208617_a(0.0D, 2.0D, 7.0D, 2.0D, 13.0D, 9.0D), Block.func_208617_a(14.0D, 2.0D, 7.0D, 16.0D, 13.0D, 9.0D));
   protected static final VoxelShape field_208067_C = VoxelShapes.func_197872_a(Block.func_208617_a(7.0D, 2.0D, 0.0D, 9.0D, 13.0D, 2.0D), Block.func_208617_a(7.0D, 2.0D, 14.0D, 9.0D, 13.0D, 16.0D));

   public FenceGateBlock(AbstractBlock.Properties p_i48398_1_) {
      super(p_i48398_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176466_a, Boolean.valueOf(false)).func_206870_a(field_176465_b, Boolean.valueOf(false)).func_206870_a(field_176467_M, Boolean.valueOf(false)));
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      if (p_220053_1_.func_177229_b(field_176467_M)) {
         return p_220053_1_.func_177229_b(field_185512_D).func_176740_k() == Direction.Axis.X ? field_185544_g : field_185543_f;
      } else {
         return p_220053_1_.func_177229_b(field_185512_D).func_176740_k() == Direction.Axis.X ? field_185542_e : field_185541_d;
      }
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      Direction.Axis direction$axis = p_196271_2_.func_176740_k();
      if (p_196271_1_.func_177229_b(field_185512_D).func_176746_e().func_176740_k() != direction$axis) {
         return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      } else {
         boolean flag = this.func_196380_i(p_196271_3_) || this.func_196380_i(p_196271_4_.func_180495_p(p_196271_5_.func_177972_a(p_196271_2_.func_176734_d())));
         return p_196271_1_.func_206870_a(field_176467_M, Boolean.valueOf(flag));
      }
   }

   public VoxelShape func_220071_b(BlockState p_220071_1_, IBlockReader p_220071_2_, BlockPos p_220071_3_, ISelectionContext p_220071_4_) {
      if (p_220071_1_.func_177229_b(field_176466_a)) {
         return VoxelShapes.func_197880_a();
      } else {
         return p_220071_1_.func_177229_b(field_185512_D).func_176740_k() == Direction.Axis.Z ? field_208068_x : field_185540_C;
      }
   }

   public VoxelShape func_196247_c(BlockState p_196247_1_, IBlockReader p_196247_2_, BlockPos p_196247_3_) {
      if (p_196247_1_.func_177229_b(field_176467_M)) {
         return p_196247_1_.func_177229_b(field_185512_D).func_176740_k() == Direction.Axis.X ? field_208067_C : field_208066_B;
      } else {
         return p_196247_1_.func_177229_b(field_185512_D).func_176740_k() == Direction.Axis.X ? field_185539_B : field_208069_z;
      }
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      switch(p_196266_4_) {
      case LAND:
         return p_196266_1_.func_177229_b(field_176466_a);
      case WATER:
         return false;
      case AIR:
         return p_196266_1_.func_177229_b(field_176466_a);
      default:
         return false;
      }
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      World world = p_196258_1_.func_195991_k();
      BlockPos blockpos = p_196258_1_.func_195995_a();
      boolean flag = world.func_175640_z(blockpos);
      Direction direction = p_196258_1_.func_195992_f();
      Direction.Axis direction$axis = direction.func_176740_k();
      boolean flag1 = direction$axis == Direction.Axis.Z && (this.func_196380_i(world.func_180495_p(blockpos.func_177976_e())) || this.func_196380_i(world.func_180495_p(blockpos.func_177974_f()))) || direction$axis == Direction.Axis.X && (this.func_196380_i(world.func_180495_p(blockpos.func_177978_c())) || this.func_196380_i(world.func_180495_p(blockpos.func_177968_d())));
      return this.func_176223_P().func_206870_a(field_185512_D, direction).func_206870_a(field_176466_a, Boolean.valueOf(flag)).func_206870_a(field_176465_b, Boolean.valueOf(flag)).func_206870_a(field_176467_M, Boolean.valueOf(flag1));
   }

   private boolean func_196380_i(BlockState p_196380_1_) {
      return p_196380_1_.func_177230_c().func_203417_a(BlockTags.field_219757_z);
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      if (p_225533_1_.func_177229_b(field_176466_a)) {
         p_225533_1_ = p_225533_1_.func_206870_a(field_176466_a, Boolean.valueOf(false));
         p_225533_2_.func_180501_a(p_225533_3_, p_225533_1_, 10);
      } else {
         Direction direction = p_225533_4_.func_174811_aO();
         if (p_225533_1_.func_177229_b(field_185512_D) == direction.func_176734_d()) {
            p_225533_1_ = p_225533_1_.func_206870_a(field_185512_D, direction);
         }

         p_225533_1_ = p_225533_1_.func_206870_a(field_176466_a, Boolean.valueOf(true));
         p_225533_2_.func_180501_a(p_225533_3_, p_225533_1_, 10);
      }

      p_225533_2_.func_217378_a(p_225533_4_, p_225533_1_.func_177229_b(field_176466_a) ? 1008 : 1014, p_225533_3_, 0);
      return ActionResultType.func_233537_a_(p_225533_2_.field_72995_K);
   }

   public void func_220069_a(BlockState p_220069_1_, World p_220069_2_, BlockPos p_220069_3_, Block p_220069_4_, BlockPos p_220069_5_, boolean p_220069_6_) {
      if (!p_220069_2_.field_72995_K) {
         boolean flag = p_220069_2_.func_175640_z(p_220069_3_);
         if (p_220069_1_.func_177229_b(field_176465_b) != flag) {
            p_220069_2_.func_180501_a(p_220069_3_, p_220069_1_.func_206870_a(field_176465_b, Boolean.valueOf(flag)).func_206870_a(field_176466_a, Boolean.valueOf(flag)), 2);
            if (p_220069_1_.func_177229_b(field_176466_a) != flag) {
               p_220069_2_.func_217378_a((PlayerEntity)null, flag ? 1008 : 1014, p_220069_3_, 0);
            }
         }

      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_185512_D, field_176466_a, field_176465_b, field_176467_M);
   }

   public static boolean func_220253_a(BlockState p_220253_0_, Direction p_220253_1_) {
      return p_220253_0_.func_177229_b(field_185512_D).func_176740_k() == p_220253_1_.func_176746_e().func_176740_k();
   }
}
