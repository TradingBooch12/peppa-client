package net.minecraft.block;

import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;

public class SkullBlock extends AbstractSkullBlock {
   public static final IntegerProperty field_196294_a = BlockStateProperties.field_208138_am;
   protected static final VoxelShape field_196295_b = Block.func_208617_a(4.0D, 0.0D, 4.0D, 12.0D, 8.0D, 12.0D);

   protected SkullBlock(SkullBlock.ISkullType p_i48332_1_, AbstractBlock.Properties p_i48332_2_) {
      super(p_i48332_1_, p_i48332_2_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196294_a, Integer.valueOf(0)));
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196295_b;
   }

   public VoxelShape func_196247_c(BlockState p_196247_1_, IBlockReader p_196247_2_, BlockPos p_196247_3_) {
      return VoxelShapes.func_197880_a();
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_196294_a, Integer.valueOf(MathHelper.func_76128_c((double)(p_196258_1_.func_195990_h() * 16.0F / 360.0F) + 0.5D) & 15));
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_196294_a, Integer.valueOf(p_185499_2_.func_185833_a(p_185499_1_.func_177229_b(field_196294_a), 16)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_206870_a(field_196294_a, Integer.valueOf(p_185471_2_.func_185802_a(p_185471_1_.func_177229_b(field_196294_a), 16)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196294_a);
   }

   public interface ISkullType {
   }

   public static enum Types implements SkullBlock.ISkullType {
      SKELETON,
      WITHER_SKELETON,
      PLAYER,
      ZOMBIE,
      CREEPER,
      DRAGON;
   }
}
