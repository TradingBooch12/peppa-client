package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class RedstoneLampBlock extends Block {
   public static final BooleanProperty field_196502_a = RedstoneTorchBlock.field_196528_a;

   public RedstoneLampBlock(AbstractBlock.Properties p_i48343_1_) {
      super(p_i48343_1_);
      this.func_180632_j(this.func_176223_P().func_206870_a(field_196502_a, Boolean.valueOf(false)));
   }

   @Nullable
   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_196502_a, Boolean.valueOf(p_196258_1_.func_195991_k().func_175640_z(p_196258_1_.func_195995_a())));
   }

   public void func_220069_a(BlockState p_220069_1_, World p_220069_2_, BlockPos p_220069_3_, Block p_220069_4_, BlockPos p_220069_5_, boolean p_220069_6_) {
      if (!p_220069_2_.field_72995_K) {
         boolean flag = p_220069_1_.func_177229_b(field_196502_a);
         if (flag != p_220069_2_.func_175640_z(p_220069_3_)) {
            if (flag) {
               p_220069_2_.func_205220_G_().func_205360_a(p_220069_3_, this, 4);
            } else {
               p_220069_2_.func_180501_a(p_220069_3_, p_220069_1_.func_235896_a_(field_196502_a), 2);
            }
         }

      }
   }

   public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
      if (p_225534_1_.func_177229_b(field_196502_a) && !p_225534_2_.func_175640_z(p_225534_3_)) {
         p_225534_2_.func_180501_a(p_225534_3_, p_225534_1_.func_235896_a_(field_196502_a), 2);
      }

   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196502_a);
   }
}
