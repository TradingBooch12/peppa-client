package net.minecraft.block;

import java.util.Random;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tileentity.CommandBlockLogic;
import net.minecraft.tileentity.CommandBlockTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.StringUtils;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.world.GameRules;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CommandBlockBlock extends ContainerBlock {
   private static final Logger field_193388_c = LogManager.getLogger();
   public static final DirectionProperty field_185564_a = DirectionalBlock.field_176387_N;
   public static final BooleanProperty field_185565_b = BlockStateProperties.field_208176_c;

   public CommandBlockBlock(AbstractBlock.Properties p_i48425_1_) {
      super(p_i48425_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_185564_a, Direction.NORTH).func_206870_a(field_185565_b, Boolean.valueOf(false)));
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      CommandBlockTileEntity commandblocktileentity = new CommandBlockTileEntity();
      commandblocktileentity.func_184253_b(this == Blocks.field_185777_dd);
      return commandblocktileentity;
   }

   public void func_220069_a(BlockState p_220069_1_, World p_220069_2_, BlockPos p_220069_3_, Block p_220069_4_, BlockPos p_220069_5_, boolean p_220069_6_) {
      if (!p_220069_2_.field_72995_K) {
         TileEntity tileentity = p_220069_2_.func_175625_s(p_220069_3_);
         if (tileentity instanceof CommandBlockTileEntity) {
            CommandBlockTileEntity commandblocktileentity = (CommandBlockTileEntity)tileentity;
            boolean flag = p_220069_2_.func_175640_z(p_220069_3_);
            boolean flag1 = commandblocktileentity.func_184255_d();
            commandblocktileentity.func_184250_a(flag);
            if (!flag1 && !commandblocktileentity.func_184254_e() && commandblocktileentity.func_184251_i() != CommandBlockTileEntity.Mode.SEQUENCE) {
               if (flag) {
                  commandblocktileentity.func_184249_c();
                  p_220069_2_.func_205220_G_().func_205360_a(p_220069_3_, this, 1);
               }

            }
         }
      }
   }

   public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
      TileEntity tileentity = p_225534_2_.func_175625_s(p_225534_3_);
      if (tileentity instanceof CommandBlockTileEntity) {
         CommandBlockTileEntity commandblocktileentity = (CommandBlockTileEntity)tileentity;
         CommandBlockLogic commandblocklogic = commandblocktileentity.func_145993_a();
         boolean flag = !StringUtils.func_151246_b(commandblocklogic.func_145753_i());
         CommandBlockTileEntity.Mode commandblocktileentity$mode = commandblocktileentity.func_184251_i();
         boolean flag1 = commandblocktileentity.func_184256_g();
         if (commandblocktileentity$mode == CommandBlockTileEntity.Mode.AUTO) {
            commandblocktileentity.func_184249_c();
            if (flag1) {
               this.func_193387_a(p_225534_1_, p_225534_2_, p_225534_3_, commandblocklogic, flag);
            } else if (commandblocktileentity.func_184258_j()) {
               commandblocklogic.func_184167_a(0);
            }

            if (commandblocktileentity.func_184255_d() || commandblocktileentity.func_184254_e()) {
               p_225534_2_.func_205220_G_().func_205360_a(p_225534_3_, this, 1);
            }
         } else if (commandblocktileentity$mode == CommandBlockTileEntity.Mode.REDSTONE) {
            if (flag1) {
               this.func_193387_a(p_225534_1_, p_225534_2_, p_225534_3_, commandblocklogic, flag);
            } else if (commandblocktileentity.func_184258_j()) {
               commandblocklogic.func_184167_a(0);
            }
         }

         p_225534_2_.func_175666_e(p_225534_3_, this);
      }

   }

   private void func_193387_a(BlockState p_193387_1_, World p_193387_2_, BlockPos p_193387_3_, CommandBlockLogic p_193387_4_, boolean p_193387_5_) {
      if (p_193387_5_) {
         p_193387_4_.func_145755_a(p_193387_2_);
      } else {
         p_193387_4_.func_184167_a(0);
      }

      func_193386_c(p_193387_2_, p_193387_3_, p_193387_1_.func_177229_b(field_185564_a));
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      TileEntity tileentity = p_225533_2_.func_175625_s(p_225533_3_);
      if (tileentity instanceof CommandBlockTileEntity && p_225533_4_.func_195070_dx()) {
         p_225533_4_.func_184824_a((CommandBlockTileEntity)tileentity);
         return ActionResultType.func_233537_a_(p_225533_2_.field_72995_K);
      } else {
         return ActionResultType.PASS;
      }
   }

   public boolean func_149740_M(BlockState p_149740_1_) {
      return true;
   }

   public int func_180641_l(BlockState p_180641_1_, World p_180641_2_, BlockPos p_180641_3_) {
      TileEntity tileentity = p_180641_2_.func_175625_s(p_180641_3_);
      return tileentity instanceof CommandBlockTileEntity ? ((CommandBlockTileEntity)tileentity).func_145993_a().func_145760_g() : 0;
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, BlockState p_180633_3_, LivingEntity p_180633_4_, ItemStack p_180633_5_) {
      TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);
      if (tileentity instanceof CommandBlockTileEntity) {
         CommandBlockTileEntity commandblocktileentity = (CommandBlockTileEntity)tileentity;
         CommandBlockLogic commandblocklogic = commandblocktileentity.func_145993_a();
         if (p_180633_5_.func_82837_s()) {
            commandblocklogic.func_207405_b(p_180633_5_.func_200301_q());
         }

         if (!p_180633_1_.field_72995_K) {
            if (p_180633_5_.func_179543_a("BlockEntityTag") == null) {
               commandblocklogic.func_175573_a(p_180633_1_.func_82736_K().func_223586_b(GameRules.field_223611_n));
               commandblocktileentity.func_184253_b(this == Blocks.field_185777_dd);
            }

            if (commandblocktileentity.func_184251_i() == CommandBlockTileEntity.Mode.SEQUENCE) {
               boolean flag = p_180633_1_.func_175640_z(p_180633_2_);
               commandblocktileentity.func_184250_a(flag);
            }
         }

      }
   }

   public BlockRenderType func_149645_b(BlockState p_149645_1_) {
      return BlockRenderType.MODEL;
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_185564_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_185564_a)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_185564_a)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_185564_a, field_185565_b);
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_185564_a, p_196258_1_.func_196010_d().func_176734_d());
   }

   private static void func_193386_c(World p_193386_0_, BlockPos p_193386_1_, Direction p_193386_2_) {
      BlockPos.Mutable blockpos$mutable = p_193386_1_.func_239590_i_();
      GameRules gamerules = p_193386_0_.func_82736_K();

      int i;
      BlockState blockstate;
      for(i = gamerules.func_223592_c(GameRules.field_223619_v); i-- > 0; p_193386_2_ = blockstate.func_177229_b(field_185564_a)) {
         blockpos$mutable.func_189536_c(p_193386_2_);
         blockstate = p_193386_0_.func_180495_p(blockpos$mutable);
         Block block = blockstate.func_177230_c();
         if (!blockstate.func_203425_a(Blocks.field_185777_dd)) {
            break;
         }

         TileEntity tileentity = p_193386_0_.func_175625_s(blockpos$mutable);
         if (!(tileentity instanceof CommandBlockTileEntity)) {
            break;
         }

         CommandBlockTileEntity commandblocktileentity = (CommandBlockTileEntity)tileentity;
         if (commandblocktileentity.func_184251_i() != CommandBlockTileEntity.Mode.SEQUENCE) {
            break;
         }

         if (commandblocktileentity.func_184255_d() || commandblocktileentity.func_184254_e()) {
            CommandBlockLogic commandblocklogic = commandblocktileentity.func_145993_a();
            if (commandblocktileentity.func_184249_c()) {
               if (!commandblocklogic.func_145755_a(p_193386_0_)) {
                  break;
               }

               p_193386_0_.func_175666_e(blockpos$mutable, block);
            } else if (commandblocktileentity.func_184258_j()) {
               commandblocklogic.func_184167_a(0);
            }
         }
      }

      if (i <= 0) {
         int j = Math.max(gamerules.func_223592_c(GameRules.field_223619_v), 0);
         field_193388_c.warn("Command Block chain tried to execute more than {} steps!", (int)j);
      }

   }
}
