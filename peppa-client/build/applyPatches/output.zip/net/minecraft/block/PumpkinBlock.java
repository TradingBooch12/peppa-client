package net.minecraft.block;

import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.world.World;

public class PumpkinBlock extends StemGrownBlock {
   protected PumpkinBlock(AbstractBlock.Properties p_i48347_1_) {
      super(p_i48347_1_);
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      ItemStack itemstack = p_225533_4_.func_184586_b(p_225533_5_);
      if (itemstack.func_77973_b() == Items.field_151097_aZ) {
         if (!p_225533_2_.field_72995_K) {
            Direction direction = p_225533_6_.func_216354_b();
            Direction direction1 = direction.func_176740_k() == Direction.Axis.Y ? p_225533_4_.func_174811_aO().func_176734_d() : direction;
            p_225533_2_.func_184133_a((PlayerEntity)null, p_225533_3_, SoundEvents.field_199059_fV, SoundCategory.BLOCKS, 1.0F, 1.0F);
            p_225533_2_.func_180501_a(p_225533_3_, Blocks.field_196625_cS.func_176223_P().func_206870_a(CarvedPumpkinBlock.field_196359_a, direction1), 11);
            ItemEntity itementity = new ItemEntity(p_225533_2_, (double)p_225533_3_.func_177958_n() + 0.5D + (double)direction1.func_82601_c() * 0.65D, (double)p_225533_3_.func_177956_o() + 0.1D, (double)p_225533_3_.func_177952_p() + 0.5D + (double)direction1.func_82599_e() * 0.65D, new ItemStack(Items.field_151080_bb, 4));
            itementity.func_213293_j(0.05D * (double)direction1.func_82601_c() + p_225533_2_.field_73012_v.nextDouble() * 0.02D, 0.05D, 0.05D * (double)direction1.func_82599_e() + p_225533_2_.field_73012_v.nextDouble() * 0.02D);
            p_225533_2_.func_217376_c(itementity);
            itemstack.func_222118_a(1, p_225533_4_, (p_220282_1_) -> {
               p_220282_1_.func_213334_d(p_225533_5_);
            });
         }

         return ActionResultType.func_233537_a_(p_225533_2_.field_72995_K);
      } else {
         return super.func_225533_a_(p_225533_1_, p_225533_2_, p_225533_3_, p_225533_4_, p_225533_5_, p_225533_6_);
      }
   }

   public StemBlock func_196524_d() {
      return (StemBlock)Blocks.field_150393_bb;
   }

   public AttachedStemBlock func_196523_e() {
      return (AttachedStemBlock)Blocks.field_196711_ds;
   }
}
