package net.minecraft.block;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.entity.item.FallingBlockEntity;
import net.minecraft.particles.BlockParticleData;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class FallingBlock extends Block {
   public FallingBlock(AbstractBlock.Properties p_i48401_1_) {
      super(p_i48401_1_);
   }

   public void func_220082_b(BlockState p_220082_1_, World p_220082_2_, BlockPos p_220082_3_, BlockState p_220082_4_, boolean p_220082_5_) {
      p_220082_2_.func_205220_G_().func_205360_a(p_220082_3_, this, this.func_230329_c_());
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, this.func_230329_c_());
      return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
      if (func_185759_i(p_225534_2_.func_180495_p(p_225534_3_.func_177977_b())) && p_225534_3_.func_177956_o() >= 0) {
         FallingBlockEntity fallingblockentity = new FallingBlockEntity(p_225534_2_, (double)p_225534_3_.func_177958_n() + 0.5D, (double)p_225534_3_.func_177956_o(), (double)p_225534_3_.func_177952_p() + 0.5D, p_225534_2_.func_180495_p(p_225534_3_));
         this.func_149829_a(fallingblockentity);
         p_225534_2_.func_217376_c(fallingblockentity);
      }
   }

   protected void func_149829_a(FallingBlockEntity p_149829_1_) {
   }

   protected int func_230329_c_() {
      return 2;
   }

   public static boolean func_185759_i(BlockState p_185759_0_) {
      Material material = p_185759_0_.func_185904_a();
      return p_185759_0_.func_196958_f() || p_185759_0_.func_235714_a_(BlockTags.field_232872_am_) || material.func_76224_d() || material.func_76222_j();
   }

   public void func_176502_a_(World p_176502_1_, BlockPos p_176502_2_, BlockState p_176502_3_, BlockState p_176502_4_, FallingBlockEntity p_176502_5_) {
   }

   public void func_190974_b(World p_190974_1_, BlockPos p_190974_2_, FallingBlockEntity p_190974_3_) {
   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(BlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      if (p_180655_4_.nextInt(16) == 0) {
         BlockPos blockpos = p_180655_3_.func_177977_b();
         if (func_185759_i(p_180655_2_.func_180495_p(blockpos))) {
            double d0 = (double)p_180655_3_.func_177958_n() + p_180655_4_.nextDouble();
            double d1 = (double)p_180655_3_.func_177956_o() - 0.05D;
            double d2 = (double)p_180655_3_.func_177952_p() + p_180655_4_.nextDouble();
            p_180655_2_.func_195594_a(new BlockParticleData(ParticleTypes.field_197628_u, p_180655_1_), d0, d1, d2, 0.0D, 0.0D, 0.0D);
         }
      }

   }

   @OnlyIn(Dist.CLIENT)
   public int func_189876_x(BlockState p_189876_1_, IBlockReader p_189876_2_, BlockPos p_189876_3_) {
      return -16777216;
   }
}
