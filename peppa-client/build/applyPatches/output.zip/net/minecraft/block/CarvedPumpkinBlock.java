package net.minecraft.block;

import java.util.function.Predicate;
import javax.annotation.Nullable;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.block.material.Material;
import net.minecraft.block.pattern.BlockMaterialMatcher;
import net.minecraft.block.pattern.BlockPattern;
import net.minecraft.block.pattern.BlockPatternBuilder;
import net.minecraft.block.pattern.BlockStateMatcher;
import net.minecraft.enchantment.IArmorVanishable;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.passive.SnowGolemEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.CachedBlockInfo;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;

public class CarvedPumpkinBlock extends HorizontalBlock implements IArmorVanishable {
   public static final DirectionProperty field_196359_a = HorizontalBlock.field_185512_D;
   @Nullable
   private BlockPattern field_196361_b;
   @Nullable
   private BlockPattern field_196362_c;
   @Nullable
   private BlockPattern field_196363_y;
   @Nullable
   private BlockPattern field_196364_z;
   private static final Predicate<BlockState> field_196360_A = (p_210301_0_) -> {
      return p_210301_0_ != null && (p_210301_0_.func_203425_a(Blocks.field_196625_cS) || p_210301_0_.func_203425_a(Blocks.field_196628_cT));
   };

   protected CarvedPumpkinBlock(AbstractBlock.Properties p_i48432_1_) {
      super(p_i48432_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196359_a, Direction.NORTH));
   }

   public void func_220082_b(BlockState p_220082_1_, World p_220082_2_, BlockPos p_220082_3_, BlockState p_220082_4_, boolean p_220082_5_) {
      if (!p_220082_4_.func_203425_a(p_220082_1_.func_177230_c())) {
         this.func_196358_b(p_220082_2_, p_220082_3_);
      }
   }

   public boolean func_196354_a(IWorldReader p_196354_1_, BlockPos p_196354_2_) {
      return this.func_196353_d().func_177681_a(p_196354_1_, p_196354_2_) != null || this.func_196356_f().func_177681_a(p_196354_1_, p_196354_2_) != null;
   }

   private void func_196358_b(World p_196358_1_, BlockPos p_196358_2_) {
      BlockPattern.PatternHelper blockpattern$patternhelper = this.func_196355_e().func_177681_a(p_196358_1_, p_196358_2_);
      if (blockpattern$patternhelper != null) {
         for(int i = 0; i < this.func_196355_e().func_177685_b(); ++i) {
            CachedBlockInfo cachedblockinfo = blockpattern$patternhelper.func_177670_a(0, i, 0);
            p_196358_1_.func_180501_a(cachedblockinfo.func_177508_d(), Blocks.field_150350_a.func_176223_P(), 2);
            p_196358_1_.func_217379_c(2001, cachedblockinfo.func_177508_d(), Block.func_196246_j(cachedblockinfo.func_177509_a()));
         }

         SnowGolemEntity snowgolementity = EntityType.field_200745_ak.func_200721_a(p_196358_1_);
         BlockPos blockpos1 = blockpattern$patternhelper.func_177670_a(0, 2, 0).func_177508_d();
         snowgolementity.func_70012_b((double)blockpos1.func_177958_n() + 0.5D, (double)blockpos1.func_177956_o() + 0.05D, (double)blockpos1.func_177952_p() + 0.5D, 0.0F, 0.0F);
         p_196358_1_.func_217376_c(snowgolementity);

         for(ServerPlayerEntity serverplayerentity : p_196358_1_.func_217357_a(ServerPlayerEntity.class, snowgolementity.func_174813_aQ().func_186662_g(5.0D))) {
            CriteriaTriggers.field_192133_m.func_192229_a(serverplayerentity, snowgolementity);
         }

         for(int l = 0; l < this.func_196355_e().func_177685_b(); ++l) {
            CachedBlockInfo cachedblockinfo3 = blockpattern$patternhelper.func_177670_a(0, l, 0);
            p_196358_1_.func_230547_a_(cachedblockinfo3.func_177508_d(), Blocks.field_150350_a);
         }
      } else {
         blockpattern$patternhelper = this.func_196357_g().func_177681_a(p_196358_1_, p_196358_2_);
         if (blockpattern$patternhelper != null) {
            for(int j = 0; j < this.func_196357_g().func_177684_c(); ++j) {
               for(int k = 0; k < this.func_196357_g().func_177685_b(); ++k) {
                  CachedBlockInfo cachedblockinfo2 = blockpattern$patternhelper.func_177670_a(j, k, 0);
                  p_196358_1_.func_180501_a(cachedblockinfo2.func_177508_d(), Blocks.field_150350_a.func_176223_P(), 2);
                  p_196358_1_.func_217379_c(2001, cachedblockinfo2.func_177508_d(), Block.func_196246_j(cachedblockinfo2.func_177509_a()));
               }
            }

            BlockPos blockpos = blockpattern$patternhelper.func_177670_a(1, 2, 0).func_177508_d();
            IronGolemEntity irongolementity = EntityType.field_200757_aw.func_200721_a(p_196358_1_);
            irongolementity.func_70849_f(true);
            irongolementity.func_70012_b((double)blockpos.func_177958_n() + 0.5D, (double)blockpos.func_177956_o() + 0.05D, (double)blockpos.func_177952_p() + 0.5D, 0.0F, 0.0F);
            p_196358_1_.func_217376_c(irongolementity);

            for(ServerPlayerEntity serverplayerentity1 : p_196358_1_.func_217357_a(ServerPlayerEntity.class, irongolementity.func_174813_aQ().func_186662_g(5.0D))) {
               CriteriaTriggers.field_192133_m.func_192229_a(serverplayerentity1, irongolementity);
            }

            for(int i1 = 0; i1 < this.func_196357_g().func_177684_c(); ++i1) {
               for(int j1 = 0; j1 < this.func_196357_g().func_177685_b(); ++j1) {
                  CachedBlockInfo cachedblockinfo1 = blockpattern$patternhelper.func_177670_a(i1, j1, 0);
                  p_196358_1_.func_230547_a_(cachedblockinfo1.func_177508_d(), Blocks.field_150350_a);
               }
            }
         }
      }

   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_196359_a, p_196258_1_.func_195992_f().func_176734_d());
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196359_a);
   }

   private BlockPattern func_196353_d() {
      if (this.field_196361_b == null) {
         this.field_196361_b = BlockPatternBuilder.func_177660_a().func_177659_a(" ", "#", "#").func_177662_a('#', CachedBlockInfo.func_177510_a(BlockStateMatcher.func_177638_a(Blocks.field_196604_cC))).func_177661_b();
      }

      return this.field_196361_b;
   }

   private BlockPattern func_196355_e() {
      if (this.field_196362_c == null) {
         this.field_196362_c = BlockPatternBuilder.func_177660_a().func_177659_a("^", "#", "#").func_177662_a('^', CachedBlockInfo.func_177510_a(field_196360_A)).func_177662_a('#', CachedBlockInfo.func_177510_a(BlockStateMatcher.func_177638_a(Blocks.field_196604_cC))).func_177661_b();
      }

      return this.field_196362_c;
   }

   private BlockPattern func_196356_f() {
      if (this.field_196363_y == null) {
         this.field_196363_y = BlockPatternBuilder.func_177660_a().func_177659_a("~ ~", "###", "~#~").func_177662_a('#', CachedBlockInfo.func_177510_a(BlockStateMatcher.func_177638_a(Blocks.field_150339_S))).func_177662_a('~', CachedBlockInfo.func_177510_a(BlockMaterialMatcher.func_189886_a(Material.field_151579_a))).func_177661_b();
      }

      return this.field_196363_y;
   }

   private BlockPattern func_196357_g() {
      if (this.field_196364_z == null) {
         this.field_196364_z = BlockPatternBuilder.func_177660_a().func_177659_a("~^~", "###", "~#~").func_177662_a('^', CachedBlockInfo.func_177510_a(field_196360_A)).func_177662_a('#', CachedBlockInfo.func_177510_a(BlockStateMatcher.func_177638_a(Blocks.field_150339_S))).func_177662_a('~', CachedBlockInfo.func_177510_a(BlockMaterialMatcher.func_189886_a(Material.field_151579_a))).func_177661_b();
      }

      return this.field_196364_z;
   }
}
