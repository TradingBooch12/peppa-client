package net.minecraft.block;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.nbt.NBTUtil;
import net.minecraft.tileentity.SkullTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.apache.commons.lang3.StringUtils;

public class SkullPlayerBlock extends SkullBlock {
   protected SkullPlayerBlock(AbstractBlock.Properties p_i48354_1_) {
      super(SkullBlock.Types.PLAYER, p_i48354_1_);
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, BlockState p_180633_3_, @Nullable LivingEntity p_180633_4_, ItemStack p_180633_5_) {
      super.func_180633_a(p_180633_1_, p_180633_2_, p_180633_3_, p_180633_4_, p_180633_5_);
      TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);
      if (tileentity instanceof SkullTileEntity) {
         SkullTileEntity skulltileentity = (SkullTileEntity)tileentity;
         GameProfile gameprofile = null;
         if (p_180633_5_.func_77942_o()) {
            CompoundNBT compoundnbt = p_180633_5_.func_77978_p();
            if (compoundnbt.func_150297_b("SkullOwner", 10)) {
               gameprofile = NBTUtil.func_152459_a(compoundnbt.func_74775_l("SkullOwner"));
            } else if (compoundnbt.func_150297_b("SkullOwner", 8) && !StringUtils.isBlank(compoundnbt.func_74779_i("SkullOwner"))) {
               gameprofile = new GameProfile((UUID)null, compoundnbt.func_74779_i("SkullOwner"));
            }
         }

         skulltileentity.func_195485_a(gameprofile);
      }

   }
}
