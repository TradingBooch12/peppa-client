package net.minecraft.block;

import java.util.Random;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Direction;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class ObserverBlock extends DirectionalBlock {
   public static final BooleanProperty field_190963_a = BlockStateProperties.field_208194_u;

   public ObserverBlock(AbstractBlock.Properties p_i48358_1_) {
      super(p_i48358_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176387_N, Direction.SOUTH).func_206870_a(field_190963_a, Boolean.valueOf(false)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176387_N, field_190963_a);
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_176387_N, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_176387_N)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_176387_N)));
   }

   public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
      if (p_225534_1_.func_177229_b(field_190963_a)) {
         p_225534_2_.func_180501_a(p_225534_3_, p_225534_1_.func_206870_a(field_190963_a, Boolean.valueOf(false)), 2);
      } else {
         p_225534_2_.func_180501_a(p_225534_3_, p_225534_1_.func_206870_a(field_190963_a, Boolean.valueOf(true)), 2);
         p_225534_2_.func_205220_G_().func_205360_a(p_225534_3_, this, 2);
      }

      this.func_190961_e(p_225534_2_, p_225534_3_, p_225534_1_);
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_1_.func_177229_b(field_176387_N) == p_196271_2_ && !p_196271_1_.func_177229_b(field_190963_a)) {
         this.func_203420_a(p_196271_4_, p_196271_5_);
      }

      return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   private void func_203420_a(IWorld p_203420_1_, BlockPos p_203420_2_) {
      if (!p_203420_1_.func_201670_d() && !p_203420_1_.func_205220_G_().func_205359_a(p_203420_2_, this)) {
         p_203420_1_.func_205220_G_().func_205360_a(p_203420_2_, this, 2);
      }

   }

   protected void func_190961_e(World p_190961_1_, BlockPos p_190961_2_, BlockState p_190961_3_) {
      Direction direction = p_190961_3_.func_177229_b(field_176387_N);
      BlockPos blockpos = p_190961_2_.func_177972_a(direction.func_176734_d());
      p_190961_1_.func_190524_a(blockpos, this, p_190961_2_);
      p_190961_1_.func_175695_a(blockpos, this, direction);
   }

   public boolean func_149744_f(BlockState p_149744_1_) {
      return true;
   }

   public int func_176211_b(BlockState p_176211_1_, IBlockReader p_176211_2_, BlockPos p_176211_3_, Direction p_176211_4_) {
      return p_176211_1_.func_185911_a(p_176211_2_, p_176211_3_, p_176211_4_);
   }

   public int func_180656_a(BlockState p_180656_1_, IBlockReader p_180656_2_, BlockPos p_180656_3_, Direction p_180656_4_) {
      return p_180656_1_.func_177229_b(field_190963_a) && p_180656_1_.func_177229_b(field_176387_N) == p_180656_4_ ? 15 : 0;
   }

   public void func_220082_b(BlockState p_220082_1_, World p_220082_2_, BlockPos p_220082_3_, BlockState p_220082_4_, boolean p_220082_5_) {
      if (!p_220082_1_.func_203425_a(p_220082_4_.func_177230_c())) {
         if (!p_220082_2_.func_201670_d() && p_220082_1_.func_177229_b(field_190963_a) && !p_220082_2_.func_205220_G_().func_205359_a(p_220082_3_, this)) {
            BlockState blockstate = p_220082_1_.func_206870_a(field_190963_a, Boolean.valueOf(false));
            p_220082_2_.func_180501_a(p_220082_3_, blockstate, 18);
            this.func_190961_e(p_220082_2_, p_220082_3_, blockstate);
         }

      }
   }

   public void func_196243_a(BlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, BlockState p_196243_4_, boolean p_196243_5_) {
      if (!p_196243_1_.func_203425_a(p_196243_4_.func_177230_c())) {
         if (!p_196243_2_.field_72995_K && p_196243_1_.func_177229_b(field_190963_a) && p_196243_2_.func_205220_G_().func_205359_a(p_196243_3_, this)) {
            this.func_190961_e(p_196243_2_, p_196243_3_, p_196243_1_.func_206870_a(field_190963_a, Boolean.valueOf(false)));
         }

      }
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_176387_N, p_196258_1_.func_196010_d().func_176734_d().func_176734_d());
   }
}
