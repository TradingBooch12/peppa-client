package net.minecraft.block;

import com.google.common.collect.Lists;
import java.util.Queue;
import net.minecraft.block.material.Material;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.tags.FluidTags;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Direction;
import net.minecraft.util.Tuple;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class SpongeBlock extends Block {
   protected SpongeBlock(AbstractBlock.Properties p_i48325_1_) {
      super(p_i48325_1_);
   }

   public void func_220082_b(BlockState p_220082_1_, World p_220082_2_, BlockPos p_220082_3_, BlockState p_220082_4_, boolean p_220082_5_) {
      if (!p_220082_4_.func_203425_a(p_220082_1_.func_177230_c())) {
         this.func_196510_a(p_220082_2_, p_220082_3_);
      }
   }

   public void func_220069_a(BlockState p_220069_1_, World p_220069_2_, BlockPos p_220069_3_, Block p_220069_4_, BlockPos p_220069_5_, boolean p_220069_6_) {
      this.func_196510_a(p_220069_2_, p_220069_3_);
      super.func_220069_a(p_220069_1_, p_220069_2_, p_220069_3_, p_220069_4_, p_220069_5_, p_220069_6_);
   }

   protected void func_196510_a(World p_196510_1_, BlockPos p_196510_2_) {
      if (this.func_176312_d(p_196510_1_, p_196510_2_)) {
         p_196510_1_.func_180501_a(p_196510_2_, Blocks.field_196577_ad.func_176223_P(), 2);
         p_196510_1_.func_217379_c(2001, p_196510_2_, Block.func_196246_j(Blocks.field_150355_j.func_176223_P()));
      }

   }

   private boolean func_176312_d(World p_176312_1_, BlockPos p_176312_2_) {
      Queue<Tuple<BlockPos, Integer>> queue = Lists.newLinkedList();
      queue.add(new Tuple<>(p_176312_2_, 0));
      int i = 0;

      while(!queue.isEmpty()) {
         Tuple<BlockPos, Integer> tuple = queue.poll();
         BlockPos blockpos = tuple.func_76341_a();
         int j = tuple.func_76340_b();

         for(Direction direction : Direction.values()) {
            BlockPos blockpos1 = blockpos.func_177972_a(direction);
            BlockState blockstate = p_176312_1_.func_180495_p(blockpos1);
            FluidState fluidstate = p_176312_1_.func_204610_c(blockpos1);
            Material material = blockstate.func_185904_a();
            if (fluidstate.func_206884_a(FluidTags.field_206959_a)) {
               if (blockstate.func_177230_c() instanceof IBucketPickupHandler && ((IBucketPickupHandler)blockstate.func_177230_c()).func_204508_a(p_176312_1_, blockpos1, blockstate) != Fluids.field_204541_a) {
                  ++i;
                  if (j < 6) {
                     queue.add(new Tuple<>(blockpos1, j + 1));
                  }
               } else if (blockstate.func_177230_c() instanceof FlowingFluidBlock) {
                  p_176312_1_.func_180501_a(blockpos1, Blocks.field_150350_a.func_176223_P(), 3);
                  ++i;
                  if (j < 6) {
                     queue.add(new Tuple<>(blockpos1, j + 1));
                  }
               } else if (material == Material.field_203243_f || material == Material.field_204868_h) {
                  TileEntity tileentity = blockstate.func_177230_c().func_235695_q_() ? p_176312_1_.func_175625_s(blockpos1) : null;
                  func_220059_a(blockstate, p_176312_1_, blockpos1, tileentity);
                  p_176312_1_.func_180501_a(blockpos1, Blocks.field_150350_a.func_176223_P(), 3);
                  ++i;
                  if (j < 6) {
                     queue.add(new Tuple<>(blockpos1, j + 1));
                  }
               }
            }
         }

         if (i > 64) {
            break;
         }
      }

      return i > 0;
   }
}
