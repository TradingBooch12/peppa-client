package net.minecraft.block;

import net.minecraft.util.Direction;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class BreakableBlock extends Block {
   protected BreakableBlock(AbstractBlock.Properties p_i48382_1_) {
      super(p_i48382_1_);
   }

   @OnlyIn(Dist.CLIENT)
   public boolean func_200122_a(BlockState p_200122_1_, BlockState p_200122_2_, Direction p_200122_3_) {
      return p_200122_2_.func_203425_a(this) ? true : super.func_200122_a(p_200122_1_, p_200122_2_, p_200122_3_);
   }
}
