package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.container.INamedContainerProvider;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.DirectionProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.stats.Stats;
import net.minecraft.tags.ItemTags;
import net.minecraft.tileentity.LecternTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class LecternBlock extends ContainerBlock {
   public static final DirectionProperty field_220156_a = HorizontalBlock.field_185512_D;
   public static final BooleanProperty field_220157_b = BlockStateProperties.field_208194_u;
   public static final BooleanProperty field_220158_c = BlockStateProperties.field_222515_o;
   public static final VoxelShape field_220159_d = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 2.0D, 16.0D);
   public static final VoxelShape field_220160_e = Block.func_208617_a(4.0D, 2.0D, 4.0D, 12.0D, 14.0D, 12.0D);
   public static final VoxelShape field_220161_f = VoxelShapes.func_197872_a(field_220159_d, field_220160_e);
   public static final VoxelShape field_220162_g = Block.func_208617_a(0.0D, 15.0D, 0.0D, 16.0D, 15.0D, 16.0D);
   public static final VoxelShape field_220164_h = VoxelShapes.func_197872_a(field_220161_f, field_220162_g);
   public static final VoxelShape field_220165_i = VoxelShapes.func_216384_a(Block.func_208617_a(1.0D, 10.0D, 0.0D, 5.333333D, 14.0D, 16.0D), Block.func_208617_a(5.333333D, 12.0D, 0.0D, 9.666667D, 16.0D, 16.0D), Block.func_208617_a(9.666667D, 14.0D, 0.0D, 14.0D, 18.0D, 16.0D), field_220161_f);
   public static final VoxelShape field_220166_j = VoxelShapes.func_216384_a(Block.func_208617_a(0.0D, 10.0D, 1.0D, 16.0D, 14.0D, 5.333333D), Block.func_208617_a(0.0D, 12.0D, 5.333333D, 16.0D, 16.0D, 9.666667D), Block.func_208617_a(0.0D, 14.0D, 9.666667D, 16.0D, 18.0D, 14.0D), field_220161_f);
   public static final VoxelShape field_220167_k = VoxelShapes.func_216384_a(Block.func_208617_a(15.0D, 10.0D, 0.0D, 10.666667D, 14.0D, 16.0D), Block.func_208617_a(10.666667D, 12.0D, 0.0D, 6.333333D, 16.0D, 16.0D), Block.func_208617_a(6.333333D, 14.0D, 0.0D, 2.0D, 18.0D, 16.0D), field_220161_f);
   public static final VoxelShape field_220163_w = VoxelShapes.func_216384_a(Block.func_208617_a(0.0D, 10.0D, 15.0D, 16.0D, 14.0D, 10.666667D), Block.func_208617_a(0.0D, 12.0D, 10.666667D, 16.0D, 16.0D, 6.333333D), Block.func_208617_a(0.0D, 14.0D, 6.333333D, 16.0D, 18.0D, 2.0D), field_220161_f);

   protected LecternBlock(AbstractBlock.Properties p_i49979_1_) {
      super(p_i49979_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_220156_a, Direction.NORTH).func_206870_a(field_220157_b, Boolean.valueOf(false)).func_206870_a(field_220158_c, Boolean.valueOf(false)));
   }

   public BlockRenderType func_149645_b(BlockState p_149645_1_) {
      return BlockRenderType.MODEL;
   }

   public VoxelShape func_196247_c(BlockState p_196247_1_, IBlockReader p_196247_2_, BlockPos p_196247_3_) {
      return field_220161_f;
   }

   public boolean func_220074_n(BlockState p_220074_1_) {
      return true;
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      World world = p_196258_1_.func_195991_k();
      ItemStack itemstack = p_196258_1_.func_195996_i();
      CompoundNBT compoundnbt = itemstack.func_77978_p();
      PlayerEntity playerentity = p_196258_1_.func_195999_j();
      boolean flag = false;
      if (!world.field_72995_K && playerentity != null && compoundnbt != null && playerentity.func_195070_dx() && compoundnbt.func_74764_b("BlockEntityTag")) {
         CompoundNBT compoundnbt1 = compoundnbt.func_74775_l("BlockEntityTag");
         if (compoundnbt1.func_74764_b("Book")) {
            flag = true;
         }
      }

      return this.func_176223_P().func_206870_a(field_220156_a, p_196258_1_.func_195992_f().func_176734_d()).func_206870_a(field_220158_c, Boolean.valueOf(flag));
   }

   public VoxelShape func_220071_b(BlockState p_220071_1_, IBlockReader p_220071_2_, BlockPos p_220071_3_, ISelectionContext p_220071_4_) {
      return field_220164_h;
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      switch((Direction)p_220053_1_.func_177229_b(field_220156_a)) {
      case NORTH:
         return field_220166_j;
      case SOUTH:
         return field_220163_w;
      case EAST:
         return field_220167_k;
      case WEST:
         return field_220165_i;
      default:
         return field_220161_f;
      }
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_220156_a, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_220156_a)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_220156_a)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_220156_a, field_220157_b, field_220158_c);
   }

   @Nullable
   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new LecternTileEntity();
   }

   public static boolean func_220151_a(World p_220151_0_, BlockPos p_220151_1_, BlockState p_220151_2_, ItemStack p_220151_3_) {
      if (!p_220151_2_.func_177229_b(field_220158_c)) {
         if (!p_220151_0_.field_72995_K) {
            func_220148_b(p_220151_0_, p_220151_1_, p_220151_2_, p_220151_3_);
         }

         return true;
      } else {
         return false;
      }
   }

   private static void func_220148_b(World p_220148_0_, BlockPos p_220148_1_, BlockState p_220148_2_, ItemStack p_220148_3_) {
      TileEntity tileentity = p_220148_0_.func_175625_s(p_220148_1_);
      if (tileentity instanceof LecternTileEntity) {
         LecternTileEntity lecterntileentity = (LecternTileEntity)tileentity;
         lecterntileentity.func_214045_a(p_220148_3_.func_77979_a(1));
         func_220155_a(p_220148_0_, p_220148_1_, p_220148_2_, true);
         p_220148_0_.func_184133_a((PlayerEntity)null, p_220148_1_, SoundEvents.field_219618_ai, SoundCategory.BLOCKS, 1.0F, 1.0F);
      }

   }

   public static void func_220155_a(World p_220155_0_, BlockPos p_220155_1_, BlockState p_220155_2_, boolean p_220155_3_) {
      p_220155_0_.func_180501_a(p_220155_1_, p_220155_2_.func_206870_a(field_220157_b, Boolean.valueOf(false)).func_206870_a(field_220158_c, Boolean.valueOf(p_220155_3_)), 3);
      func_220153_b(p_220155_0_, p_220155_1_, p_220155_2_);
   }

   public static void func_220154_a(World p_220154_0_, BlockPos p_220154_1_, BlockState p_220154_2_) {
      func_220149_b(p_220154_0_, p_220154_1_, p_220154_2_, true);
      p_220154_0_.func_205220_G_().func_205360_a(p_220154_1_, p_220154_2_.func_177230_c(), 2);
      p_220154_0_.func_217379_c(1043, p_220154_1_, 0);
   }

   private static void func_220149_b(World p_220149_0_, BlockPos p_220149_1_, BlockState p_220149_2_, boolean p_220149_3_) {
      p_220149_0_.func_180501_a(p_220149_1_, p_220149_2_.func_206870_a(field_220157_b, Boolean.valueOf(p_220149_3_)), 3);
      func_220153_b(p_220149_0_, p_220149_1_, p_220149_2_);
   }

   private static void func_220153_b(World p_220153_0_, BlockPos p_220153_1_, BlockState p_220153_2_) {
      p_220153_0_.func_195593_d(p_220153_1_.func_177977_b(), p_220153_2_.func_177230_c());
   }

   public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
      func_220149_b(p_225534_2_, p_225534_3_, p_225534_1_, false);
   }

   public void func_196243_a(BlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, BlockState p_196243_4_, boolean p_196243_5_) {
      if (!p_196243_1_.func_203425_a(p_196243_4_.func_177230_c())) {
         if (p_196243_1_.func_177229_b(field_220158_c)) {
            this.func_220150_d(p_196243_1_, p_196243_2_, p_196243_3_);
         }

         if (p_196243_1_.func_177229_b(field_220157_b)) {
            p_196243_2_.func_195593_d(p_196243_3_.func_177977_b(), this);
         }

         super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
      }
   }

   private void func_220150_d(BlockState p_220150_1_, World p_220150_2_, BlockPos p_220150_3_) {
      TileEntity tileentity = p_220150_2_.func_175625_s(p_220150_3_);
      if (tileentity instanceof LecternTileEntity) {
         LecternTileEntity lecterntileentity = (LecternTileEntity)tileentity;
         Direction direction = p_220150_1_.func_177229_b(field_220156_a);
         ItemStack itemstack = lecterntileentity.func_214033_c().func_77946_l();
         float f = 0.25F * (float)direction.func_82601_c();
         float f1 = 0.25F * (float)direction.func_82599_e();
         ItemEntity itementity = new ItemEntity(p_220150_2_, (double)p_220150_3_.func_177958_n() + 0.5D + (double)f, (double)(p_220150_3_.func_177956_o() + 1), (double)p_220150_3_.func_177952_p() + 0.5D + (double)f1, itemstack);
         itementity.func_174869_p();
         p_220150_2_.func_217376_c(itementity);
         lecterntileentity.func_174888_l();
      }

   }

   public boolean func_149744_f(BlockState p_149744_1_) {
      return true;
   }

   public int func_180656_a(BlockState p_180656_1_, IBlockReader p_180656_2_, BlockPos p_180656_3_, Direction p_180656_4_) {
      return p_180656_1_.func_177229_b(field_220157_b) ? 15 : 0;
   }

   public int func_176211_b(BlockState p_176211_1_, IBlockReader p_176211_2_, BlockPos p_176211_3_, Direction p_176211_4_) {
      return p_176211_4_ == Direction.UP && p_176211_1_.func_177229_b(field_220157_b) ? 15 : 0;
   }

   public boolean func_149740_M(BlockState p_149740_1_) {
      return true;
   }

   public int func_180641_l(BlockState p_180641_1_, World p_180641_2_, BlockPos p_180641_3_) {
      if (p_180641_1_.func_177229_b(field_220158_c)) {
         TileEntity tileentity = p_180641_2_.func_175625_s(p_180641_3_);
         if (tileentity instanceof LecternTileEntity) {
            return ((LecternTileEntity)tileentity).func_214034_r();
         }
      }

      return 0;
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      if (p_225533_1_.func_177229_b(field_220158_c)) {
         if (!p_225533_2_.field_72995_K) {
            this.func_220152_a(p_225533_2_, p_225533_3_, p_225533_4_);
         }

         return ActionResultType.func_233537_a_(p_225533_2_.field_72995_K);
      } else {
         ItemStack itemstack = p_225533_4_.func_184586_b(p_225533_5_);
         return !itemstack.func_190926_b() && !itemstack.func_77973_b().func_206844_a(ItemTags.field_226160_P_) ? ActionResultType.CONSUME : ActionResultType.PASS;
      }
   }

   @Nullable
   public INamedContainerProvider func_220052_b(BlockState p_220052_1_, World p_220052_2_, BlockPos p_220052_3_) {
      return !p_220052_1_.func_177229_b(field_220158_c) ? null : super.func_220052_b(p_220052_1_, p_220052_2_, p_220052_3_);
   }

   private void func_220152_a(World p_220152_1_, BlockPos p_220152_2_, PlayerEntity p_220152_3_) {
      TileEntity tileentity = p_220152_1_.func_175625_s(p_220152_2_);
      if (tileentity instanceof LecternTileEntity) {
         p_220152_3_.func_213829_a((LecternTileEntity)tileentity);
         p_220152_3_.func_195066_a(Stats.field_219735_as);
      }

   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
