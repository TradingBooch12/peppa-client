package net.minecraft.block;

import java.util.Random;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.IntegerProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.GameRules;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class FarmlandBlock extends Block {
   public static final IntegerProperty field_176531_a = BlockStateProperties.field_208133_ah;
   protected static final VoxelShape field_196432_b = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 15.0D, 16.0D);

   protected FarmlandBlock(AbstractBlock.Properties p_i48400_1_) {
      super(p_i48400_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176531_a, Integer.valueOf(0)));
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_2_ == Direction.UP && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_)) {
         p_196271_4_.func_205220_G_().func_205360_a(p_196271_5_, this, 1);
      }

      return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      BlockState blockstate = p_196260_2_.func_180495_p(p_196260_3_.func_177984_a());
      return !blockstate.func_185904_a().func_76220_a() || blockstate.func_177230_c() instanceof FenceGateBlock || blockstate.func_177230_c() instanceof MovingPistonBlock;
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return !this.func_176223_P().func_196955_c(p_196258_1_.func_195991_k(), p_196258_1_.func_195995_a()) ? Blocks.field_150346_d.func_176223_P() : super.func_196258_a(p_196258_1_);
   }

   public boolean func_220074_n(BlockState p_220074_1_) {
      return true;
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196432_b;
   }

   public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
      if (!p_225534_1_.func_196955_c(p_225534_2_, p_225534_3_)) {
         func_199610_d(p_225534_1_, p_225534_2_, p_225534_3_);
      }

   }

   public void func_225542_b_(BlockState p_225542_1_, ServerWorld p_225542_2_, BlockPos p_225542_3_, Random p_225542_4_) {
      int i = p_225542_1_.func_177229_b(field_176531_a);
      if (!func_176530_e(p_225542_2_, p_225542_3_) && !p_225542_2_.func_175727_C(p_225542_3_.func_177984_a())) {
         if (i > 0) {
            p_225542_2_.func_180501_a(p_225542_3_, p_225542_1_.func_206870_a(field_176531_a, Integer.valueOf(i - 1)), 2);
         } else if (!func_176529_d(p_225542_2_, p_225542_3_)) {
            func_199610_d(p_225542_1_, p_225542_2_, p_225542_3_);
         }
      } else if (i < 7) {
         p_225542_2_.func_180501_a(p_225542_3_, p_225542_1_.func_206870_a(field_176531_a, Integer.valueOf(7)), 2);
      }

   }

   public void func_180658_a(World p_180658_1_, BlockPos p_180658_2_, Entity p_180658_3_, float p_180658_4_) {
      if (!p_180658_1_.field_72995_K && p_180658_1_.field_73012_v.nextFloat() < p_180658_4_ - 0.5F && p_180658_3_ instanceof LivingEntity && (p_180658_3_ instanceof PlayerEntity || p_180658_1_.func_82736_K().func_223586_b(GameRules.field_223599_b)) && p_180658_3_.func_213311_cf() * p_180658_3_.func_213311_cf() * p_180658_3_.func_213302_cg() > 0.512F) {
         func_199610_d(p_180658_1_.func_180495_p(p_180658_2_), p_180658_1_, p_180658_2_);
      }

      super.func_180658_a(p_180658_1_, p_180658_2_, p_180658_3_, p_180658_4_);
   }

   public static void func_199610_d(BlockState p_199610_0_, World p_199610_1_, BlockPos p_199610_2_) {
      p_199610_1_.func_175656_a(p_199610_2_, func_199601_a(p_199610_0_, Blocks.field_150346_d.func_176223_P(), p_199610_1_, p_199610_2_));
   }

   private static boolean func_176529_d(IBlockReader p_176529_0_, BlockPos p_176529_1_) {
      Block block = p_176529_0_.func_180495_p(p_176529_1_.func_177984_a()).func_177230_c();
      return block instanceof CropsBlock || block instanceof StemBlock || block instanceof AttachedStemBlock;
   }

   private static boolean func_176530_e(IWorldReader p_176530_0_, BlockPos p_176530_1_) {
      for(BlockPos blockpos : BlockPos.func_218278_a(p_176530_1_.func_177982_a(-4, 0, -4), p_176530_1_.func_177982_a(4, 1, 4))) {
         if (p_176530_0_.func_204610_c(blockpos).func_206884_a(FluidTags.field_206959_a)) {
            return true;
         }
      }

      return false;
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176531_a);
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
