package net.minecraft.block;

import java.util.Random;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class CryingObsidianBlock extends Block {
   public CryingObsidianBlock(AbstractBlock.Properties p_i241176_1_) {
      super(p_i241176_1_);
   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(BlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      if (p_180655_4_.nextInt(5) == 0) {
         Direction direction = Direction.func_239631_a_(p_180655_4_);
         if (direction != Direction.UP) {
            BlockPos blockpos = p_180655_3_.func_177972_a(direction);
            BlockState blockstate = p_180655_2_.func_180495_p(blockpos);
            if (!p_180655_1_.func_200132_m() || !blockstate.func_224755_d(p_180655_2_, blockpos, direction.func_176734_d())) {
               double d0 = direction.func_82601_c() == 0 ? p_180655_4_.nextDouble() : 0.5D + (double)direction.func_82601_c() * 0.6D;
               double d1 = direction.func_96559_d() == 0 ? p_180655_4_.nextDouble() : 0.5D + (double)direction.func_96559_d() * 0.6D;
               double d2 = direction.func_82599_e() == 0 ? p_180655_4_.nextDouble() : 0.5D + (double)direction.func_82599_e() * 0.6D;
               p_180655_2_.func_195594_a(ParticleTypes.field_239816_ap_, (double)p_180655_3_.func_177958_n() + d0, (double)p_180655_3_.func_177956_o() + d1, (double)p_180655_3_.func_177952_p() + d2, 0.0D, 0.0D, 0.0D);
            }
         }
      }
   }
}
