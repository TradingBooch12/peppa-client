package net.minecraft.block;

import java.util.Random;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.particles.RedstoneParticleData;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class RedstoneOreBlock extends Block {
   public static final BooleanProperty field_196501_a = RedstoneTorchBlock.field_196528_a;

   public RedstoneOreBlock(AbstractBlock.Properties p_i48345_1_) {
      super(p_i48345_1_);
      this.func_180632_j(this.func_176223_P().func_206870_a(field_196501_a, Boolean.valueOf(false)));
   }

   public void func_196270_a(BlockState p_196270_1_, World p_196270_2_, BlockPos p_196270_3_, PlayerEntity p_196270_4_) {
      func_196500_d(p_196270_1_, p_196270_2_, p_196270_3_);
      super.func_196270_a(p_196270_1_, p_196270_2_, p_196270_3_, p_196270_4_);
   }

   public void func_176199_a(World p_176199_1_, BlockPos p_176199_2_, Entity p_176199_3_) {
      func_196500_d(p_176199_1_.func_180495_p(p_176199_2_), p_176199_1_, p_176199_2_);
      super.func_176199_a(p_176199_1_, p_176199_2_, p_176199_3_);
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      if (p_225533_2_.field_72995_K) {
         func_180691_e(p_225533_2_, p_225533_3_);
      } else {
         func_196500_d(p_225533_1_, p_225533_2_, p_225533_3_);
      }

      ItemStack itemstack = p_225533_4_.func_184586_b(p_225533_5_);
      return itemstack.func_77973_b() instanceof BlockItem && (new BlockItemUseContext(p_225533_4_, p_225533_5_, itemstack, p_225533_6_)).func_196011_b() ? ActionResultType.PASS : ActionResultType.SUCCESS;
   }

   private static void func_196500_d(BlockState p_196500_0_, World p_196500_1_, BlockPos p_196500_2_) {
      func_180691_e(p_196500_1_, p_196500_2_);
      if (!p_196500_0_.func_177229_b(field_196501_a)) {
         p_196500_1_.func_180501_a(p_196500_2_, p_196500_0_.func_206870_a(field_196501_a, Boolean.valueOf(true)), 3);
      }

   }

   public boolean func_149653_t(BlockState p_149653_1_) {
      return p_149653_1_.func_177229_b(field_196501_a);
   }

   public void func_225542_b_(BlockState p_225542_1_, ServerWorld p_225542_2_, BlockPos p_225542_3_, Random p_225542_4_) {
      if (p_225542_1_.func_177229_b(field_196501_a)) {
         p_225542_2_.func_180501_a(p_225542_3_, p_225542_1_.func_206870_a(field_196501_a, Boolean.valueOf(false)), 3);
      }

   }

   public void func_220062_a(BlockState p_220062_1_, ServerWorld p_220062_2_, BlockPos p_220062_3_, ItemStack p_220062_4_) {
      super.func_220062_a(p_220062_1_, p_220062_2_, p_220062_3_, p_220062_4_);
      if (EnchantmentHelper.func_77506_a(Enchantments.field_185306_r, p_220062_4_) == 0) {
         int i = 1 + p_220062_2_.field_73012_v.nextInt(5);
         this.func_180637_b(p_220062_2_, p_220062_3_, i);
      }

   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(BlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      if (p_180655_1_.func_177229_b(field_196501_a)) {
         func_180691_e(p_180655_2_, p_180655_3_);
      }

   }

   private static void func_180691_e(World p_180691_0_, BlockPos p_180691_1_) {
      double d0 = 0.5625D;
      Random random = p_180691_0_.field_73012_v;

      for(Direction direction : Direction.values()) {
         BlockPos blockpos = p_180691_1_.func_177972_a(direction);
         if (!p_180691_0_.func_180495_p(blockpos).func_200015_d(p_180691_0_, blockpos)) {
            Direction.Axis direction$axis = direction.func_176740_k();
            double d1 = direction$axis == Direction.Axis.X ? 0.5D + 0.5625D * (double)direction.func_82601_c() : (double)random.nextFloat();
            double d2 = direction$axis == Direction.Axis.Y ? 0.5D + 0.5625D * (double)direction.func_96559_d() : (double)random.nextFloat();
            double d3 = direction$axis == Direction.Axis.Z ? 0.5D + 0.5625D * (double)direction.func_82599_e() : (double)random.nextFloat();
            p_180691_0_.func_195594_a(RedstoneParticleData.field_197564_a, (double)p_180691_1_.func_177958_n() + d1, (double)p_180691_1_.func_177956_o() + d2, (double)p_180691_1_.func_177952_p() + d3, 0.0D, 0.0D, 0.0D);
         }
      }

   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196501_a);
   }
}
