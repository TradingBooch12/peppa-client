package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MusicDiscItem;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.tileentity.JukeboxTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;

public class JukeboxBlock extends ContainerBlock {
   public static final BooleanProperty field_176432_a = BlockStateProperties.field_208187_n;

   protected JukeboxBlock(AbstractBlock.Properties p_i48372_1_) {
      super(p_i48372_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176432_a, Boolean.valueOf(false)));
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, BlockState p_180633_3_, @Nullable LivingEntity p_180633_4_, ItemStack p_180633_5_) {
      super.func_180633_a(p_180633_1_, p_180633_2_, p_180633_3_, p_180633_4_, p_180633_5_);
      CompoundNBT compoundnbt = p_180633_5_.func_196082_o();
      if (compoundnbt.func_74764_b("BlockEntityTag")) {
         CompoundNBT compoundnbt1 = compoundnbt.func_74775_l("BlockEntityTag");
         if (compoundnbt1.func_74764_b("RecordItem")) {
            p_180633_1_.func_180501_a(p_180633_2_, p_180633_3_.func_206870_a(field_176432_a, Boolean.valueOf(true)), 2);
         }
      }

   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      if (p_225533_1_.func_177229_b(field_176432_a)) {
         this.func_203419_a(p_225533_2_, p_225533_3_);
         p_225533_1_ = p_225533_1_.func_206870_a(field_176432_a, Boolean.valueOf(false));
         p_225533_2_.func_180501_a(p_225533_3_, p_225533_1_, 2);
         return ActionResultType.func_233537_a_(p_225533_2_.field_72995_K);
      } else {
         return ActionResultType.PASS;
      }
   }

   public void func_176431_a(IWorld p_176431_1_, BlockPos p_176431_2_, BlockState p_176431_3_, ItemStack p_176431_4_) {
      TileEntity tileentity = p_176431_1_.func_175625_s(p_176431_2_);
      if (tileentity instanceof JukeboxTileEntity) {
         ((JukeboxTileEntity)tileentity).func_195535_a(p_176431_4_.func_77946_l());
         p_176431_1_.func_180501_a(p_176431_2_, p_176431_3_.func_206870_a(field_176432_a, Boolean.valueOf(true)), 2);
      }
   }

   private void func_203419_a(World p_203419_1_, BlockPos p_203419_2_) {
      if (!p_203419_1_.field_72995_K) {
         TileEntity tileentity = p_203419_1_.func_175625_s(p_203419_2_);
         if (tileentity instanceof JukeboxTileEntity) {
            JukeboxTileEntity jukeboxtileentity = (JukeboxTileEntity)tileentity;
            ItemStack itemstack = jukeboxtileentity.func_195537_c();
            if (!itemstack.func_190926_b()) {
               p_203419_1_.func_217379_c(1010, p_203419_2_, 0);
               jukeboxtileentity.func_174888_l();
               float f = 0.7F;
               double d0 = (double)(p_203419_1_.field_73012_v.nextFloat() * 0.7F) + (double)0.15F;
               double d1 = (double)(p_203419_1_.field_73012_v.nextFloat() * 0.7F) + (double)0.060000002F + 0.6D;
               double d2 = (double)(p_203419_1_.field_73012_v.nextFloat() * 0.7F) + (double)0.15F;
               ItemStack itemstack1 = itemstack.func_77946_l();
               ItemEntity itementity = new ItemEntity(p_203419_1_, (double)p_203419_2_.func_177958_n() + d0, (double)p_203419_2_.func_177956_o() + d1, (double)p_203419_2_.func_177952_p() + d2, itemstack1);
               itementity.func_174869_p();
               p_203419_1_.func_217376_c(itementity);
            }
         }
      }
   }

   public void func_196243_a(BlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, BlockState p_196243_4_, boolean p_196243_5_) {
      if (!p_196243_1_.func_203425_a(p_196243_4_.func_177230_c())) {
         this.func_203419_a(p_196243_2_, p_196243_3_);
         super.func_196243_a(p_196243_1_, p_196243_2_, p_196243_3_, p_196243_4_, p_196243_5_);
      }
   }

   public TileEntity func_196283_a_(IBlockReader p_196283_1_) {
      return new JukeboxTileEntity();
   }

   public boolean func_149740_M(BlockState p_149740_1_) {
      return true;
   }

   public int func_180641_l(BlockState p_180641_1_, World p_180641_2_, BlockPos p_180641_3_) {
      TileEntity tileentity = p_180641_2_.func_175625_s(p_180641_3_);
      if (tileentity instanceof JukeboxTileEntity) {
         Item item = ((JukeboxTileEntity)tileentity).func_195537_c().func_77973_b();
         if (item instanceof MusicDiscItem) {
            return ((MusicDiscItem)item).func_195975_g();
         }
      }

      return 0;
   }

   public BlockRenderType func_149645_b(BlockState p_149645_1_) {
      return BlockRenderType.MODEL;
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176432_a);
   }
}
