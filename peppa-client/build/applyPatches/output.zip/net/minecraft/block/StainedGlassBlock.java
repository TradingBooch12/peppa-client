package net.minecraft.block;

import net.minecraft.item.DyeColor;

public class StainedGlassBlock extends AbstractGlassBlock implements IBeaconBeamColorProvider {
   private final DyeColor field_196458_a;

   public StainedGlassBlock(DyeColor p_i48323_1_, AbstractBlock.Properties p_i48323_2_) {
      super(p_i48323_2_);
      this.field_196458_a = p_i48323_1_;
   }

   public DyeColor func_196457_d() {
      return this.field_196458_a;
   }
}
