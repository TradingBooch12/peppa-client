package net.minecraft.block;

import java.util.Random;
import net.minecraft.fluid.Fluids;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class CoralPlantBlock extends AbstractCoralPlantBlock {
   private final Block field_212562_c;
   protected static final VoxelShape field_207800_a = Block.func_208617_a(2.0D, 0.0D, 2.0D, 14.0D, 15.0D, 14.0D);

   protected CoralPlantBlock(Block p_i49809_1_, AbstractBlock.Properties p_i49809_2_) {
      super(p_i49809_2_);
      this.field_212562_c = p_i49809_1_;
   }

   public void func_220082_b(BlockState p_220082_1_, World p_220082_2_, BlockPos p_220082_3_, BlockState p_220082_4_, boolean p_220082_5_) {
      this.func_212558_a(p_220082_1_, p_220082_2_, p_220082_3_);
   }

   public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
      if (!func_212557_b_(p_225534_1_, p_225534_2_, p_225534_3_)) {
         p_225534_2_.func_180501_a(p_225534_3_, this.field_212562_c.func_176223_P().func_206870_a(field_212560_b, Boolean.valueOf(false)), 2);
      }

   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      if (p_196271_2_ == Direction.DOWN && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_)) {
         return Blocks.field_150350_a.func_176223_P();
      } else {
         this.func_212558_a(p_196271_1_, p_196271_4_, p_196271_5_);
         if (p_196271_1_.func_177229_b(field_212560_b)) {
            p_196271_4_.func_205219_F_().func_205360_a(p_196271_5_, Fluids.field_204546_a, Fluids.field_204546_a.func_205569_a(p_196271_4_));
         }

         return super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      }
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_207800_a;
   }
}
