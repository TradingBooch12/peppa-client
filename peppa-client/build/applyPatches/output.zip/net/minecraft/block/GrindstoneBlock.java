package net.minecraft.block;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.container.GrindstoneContainer;
import net.minecraft.inventory.container.INamedContainerProvider;
import net.minecraft.inventory.container.SimpleNamedContainerProvider;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.AttachFace;
import net.minecraft.stats.Stats;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.Hand;
import net.minecraft.util.IWorldPosCallable;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;

public class GrindstoneBlock extends HorizontalFaceBlock {
   public static final VoxelShape field_220238_a = Block.func_208617_a(2.0D, 0.0D, 6.0D, 4.0D, 7.0D, 10.0D);
   public static final VoxelShape field_220239_b = Block.func_208617_a(12.0D, 0.0D, 6.0D, 14.0D, 7.0D, 10.0D);
   public static final VoxelShape field_220240_c = Block.func_208617_a(2.0D, 7.0D, 5.0D, 4.0D, 13.0D, 11.0D);
   public static final VoxelShape field_220241_d = Block.func_208617_a(12.0D, 7.0D, 5.0D, 14.0D, 13.0D, 11.0D);
   public static final VoxelShape field_220242_e = VoxelShapes.func_197872_a(field_220238_a, field_220240_c);
   public static final VoxelShape field_220243_f = VoxelShapes.func_197872_a(field_220239_b, field_220241_d);
   public static final VoxelShape field_220244_g = VoxelShapes.func_197872_a(field_220242_e, field_220243_f);
   public static final VoxelShape field_220245_h = VoxelShapes.func_197872_a(field_220244_g, Block.func_208617_a(4.0D, 4.0D, 2.0D, 12.0D, 16.0D, 14.0D));
   public static final VoxelShape field_220246_i = Block.func_208617_a(6.0D, 0.0D, 2.0D, 10.0D, 7.0D, 4.0D);
   public static final VoxelShape field_220247_j = Block.func_208617_a(6.0D, 0.0D, 12.0D, 10.0D, 7.0D, 14.0D);
   public static final VoxelShape field_220248_k = Block.func_208617_a(5.0D, 7.0D, 2.0D, 11.0D, 13.0D, 4.0D);
   public static final VoxelShape field_220249_w = Block.func_208617_a(5.0D, 7.0D, 12.0D, 11.0D, 13.0D, 14.0D);
   public static final VoxelShape field_220250_x = VoxelShapes.func_197872_a(field_220246_i, field_220248_k);
   public static final VoxelShape field_220251_y = VoxelShapes.func_197872_a(field_220247_j, field_220249_w);
   public static final VoxelShape field_220252_z = VoxelShapes.func_197872_a(field_220250_x, field_220251_y);
   public static final VoxelShape field_220213_A = VoxelShapes.func_197872_a(field_220252_z, Block.func_208617_a(2.0D, 4.0D, 4.0D, 14.0D, 16.0D, 12.0D));
   public static final VoxelShape field_220214_B = Block.func_208617_a(2.0D, 6.0D, 0.0D, 4.0D, 10.0D, 7.0D);
   public static final VoxelShape field_220215_D = Block.func_208617_a(12.0D, 6.0D, 0.0D, 14.0D, 10.0D, 7.0D);
   public static final VoxelShape field_220216_E = Block.func_208617_a(2.0D, 5.0D, 7.0D, 4.0D, 11.0D, 13.0D);
   public static final VoxelShape field_220217_F = Block.func_208617_a(12.0D, 5.0D, 7.0D, 14.0D, 11.0D, 13.0D);
   public static final VoxelShape field_220218_G = VoxelShapes.func_197872_a(field_220214_B, field_220216_E);
   public static final VoxelShape field_220219_H = VoxelShapes.func_197872_a(field_220215_D, field_220217_F);
   public static final VoxelShape field_220220_I = VoxelShapes.func_197872_a(field_220218_G, field_220219_H);
   public static final VoxelShape field_220221_J = VoxelShapes.func_197872_a(field_220220_I, Block.func_208617_a(4.0D, 2.0D, 4.0D, 12.0D, 14.0D, 16.0D));
   public static final VoxelShape field_220222_K = Block.func_208617_a(2.0D, 6.0D, 7.0D, 4.0D, 10.0D, 16.0D);
   public static final VoxelShape field_220223_L = Block.func_208617_a(12.0D, 6.0D, 7.0D, 14.0D, 10.0D, 16.0D);
   public static final VoxelShape field_220224_M = Block.func_208617_a(2.0D, 5.0D, 3.0D, 4.0D, 11.0D, 9.0D);
   public static final VoxelShape field_220225_N = Block.func_208617_a(12.0D, 5.0D, 3.0D, 14.0D, 11.0D, 9.0D);
   public static final VoxelShape field_220226_O = VoxelShapes.func_197872_a(field_220222_K, field_220224_M);
   public static final VoxelShape field_220227_P = VoxelShapes.func_197872_a(field_220223_L, field_220225_N);
   public static final VoxelShape field_220228_Q = VoxelShapes.func_197872_a(field_220226_O, field_220227_P);
   public static final VoxelShape field_220229_R = VoxelShapes.func_197872_a(field_220228_Q, Block.func_208617_a(4.0D, 2.0D, 0.0D, 12.0D, 14.0D, 12.0D));
   public static final VoxelShape field_220230_S = Block.func_208617_a(7.0D, 6.0D, 2.0D, 16.0D, 10.0D, 4.0D);
   public static final VoxelShape field_220231_T = Block.func_208617_a(7.0D, 6.0D, 12.0D, 16.0D, 10.0D, 14.0D);
   public static final VoxelShape field_220232_U = Block.func_208617_a(3.0D, 5.0D, 2.0D, 9.0D, 11.0D, 4.0D);
   public static final VoxelShape field_220233_V = Block.func_208617_a(3.0D, 5.0D, 12.0D, 9.0D, 11.0D, 14.0D);
   public static final VoxelShape field_220234_W = VoxelShapes.func_197872_a(field_220230_S, field_220232_U);
   public static final VoxelShape field_220235_X = VoxelShapes.func_197872_a(field_220231_T, field_220233_V);
   public static final VoxelShape field_220236_Y = VoxelShapes.func_197872_a(field_220234_W, field_220235_X);
   public static final VoxelShape field_220237_Z = VoxelShapes.func_197872_a(field_220236_Y, Block.func_208617_a(0.0D, 2.0D, 4.0D, 12.0D, 14.0D, 12.0D));
   public static final VoxelShape field_220188_aa = Block.func_208617_a(0.0D, 6.0D, 2.0D, 9.0D, 10.0D, 4.0D);
   public static final VoxelShape field_220189_ab = Block.func_208617_a(0.0D, 6.0D, 12.0D, 9.0D, 10.0D, 14.0D);
   public static final VoxelShape field_220190_ac = Block.func_208617_a(7.0D, 5.0D, 2.0D, 13.0D, 11.0D, 4.0D);
   public static final VoxelShape field_220191_ad = Block.func_208617_a(7.0D, 5.0D, 12.0D, 13.0D, 11.0D, 14.0D);
   public static final VoxelShape field_220192_ae = VoxelShapes.func_197872_a(field_220188_aa, field_220190_ac);
   public static final VoxelShape field_220193_af = VoxelShapes.func_197872_a(field_220189_ab, field_220191_ad);
   public static final VoxelShape field_220194_ag = VoxelShapes.func_197872_a(field_220192_ae, field_220193_af);
   public static final VoxelShape field_220195_ah = VoxelShapes.func_197872_a(field_220194_ag, Block.func_208617_a(4.0D, 2.0D, 4.0D, 16.0D, 14.0D, 12.0D));
   public static final VoxelShape field_220196_ai = Block.func_208617_a(2.0D, 9.0D, 6.0D, 4.0D, 16.0D, 10.0D);
   public static final VoxelShape field_220197_aj = Block.func_208617_a(12.0D, 9.0D, 6.0D, 14.0D, 16.0D, 10.0D);
   public static final VoxelShape field_220198_ak = Block.func_208617_a(2.0D, 3.0D, 5.0D, 4.0D, 9.0D, 11.0D);
   public static final VoxelShape field_220199_al = Block.func_208617_a(12.0D, 3.0D, 5.0D, 14.0D, 9.0D, 11.0D);
   public static final VoxelShape field_220200_am = VoxelShapes.func_197872_a(field_220196_ai, field_220198_ak);
   public static final VoxelShape field_220201_an = VoxelShapes.func_197872_a(field_220197_aj, field_220199_al);
   public static final VoxelShape field_220202_ao = VoxelShapes.func_197872_a(field_220200_am, field_220201_an);
   public static final VoxelShape field_220203_ap = VoxelShapes.func_197872_a(field_220202_ao, Block.func_208617_a(4.0D, 0.0D, 2.0D, 12.0D, 12.0D, 14.0D));
   public static final VoxelShape field_220204_aq = Block.func_208617_a(6.0D, 9.0D, 2.0D, 10.0D, 16.0D, 4.0D);
   public static final VoxelShape field_220205_ar = Block.func_208617_a(6.0D, 9.0D, 12.0D, 10.0D, 16.0D, 14.0D);
   public static final VoxelShape field_220206_as = Block.func_208617_a(5.0D, 3.0D, 2.0D, 11.0D, 9.0D, 4.0D);
   public static final VoxelShape field_220207_at = Block.func_208617_a(5.0D, 3.0D, 12.0D, 11.0D, 9.0D, 14.0D);
   public static final VoxelShape field_220208_au = VoxelShapes.func_197872_a(field_220204_aq, field_220206_as);
   public static final VoxelShape field_220209_av = VoxelShapes.func_197872_a(field_220205_ar, field_220207_at);
   public static final VoxelShape field_220210_aw = VoxelShapes.func_197872_a(field_220208_au, field_220209_av);
   public static final VoxelShape field_220211_ax = VoxelShapes.func_197872_a(field_220210_aw, Block.func_208617_a(2.0D, 0.0D, 4.0D, 14.0D, 12.0D, 12.0D));
   private static final ITextComponent field_220212_az = new TranslationTextComponent("container.grindstone_title");

   protected GrindstoneBlock(AbstractBlock.Properties p_i49983_1_) {
      super(p_i49983_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_185512_D, Direction.NORTH).func_206870_a(field_196366_M, AttachFace.WALL));
   }

   public BlockRenderType func_149645_b(BlockState p_149645_1_) {
      return BlockRenderType.MODEL;
   }

   private VoxelShape func_220186_q(BlockState p_220186_1_) {
      Direction direction = p_220186_1_.func_177229_b(field_185512_D);
      switch((AttachFace)p_220186_1_.func_177229_b(field_196366_M)) {
      case FLOOR:
         if (direction != Direction.NORTH && direction != Direction.SOUTH) {
            return field_220213_A;
         }

         return field_220245_h;
      case WALL:
         if (direction == Direction.NORTH) {
            return field_220229_R;
         } else if (direction == Direction.SOUTH) {
            return field_220221_J;
         } else {
            if (direction == Direction.EAST) {
               return field_220195_ah;
            }

            return field_220237_Z;
         }
      case CEILING:
         if (direction != Direction.NORTH && direction != Direction.SOUTH) {
            return field_220211_ax;
         }

         return field_220203_ap;
      default:
         return field_220213_A;
      }
   }

   public VoxelShape func_220071_b(BlockState p_220071_1_, IBlockReader p_220071_2_, BlockPos p_220071_3_, ISelectionContext p_220071_4_) {
      return this.func_220186_q(p_220071_1_);
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return this.func_220186_q(p_220053_1_);
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      return true;
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      if (p_225533_2_.field_72995_K) {
         return ActionResultType.SUCCESS;
      } else {
         p_225533_4_.func_213829_a(p_225533_1_.func_215699_b(p_225533_2_, p_225533_3_));
         p_225533_4_.func_195066_a(Stats.field_226146_aB_);
         return ActionResultType.CONSUME;
      }
   }

   public INamedContainerProvider func_220052_b(BlockState p_220052_1_, World p_220052_2_, BlockPos p_220052_3_) {
      return new SimpleNamedContainerProvider((p_220187_2_, p_220187_3_, p_220187_4_) -> {
         return new GrindstoneContainer(p_220187_2_, p_220187_3_, IWorldPosCallable.func_221488_a(p_220052_2_, p_220052_3_));
      }, field_220212_az);
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_185512_D, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_185512_D)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_185512_D)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_185512_D, field_196366_M);
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
