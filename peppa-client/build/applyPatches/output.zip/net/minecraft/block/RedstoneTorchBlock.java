package net.minecraft.block;

import com.google.common.collect.Lists;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;
import net.minecraft.particles.RedstoneParticleData;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class RedstoneTorchBlock extends TorchBlock {
   public static final BooleanProperty field_196528_a = BlockStateProperties.field_208190_q;
   private static final Map<IBlockReader, List<RedstoneTorchBlock.Toggle>> field_196529_b = new WeakHashMap<>();

   protected RedstoneTorchBlock(AbstractBlock.Properties p_i48342_1_) {
      super(p_i48342_1_, RedstoneParticleData.field_197564_a);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_196528_a, Boolean.valueOf(true)));
   }

   public void func_220082_b(BlockState p_220082_1_, World p_220082_2_, BlockPos p_220082_3_, BlockState p_220082_4_, boolean p_220082_5_) {
      for(Direction direction : Direction.values()) {
         p_220082_2_.func_195593_d(p_220082_3_.func_177972_a(direction), this);
      }

   }

   public void func_196243_a(BlockState p_196243_1_, World p_196243_2_, BlockPos p_196243_3_, BlockState p_196243_4_, boolean p_196243_5_) {
      if (!p_196243_5_) {
         for(Direction direction : Direction.values()) {
            p_196243_2_.func_195593_d(p_196243_3_.func_177972_a(direction), this);
         }

      }
   }

   public int func_180656_a(BlockState p_180656_1_, IBlockReader p_180656_2_, BlockPos p_180656_3_, Direction p_180656_4_) {
      return p_180656_1_.func_177229_b(field_196528_a) && Direction.UP != p_180656_4_ ? 15 : 0;
   }

   protected boolean func_176597_g(World p_176597_1_, BlockPos p_176597_2_, BlockState p_176597_3_) {
      return p_176597_1_.func_175709_b(p_176597_2_.func_177977_b(), Direction.DOWN);
   }

   public void func_225534_a_(BlockState p_225534_1_, ServerWorld p_225534_2_, BlockPos p_225534_3_, Random p_225534_4_) {
      boolean flag = this.func_176597_g(p_225534_2_, p_225534_3_, p_225534_1_);
      List<RedstoneTorchBlock.Toggle> list = field_196529_b.get(p_225534_2_);

      while(list != null && !list.isEmpty() && p_225534_2_.func_82737_E() - (list.get(0)).field_150844_d > 60L) {
         list.remove(0);
      }

      if (p_225534_1_.func_177229_b(field_196528_a)) {
         if (flag) {
            p_225534_2_.func_180501_a(p_225534_3_, p_225534_1_.func_206870_a(field_196528_a, Boolean.valueOf(false)), 3);
            if (func_176598_a(p_225534_2_, p_225534_3_, true)) {
               p_225534_2_.func_217379_c(1502, p_225534_3_, 0);
               p_225534_2_.func_205220_G_().func_205360_a(p_225534_3_, p_225534_2_.func_180495_p(p_225534_3_).func_177230_c(), 160);
            }
         }
      } else if (!flag && !func_176598_a(p_225534_2_, p_225534_3_, false)) {
         p_225534_2_.func_180501_a(p_225534_3_, p_225534_1_.func_206870_a(field_196528_a, Boolean.valueOf(true)), 3);
      }

   }

   public void func_220069_a(BlockState p_220069_1_, World p_220069_2_, BlockPos p_220069_3_, Block p_220069_4_, BlockPos p_220069_5_, boolean p_220069_6_) {
      if (p_220069_1_.func_177229_b(field_196528_a) == this.func_176597_g(p_220069_2_, p_220069_3_, p_220069_1_) && !p_220069_2_.func_205220_G_().func_205361_b(p_220069_3_, this)) {
         p_220069_2_.func_205220_G_().func_205360_a(p_220069_3_, this, 2);
      }

   }

   public int func_176211_b(BlockState p_176211_1_, IBlockReader p_176211_2_, BlockPos p_176211_3_, Direction p_176211_4_) {
      return p_176211_4_ == Direction.DOWN ? p_176211_1_.func_185911_a(p_176211_2_, p_176211_3_, p_176211_4_) : 0;
   }

   public boolean func_149744_f(BlockState p_149744_1_) {
      return true;
   }

   @OnlyIn(Dist.CLIENT)
   public void func_180655_c(BlockState p_180655_1_, World p_180655_2_, BlockPos p_180655_3_, Random p_180655_4_) {
      if (p_180655_1_.func_177229_b(field_196528_a)) {
         double d0 = (double)p_180655_3_.func_177958_n() + 0.5D + (p_180655_4_.nextDouble() - 0.5D) * 0.2D;
         double d1 = (double)p_180655_3_.func_177956_o() + 0.7D + (p_180655_4_.nextDouble() - 0.5D) * 0.2D;
         double d2 = (double)p_180655_3_.func_177952_p() + 0.5D + (p_180655_4_.nextDouble() - 0.5D) * 0.2D;
         p_180655_2_.func_195594_a(this.field_235607_e_, d0, d1, d2, 0.0D, 0.0D, 0.0D);
      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_196528_a);
   }

   private static boolean func_176598_a(World p_176598_0_, BlockPos p_176598_1_, boolean p_176598_2_) {
      List<RedstoneTorchBlock.Toggle> list = field_196529_b.computeIfAbsent(p_176598_0_, (p_220288_0_) -> {
         return Lists.newArrayList();
      });
      if (p_176598_2_) {
         list.add(new RedstoneTorchBlock.Toggle(p_176598_1_.func_185334_h(), p_176598_0_.func_82737_E()));
      }

      int i = 0;

      for(int j = 0; j < list.size(); ++j) {
         RedstoneTorchBlock.Toggle redstonetorchblock$toggle = list.get(j);
         if (redstonetorchblock$toggle.field_180111_a.equals(p_176598_1_)) {
            ++i;
            if (i >= 8) {
               return true;
            }
         }
      }

      return false;
   }

   public static class Toggle {
      private final BlockPos field_180111_a;
      private final long field_150844_d;

      public Toggle(BlockPos p_i45688_1_, long p_i45688_2_) {
         this.field_180111_a = p_i45688_1_;
         this.field_150844_d = p_i45688_2_;
      }
   }
}
