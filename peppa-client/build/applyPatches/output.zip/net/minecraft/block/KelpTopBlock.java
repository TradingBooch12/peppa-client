package net.minecraft.block;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorld;

public class KelpTopBlock extends AbstractTopPlantBlock implements ILiquidContainer {
   protected static final VoxelShape field_207797_b = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 9.0D, 16.0D);

   protected KelpTopBlock(AbstractBlock.Properties p_i48781_1_) {
      super(p_i48781_1_, Direction.UP, field_207797_b, true, 0.14D);
   }

   protected boolean func_230334_h_(BlockState p_230334_1_) {
      return p_230334_1_.func_203425_a(Blocks.field_150355_j);
   }

   protected Block func_230330_d_() {
      return Blocks.field_203215_jy;
   }

   protected boolean func_230333_c_(Block p_230333_1_) {
      return p_230333_1_ != Blocks.field_196814_hQ;
   }

   public boolean func_204510_a(IBlockReader p_204510_1_, BlockPos p_204510_2_, BlockState p_204510_3_, Fluid p_204510_4_) {
      return false;
   }

   public boolean func_204509_a(IWorld p_204509_1_, BlockPos p_204509_2_, BlockState p_204509_3_, FluidState p_204509_4_) {
      return false;
   }

   protected int func_230332_a_(Random p_230332_1_) {
      return 1;
   }

   @Nullable
   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      FluidState fluidstate = p_196258_1_.func_195991_k().func_204610_c(p_196258_1_.func_195995_a());
      return fluidstate.func_206884_a(FluidTags.field_206959_a) && fluidstate.func_206882_g() == 8 ? super.func_196258_a(p_196258_1_) : null;
   }

   public FluidState func_204507_t(BlockState p_204507_1_) {
      return Fluids.field_204546_a.func_207204_a(false);
   }
}
