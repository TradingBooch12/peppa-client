package net.minecraft.block;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.pathfinding.PathType;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

public class DragonEggBlock extends FallingBlock {
   protected static final VoxelShape field_196444_a = Block.func_208617_a(1.0D, 0.0D, 1.0D, 15.0D, 16.0D, 15.0D);

   public DragonEggBlock(AbstractBlock.Properties p_i48411_1_) {
      super(p_i48411_1_);
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      return field_196444_a;
   }

   public ActionResultType func_225533_a_(BlockState p_225533_1_, World p_225533_2_, BlockPos p_225533_3_, PlayerEntity p_225533_4_, Hand p_225533_5_, BlockRayTraceResult p_225533_6_) {
      this.func_196443_d(p_225533_1_, p_225533_2_, p_225533_3_);
      return ActionResultType.func_233537_a_(p_225533_2_.field_72995_K);
   }

   public void func_196270_a(BlockState p_196270_1_, World p_196270_2_, BlockPos p_196270_3_, PlayerEntity p_196270_4_) {
      this.func_196443_d(p_196270_1_, p_196270_2_, p_196270_3_);
   }

   private void func_196443_d(BlockState p_196443_1_, World p_196443_2_, BlockPos p_196443_3_) {
      for(int i = 0; i < 1000; ++i) {
         BlockPos blockpos = p_196443_3_.func_177982_a(p_196443_2_.field_73012_v.nextInt(16) - p_196443_2_.field_73012_v.nextInt(16), p_196443_2_.field_73012_v.nextInt(8) - p_196443_2_.field_73012_v.nextInt(8), p_196443_2_.field_73012_v.nextInt(16) - p_196443_2_.field_73012_v.nextInt(16));
         if (p_196443_2_.func_180495_p(blockpos).func_196958_f()) {
            if (p_196443_2_.field_72995_K) {
               for(int j = 0; j < 128; ++j) {
                  double d0 = p_196443_2_.field_73012_v.nextDouble();
                  float f = (p_196443_2_.field_73012_v.nextFloat() - 0.5F) * 0.2F;
                  float f1 = (p_196443_2_.field_73012_v.nextFloat() - 0.5F) * 0.2F;
                  float f2 = (p_196443_2_.field_73012_v.nextFloat() - 0.5F) * 0.2F;
                  double d1 = MathHelper.func_219803_d(d0, (double)blockpos.func_177958_n(), (double)p_196443_3_.func_177958_n()) + (p_196443_2_.field_73012_v.nextDouble() - 0.5D) + 0.5D;
                  double d2 = MathHelper.func_219803_d(d0, (double)blockpos.func_177956_o(), (double)p_196443_3_.func_177956_o()) + p_196443_2_.field_73012_v.nextDouble() - 0.5D;
                  double d3 = MathHelper.func_219803_d(d0, (double)blockpos.func_177952_p(), (double)p_196443_3_.func_177952_p()) + (p_196443_2_.field_73012_v.nextDouble() - 0.5D) + 0.5D;
                  p_196443_2_.func_195594_a(ParticleTypes.field_197599_J, d1, d2, d3, (double)f, (double)f1, (double)f2);
               }
            } else {
               p_196443_2_.func_180501_a(blockpos, p_196443_1_, 2);
               p_196443_2_.func_217377_a(p_196443_3_, false);
            }

            return;
         }
      }

   }

   protected int func_230329_c_() {
      return 5;
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
