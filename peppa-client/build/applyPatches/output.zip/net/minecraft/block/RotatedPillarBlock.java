package net.minecraft.block;

import net.minecraft.item.BlockItemUseContext;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.util.Direction;
import net.minecraft.util.Rotation;

public class RotatedPillarBlock extends Block {
   public static final EnumProperty<Direction.Axis> field_176298_M = BlockStateProperties.field_208148_A;

   public RotatedPillarBlock(AbstractBlock.Properties p_i48339_1_) {
      super(p_i48339_1_);
      this.func_180632_j(this.func_176223_P().func_206870_a(field_176298_M, Direction.Axis.Y));
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      switch(p_185499_2_) {
      case COUNTERCLOCKWISE_90:
      case CLOCKWISE_90:
         switch((Direction.Axis)p_185499_1_.func_177229_b(field_176298_M)) {
         case X:
            return p_185499_1_.func_206870_a(field_176298_M, Direction.Axis.Z);
         case Z:
            return p_185499_1_.func_206870_a(field_176298_M, Direction.Axis.X);
         default:
            return p_185499_1_;
         }
      default:
         return p_185499_1_;
      }
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176298_M);
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_176298_M, p_196258_1_.func_196000_l().func_176740_k());
   }
}
