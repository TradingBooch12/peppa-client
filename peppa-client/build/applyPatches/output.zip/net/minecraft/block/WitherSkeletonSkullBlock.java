package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.block.material.Material;
import net.minecraft.block.pattern.BlockMaterialMatcher;
import net.minecraft.block.pattern.BlockPattern;
import net.minecraft.block.pattern.BlockPatternBuilder;
import net.minecraft.block.pattern.BlockStateMatcher;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.tags.BlockTags;
import net.minecraft.tileentity.SkullTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.CachedBlockInfo;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Difficulty;
import net.minecraft.world.World;

public class WitherSkeletonSkullBlock extends SkullBlock {
   @Nullable
   private static BlockPattern field_196300_c;
   @Nullable
   private static BlockPattern field_196301_y;

   protected WitherSkeletonSkullBlock(AbstractBlock.Properties p_i48293_1_) {
      super(SkullBlock.Types.WITHER_SKELETON, p_i48293_1_);
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, BlockState p_180633_3_, @Nullable LivingEntity p_180633_4_, ItemStack p_180633_5_) {
      super.func_180633_a(p_180633_1_, p_180633_2_, p_180633_3_, p_180633_4_, p_180633_5_);
      TileEntity tileentity = p_180633_1_.func_175625_s(p_180633_2_);
      if (tileentity instanceof SkullTileEntity) {
         func_196298_a(p_180633_1_, p_180633_2_, (SkullTileEntity)tileentity);
      }

   }

   public static void func_196298_a(World p_196298_0_, BlockPos p_196298_1_, SkullTileEntity p_196298_2_) {
      if (!p_196298_0_.field_72995_K) {
         BlockState blockstate = p_196298_2_.func_195044_w();
         boolean flag = blockstate.func_203425_a(Blocks.field_196705_eO) || blockstate.func_203425_a(Blocks.field_196704_eN);
         if (flag && p_196298_1_.func_177956_o() >= 0 && p_196298_0_.func_175659_aa() != Difficulty.PEACEFUL) {
            BlockPattern blockpattern = func_196296_d();
            BlockPattern.PatternHelper blockpattern$patternhelper = blockpattern.func_177681_a(p_196298_0_, p_196298_1_);
            if (blockpattern$patternhelper != null) {
               for(int i = 0; i < blockpattern.func_177684_c(); ++i) {
                  for(int j = 0; j < blockpattern.func_177685_b(); ++j) {
                     CachedBlockInfo cachedblockinfo = blockpattern$patternhelper.func_177670_a(i, j, 0);
                     p_196298_0_.func_180501_a(cachedblockinfo.func_177508_d(), Blocks.field_150350_a.func_176223_P(), 2);
                     p_196298_0_.func_217379_c(2001, cachedblockinfo.func_177508_d(), Block.func_196246_j(cachedblockinfo.func_177509_a()));
                  }
               }

               WitherEntity witherentity = EntityType.field_200760_az.func_200721_a(p_196298_0_);
               BlockPos blockpos = blockpattern$patternhelper.func_177670_a(1, 2, 0).func_177508_d();
               witherentity.func_70012_b((double)blockpos.func_177958_n() + 0.5D, (double)blockpos.func_177956_o() + 0.55D, (double)blockpos.func_177952_p() + 0.5D, blockpattern$patternhelper.func_177669_b().func_176740_k() == Direction.Axis.X ? 0.0F : 90.0F, 0.0F);
               witherentity.field_70761_aq = blockpattern$patternhelper.func_177669_b().func_176740_k() == Direction.Axis.X ? 0.0F : 90.0F;
               witherentity.func_82206_m();

               for(ServerPlayerEntity serverplayerentity : p_196298_0_.func_217357_a(ServerPlayerEntity.class, witherentity.func_174813_aQ().func_186662_g(50.0D))) {
                  CriteriaTriggers.field_192133_m.func_192229_a(serverplayerentity, witherentity);
               }

               p_196298_0_.func_217376_c(witherentity);

               for(int k = 0; k < blockpattern.func_177684_c(); ++k) {
                  for(int l = 0; l < blockpattern.func_177685_b(); ++l) {
                     p_196298_0_.func_230547_a_(blockpattern$patternhelper.func_177670_a(k, l, 0).func_177508_d(), Blocks.field_150350_a);
                  }
               }

            }
         }
      }
   }

   public static boolean func_196299_b(World p_196299_0_, BlockPos p_196299_1_, ItemStack p_196299_2_) {
      if (p_196299_2_.func_77973_b() == Items.field_196183_dw && p_196299_1_.func_177956_o() >= 2 && p_196299_0_.func_175659_aa() != Difficulty.PEACEFUL && !p_196299_0_.field_72995_K) {
         return func_196297_e().func_177681_a(p_196299_0_, p_196299_1_) != null;
      } else {
         return false;
      }
   }

   private static BlockPattern func_196296_d() {
      if (field_196300_c == null) {
         field_196300_c = BlockPatternBuilder.func_177660_a().func_177659_a("^^^", "###", "~#~").func_177662_a('#', (p_235639_0_) -> {
            return p_235639_0_.func_177509_a().func_235714_a_(BlockTags.field_232871_ah_);
         }).func_177662_a('^', CachedBlockInfo.func_177510_a(BlockStateMatcher.func_177638_a(Blocks.field_196705_eO).or(BlockStateMatcher.func_177638_a(Blocks.field_196704_eN)))).func_177662_a('~', CachedBlockInfo.func_177510_a(BlockMaterialMatcher.func_189886_a(Material.field_151579_a))).func_177661_b();
      }

      return field_196300_c;
   }

   private static BlockPattern func_196297_e() {
      if (field_196301_y == null) {
         field_196301_y = BlockPatternBuilder.func_177660_a().func_177659_a("   ", "###", "~#~").func_177662_a('#', (p_235638_0_) -> {
            return p_235638_0_.func_177509_a().func_235714_a_(BlockTags.field_232871_ah_);
         }).func_177662_a('~', CachedBlockInfo.func_177510_a(BlockMaterialMatcher.func_189886_a(Material.field_151579_a))).func_177661_b();
      }

      return field_196301_y;
   }
}
