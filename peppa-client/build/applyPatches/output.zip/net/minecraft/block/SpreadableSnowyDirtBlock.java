package net.minecraft.block;

import java.util.Random;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.lighting.LightEngine;
import net.minecraft.world.server.ServerWorld;

public abstract class SpreadableSnowyDirtBlock extends SnowyDirtBlock {
   protected SpreadableSnowyDirtBlock(AbstractBlock.Properties p_i48324_1_) {
      super(p_i48324_1_);
   }

   private static boolean func_220257_b(BlockState p_220257_0_, IWorldReader p_220257_1_, BlockPos p_220257_2_) {
      BlockPos blockpos = p_220257_2_.func_177984_a();
      BlockState blockstate = p_220257_1_.func_180495_p(blockpos);
      if (blockstate.func_203425_a(Blocks.field_150433_aE) && blockstate.func_177229_b(SnowBlock.field_176315_a) == 1) {
         return true;
      } else if (blockstate.func_204520_s().func_206882_g() == 8) {
         return false;
      } else {
         int i = LightEngine.func_215613_a(p_220257_1_, p_220257_0_, p_220257_2_, blockstate, blockpos, Direction.UP, blockstate.func_200016_a(p_220257_1_, blockpos));
         return i < p_220257_1_.func_201572_C();
      }
   }

   private static boolean func_220256_c(BlockState p_220256_0_, IWorldReader p_220256_1_, BlockPos p_220256_2_) {
      BlockPos blockpos = p_220256_2_.func_177984_a();
      return func_220257_b(p_220256_0_, p_220256_1_, p_220256_2_) && !p_220256_1_.func_204610_c(blockpos).func_206884_a(FluidTags.field_206959_a);
   }

   public void func_225542_b_(BlockState p_225542_1_, ServerWorld p_225542_2_, BlockPos p_225542_3_, Random p_225542_4_) {
      if (!func_220257_b(p_225542_1_, p_225542_2_, p_225542_3_)) {
         p_225542_2_.func_175656_a(p_225542_3_, Blocks.field_150346_d.func_176223_P());
      } else {
         if (p_225542_2_.func_201696_r(p_225542_3_.func_177984_a()) >= 9) {
            BlockState blockstate = this.func_176223_P();

            for(int i = 0; i < 4; ++i) {
               BlockPos blockpos = p_225542_3_.func_177982_a(p_225542_4_.nextInt(3) - 1, p_225542_4_.nextInt(5) - 3, p_225542_4_.nextInt(3) - 1);
               if (p_225542_2_.func_180495_p(blockpos).func_203425_a(Blocks.field_150346_d) && func_220256_c(blockstate, p_225542_2_, blockpos)) {
                  p_225542_2_.func_175656_a(blockpos, blockstate.func_206870_a(field_196382_a, Boolean.valueOf(p_225542_2_.func_180495_p(blockpos.func_177984_a()).func_203425_a(Blocks.field_150433_aE))));
               }
            }
         }

      }
   }
}
