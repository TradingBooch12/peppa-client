package net.minecraft.block;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.block.material.PushReaction;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.pathfinding.PathType;
import net.minecraft.state.BooleanProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.PistonType;
import net.minecraft.tileentity.PistonTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Direction;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class PistonBlock extends DirectionalBlock {
   public static final BooleanProperty field_176320_b = BlockStateProperties.field_208181_h;
   protected static final VoxelShape field_185648_b = Block.func_208617_a(0.0D, 0.0D, 0.0D, 12.0D, 16.0D, 16.0D);
   protected static final VoxelShape field_185649_c = Block.func_208617_a(4.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D);
   protected static final VoxelShape field_185650_d = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 12.0D);
   protected static final VoxelShape field_185651_e = Block.func_208617_a(0.0D, 0.0D, 4.0D, 16.0D, 16.0D, 16.0D);
   protected static final VoxelShape field_185652_f = Block.func_208617_a(0.0D, 0.0D, 0.0D, 16.0D, 12.0D, 16.0D);
   protected static final VoxelShape field_185653_g = Block.func_208617_a(0.0D, 4.0D, 0.0D, 16.0D, 16.0D, 16.0D);
   private final boolean field_150082_a;

   public PistonBlock(boolean p_i48281_1_, AbstractBlock.Properties p_i48281_2_) {
      super(p_i48281_2_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176387_N, Direction.NORTH).func_206870_a(field_176320_b, Boolean.valueOf(false)));
      this.field_150082_a = p_i48281_1_;
   }

   public VoxelShape func_220053_a(BlockState p_220053_1_, IBlockReader p_220053_2_, BlockPos p_220053_3_, ISelectionContext p_220053_4_) {
      if (p_220053_1_.func_177229_b(field_176320_b)) {
         switch((Direction)p_220053_1_.func_177229_b(field_176387_N)) {
         case DOWN:
            return field_185653_g;
         case UP:
         default:
            return field_185652_f;
         case NORTH:
            return field_185651_e;
         case SOUTH:
            return field_185650_d;
         case WEST:
            return field_185649_c;
         case EAST:
            return field_185648_b;
         }
      } else {
         return VoxelShapes.func_197868_b();
      }
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, BlockState p_180633_3_, LivingEntity p_180633_4_, ItemStack p_180633_5_) {
      if (!p_180633_1_.field_72995_K) {
         this.func_176316_e(p_180633_1_, p_180633_2_, p_180633_3_);
      }

   }

   public void func_220069_a(BlockState p_220069_1_, World p_220069_2_, BlockPos p_220069_3_, Block p_220069_4_, BlockPos p_220069_5_, boolean p_220069_6_) {
      if (!p_220069_2_.field_72995_K) {
         this.func_176316_e(p_220069_2_, p_220069_3_, p_220069_1_);
      }

   }

   public void func_220082_b(BlockState p_220082_1_, World p_220082_2_, BlockPos p_220082_3_, BlockState p_220082_4_, boolean p_220082_5_) {
      if (!p_220082_4_.func_203425_a(p_220082_1_.func_177230_c())) {
         if (!p_220082_2_.field_72995_K && p_220082_2_.func_175625_s(p_220082_3_) == null) {
            this.func_176316_e(p_220082_2_, p_220082_3_, p_220082_1_);
         }

      }
   }

   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      return this.func_176223_P().func_206870_a(field_176387_N, p_196258_1_.func_196010_d().func_176734_d()).func_206870_a(field_176320_b, Boolean.valueOf(false));
   }

   private void func_176316_e(World p_176316_1_, BlockPos p_176316_2_, BlockState p_176316_3_) {
      Direction direction = p_176316_3_.func_177229_b(field_176387_N);
      boolean flag = this.func_176318_b(p_176316_1_, p_176316_2_, direction);
      if (flag && !p_176316_3_.func_177229_b(field_176320_b)) {
         if ((new PistonBlockStructureHelper(p_176316_1_, p_176316_2_, direction, true)).func_177253_a()) {
            p_176316_1_.func_175641_c(p_176316_2_, this, 0, direction.func_176745_a());
         }
      } else if (!flag && p_176316_3_.func_177229_b(field_176320_b)) {
         BlockPos blockpos = p_176316_2_.func_177967_a(direction, 2);
         BlockState blockstate = p_176316_1_.func_180495_p(blockpos);
         int i = 1;
         if (blockstate.func_203425_a(Blocks.field_196603_bb) && blockstate.func_177229_b(field_176387_N) == direction) {
            TileEntity tileentity = p_176316_1_.func_175625_s(blockpos);
            if (tileentity instanceof PistonTileEntity) {
               PistonTileEntity pistontileentity = (PistonTileEntity)tileentity;
               if (pistontileentity.func_145868_b() && (pistontileentity.func_145860_a(0.0F) < 0.5F || p_176316_1_.func_82737_E() == pistontileentity.func_211146_k() || ((ServerWorld)p_176316_1_).func_211158_j_())) {
                  i = 2;
               }
            }
         }

         p_176316_1_.func_175641_c(p_176316_2_, this, i, direction.func_176745_a());
      }

   }

   private boolean func_176318_b(World p_176318_1_, BlockPos p_176318_2_, Direction p_176318_3_) {
      for(Direction direction : Direction.values()) {
         if (direction != p_176318_3_ && p_176318_1_.func_175709_b(p_176318_2_.func_177972_a(direction), direction)) {
            return true;
         }
      }

      if (p_176318_1_.func_175709_b(p_176318_2_, Direction.DOWN)) {
         return true;
      } else {
         BlockPos blockpos = p_176318_2_.func_177984_a();

         for(Direction direction1 : Direction.values()) {
            if (direction1 != Direction.DOWN && p_176318_1_.func_175709_b(blockpos.func_177972_a(direction1), direction1)) {
               return true;
            }
         }

         return false;
      }
   }

   public boolean func_189539_a(BlockState p_189539_1_, World p_189539_2_, BlockPos p_189539_3_, int p_189539_4_, int p_189539_5_) {
      Direction direction = p_189539_1_.func_177229_b(field_176387_N);
      if (!p_189539_2_.field_72995_K) {
         boolean flag = this.func_176318_b(p_189539_2_, p_189539_3_, direction);
         if (flag && (p_189539_4_ == 1 || p_189539_4_ == 2)) {
            p_189539_2_.func_180501_a(p_189539_3_, p_189539_1_.func_206870_a(field_176320_b, Boolean.valueOf(true)), 2);
            return false;
         }

         if (!flag && p_189539_4_ == 0) {
            return false;
         }
      }

      if (p_189539_4_ == 0) {
         if (!this.func_176319_a(p_189539_2_, p_189539_3_, direction, true)) {
            return false;
         }

         p_189539_2_.func_180501_a(p_189539_3_, p_189539_1_.func_206870_a(field_176320_b, Boolean.valueOf(true)), 67);
         p_189539_2_.func_184133_a((PlayerEntity)null, p_189539_3_, SoundEvents.field_187715_dR, SoundCategory.BLOCKS, 0.5F, p_189539_2_.field_73012_v.nextFloat() * 0.25F + 0.6F);
      } else if (p_189539_4_ == 1 || p_189539_4_ == 2) {
         TileEntity tileentity1 = p_189539_2_.func_175625_s(p_189539_3_.func_177972_a(direction));
         if (tileentity1 instanceof PistonTileEntity) {
            ((PistonTileEntity)tileentity1).func_145866_f();
         }

         BlockState blockstate = Blocks.field_196603_bb.func_176223_P().func_206870_a(MovingPistonBlock.field_196344_a, direction).func_206870_a(MovingPistonBlock.field_196345_b, this.field_150082_a ? PistonType.STICKY : PistonType.DEFAULT);
         p_189539_2_.func_180501_a(p_189539_3_, blockstate, 20);
         p_189539_2_.func_175690_a(p_189539_3_, MovingPistonBlock.func_196343_a(this.func_176223_P().func_206870_a(field_176387_N, Direction.func_82600_a(p_189539_5_ & 7)), direction, false, true));
         p_189539_2_.func_230547_a_(p_189539_3_, blockstate.func_177230_c());
         blockstate.func_235734_a_(p_189539_2_, p_189539_3_, 2);
         if (this.field_150082_a) {
            BlockPos blockpos = p_189539_3_.func_177982_a(direction.func_82601_c() * 2, direction.func_96559_d() * 2, direction.func_82599_e() * 2);
            BlockState blockstate1 = p_189539_2_.func_180495_p(blockpos);
            boolean flag1 = false;
            if (blockstate1.func_203425_a(Blocks.field_196603_bb)) {
               TileEntity tileentity = p_189539_2_.func_175625_s(blockpos);
               if (tileentity instanceof PistonTileEntity) {
                  PistonTileEntity pistontileentity = (PistonTileEntity)tileentity;
                  if (pistontileentity.func_212363_d() == direction && pistontileentity.func_145868_b()) {
                     pistontileentity.func_145866_f();
                     flag1 = true;
                  }
               }
            }

            if (!flag1) {
               if (p_189539_4_ != 1 || blockstate1.func_196958_f() || !func_185646_a(blockstate1, p_189539_2_, blockpos, direction.func_176734_d(), false, direction) || blockstate1.func_185905_o() != PushReaction.NORMAL && !blockstate1.func_203425_a(Blocks.field_150331_J) && !blockstate1.func_203425_a(Blocks.field_150320_F)) {
                  p_189539_2_.func_217377_a(p_189539_3_.func_177972_a(direction), false);
               } else {
                  this.func_176319_a(p_189539_2_, p_189539_3_, direction, false);
               }
            }
         } else {
            p_189539_2_.func_217377_a(p_189539_3_.func_177972_a(direction), false);
         }

         p_189539_2_.func_184133_a((PlayerEntity)null, p_189539_3_, SoundEvents.field_187712_dQ, SoundCategory.BLOCKS, 0.5F, p_189539_2_.field_73012_v.nextFloat() * 0.15F + 0.6F);
      }

      return true;
   }

   public static boolean func_185646_a(BlockState p_185646_0_, World p_185646_1_, BlockPos p_185646_2_, Direction p_185646_3_, boolean p_185646_4_, Direction p_185646_5_) {
      if (p_185646_2_.func_177956_o() >= 0 && p_185646_2_.func_177956_o() <= p_185646_1_.func_217301_I() - 1 && p_185646_1_.func_175723_af().func_177746_a(p_185646_2_)) {
         if (p_185646_0_.func_196958_f()) {
            return true;
         } else if (!p_185646_0_.func_203425_a(Blocks.field_150343_Z) && !p_185646_0_.func_203425_a(Blocks.field_235399_ni_) && !p_185646_0_.func_203425_a(Blocks.field_235400_nj_)) {
            if (p_185646_3_ == Direction.DOWN && p_185646_2_.func_177956_o() == 0) {
               return false;
            } else if (p_185646_3_ == Direction.UP && p_185646_2_.func_177956_o() == p_185646_1_.func_217301_I() - 1) {
               return false;
            } else {
               if (!p_185646_0_.func_203425_a(Blocks.field_150331_J) && !p_185646_0_.func_203425_a(Blocks.field_150320_F)) {
                  if (p_185646_0_.func_185887_b(p_185646_1_, p_185646_2_) == -1.0F) {
                     return false;
                  }

                  switch(p_185646_0_.func_185905_o()) {
                  case BLOCK:
                     return false;
                  case DESTROY:
                     return p_185646_4_;
                  case PUSH_ONLY:
                     return p_185646_3_ == p_185646_5_;
                  }
               } else if (p_185646_0_.func_177229_b(field_176320_b)) {
                  return false;
               }

               return !p_185646_0_.func_177230_c().func_235695_q_();
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean func_176319_a(World p_176319_1_, BlockPos p_176319_2_, Direction p_176319_3_, boolean p_176319_4_) {
      BlockPos blockpos = p_176319_2_.func_177972_a(p_176319_3_);
      if (!p_176319_4_ && p_176319_1_.func_180495_p(blockpos).func_203425_a(Blocks.field_150332_K)) {
         p_176319_1_.func_180501_a(blockpos, Blocks.field_150350_a.func_176223_P(), 20);
      }

      PistonBlockStructureHelper pistonblockstructurehelper = new PistonBlockStructureHelper(p_176319_1_, p_176319_2_, p_176319_3_, p_176319_4_);
      if (!pistonblockstructurehelper.func_177253_a()) {
         return false;
      } else {
         Map<BlockPos, BlockState> map = Maps.newHashMap();
         List<BlockPos> list = pistonblockstructurehelper.func_177254_c();
         List<BlockState> list1 = Lists.newArrayList();

         for(int i = 0; i < list.size(); ++i) {
            BlockPos blockpos1 = list.get(i);
            BlockState blockstate = p_176319_1_.func_180495_p(blockpos1);
            list1.add(blockstate);
            map.put(blockpos1, blockstate);
         }

         List<BlockPos> list2 = pistonblockstructurehelper.func_177252_d();
         BlockState[] ablockstate = new BlockState[list.size() + list2.size()];
         Direction direction = p_176319_4_ ? p_176319_3_ : p_176319_3_.func_176734_d();
         int j = 0;

         for(int k = list2.size() - 1; k >= 0; --k) {
            BlockPos blockpos2 = list2.get(k);
            BlockState blockstate1 = p_176319_1_.func_180495_p(blockpos2);
            TileEntity tileentity = blockstate1.func_177230_c().func_235695_q_() ? p_176319_1_.func_175625_s(blockpos2) : null;
            func_220059_a(blockstate1, p_176319_1_, blockpos2, tileentity);
            p_176319_1_.func_180501_a(blockpos2, Blocks.field_150350_a.func_176223_P(), 18);
            ablockstate[j++] = blockstate1;
         }

         for(int l = list.size() - 1; l >= 0; --l) {
            BlockPos blockpos3 = list.get(l);
            BlockState blockstate5 = p_176319_1_.func_180495_p(blockpos3);
            blockpos3 = blockpos3.func_177972_a(direction);
            map.remove(blockpos3);
            p_176319_1_.func_180501_a(blockpos3, Blocks.field_196603_bb.func_176223_P().func_206870_a(field_176387_N, p_176319_3_), 68);
            p_176319_1_.func_175690_a(blockpos3, MovingPistonBlock.func_196343_a(list1.get(l), p_176319_3_, p_176319_4_, false));
            ablockstate[j++] = blockstate5;
         }

         if (p_176319_4_) {
            PistonType pistontype = this.field_150082_a ? PistonType.STICKY : PistonType.DEFAULT;
            BlockState blockstate4 = Blocks.field_150332_K.func_176223_P().func_206870_a(PistonHeadBlock.field_176387_N, p_176319_3_).func_206870_a(PistonHeadBlock.field_176325_b, pistontype);
            BlockState blockstate6 = Blocks.field_196603_bb.func_176223_P().func_206870_a(MovingPistonBlock.field_196344_a, p_176319_3_).func_206870_a(MovingPistonBlock.field_196345_b, this.field_150082_a ? PistonType.STICKY : PistonType.DEFAULT);
            map.remove(blockpos);
            p_176319_1_.func_180501_a(blockpos, blockstate6, 68);
            p_176319_1_.func_175690_a(blockpos, MovingPistonBlock.func_196343_a(blockstate4, p_176319_3_, true, true));
         }

         BlockState blockstate3 = Blocks.field_150350_a.func_176223_P();

         for(BlockPos blockpos4 : map.keySet()) {
            p_176319_1_.func_180501_a(blockpos4, blockstate3, 82);
         }

         for(Entry<BlockPos, BlockState> entry : map.entrySet()) {
            BlockPos blockpos5 = entry.getKey();
            BlockState blockstate2 = entry.getValue();
            blockstate2.func_196948_b(p_176319_1_, blockpos5, 2);
            blockstate3.func_235734_a_(p_176319_1_, blockpos5, 2);
            blockstate3.func_196948_b(p_176319_1_, blockpos5, 2);
         }

         j = 0;

         for(int i1 = list2.size() - 1; i1 >= 0; --i1) {
            BlockState blockstate7 = ablockstate[j++];
            BlockPos blockpos6 = list2.get(i1);
            blockstate7.func_196948_b(p_176319_1_, blockpos6, 2);
            p_176319_1_.func_195593_d(blockpos6, blockstate7.func_177230_c());
         }

         for(int j1 = list.size() - 1; j1 >= 0; --j1) {
            p_176319_1_.func_195593_d(list.get(j1), ablockstate[j++].func_177230_c());
         }

         if (p_176319_4_) {
            p_176319_1_.func_195593_d(blockpos, Blocks.field_150332_K);
         }

         return true;
      }
   }

   public BlockState func_185499_a(BlockState p_185499_1_, Rotation p_185499_2_) {
      return p_185499_1_.func_206870_a(field_176387_N, p_185499_2_.func_185831_a(p_185499_1_.func_177229_b(field_176387_N)));
   }

   public BlockState func_185471_a(BlockState p_185471_1_, Mirror p_185471_2_) {
      return p_185471_1_.func_185907_a(p_185471_2_.func_185800_a(p_185471_1_.func_177229_b(field_176387_N)));
   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176387_N, field_176320_b);
   }

   public boolean func_220074_n(BlockState p_220074_1_) {
      return p_220074_1_.func_177229_b(field_176320_b);
   }

   public boolean func_196266_a(BlockState p_196266_1_, IBlockReader p_196266_2_, BlockPos p_196266_3_, PathType p_196266_4_) {
      return false;
   }
}
