package net.minecraft.block;

import javax.annotation.Nullable;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItemUseContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.EnumProperty;
import net.minecraft.state.StateContainer;
import net.minecraft.state.properties.BlockStateProperties;
import net.minecraft.state.properties.DoubleBlockHalf;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.IWorld;
import net.minecraft.world.IWorldReader;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

public class DoublePlantBlock extends BushBlock {
   public static final EnumProperty<DoubleBlockHalf> field_176492_b = BlockStateProperties.field_208163_P;

   public DoublePlantBlock(AbstractBlock.Properties p_i48412_1_) {
      super(p_i48412_1_);
      this.func_180632_j(this.field_176227_L.func_177621_b().func_206870_a(field_176492_b, DoubleBlockHalf.LOWER));
   }

   public BlockState func_196271_a(BlockState p_196271_1_, Direction p_196271_2_, BlockState p_196271_3_, IWorld p_196271_4_, BlockPos p_196271_5_, BlockPos p_196271_6_) {
      DoubleBlockHalf doubleblockhalf = p_196271_1_.func_177229_b(field_176492_b);
      if (p_196271_2_.func_176740_k() != Direction.Axis.Y || doubleblockhalf == DoubleBlockHalf.LOWER != (p_196271_2_ == Direction.UP) || p_196271_3_.func_203425_a(this) && p_196271_3_.func_177229_b(field_176492_b) != doubleblockhalf) {
         return doubleblockhalf == DoubleBlockHalf.LOWER && p_196271_2_ == Direction.DOWN && !p_196271_1_.func_196955_c(p_196271_4_, p_196271_5_) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(p_196271_1_, p_196271_2_, p_196271_3_, p_196271_4_, p_196271_5_, p_196271_6_);
      } else {
         return Blocks.field_150350_a.func_176223_P();
      }
   }

   @Nullable
   public BlockState func_196258_a(BlockItemUseContext p_196258_1_) {
      BlockPos blockpos = p_196258_1_.func_195995_a();
      return blockpos.func_177956_o() < 255 && p_196258_1_.func_195991_k().func_180495_p(blockpos.func_177984_a()).func_196953_a(p_196258_1_) ? super.func_196258_a(p_196258_1_) : null;
   }

   public void func_180633_a(World p_180633_1_, BlockPos p_180633_2_, BlockState p_180633_3_, LivingEntity p_180633_4_, ItemStack p_180633_5_) {
      p_180633_1_.func_180501_a(p_180633_2_.func_177984_a(), this.func_176223_P().func_206870_a(field_176492_b, DoubleBlockHalf.UPPER), 3);
   }

   public boolean func_196260_a(BlockState p_196260_1_, IWorldReader p_196260_2_, BlockPos p_196260_3_) {
      if (p_196260_1_.func_177229_b(field_176492_b) != DoubleBlockHalf.UPPER) {
         return super.func_196260_a(p_196260_1_, p_196260_2_, p_196260_3_);
      } else {
         BlockState blockstate = p_196260_2_.func_180495_p(p_196260_3_.func_177977_b());
         return blockstate.func_203425_a(this) && blockstate.func_177229_b(field_176492_b) == DoubleBlockHalf.LOWER;
      }
   }

   public void func_196390_a(IWorld p_196390_1_, BlockPos p_196390_2_, int p_196390_3_) {
      p_196390_1_.func_180501_a(p_196390_2_, this.func_176223_P().func_206870_a(field_176492_b, DoubleBlockHalf.LOWER), p_196390_3_);
      p_196390_1_.func_180501_a(p_196390_2_.func_177984_a(), this.func_176223_P().func_206870_a(field_176492_b, DoubleBlockHalf.UPPER), p_196390_3_);
   }

   public void func_176208_a(World p_176208_1_, BlockPos p_176208_2_, BlockState p_176208_3_, PlayerEntity p_176208_4_) {
      if (!p_176208_1_.field_72995_K) {
         if (p_176208_4_.func_184812_l_()) {
            func_241471_b_(p_176208_1_, p_176208_2_, p_176208_3_, p_176208_4_);
         } else {
            func_220054_a(p_176208_3_, p_176208_1_, p_176208_2_, (TileEntity)null, p_176208_4_, p_176208_4_.func_184614_ca());
         }
      }

      super.func_176208_a(p_176208_1_, p_176208_2_, p_176208_3_, p_176208_4_);
   }

   public void func_180657_a(World p_180657_1_, PlayerEntity p_180657_2_, BlockPos p_180657_3_, BlockState p_180657_4_, @Nullable TileEntity p_180657_5_, ItemStack p_180657_6_) {
      super.func_180657_a(p_180657_1_, p_180657_2_, p_180657_3_, Blocks.field_150350_a.func_176223_P(), p_180657_5_, p_180657_6_);
   }

   protected static void func_241471_b_(World p_241471_0_, BlockPos p_241471_1_, BlockState p_241471_2_, PlayerEntity p_241471_3_) {
      DoubleBlockHalf doubleblockhalf = p_241471_2_.func_177229_b(field_176492_b);
      if (doubleblockhalf == DoubleBlockHalf.UPPER) {
         BlockPos blockpos = p_241471_1_.func_177977_b();
         BlockState blockstate = p_241471_0_.func_180495_p(blockpos);
         if (blockstate.func_177230_c() == p_241471_2_.func_177230_c() && blockstate.func_177229_b(field_176492_b) == DoubleBlockHalf.LOWER) {
            p_241471_0_.func_180501_a(blockpos, Blocks.field_150350_a.func_176223_P(), 35);
            p_241471_0_.func_217378_a(p_241471_3_, 2001, blockpos, Block.func_196246_j(blockstate));
         }
      }

   }

   protected void func_206840_a(StateContainer.Builder<Block, BlockState> p_206840_1_) {
      p_206840_1_.func_206894_a(field_176492_b);
   }

   public AbstractBlock.OffsetType func_176218_Q() {
      return AbstractBlock.OffsetType.XZ;
   }

   @OnlyIn(Dist.CLIENT)
   public long func_209900_a(BlockState p_209900_1_, BlockPos p_209900_2_) {
      return MathHelper.func_180187_c(p_209900_2_.func_177958_n(), p_209900_2_.func_177979_c(p_209900_1_.func_177229_b(field_176492_b) == DoubleBlockHalf.LOWER ? 0 : 1).func_177956_o(), p_209900_2_.func_177952_p());
   }
}
