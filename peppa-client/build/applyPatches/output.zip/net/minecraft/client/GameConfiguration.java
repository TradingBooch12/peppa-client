package net.minecraft.client;

import com.mojang.authlib.properties.PropertyMap;
import java.io.File;
import java.net.Proxy;
import javax.annotation.Nullable;
import net.minecraft.client.renderer.ScreenSize;
import net.minecraft.client.resources.FolderResourceIndex;
import net.minecraft.client.resources.ResourceIndex;
import net.minecraft.util.Session;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GameConfiguration {
   public final GameConfiguration.UserInformation field_178745_a;
   public final ScreenSize field_178743_b;
   public final GameConfiguration.FolderInformation field_178744_c;
   public final GameConfiguration.GameInformation field_178741_d;
   public final GameConfiguration.ServerInformation field_178742_e;

   public GameConfiguration(GameConfiguration.UserInformation p_i51071_1_, ScreenSize p_i51071_2_, GameConfiguration.FolderInformation p_i51071_3_, GameConfiguration.GameInformation p_i51071_4_, GameConfiguration.ServerInformation p_i51071_5_) {
      this.field_178745_a = p_i51071_1_;
      this.field_178743_b = p_i51071_2_;
      this.field_178744_c = p_i51071_3_;
      this.field_178741_d = p_i51071_4_;
      this.field_178742_e = p_i51071_5_;
   }

   @OnlyIn(Dist.CLIENT)
   public static class FolderInformation {
      public final File field_178760_a;
      public final File field_178758_b;
      public final File field_178759_c;
      @Nullable
      public final String field_178757_d;

      public FolderInformation(File p_i45489_1_, File p_i45489_2_, File p_i45489_3_, @Nullable String p_i45489_4_) {
         this.field_178760_a = p_i45489_1_;
         this.field_178758_b = p_i45489_2_;
         this.field_178759_c = p_i45489_3_;
         this.field_178757_d = p_i45489_4_;
      }

      public ResourceIndex func_187052_a() {
         return (ResourceIndex)(this.field_178757_d == null ? new FolderResourceIndex(this.field_178759_c) : new ResourceIndex(this.field_178759_c, this.field_178757_d));
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class GameInformation {
      public final boolean field_178756_a;
      public final String field_178755_b;
      public final String field_187053_c;
      public final boolean field_239099_d_;
      public final boolean field_239100_e_;

      public GameInformation(boolean p_i232334_1_, String p_i232334_2_, String p_i232334_3_, boolean p_i232334_4_, boolean p_i232334_5_) {
         this.field_178756_a = p_i232334_1_;
         this.field_178755_b = p_i232334_2_;
         this.field_187053_c = p_i232334_3_;
         this.field_239099_d_ = p_i232334_4_;
         this.field_239100_e_ = p_i232334_5_;
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class ServerInformation {
      @Nullable
      public final String field_178754_a;
      public final int field_178753_b;

      public ServerInformation(@Nullable String p_i45487_1_, int p_i45487_2_) {
         this.field_178754_a = p_i45487_1_;
         this.field_178753_b = p_i45487_2_;
      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class UserInformation {
      public final Session field_178752_a;
      public final PropertyMap field_178750_b;
      public final PropertyMap field_181172_c;
      public final Proxy field_178751_c;

      public UserInformation(Session p_i46375_1_, PropertyMap p_i46375_2_, PropertyMap p_i46375_3_, Proxy p_i46375_4_) {
         this.field_178752_a = p_i46375_1_;
         this.field_178750_b = p_i46375_2_;
         this.field_181172_c = p_i46375_3_;
         this.field_178751_c = p_i46375_4_;
      }
   }
}
