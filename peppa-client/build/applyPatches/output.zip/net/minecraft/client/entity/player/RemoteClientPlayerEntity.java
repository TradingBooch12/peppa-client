package net.minecraft.client.entity.player;

import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.ITextComponent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class RemoteClientPlayerEntity extends AbstractClientPlayerEntity {
   public RemoteClientPlayerEntity(ClientWorld p_i50989_1_, GameProfile p_i50989_2_) {
      super(p_i50989_1_, p_i50989_2_);
      this.field_70138_W = 1.0F;
      this.field_70145_X = true;
   }

   public boolean func_70112_a(double p_70112_1_) {
      double d0 = this.func_174813_aQ().func_72320_b() * 10.0D;
      if (Double.isNaN(d0)) {
         d0 = 1.0D;
      }

      d0 = d0 * 64.0D * func_184183_bd();
      return p_70112_1_ < d0 * d0;
   }

   public boolean func_70097_a(DamageSource p_70097_1_, float p_70097_2_) {
      return true;
   }

   public void func_70071_h_() {
      super.func_70071_h_();
      this.func_233629_a_(this, false);
   }

   public void func_70636_d() {
      if (this.field_70716_bi > 0) {
         double d0 = this.func_226277_ct_() + (this.field_184623_bh - this.func_226277_ct_()) / (double)this.field_70716_bi;
         double d1 = this.func_226278_cu_() + (this.field_184624_bi - this.func_226278_cu_()) / (double)this.field_70716_bi;
         double d2 = this.func_226281_cx_() + (this.field_184625_bj - this.func_226281_cx_()) / (double)this.field_70716_bi;
         this.field_70177_z = (float)((double)this.field_70177_z + MathHelper.func_76138_g(this.field_184626_bk - (double)this.field_70177_z) / (double)this.field_70716_bi);
         this.field_70125_A = (float)((double)this.field_70125_A + (this.field_70709_bj - (double)this.field_70125_A) / (double)this.field_70716_bi);
         --this.field_70716_bi;
         this.func_70107_b(d0, d1, d2);
         this.func_70101_b(this.field_70177_z, this.field_70125_A);
      }

      if (this.field_208002_br > 0) {
         this.field_70759_as = (float)((double)this.field_70759_as + MathHelper.func_76138_g(this.field_208001_bq - (double)this.field_70759_as) / (double)this.field_208002_br);
         --this.field_208002_br;
      }

      this.field_71107_bF = this.field_71109_bG;
      this.func_82168_bl();
      float f1;
      if (this.field_70122_E && !this.func_233643_dh_()) {
         f1 = Math.min(0.1F, MathHelper.func_76133_a(func_213296_b(this.func_213322_ci())));
      } else {
         f1 = 0.0F;
      }

      if (!this.field_70122_E && !this.func_233643_dh_()) {
         float f2 = (float)Math.atan(-this.func_213322_ci().field_72448_b * (double)0.2F) * 15.0F;
      } else {
         float f = 0.0F;
      }

      this.field_71109_bG += (f1 - this.field_71109_bG) * 0.4F;
      this.field_70170_p.func_217381_Z().func_76320_a("push");
      this.func_85033_bc();
      this.field_70170_p.func_217381_Z().func_76319_b();
   }

   protected void func_213832_dB() {
   }

   public void func_145747_a(ITextComponent p_145747_1_, UUID p_145747_2_) {
      Minecraft minecraft = Minecraft.func_71410_x();
      if (!minecraft.func_238198_a_(p_145747_2_)) {
         minecraft.field_71456_v.func_146158_b().func_146227_a(p_145747_1_);
      }

   }
}
