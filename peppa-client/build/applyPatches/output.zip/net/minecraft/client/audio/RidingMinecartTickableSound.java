package net.minecraft.client.audio;

import net.minecraft.entity.Entity;
import net.minecraft.entity.item.minecart.AbstractMinecartEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class RidingMinecartTickableSound extends TickableSound {
   private final PlayerEntity field_147672_k;
   private final AbstractMinecartEntity field_147671_l;

   public RidingMinecartTickableSound(PlayerEntity p_i48613_1_, AbstractMinecartEntity p_i48613_2_) {
      super(SoundEvents.field_187780_dr, SoundCategory.NEUTRAL);
      this.field_147672_k = p_i48613_1_;
      this.field_147671_l = p_i48613_2_;
      this.field_147666_i = ISound.AttenuationType.NONE;
      this.field_147659_g = true;
      this.field_147665_h = 0;
      this.field_147662_b = 0.0F;
   }

   public boolean func_230510_t_() {
      return !this.field_147671_l.func_174814_R();
   }

   public boolean func_211503_n() {
      return true;
   }

   public void func_73660_a() {
      if (!this.field_147671_l.field_70128_L && this.field_147672_k.func_184218_aH() && this.field_147672_k.func_184187_bx() == this.field_147671_l) {
         float f = MathHelper.func_76133_a(Entity.func_213296_b(this.field_147671_l.func_213322_ci()));
         if ((double)f >= 0.01D) {
            this.field_147662_b = 0.0F + MathHelper.func_76131_a(f, 0.0F, 1.0F) * 0.75F;
         } else {
            this.field_147662_b = 0.0F;
         }

      } else {
         this.func_239509_o_();
      }
   }
}
