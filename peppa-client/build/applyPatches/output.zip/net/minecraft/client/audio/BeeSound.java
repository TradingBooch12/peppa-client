package net.minecraft.client.audio;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.BeeEntity;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class BeeSound extends TickableSound {
   protected final BeeEntity field_229357_o_;
   private boolean field_229358_p_;

   public BeeSound(BeeEntity p_i226060_1_, SoundEvent p_i226060_2_, SoundCategory p_i226060_3_) {
      super(p_i226060_2_, p_i226060_3_);
      this.field_229357_o_ = p_i226060_1_;
      this.field_147660_d = (double)((float)p_i226060_1_.func_226277_ct_());
      this.field_147661_e = (double)((float)p_i226060_1_.func_226278_cu_());
      this.field_147658_f = (double)((float)p_i226060_1_.func_226281_cx_());
      this.field_147659_g = true;
      this.field_147665_h = 0;
      this.field_147662_b = 0.0F;
   }

   public void func_73660_a() {
      boolean flag = this.func_225643_p_();
      if (flag && !this.func_147667_k()) {
         Minecraft.func_71410_x().func_147118_V().func_229364_a_(this.func_225642_o_());
         this.field_229358_p_ = true;
      }

      if (!this.field_229357_o_.field_70128_L && !this.field_229358_p_) {
         this.field_147660_d = (double)((float)this.field_229357_o_.func_226277_ct_());
         this.field_147661_e = (double)((float)this.field_229357_o_.func_226278_cu_());
         this.field_147658_f = (double)((float)this.field_229357_o_.func_226281_cx_());
         float f = MathHelper.func_76133_a(Entity.func_213296_b(this.field_229357_o_.func_213322_ci()));
         if ((double)f >= 0.01D) {
            this.field_147663_c = MathHelper.func_219799_g(MathHelper.func_76131_a(f, this.func_229359_s_(), this.func_229360_t_()), this.func_229359_s_(), this.func_229360_t_());
            this.field_147662_b = MathHelper.func_219799_g(MathHelper.func_76131_a(f, 0.0F, 0.5F), 0.0F, 1.2F);
         } else {
            this.field_147663_c = 0.0F;
            this.field_147662_b = 0.0F;
         }

      } else {
         this.func_239509_o_();
      }
   }

   private float func_229359_s_() {
      return this.field_229357_o_.func_70631_g_() ? 1.1F : 0.7F;
   }

   private float func_229360_t_() {
      return this.field_229357_o_.func_70631_g_() ? 1.5F : 1.1F;
   }

   public boolean func_211503_n() {
      return true;
   }

   public boolean func_230510_t_() {
      return !this.field_229357_o_.func_174814_R();
   }

   protected abstract TickableSound func_225642_o_();

   protected abstract boolean func_225643_p_();
}
