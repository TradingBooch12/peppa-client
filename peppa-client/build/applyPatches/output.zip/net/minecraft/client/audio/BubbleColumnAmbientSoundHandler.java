package net.minecraft.client.audio;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.BubbleColumnBlock;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.util.SoundEvents;
import net.minecraft.world.World;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class BubbleColumnAmbientSoundHandler implements IAmbientSoundHandler {
   private final ClientPlayerEntity field_217864_a;
   private boolean field_217865_b;
   private boolean field_217866_c = true;

   public BubbleColumnAmbientSoundHandler(ClientPlayerEntity p_i50900_1_) {
      this.field_217864_a = p_i50900_1_;
   }

   public void func_204253_a() {
      World world = this.field_217864_a.field_70170_p;
      BlockState blockstate = world.func_234939_c_(this.field_217864_a.func_174813_aQ().func_72314_b(0.0D, (double)-0.4F, 0.0D).func_186664_h(0.001D)).filter((p_239528_0_) -> {
         return p_239528_0_.func_203425_a(Blocks.field_203203_C);
      }).findFirst().orElse((BlockState)null);
      if (blockstate != null) {
         if (!this.field_217865_b && !this.field_217866_c && blockstate.func_203425_a(Blocks.field_203203_C) && !this.field_217864_a.func_175149_v()) {
            boolean flag = blockstate.func_177229_b(BubbleColumnBlock.field_203160_a);
            if (flag) {
               this.field_217864_a.func_184185_a(SoundEvents.field_203283_jd, 1.0F, 1.0F);
            } else {
               this.field_217864_a.func_184185_a(SoundEvents.field_203252_T, 1.0F, 1.0F);
            }
         }

         this.field_217865_b = true;
      } else {
         this.field_217865_b = false;
      }

      this.field_217866_c = false;
   }
}
