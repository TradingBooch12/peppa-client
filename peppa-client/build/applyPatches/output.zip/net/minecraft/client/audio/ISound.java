package net.minecraft.client.audio;

import javax.annotation.Nullable;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public interface ISound {
   ResourceLocation func_147650_b();

   @Nullable
   SoundEventAccessor func_184366_a(SoundHandler p_184366_1_);

   Sound func_184364_b();

   SoundCategory func_184365_d();

   boolean func_147657_c();

   boolean func_217861_m();

   int func_147652_d();

   float func_147653_e();

   float func_147655_f();

   double func_147649_g();

   double func_147654_h();

   double func_147651_i();

   ISound.AttenuationType func_147656_j();

   default boolean func_211503_n() {
      return false;
   }

   default boolean func_230510_t_() {
      return true;
   }

   @OnlyIn(Dist.CLIENT)
   public static enum AttenuationType {
      NONE,
      LINEAR;
   }
}
