package net.minecraft.client.audio;

import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ElytraSound extends TickableSound {
   private final ClientPlayerEntity field_189405_m;
   private int field_189406_n;

   public ElytraSound(ClientPlayerEntity p_i47113_1_) {
      super(SoundEvents.field_189426_aK, SoundCategory.PLAYERS);
      this.field_189405_m = p_i47113_1_;
      this.field_147659_g = true;
      this.field_147665_h = 0;
      this.field_147662_b = 0.1F;
   }

   public void func_73660_a() {
      ++this.field_189406_n;
      if (!this.field_189405_m.field_70128_L && (this.field_189406_n <= 20 || this.field_189405_m.func_184613_cA())) {
         this.field_147660_d = (double)((float)this.field_189405_m.func_226277_ct_());
         this.field_147661_e = (double)((float)this.field_189405_m.func_226278_cu_());
         this.field_147658_f = (double)((float)this.field_189405_m.func_226281_cx_());
         float f = (float)this.field_189405_m.func_213322_ci().func_189985_c();
         if ((double)f >= 1.0E-7D) {
            this.field_147662_b = MathHelper.func_76131_a(f / 4.0F, 0.0F, 1.0F);
         } else {
            this.field_147662_b = 0.0F;
         }

         if (this.field_189406_n < 20) {
            this.field_147662_b = 0.0F;
         } else if (this.field_189406_n < 40) {
            this.field_147662_b = (float)((double)this.field_147662_b * ((double)(this.field_189406_n - 20) / 20.0D));
         }

         float f1 = 0.8F;
         if (this.field_147662_b > 0.8F) {
            this.field_147663_c = 1.0F + (this.field_147662_b - 0.8F);
         } else {
            this.field_147663_c = 1.0F;
         }

      } else {
         this.func_239509_o_();
      }
   }
}
