package net.minecraft.client.audio;

import net.minecraft.entity.Entity;
import net.minecraft.entity.item.minecart.AbstractMinecartEntity;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class MinecartTickableSound extends TickableSound {
   private final AbstractMinecartEntity field_147670_k;
   private float field_147669_l = 0.0F;

   public MinecartTickableSound(AbstractMinecartEntity p_i48614_1_) {
      super(SoundEvents.field_187782_ds, SoundCategory.NEUTRAL);
      this.field_147670_k = p_i48614_1_;
      this.field_147659_g = true;
      this.field_147665_h = 0;
      this.field_147662_b = 0.0F;
      this.field_147660_d = (double)((float)p_i48614_1_.func_226277_ct_());
      this.field_147661_e = (double)((float)p_i48614_1_.func_226278_cu_());
      this.field_147658_f = (double)((float)p_i48614_1_.func_226281_cx_());
   }

   public boolean func_230510_t_() {
      return !this.field_147670_k.func_174814_R();
   }

   public boolean func_211503_n() {
      return true;
   }

   public void func_73660_a() {
      if (this.field_147670_k.field_70128_L) {
         this.func_239509_o_();
      } else {
         this.field_147660_d = (double)((float)this.field_147670_k.func_226277_ct_());
         this.field_147661_e = (double)((float)this.field_147670_k.func_226278_cu_());
         this.field_147658_f = (double)((float)this.field_147670_k.func_226281_cx_());
         float f = MathHelper.func_76133_a(Entity.func_213296_b(this.field_147670_k.func_213322_ci()));
         if ((double)f >= 0.01D) {
            this.field_147669_l = MathHelper.func_76131_a(this.field_147669_l + 0.0025F, 0.0F, 1.0F);
            this.field_147662_b = MathHelper.func_219799_g(MathHelper.func_76131_a(f, 0.0F, 0.5F), 0.0F, 0.7F);
         } else {
            this.field_147669_l = 0.0F;
            this.field_147662_b = 0.0F;
         }

      }
   }
}
