package net.minecraft.client.audio;

import net.minecraft.util.SoundEvent;
import net.minecraft.util.SoundEvents;

public class BackgroundMusicTracks {
   public static final BackgroundMusicSelector field_232670_a_ = new BackgroundMusicSelector(SoundEvents.field_187671_dC, 20, 600, true);
   public static final BackgroundMusicSelector field_232671_b_ = new BackgroundMusicSelector(SoundEvents.field_187792_dx, 12000, 24000, false);
   public static final BackgroundMusicSelector field_232672_c_ = new BackgroundMusicSelector(SoundEvents.field_187794_dy, 0, 0, true);
   public static final BackgroundMusicSelector field_232673_d_ = new BackgroundMusicSelector(SoundEvents.field_187796_dz, 0, 0, true);
   public static final BackgroundMusicSelector field_232674_e_ = new BackgroundMusicSelector(SoundEvents.field_187667_dA, 6000, 24000, true);
   public static final BackgroundMusicSelector field_232675_f_ = func_232677_a_(SoundEvents.field_209163_fp);
   public static final BackgroundMusicSelector field_232676_g_ = func_232677_a_(SoundEvents.field_187669_dB);

   public static BackgroundMusicSelector func_232677_a_(SoundEvent p_232677_0_) {
      return new BackgroundMusicSelector(p_232677_0_, 12000, 24000, false);
   }
}
