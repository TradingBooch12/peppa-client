package net.minecraft.client.audio;

import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.math.vector.Vector3f;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.lwjgl.openal.AL10;

@OnlyIn(Dist.CLIENT)
public class Listener {
   private float field_216471_b = 1.0F;
   private Vector3d field_237503_b_ = Vector3d.field_186680_a;

   public void func_216465_a(Vector3d p_216465_1_) {
      this.field_237503_b_ = p_216465_1_;
      AL10.alListener3f(4100, (float)p_216465_1_.field_72450_a, (float)p_216465_1_.field_72448_b, (float)p_216465_1_.field_72449_c);
   }

   public Vector3d func_237504_a_() {
      return this.field_237503_b_;
   }

   public void func_227580_a_(Vector3f p_227580_1_, Vector3f p_227580_2_) {
      AL10.alListenerfv(4111, new float[]{p_227580_1_.func_195899_a(), p_227580_1_.func_195900_b(), p_227580_1_.func_195902_c(), p_227580_2_.func_195899_a(), p_227580_2_.func_195900_b(), p_227580_2_.func_195902_c()});
   }

   public void func_216466_a(float p_216466_1_) {
      AL10.alListenerf(4106, p_216466_1_);
      this.field_216471_b = p_216466_1_;
   }

   public float func_216467_a() {
      return this.field_216471_b;
   }

   public void func_216468_b() {
      this.func_216465_a(Vector3d.field_186680_a);
      this.func_227580_a_(Vector3f.field_229182_e_, Vector3f.field_229181_d_);
   }
}
