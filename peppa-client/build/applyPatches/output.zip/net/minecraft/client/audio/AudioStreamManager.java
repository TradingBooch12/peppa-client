package net.minecraft.client.audio;

import com.google.common.collect.Maps;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import net.minecraft.resources.IResource;
import net.minecraft.resources.IResourceManager;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Util;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class AudioStreamManager {
   private final IResourceManager field_217918_a;
   private final Map<ResourceLocation, CompletableFuture<AudioStreamBuffer>> field_217919_b = Maps.newHashMap();

   public AudioStreamManager(IResourceManager p_i50893_1_) {
      this.field_217918_a = p_i50893_1_;
   }

   public CompletableFuture<AudioStreamBuffer> func_217909_a(ResourceLocation p_217909_1_) {
      return this.field_217919_b.computeIfAbsent(p_217909_1_, (p_217913_1_) -> {
         return CompletableFuture.supplyAsync(() -> {
            try (
               IResource iresource = this.field_217918_a.func_199002_a(p_217913_1_);
               InputStream inputstream = iresource.func_199027_b();
               OggAudioStream oggaudiostream = new OggAudioStream(inputstream);
            ) {
               ByteBuffer bytebuffer = oggaudiostream.func_216453_b();
               return new AudioStreamBuffer(bytebuffer, oggaudiostream.func_216454_a());
            } catch (IOException ioexception) {
               throw new CompletionException(ioexception);
            }
         }, Util.func_215072_e());
      });
   }

   public CompletableFuture<IAudioStream> func_217917_b(ResourceLocation p_217917_1_, boolean p_217917_2_) {
      return CompletableFuture.supplyAsync(() -> {
         try {
            IResource iresource = this.field_217918_a.func_199002_a(p_217917_1_);
            InputStream inputstream = iresource.func_199027_b();
            return (IAudioStream)(p_217917_2_ ? new OggAudioStreamWrapper(OggAudioStream::new, inputstream) : new OggAudioStream(inputstream));
         } catch (IOException ioexception) {
            throw new CompletionException(ioexception);
         }
      }, Util.func_215072_e());
   }

   public void func_217912_a() {
      this.field_217919_b.values().forEach((p_217910_0_) -> {
         p_217910_0_.thenAccept(AudioStreamBuffer::func_216474_b);
      });
      this.field_217919_b.clear();
   }

   public CompletableFuture<?> func_217908_a(Collection<Sound> p_217908_1_) {
      return CompletableFuture.allOf(p_217908_1_.stream().map((p_217911_1_) -> {
         return this.func_217909_a(p_217911_1_.func_188721_b());
      }).toArray((p_217916_0_) -> {
         return new CompletableFuture[p_217916_0_];
      }));
   }
}
