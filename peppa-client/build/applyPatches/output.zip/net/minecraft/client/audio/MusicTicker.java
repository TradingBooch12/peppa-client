package net.minecraft.client.audio;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class MusicTicker {
   private final Random field_147679_a = new Random();
   private final Minecraft field_147677_b;
   @Nullable
   private ISound field_147678_c;
   private int field_147676_d = 100;

   public MusicTicker(Minecraft p_i45112_1_) {
      this.field_147677_b = p_i45112_1_;
   }

   public void func_73660_a() {
      BackgroundMusicSelector backgroundmusicselector = this.field_147677_b.func_238178_U_();
      if (this.field_147678_c != null) {
         if (!backgroundmusicselector.func_232661_a_().func_187503_a().equals(this.field_147678_c.func_147650_b()) && backgroundmusicselector.func_232668_d_()) {
            this.field_147677_b.func_147118_V().func_147683_b(this.field_147678_c);
            this.field_147676_d = MathHelper.func_76136_a(this.field_147679_a, 0, backgroundmusicselector.func_232664_b_() / 2);
         }

         if (!this.field_147677_b.func_147118_V().func_215294_c(this.field_147678_c)) {
            this.field_147678_c = null;
            this.field_147676_d = Math.min(this.field_147676_d, MathHelper.func_76136_a(this.field_147679_a, backgroundmusicselector.func_232664_b_(), backgroundmusicselector.func_232666_c_()));
         }
      }

      this.field_147676_d = Math.min(this.field_147676_d, backgroundmusicselector.func_232666_c_());
      if (this.field_147678_c == null && this.field_147676_d-- <= 0) {
         this.func_239539_a_(backgroundmusicselector);
      }

   }

   public void func_239539_a_(BackgroundMusicSelector p_239539_1_) {
      this.field_147678_c = SimpleSound.func_184370_a(p_239539_1_.func_232661_a_());
      if (this.field_147678_c.func_184364_b() != SoundHandler.field_147700_a) {
         this.field_147677_b.func_147118_V().func_147682_a(this.field_147678_c);
      }

      this.field_147676_d = Integer.MAX_VALUE;
   }

   public void func_209200_a() {
      if (this.field_147678_c != null) {
         this.field_147677_b.func_147118_V().func_147683_b(this.field_147678_c);
         this.field_147678_c = null;
      }

      this.field_147676_d += 100;
   }

   public boolean func_239540_b_(BackgroundMusicSelector p_239540_1_) {
      return this.field_147678_c == null ? false : p_239540_1_.func_232661_a_().func_187503_a().equals(this.field_147678_c.func_147650_b());
   }
}
