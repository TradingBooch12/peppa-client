package net.minecraft.client.audio;

import net.minecraft.entity.monster.GuardianEntity;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class GuardianSound extends TickableSound {
   private final GuardianEntity field_174934_k;

   public GuardianSound(GuardianEntity p_i46071_1_) {
      super(SoundEvents.field_187675_cd, SoundCategory.HOSTILE);
      this.field_174934_k = p_i46071_1_;
      this.field_147666_i = ISound.AttenuationType.NONE;
      this.field_147659_g = true;
      this.field_147665_h = 0;
   }

   public boolean func_230510_t_() {
      return !this.field_174934_k.func_174814_R();
   }

   public void func_73660_a() {
      if (!this.field_174934_k.field_70128_L && this.field_174934_k.func_70638_az() == null) {
         this.field_147660_d = (double)((float)this.field_174934_k.func_226277_ct_());
         this.field_147661_e = (double)((float)this.field_174934_k.func_226278_cu_());
         this.field_147658_f = (double)((float)this.field_174934_k.func_226281_cx_());
         float f = this.field_174934_k.func_175477_p(0.0F);
         this.field_147662_b = 0.0F + 1.0F * f * f;
         this.field_147663_c = 0.7F + 0.5F * f;
      } else {
         this.func_239509_o_();
      }
   }
}
