package net.minecraft.client.audio;

import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public abstract class TickableSound extends LocatableSound implements ITickableSound {
   private boolean field_147668_j;

   protected TickableSound(SoundEvent p_i46532_1_, SoundCategory p_i46532_2_) {
      super(p_i46532_1_, p_i46532_2_);
   }

   public boolean func_147667_k() {
      return this.field_147668_j;
   }

   protected final void func_239509_o_() {
      this.field_147668_j = true;
      this.field_147659_g = false;
   }
}
