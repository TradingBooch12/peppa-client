package net.minecraft.client.audio;

import java.util.concurrent.locks.LockSupport;
import net.minecraft.util.concurrent.ThreadTaskExecutor;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class SoundEngineExecutor extends ThreadTaskExecutor<Runnable> {
   private Thread field_213179_a = this.func_213175_b();
   private volatile boolean field_213180_b;

   public SoundEngineExecutor() {
      super("Sound executor");
   }

   private Thread func_213175_b() {
      Thread thread = new Thread(this::func_213178_c);
      thread.setDaemon(true);
      thread.setName("Sound engine");
      thread.start();
      return thread;
   }

   protected Runnable func_212875_d_(Runnable p_212875_1_) {
      return p_212875_1_;
   }

   protected boolean func_212874_c_(Runnable p_212874_1_) {
      return !this.field_213180_b;
   }

   protected Thread func_213170_ax() {
      return this.field_213179_a;
   }

   private void func_213178_c() {
      while(!this.field_213180_b) {
         this.func_213161_c(() -> {
            return this.field_213180_b;
         });
      }

   }

   protected void func_223705_bi() {
      LockSupport.park("waiting for tasks");
   }

   public void func_213176_a() {
      this.field_213180_b = true;
      this.field_213179_a.interrupt();

      try {
         this.field_213179_a.join();
      } catch (InterruptedException interruptedexception) {
         Thread.currentThread().interrupt();
      }

      this.func_213159_be();
      this.field_213180_b = false;
      this.field_213179_a = this.func_213175_b();
   }
}
