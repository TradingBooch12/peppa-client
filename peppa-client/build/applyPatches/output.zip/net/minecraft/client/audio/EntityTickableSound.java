package net.minecraft.client.audio;

import net.minecraft.entity.Entity;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class EntityTickableSound extends TickableSound {
   private final Entity field_217863_o;

   public EntityTickableSound(SoundEvent p_i50898_1_, SoundCategory p_i50898_2_, Entity p_i50898_3_) {
      this(p_i50898_1_, p_i50898_2_, 1.0F, 1.0F, p_i50898_3_);
   }

   public EntityTickableSound(SoundEvent p_i50899_1_, SoundCategory p_i50899_2_, float p_i50899_3_, float p_i50899_4_, Entity p_i50899_5_) {
      super(p_i50899_1_, p_i50899_2_);
      this.field_147662_b = p_i50899_3_;
      this.field_147663_c = p_i50899_4_;
      this.field_217863_o = p_i50899_5_;
      this.field_147660_d = (double)((float)this.field_217863_o.func_226277_ct_());
      this.field_147661_e = (double)((float)this.field_217863_o.func_226278_cu_());
      this.field_147658_f = (double)((float)this.field_217863_o.func_226281_cx_());
   }

   public boolean func_230510_t_() {
      return !this.field_217863_o.func_174814_R();
   }

   public void func_73660_a() {
      if (this.field_217863_o.field_70128_L) {
         this.func_239509_o_();
      } else {
         this.field_147660_d = (double)((float)this.field_217863_o.func_226277_ct_());
         this.field_147661_e = (double)((float)this.field_217863_o.func_226278_cu_());
         this.field_147658_f = (double)((float)this.field_217863_o.func_226281_cx_());
      }
   }
}
