package net.minecraft.client.audio;

import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.SoundEvents;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class UnderwaterAmbientSounds {
   @OnlyIn(Dist.CLIENT)
   public static class SubSound extends TickableSound {
      private final ClientPlayerEntity field_204202_n;

      protected SubSound(ClientPlayerEntity p_i48884_1_, SoundEvent p_i48884_2_) {
         super(p_i48884_2_, SoundCategory.AMBIENT);
         this.field_204202_n = p_i48884_1_;
         this.field_147659_g = false;
         this.field_147665_h = 0;
         this.field_147662_b = 1.0F;
         this.field_204201_l = true;
         this.field_217862_m = true;
      }

      public void func_73660_a() {
         if (this.field_204202_n.field_70128_L || !this.field_204202_n.func_204231_K()) {
            this.func_239509_o_();
         }

      }
   }

   @OnlyIn(Dist.CLIENT)
   public static class UnderWaterSound extends TickableSound {
      private final ClientPlayerEntity field_204203_n;
      private int field_204204_o;

      public UnderWaterSound(ClientPlayerEntity p_i48883_1_) {
         super(SoundEvents.field_204323_b, SoundCategory.AMBIENT);
         this.field_204203_n = p_i48883_1_;
         this.field_147659_g = true;
         this.field_147665_h = 0;
         this.field_147662_b = 1.0F;
         this.field_204201_l = true;
         this.field_217862_m = true;
      }

      public void func_73660_a() {
         if (!this.field_204203_n.field_70128_L && this.field_204204_o >= 0) {
            if (this.field_204203_n.func_204231_K()) {
               ++this.field_204204_o;
            } else {
               this.field_204204_o -= 2;
            }

            this.field_204204_o = Math.min(this.field_204204_o, 40);
            this.field_147662_b = Math.max(0.0F, Math.min((float)this.field_204204_o / 40.0F, 1.0F));
         } else {
            this.func_239509_o_();
         }
      }
   }
}
