package net.minecraft.client;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Queues;
import com.google.gson.JsonElement;
import com.mojang.authlib.AuthenticationService;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.GameProfileRepository;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import com.mojang.authlib.minecraft.OfflineSocialInteractions;
import com.mojang.authlib.minecraft.SocialInteractionsService;
import com.mojang.authlib.properties.PropertyMap;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import com.mojang.blaze3d.matrix.MatrixStack;
import com.mojang.blaze3d.platform.PlatformDescriptors;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.datafixers.DataFixer;
import com.mojang.datafixers.util.Function4;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.Lifecycle;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.Proxy;
import java.net.SocketAddress;
import java.nio.ByteOrder;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Queue;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.client.audio.BackgroundMusicSelector;
import net.minecraft.client.audio.BackgroundMusicTracks;
import net.minecraft.client.audio.MusicTicker;
import net.minecraft.client.audio.SoundHandler;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.client.gui.DialogTexts;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.IngameGui;
import net.minecraft.client.gui.LoadingGui;
import net.minecraft.client.gui.ResourceLoadProgressGui;
import net.minecraft.client.gui.ScreenManager;
import net.minecraft.client.gui.advancements.AdvancementsScreen;
import net.minecraft.client.gui.chat.NarratorChatListener;
import net.minecraft.client.gui.fonts.FontResourceManager;
import net.minecraft.client.gui.recipebook.RecipeList;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.ConfirmBackupScreen;
import net.minecraft.client.gui.screen.ConfirmScreen;
import net.minecraft.client.gui.screen.ConnectingScreen;
import net.minecraft.client.gui.screen.DatapackFailureScreen;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.gui.screen.DirtMessageScreen;
import net.minecraft.client.gui.screen.EditWorldScreen;
import net.minecraft.client.gui.screen.IngameMenuScreen;
import net.minecraft.client.gui.screen.MainMenuScreen;
import net.minecraft.client.gui.screen.MemoryErrorScreen;
import net.minecraft.client.gui.screen.MultiplayerScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.SleepInMultiplayerScreen;
import net.minecraft.client.gui.screen.WinGameScreen;
import net.minecraft.client.gui.screen.WorkingScreen;
import net.minecraft.client.gui.screen.WorldLoadProgressScreen;
import net.minecraft.client.gui.screen.inventory.CreativeScreen;
import net.minecraft.client.gui.screen.inventory.InventoryScreen;
import net.minecraft.client.gui.social.FilterManager;
import net.minecraft.client.gui.social.SocialInteractionsScreen;
import net.minecraft.client.gui.toasts.SystemToast;
import net.minecraft.client.gui.toasts.ToastGui;
import net.minecraft.client.gui.toasts.TutorialToast;
import net.minecraft.client.multiplayer.PlayerController;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.network.login.ClientLoginNetHandler;
import net.minecraft.client.network.play.ClientPlayNetHandler;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.client.renderer.BlockModelShapes;
import net.minecraft.client.renderer.BlockRendererDispatcher;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.FirstPersonRenderer;
import net.minecraft.client.renderer.FogRenderer;
import net.minecraft.client.renderer.GPUWarning;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.IWindowEventListener;
import net.minecraft.client.renderer.ItemRenderer;
import net.minecraft.client.renderer.RenderTypeBuffers;
import net.minecraft.client.renderer.ScreenSize;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.VirtualScreen;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.color.BlockColors;
import net.minecraft.client.renderer.color.ItemColors;
import net.minecraft.client.renderer.debug.DebugRenderer;
import net.minecraft.client.renderer.entity.EntityRendererManager;
import net.minecraft.client.renderer.model.IBakedModel;
import net.minecraft.client.renderer.model.ModelManager;
import net.minecraft.client.renderer.texture.PaintingSpriteUploader;
import net.minecraft.client.renderer.texture.PotionSpriteUploader;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.tileentity.TileEntityRendererDispatcher;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.DownloadingPackFinder;
import net.minecraft.client.resources.FoliageColorReloadListener;
import net.minecraft.client.resources.GrassColorReloadListener;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.resources.LanguageManager;
import net.minecraft.client.resources.LegacyResourcePackWrapper;
import net.minecraft.client.resources.LegacyResourcePackWrapperV4;
import net.minecraft.client.resources.SkinManager;
import net.minecraft.client.settings.AmbientOcclusionStatus;
import net.minecraft.client.settings.CloudOption;
import net.minecraft.client.settings.CreativeSettings;
import net.minecraft.client.settings.GraphicsFanciness;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.client.settings.PointOfView;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.client.tutorial.Tutorial;
import net.minecraft.client.util.IMutableSearchTree;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.client.util.SearchTree;
import net.minecraft.client.util.SearchTreeManager;
import net.minecraft.client.util.SearchTreeReloadable;
import net.minecraft.client.util.Splashes;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.command.Commands;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.crash.ReportedException;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.item.ArmorStandEntity;
import net.minecraft.entity.item.BoatEntity;
import net.minecraft.entity.item.EnderCrystalEntity;
import net.minecraft.entity.item.ItemFrameEntity;
import net.minecraft.entity.item.LeashKnotEntity;
import net.minecraft.entity.item.PaintingEntity;
import net.minecraft.entity.item.minecart.AbstractMinecartEntity;
import net.minecraft.entity.player.ChatVisibility;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SkullItem;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.nbt.INBT;
import net.minecraft.nbt.ListNBT;
import net.minecraft.nbt.NBTDynamicOps;
import net.minecraft.nbt.StringNBT;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.ProtocolType;
import net.minecraft.network.handshake.client.CHandshakePacket;
import net.minecraft.network.login.client.CLoginStartPacket;
import net.minecraft.network.play.client.CPlayerDiggingPacket;
import net.minecraft.profiler.DataPoint;
import net.minecraft.profiler.EmptyProfiler;
import net.minecraft.profiler.IProfileResult;
import net.minecraft.profiler.IProfiler;
import net.minecraft.profiler.ISnooperInfo;
import net.minecraft.profiler.LongTickDetector;
import net.minecraft.profiler.Snooper;
import net.minecraft.profiler.TimeTracker;
import net.minecraft.resources.DataPackRegistries;
import net.minecraft.resources.FolderPackFinder;
import net.minecraft.resources.IPackNameDecorator;
import net.minecraft.resources.IReloadableResourceManager;
import net.minecraft.resources.IResourceManager;
import net.minecraft.resources.IResourcePack;
import net.minecraft.resources.ResourcePackInfo;
import net.minecraft.resources.ResourcePackList;
import net.minecraft.resources.ResourcePackType;
import net.minecraft.resources.ServerPackFinder;
import net.minecraft.resources.SimpleReloadableResourceManager;
import net.minecraft.resources.data.PackMetadataSection;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.management.PlayerProfileCache;
import net.minecraft.tags.ItemTags;
import net.minecraft.tileentity.SkullTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Direction;
import net.minecraft.util.FrameTimer;
import net.minecraft.util.Hand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.Session;
import net.minecraft.util.SharedConstants;
import net.minecraft.util.Timer;
import net.minecraft.util.Unit;
import net.minecraft.util.Util;
import net.minecraft.util.concurrent.RecursiveEventLoop;
import net.minecraft.util.datafix.DataFixesManager;
import net.minecraft.util.datafix.codec.DatapackCodec;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.EntityRayTraceResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.registry.Bootstrap;
import net.minecraft.util.registry.DynamicRegistries;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.registry.WorldGenSettingsExport;
import net.minecraft.util.registry.WorldSettingsImport;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.KeybindTextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.World;
import net.minecraft.world.WorldSettings;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.listener.ChainedChunkStatusListener;
import net.minecraft.world.chunk.listener.TrackingChunkStatusListener;
import net.minecraft.world.gen.settings.DimensionGeneratorSettings;
import net.minecraft.world.storage.FolderName;
import net.minecraft.world.storage.IServerConfiguration;
import net.minecraft.world.storage.SaveFormat;
import net.minecraft.world.storage.ServerWorldInfo;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@OnlyIn(Dist.CLIENT)
public class Minecraft extends RecursiveEventLoop<Runnable> implements ISnooperInfo, IWindowEventListener {
   private static Minecraft field_71432_P;
   private static final Logger field_147123_G = LogManager.getLogger();
   public static final boolean field_142025_a = Util.func_110647_a() == Util.OS.OSX;
   public static final ResourceLocation field_211502_b = new ResourceLocation("default");
   public static final ResourceLocation field_238177_c_ = new ResourceLocation("uniform");
   public static final ResourceLocation field_71464_q = new ResourceLocation("alt");
   private static final CompletableFuture<Unit> field_223714_G = CompletableFuture.completedFuture(Unit.INSTANCE);
   private static final ITextComponent field_244596_I = new TranslationTextComponent("multiplayer.socialInteractions.not_available");
   private final File field_130070_K;
   private final PropertyMap field_181038_N;
   private final TextureManager field_71446_o;
   private final DataFixer field_184131_U;
   private final VirtualScreen field_195557_T;
   private final MainWindow field_195558_d;
   private final Timer field_71428_T = new Timer(20.0F, 0L);
   private final Snooper field_71427_U = new Snooper("client", this, Util.func_211177_b());
   private final RenderTypeBuffers field_228006_P_;
   public final WorldRenderer field_71438_f;
   private final EntityRendererManager field_175616_W;
   private final ItemRenderer field_175621_X;
   private final FirstPersonRenderer field_175620_Y;
   public final ParticleManager field_71452_i;
   private final SearchTreeManager field_193995_ae = new SearchTreeManager();
   private final Session field_71449_j;
   public final FontRenderer field_71466_p;
   public final GameRenderer field_71460_t;
   public final DebugRenderer field_184132_p;
   private final AtomicReference<TrackingChunkStatusListener> field_213277_ad = new AtomicReference<>();
   public final IngameGui field_71456_v;
   public final GameSettings field_71474_y;
   private final CreativeSettings field_191950_u;
   public final MouseHelper field_71417_B;
   public final KeyboardListener field_195559_v;
   public final File field_71412_D;
   private final String field_110447_Z;
   private final String field_184130_ao;
   private final Proxy field_110453_aa;
   private final SaveFormat field_71469_aa;
   public final FrameTimer field_181542_y = new FrameTimer();
   private final boolean field_147129_ai;
   private final boolean field_71459_aj;
   private final boolean field_238175_ae_;
   private final boolean field_238176_af_;
   private final IReloadableResourceManager field_110451_am;
   private final DownloadingPackFinder field_195554_ax;
   private final ResourcePackList field_110448_aq;
   private final LanguageManager field_135017_as;
   private final BlockColors field_184127_aH;
   private final ItemColors field_184128_aI;
   private final Framebuffer field_147124_at;
   private final SoundHandler field_147127_av;
   private final MusicTicker field_147126_aw;
   private final FontResourceManager field_211501_aD;
   private final Splashes field_213271_aF;
   private final GPUWarning field_241557_ar_;
   private final MinecraftSessionService field_152355_az;
   private final SocialInteractionsService field_244734_au;
   private final SkinManager field_152350_aA;
   private final ModelManager field_175617_aL;
   private final BlockRendererDispatcher field_175618_aM;
   private final PaintingSpriteUploader field_213272_aL;
   private final PotionSpriteUploader field_213273_aM;
   private final ToastGui field_193034_aS;
   private final MinecraftGame field_213274_aO = new MinecraftGame(this);
   private final Tutorial field_193035_aW;
   private final FilterManager field_244597_aC;
   public static byte[] field_71444_a = new byte[10485760];
   @Nullable
   public PlayerController field_71442_b;
   @Nullable
   public ClientWorld field_71441_e;
   @Nullable
   public ClientPlayerEntity field_71439_g;
   @Nullable
   private IntegratedServer field_71437_Z;
   @Nullable
   private ServerData field_71422_O;
   @Nullable
   private NetworkManager field_71453_ak;
   private boolean field_71455_al;
   @Nullable
   public Entity field_175622_Z;
   @Nullable
   public Entity field_147125_j;
   @Nullable
   public RayTraceResult field_71476_x;
   private int field_71467_ac;
   protected int field_71429_W;
   private boolean field_71445_n;
   private float field_193996_ah;
   private long field_181543_z = Util.func_211178_c();
   private long field_71419_L;
   private int field_71420_M;
   public boolean field_71454_w;
   @Nullable
   public Screen field_71462_r;
   @Nullable
   public LoadingGui field_213279_p;
   private boolean field_181541_X;
   private Thread field_152352_aC;
   private volatile boolean field_71425_J = true;
   @Nullable
   private CrashReport field_71433_S;
   private static int field_71470_ab;
   public String field_71426_K = "";
   public boolean field_228004_B_;
   public boolean field_228005_C_;
   public boolean field_175612_E = true;
   private boolean field_195555_I;
   private final Queue<Runnable> field_213275_aU = Queues.newConcurrentLinkedQueue();
   @Nullable
   private CompletableFuture<Void> field_213276_aV;
   @Nullable
   private TutorialToast field_244598_aV;
   private IProfiler field_71424_I = EmptyProfiler.field_219906_a;
   private int field_238172_aT_;
   private final TimeTracker field_238173_aU_ = new TimeTracker(Util.field_211180_a, () -> {
      return this.field_238172_aT_;
   });
   @Nullable
   private IProfileResult field_238174_aV_;
   private String field_71465_an = "root";

   public Minecraft(GameConfiguration p_i45547_1_) {
      super("Client");
      field_71432_P = this;
      this.field_71412_D = p_i45547_1_.field_178744_c.field_178760_a;
      File file1 = p_i45547_1_.field_178744_c.field_178759_c;
      this.field_130070_K = p_i45547_1_.field_178744_c.field_178758_b;
      this.field_110447_Z = p_i45547_1_.field_178741_d.field_178755_b;
      this.field_184130_ao = p_i45547_1_.field_178741_d.field_187053_c;
      this.field_181038_N = p_i45547_1_.field_178745_a.field_181172_c;
      this.field_195554_ax = new DownloadingPackFinder(new File(this.field_71412_D, "server-resource-packs"), p_i45547_1_.field_178744_c.func_187052_a());
      this.field_110448_aq = new ResourcePackList(Minecraft::func_228011_a_, this.field_195554_ax, new FolderPackFinder(this.field_130070_K, IPackNameDecorator.field_232625_a_));
      this.field_110453_aa = p_i45547_1_.field_178745_a.field_178751_c;
      YggdrasilAuthenticationService yggdrasilauthenticationservice = new YggdrasilAuthenticationService(this.field_110453_aa);
      this.field_152355_az = yggdrasilauthenticationservice.createMinecraftSessionService();
      this.field_244734_au = this.func_244735_a(yggdrasilauthenticationservice, p_i45547_1_);
      this.field_71449_j = p_i45547_1_.field_178745_a.field_178752_a;
      field_147123_G.info("Setting user: {}", (Object)this.field_71449_j.func_111285_a());
      field_147123_G.debug("(Session ID is {})", (Object)this.field_71449_j.func_111286_b());
      this.field_71459_aj = p_i45547_1_.field_178741_d.field_178756_a;
      this.field_238175_ae_ = !p_i45547_1_.field_178741_d.field_239099_d_;
      this.field_238176_af_ = !p_i45547_1_.field_178741_d.field_239100_e_;
      this.field_147129_ai = func_147122_X();
      this.field_71437_Z = null;
      String s;
      int i;
      if (this.func_238216_r_() && p_i45547_1_.field_178742_e.field_178754_a != null) {
         s = p_i45547_1_.field_178742_e.field_178754_a;
         i = p_i45547_1_.field_178742_e.field_178753_b;
      } else {
         s = null;
         i = 0;
      }

      KeybindTextComponent.func_240696_a_(KeyBinding::func_193626_b);
      this.field_184131_U = DataFixesManager.func_210901_a();
      this.field_193034_aS = new ToastGui(this);
      this.field_193035_aW = new Tutorial(this);
      this.field_152352_aC = Thread.currentThread();
      this.field_71474_y = new GameSettings(this, this.field_71412_D);
      this.field_191950_u = new CreativeSettings(this.field_71412_D, this.field_184131_U);
      field_147123_G.info("Backend library: {}", (Object)RenderSystem.getBackendDescription());
      ScreenSize screensize;
      if (this.field_71474_y.field_92119_C > 0 && this.field_71474_y.field_92118_B > 0) {
         screensize = new ScreenSize(this.field_71474_y.field_92118_B, this.field_71474_y.field_92119_C, p_i45547_1_.field_178743_b.field_216496_c, p_i45547_1_.field_178743_b.field_216497_d, p_i45547_1_.field_178743_b.field_216498_e);
      } else {
         screensize = p_i45547_1_.field_178743_b;
      }

      Util.field_211180_a = RenderSystem.initBackendSystem();
      this.field_195557_T = new VirtualScreen(this);
      this.field_195558_d = this.field_195557_T.func_217626_a(screensize, this.field_71474_y.field_198019_u, this.func_230149_ax_());
      this.func_213228_a(true);

      try {
         InputStream inputstream = this.func_195541_I().func_195746_a().func_195761_a(ResourcePackType.CLIENT_RESOURCES, new ResourceLocation("icons/icon_16x16.png"));
         InputStream inputstream1 = this.func_195541_I().func_195746_a().func_195761_a(ResourcePackType.CLIENT_RESOURCES, new ResourceLocation("icons/icon_32x32.png"));
         this.field_195558_d.func_216529_a(inputstream, inputstream1);
      } catch (IOException ioexception) {
         field_147123_G.error("Couldn't set icon", (Throwable)ioexception);
      }

      this.field_195558_d.func_216526_a(this.field_71474_y.field_74350_i);
      this.field_71417_B = new MouseHelper(this);
      this.field_71417_B.func_198029_a(this.field_195558_d.func_198092_i());
      this.field_195559_v = new KeyboardListener(this);
      this.field_195559_v.func_197968_a(this.field_195558_d.func_198092_i());
      RenderSystem.initRenderer(this.field_71474_y.field_209231_W, false);
      this.field_147124_at = new Framebuffer(this.field_195558_d.func_198109_k(), this.field_195558_d.func_198091_l(), true, field_142025_a);
      this.field_147124_at.func_147604_a(0.0F, 0.0F, 0.0F, 0.0F);
      this.field_110451_am = new SimpleReloadableResourceManager(ResourcePackType.CLIENT_RESOURCES);
      this.field_110448_aq.func_198983_a();
      this.field_71474_y.func_198017_a(this.field_110448_aq);
      this.field_135017_as = new LanguageManager(this.field_71474_y.field_74363_ab);
      this.field_110451_am.func_219534_a(this.field_135017_as);
      this.field_71446_o = new TextureManager(this.field_110451_am);
      this.field_110451_am.func_219534_a(this.field_71446_o);
      this.field_152350_aA = new SkinManager(this.field_71446_o, new File(file1, "skins"), this.field_152355_az);
      this.field_71469_aa = new SaveFormat(this.field_71412_D.toPath().resolve("saves"), this.field_71412_D.toPath().resolve("backups"), this.field_184131_U);
      this.field_147127_av = new SoundHandler(this.field_110451_am, this.field_71474_y);
      this.field_110451_am.func_219534_a(this.field_147127_av);
      this.field_213271_aF = new Splashes(this.field_71449_j);
      this.field_110451_am.func_219534_a(this.field_213271_aF);
      this.field_147126_aw = new MusicTicker(this);
      this.field_211501_aD = new FontResourceManager(this.field_71446_o);
      this.field_71466_p = this.field_211501_aD.func_238548_a_();
      this.field_110451_am.func_219534_a(this.field_211501_aD.func_216884_a());
      this.func_238209_b_(this.func_211821_e());
      this.field_110451_am.func_219534_a(new GrassColorReloadListener());
      this.field_110451_am.func_219534_a(new FoliageColorReloadListener());
      this.field_195558_d.func_227799_a_("Startup");
      RenderSystem.setupDefaultState(0, 0, this.field_195558_d.func_198109_k(), this.field_195558_d.func_198091_l());
      this.field_195558_d.func_227799_a_("Post startup");
      this.field_184127_aH = BlockColors.func_186723_a();
      this.field_184128_aI = ItemColors.func_186729_a(this.field_184127_aH);
      this.field_175617_aL = new ModelManager(this.field_71446_o, this.field_184127_aH, this.field_71474_y.field_151442_I);
      this.field_110451_am.func_219534_a(this.field_175617_aL);
      this.field_175621_X = new ItemRenderer(this.field_71446_o, this.field_175617_aL, this.field_184128_aI);
      this.field_175616_W = new EntityRendererManager(this.field_71446_o, this.field_175621_X, this.field_110451_am, this.field_71466_p, this.field_71474_y);
      this.field_175620_Y = new FirstPersonRenderer(this);
      this.field_110451_am.func_219534_a(this.field_175621_X);
      this.field_228006_P_ = new RenderTypeBuffers();
      this.field_71460_t = new GameRenderer(this, this.field_110451_am, this.field_228006_P_);
      this.field_110451_am.func_219534_a(this.field_71460_t);
      this.field_244597_aC = new FilterManager(this, this.field_244734_au);
      this.field_175618_aM = new BlockRendererDispatcher(this.field_175617_aL.func_174954_c(), this.field_184127_aH);
      this.field_110451_am.func_219534_a(this.field_175618_aM);
      this.field_71438_f = new WorldRenderer(this, this.field_228006_P_);
      this.field_110451_am.func_219534_a(this.field_71438_f);
      this.func_193986_ar();
      this.field_110451_am.func_219534_a(this.field_193995_ae);
      this.field_71452_i = new ParticleManager(this.field_71441_e, this.field_71446_o);
      this.field_110451_am.func_219534_a(this.field_71452_i);
      this.field_213272_aL = new PaintingSpriteUploader(this.field_71446_o);
      this.field_110451_am.func_219534_a(this.field_213272_aL);
      this.field_213273_aM = new PotionSpriteUploader(this.field_71446_o);
      this.field_110451_am.func_219534_a(this.field_213273_aM);
      this.field_241557_ar_ = new GPUWarning();
      this.field_110451_am.func_219534_a(this.field_241557_ar_);
      this.field_71456_v = new IngameGui(this);
      this.field_184132_p = new DebugRenderer(this);
      RenderSystem.setErrorCallback(this::func_195545_a);
      if (this.field_71474_y.field_74353_u && !this.field_195558_d.func_198113_j()) {
         this.field_195558_d.func_198077_g();
         this.field_71474_y.field_74353_u = this.field_195558_d.func_198113_j();
      }

      this.field_195558_d.func_216523_b(this.field_71474_y.field_74352_v);
      this.field_195558_d.func_224798_d(this.field_71474_y.field_225307_E);
      this.field_195558_d.func_227801_c_();
      this.func_213226_a();
      if (s != null) {
         this.func_147108_a(new ConnectingScreen(new MainMenuScreen(), this, s, i));
      } else {
         this.func_147108_a(new MainMenuScreen(true));
      }

      ResourceLoadProgressGui.func_212970_a(this);
      List<IResourcePack> list = this.field_110448_aq.func_232623_f_();
      this.func_213268_a(new ResourceLoadProgressGui(this, this.field_110451_am.func_219537_a(Util.func_215072_e(), this, field_223714_G, list), (p_238197_1_) -> {
         Util.func_215077_a(p_238197_1_, this::func_229988_a_, () -> {
            if (SharedConstants.field_206244_b) {
               this.func_213256_aB();
            }

         });
      }, false));
   }

   public void func_230150_b_() {
      this.field_195558_d.func_230148_b_(this.func_230149_ax_());
   }

   private String func_230149_ax_() {
      StringBuilder stringbuilder = new StringBuilder("Minecraft");
      if (this.func_230151_c_()) {
         stringbuilder.append("*");
      }

      stringbuilder.append(" ");
      stringbuilder.append(SharedConstants.func_215069_a().getName());
      ClientPlayNetHandler clientplaynethandler = this.func_147114_u();
      if (clientplaynethandler != null && clientplaynethandler.func_147298_b().func_150724_d()) {
         stringbuilder.append(" - ");
         if (this.field_71437_Z != null && !this.field_71437_Z.func_71344_c()) {
            stringbuilder.append(I18n.func_135052_a("title.singleplayer"));
         } else if (this.func_181540_al()) {
            stringbuilder.append(I18n.func_135052_a("title.multiplayer.realms"));
         } else if (this.field_71437_Z == null && (this.field_71422_O == null || !this.field_71422_O.func_181041_d())) {
            stringbuilder.append(I18n.func_135052_a("title.multiplayer.other"));
         } else {
            stringbuilder.append(I18n.func_135052_a("title.multiplayer.lan"));
         }
      }

      return stringbuilder.toString();
   }

   private SocialInteractionsService func_244735_a(YggdrasilAuthenticationService p_244735_1_, GameConfiguration p_244735_2_) {
      try {
         return p_244735_1_.createSocialInteractionsService(p_244735_2_.field_178745_a.field_178752_a.func_148254_d());
      } catch (AuthenticationException authenticationexception) {
         field_147123_G.error("Failed to verify authentication", (Throwable)authenticationexception);
         return new OfflineSocialInteractions();
      }
   }

   public boolean func_230151_c_() {
      return !"vanilla".equals(ClientBrandRetriever.getClientModName()) || Minecraft.class.getSigners() == null;
   }

   private void func_229988_a_(Throwable p_229988_1_) {
      if (this.field_110448_aq.func_232621_d_().size() > 1) {
         ITextComponent itextcomponent;
         if (p_229988_1_ instanceof SimpleReloadableResourceManager.FailedPackException) {
            itextcomponent = new StringTextComponent(((SimpleReloadableResourceManager.FailedPackException)p_229988_1_).func_241203_a().func_195762_a());
         } else {
            itextcomponent = null;
         }

         this.func_243208_a(p_229988_1_, itextcomponent);
      } else {
         Util.func_229756_b_(p_229988_1_);
      }

   }

   public void func_243208_a(Throwable p_243208_1_, @Nullable ITextComponent p_243208_2_) {
      field_147123_G.info("Caught error loading resourcepacks, removing all selected resourcepacks", p_243208_1_);
      this.field_110448_aq.func_198985_a(Collections.emptyList());
      this.field_71474_y.field_151453_l.clear();
      this.field_71474_y.field_183018_l.clear();
      this.field_71474_y.func_74303_b();
      this.func_213237_g().thenRun(() -> {
         ToastGui toastgui = this.func_193033_an();
         SystemToast.func_193657_a(toastgui, SystemToast.Type.PACK_LOAD_FAILURE, new TranslationTextComponent("resourcePack.load_fail"), p_243208_2_);
      });
   }

   public void func_99999_d() {
      this.field_152352_aC = Thread.currentThread();

      try {
         boolean flag = false;

         while(this.field_71425_J) {
            if (this.field_71433_S != null) {
               func_71377_b(this.field_71433_S);
               return;
            }

            try {
               LongTickDetector longtickdetector = LongTickDetector.func_233524_a_("Renderer");
               boolean flag1 = this.func_238202_aF_();
               this.func_238201_a_(flag1, longtickdetector);
               this.field_71424_I.func_219894_a();
               this.func_195542_b(!flag);
               this.field_71424_I.func_219897_b();
               this.func_238210_b_(flag1, longtickdetector);
            } catch (OutOfMemoryError outofmemoryerror) {
               if (flag) {
                  throw outofmemoryerror;
               }

               this.func_71398_f();
               this.func_147108_a(new MemoryErrorScreen());
               System.gc();
               field_147123_G.fatal("Out of memory", (Throwable)outofmemoryerror);
               flag = true;
            }
         }
      } catch (ReportedException reportedexception) {
         this.func_71396_d(reportedexception.func_71575_a());
         this.func_71398_f();
         field_147123_G.fatal("Reported exception thrown!", (Throwable)reportedexception);
         func_71377_b(reportedexception.func_71575_a());
      } catch (Throwable throwable) {
         CrashReport crashreport = this.func_71396_d(new CrashReport("Unexpected error", throwable));
         field_147123_G.fatal("Unreported exception thrown!", throwable);
         this.func_71398_f();
         func_71377_b(crashreport);
      }

   }

   void func_238209_b_(boolean p_238209_1_) {
      this.field_211501_aD.func_238551_a_(p_238209_1_ ? ImmutableMap.of(field_211502_b, field_238177_c_) : ImmutableMap.of());
   }

   private void func_193986_ar() {
      SearchTree<ItemStack> searchtree = new SearchTree<>((p_213242_0_) -> {
         return p_213242_0_.func_82840_a((PlayerEntity)null, ITooltipFlag.TooltipFlags.NORMAL).stream().map((p_213230_0_) -> {
            return TextFormatting.func_110646_a(p_213230_0_.getString()).trim();
         }).filter((p_213267_0_) -> {
            return !p_213267_0_.isEmpty();
         });
      }, (p_213251_0_) -> {
         return Stream.of(Registry.field_212630_s.func_177774_c(p_213251_0_.func_77973_b()));
      });
      SearchTreeReloadable<ItemStack> searchtreereloadable = new SearchTreeReloadable<>((p_213235_0_) -> {
         return ItemTags.func_199903_a().func_199913_a(p_213235_0_.func_77973_b()).stream();
      });
      NonNullList<ItemStack> nonnulllist = NonNullList.func_191196_a();

      for(Item item : Registry.field_212630_s) {
         item.func_150895_a(ItemGroup.field_78027_g, nonnulllist);
      }

      nonnulllist.forEach((p_213232_2_) -> {
         searchtree.func_217872_a(p_213232_2_);
         searchtreereloadable.func_217872_a(p_213232_2_);
      });
      SearchTree<RecipeList> searchtree1 = new SearchTree<>((p_213252_0_) -> {
         return p_213252_0_.func_192711_b().stream().flatMap((p_213234_0_) -> {
            return p_213234_0_.func_77571_b().func_82840_a((PlayerEntity)null, ITooltipFlag.TooltipFlags.NORMAL).stream();
         }).map((p_213264_0_) -> {
            return TextFormatting.func_110646_a(p_213264_0_.getString()).trim();
         }).filter((p_213238_0_) -> {
            return !p_213238_0_.isEmpty();
         });
      }, (p_213258_0_) -> {
         return p_213258_0_.func_192711_b().stream().map((p_213244_0_) -> {
            return Registry.field_212630_s.func_177774_c(p_213244_0_.func_77571_b().func_77973_b());
         });
      });
      this.field_193995_ae.func_215357_a(SearchTreeManager.field_215359_a, searchtree);
      this.field_193995_ae.func_215357_a(SearchTreeManager.field_215360_b, searchtreereloadable);
      this.field_193995_ae.func_215357_a(SearchTreeManager.field_194012_b, searchtree1);
   }

   private void func_195545_a(int p_195545_1_, long p_195545_2_) {
      this.field_71474_y.field_74352_v = false;
      this.field_71474_y.func_74303_b();
   }

   private static boolean func_147122_X() {
      String[] astring = new String[]{"sun.arch.data.model", "com.ibm.vm.bitmode", "os.arch"};

      for(String s : astring) {
         String s1 = System.getProperty(s);
         if (s1 != null && s1.contains("64")) {
            return true;
         }
      }

      return false;
   }

   public Framebuffer func_147110_a() {
      return this.field_147124_at;
   }

   public String func_175600_c() {
      return this.field_110447_Z;
   }

   public String func_184123_d() {
      return this.field_184130_ao;
   }

   public void func_71404_a(CrashReport p_71404_1_) {
      this.field_71433_S = p_71404_1_;
   }

   public static void func_71377_b(CrashReport p_71377_0_) {
      File file1 = new File(func_71410_x().field_71412_D, "crash-reports");
      File file2 = new File(file1, "crash-" + (new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss")).format(new Date()) + "-client.txt");
      Bootstrap.func_179870_a(p_71377_0_.func_71502_e());
      if (p_71377_0_.func_71497_f() != null) {
         Bootstrap.func_179870_a("#@!@# Game crashed! Crash report saved to: #@!@# " + p_71377_0_.func_71497_f());
         System.exit(-1);
      } else if (p_71377_0_.func_147149_a(file2)) {
         Bootstrap.func_179870_a("#@!@# Game crashed! Crash report saved to: #@!@# " + file2.getAbsolutePath());
         System.exit(-1);
      } else {
         Bootstrap.func_179870_a("#@?@# Game crashed! Crash report could not be saved. #@?@#");
         System.exit(-2);
      }

   }

   public boolean func_211821_e() {
      return this.field_71474_y.field_211842_aO;
   }

   public CompletableFuture<Void> func_213237_g() {
      if (this.field_213276_aV != null) {
         return this.field_213276_aV;
      } else {
         CompletableFuture<Void> completablefuture = new CompletableFuture<>();
         if (this.field_213279_p instanceof ResourceLoadProgressGui) {
            this.field_213276_aV = completablefuture;
            return completablefuture;
         } else {
            this.field_110448_aq.func_198983_a();
            List<IResourcePack> list = this.field_110448_aq.func_232623_f_();
            this.func_213268_a(new ResourceLoadProgressGui(this, this.field_110451_am.func_219537_a(Util.func_215072_e(), this, field_223714_G, list), (p_238200_2_) -> {
               Util.func_215077_a(p_238200_2_, this::func_229988_a_, () -> {
                  this.field_71438_f.func_72712_a();
                  completablefuture.complete((Void)null);
               });
            }, true));
            return completablefuture;
         }
      }
   }

   private void func_213256_aB() {
      boolean flag = false;
      BlockModelShapes blockmodelshapes = this.func_175602_ab().func_175023_a();
      IBakedModel ibakedmodel = blockmodelshapes.func_178126_b().func_174951_a();

      for(Block block : Registry.field_212618_g) {
         for(BlockState blockstate : block.func_176194_O().func_177619_a()) {
            if (blockstate.func_185901_i() == BlockRenderType.MODEL) {
               IBakedModel ibakedmodel1 = blockmodelshapes.func_178125_b(blockstate);
               if (ibakedmodel1 == ibakedmodel) {
                  field_147123_G.debug("Missing model for: {}", (Object)blockstate);
                  flag = true;
               }
            }
         }
      }

      TextureAtlasSprite textureatlassprite1 = ibakedmodel.func_177554_e();

      for(Block block1 : Registry.field_212618_g) {
         for(BlockState blockstate1 : block1.func_176194_O().func_177619_a()) {
            TextureAtlasSprite textureatlassprite = blockmodelshapes.func_178122_a(blockstate1);
            if (!blockstate1.func_196958_f() && textureatlassprite == textureatlassprite1) {
               field_147123_G.debug("Missing particle icon for: {}", (Object)blockstate1);
               flag = true;
            }
         }
      }

      NonNullList<ItemStack> nonnulllist = NonNullList.func_191196_a();

      for(Item item : Registry.field_212630_s) {
         nonnulllist.clear();
         item.func_150895_a(ItemGroup.field_78027_g, nonnulllist);

         for(ItemStack itemstack : nonnulllist) {
            String s = itemstack.func_77977_a();
            String s1 = (new TranslationTextComponent(s)).getString();
            if (s1.toLowerCase(Locale.ROOT).equals(item.func_77658_a())) {
               field_147123_G.debug("Missing translation for: {} {} {}", itemstack, s, itemstack.func_77973_b());
            }
         }
      }

      flag = flag | ScreenManager.func_216910_a();
      if (flag) {
         throw new IllegalStateException("Your game data is foobar, fix the errors above!");
      }
   }

   public SaveFormat func_71359_d() {
      return this.field_71469_aa;
   }

   private void func_238207_b_(String p_238207_1_) {
      if (!this.func_71387_A() && !this.func_238217_s_()) {
         if (this.field_71439_g != null) {
            this.field_71439_g.func_145747_a((new TranslationTextComponent("chat.cannotSend")).func_240699_a_(TextFormatting.RED), Util.field_240973_b_);
         }
      } else {
         this.func_147108_a(new ChatScreen(p_238207_1_));
      }

   }

   public void func_147108_a(@Nullable Screen p_147108_1_) {
      if (this.field_71462_r != null) {
         this.field_71462_r.func_231164_f_();
      }

      if (p_147108_1_ == null && this.field_71441_e == null) {
         p_147108_1_ = new MainMenuScreen();
      } else if (p_147108_1_ == null && this.field_71439_g.func_233643_dh_()) {
         if (this.field_71439_g.func_228353_F_()) {
            p_147108_1_ = new DeathScreen((ITextComponent)null, this.field_71441_e.func_72912_H().func_76093_s());
         } else {
            this.field_71439_g.func_71004_bE();
         }
      }

      if (p_147108_1_ instanceof MainMenuScreen || p_147108_1_ instanceof MultiplayerScreen) {
         this.field_71474_y.field_74330_P = false;
         this.field_71456_v.func_146158_b().func_146231_a(true);
      }

      this.field_71462_r = p_147108_1_;
      if (p_147108_1_ != null) {
         this.field_71417_B.func_198032_j();
         KeyBinding.func_74506_a();
         p_147108_1_.func_231158_b_(this, this.field_195558_d.func_198107_o(), this.field_195558_d.func_198087_p());
         this.field_71454_w = false;
         NarratorChatListener.field_193643_a.func_216864_a(p_147108_1_.func_231167_h_());
      } else {
         this.field_147127_av.func_147687_e();
         this.field_71417_B.func_198034_i();
      }

      this.func_230150_b_();
   }

   public void func_213268_a(@Nullable LoadingGui p_213268_1_) {
      this.field_213279_p = p_213268_1_;
   }

   public void func_71405_e() {
      try {
         field_147123_G.info("Stopping!");

         try {
            NarratorChatListener.field_193643_a.func_216867_c();
         } catch (Throwable throwable1) {
         }

         try {
            if (this.field_71441_e != null) {
               this.field_71441_e.func_72882_A();
            }

            this.func_213254_o();
         } catch (Throwable throwable) {
         }

         if (this.field_71462_r != null) {
            this.field_71462_r.func_231164_f_();
         }

         this.close();
      } finally {
         Util.field_211180_a = System::nanoTime;
         if (this.field_71433_S == null) {
            System.exit(0);
         }

      }

   }

   public void close() {
      try {
         this.field_175617_aL.close();
         this.field_211501_aD.close();
         this.field_71460_t.close();
         this.field_71438_f.close();
         this.field_147127_av.func_147685_d();
         this.field_110448_aq.close();
         this.field_71452_i.func_215232_a();
         this.field_213273_aM.close();
         this.field_213272_aL.close();
         this.field_71446_o.close();
         this.field_110451_am.close();
         Util.func_240993_h_();
      } catch (Throwable throwable) {
         field_147123_G.error("Shutdown failure!", throwable);
         throw throwable;
      } finally {
         this.field_195557_T.close();
         this.field_195558_d.close();
      }

   }

   private void func_195542_b(boolean p_195542_1_) {
      this.field_195558_d.func_227799_a_("Pre render");
      long i = Util.func_211178_c();
      if (this.field_195558_d.func_227800_b_()) {
         this.func_71400_g();
      }

      if (this.field_213276_aV != null && !(this.field_213279_p instanceof ResourceLoadProgressGui)) {
         CompletableFuture<Void> completablefuture = this.field_213276_aV;
         this.field_213276_aV = null;
         this.func_213237_g().thenRun(() -> {
            completablefuture.complete((Void)null);
         });
      }

      Runnable runnable;
      while((runnable = this.field_213275_aU.poll()) != null) {
         runnable.run();
      }

      if (p_195542_1_) {
         int j = this.field_71428_T.func_238400_a_(Util.func_211177_b());
         this.field_71424_I.func_76320_a("scheduledExecutables");
         this.func_213160_bf();
         this.field_71424_I.func_76319_b();
         this.field_71424_I.func_76320_a("tick");

         for(int k = 0; k < Math.min(10, j); ++k) {
            this.field_71424_I.func_230035_c_("clientTick");
            this.func_71407_l();
         }

         this.field_71424_I.func_76319_b();
      }

      this.field_71417_B.func_198028_a();
      this.field_195558_d.func_227799_a_("Render");
      this.field_71424_I.func_76320_a("sound");
      this.field_147127_av.func_215289_a(this.field_71460_t.func_215316_n());
      this.field_71424_I.func_76319_b();
      this.field_71424_I.func_76320_a("render");
      RenderSystem.pushMatrix();
      RenderSystem.clear(16640, field_142025_a);
      this.field_147124_at.func_147610_a(true);
      FogRenderer.func_228370_a_();
      this.field_71424_I.func_76320_a("display");
      RenderSystem.enableTexture();
      RenderSystem.enableCull();
      this.field_71424_I.func_76319_b();
      if (!this.field_71454_w) {
         this.field_71424_I.func_219895_b("gameRenderer");
         this.field_71460_t.func_195458_a(this.field_71445_n ? this.field_193996_ah : this.field_71428_T.field_194147_b, i, p_195542_1_);
         this.field_71424_I.func_219895_b("toasts");
         this.field_193034_aS.func_238541_a_(new MatrixStack());
         this.field_71424_I.func_76319_b();
      }

      if (this.field_238174_aV_ != null) {
         this.field_71424_I.func_76320_a("fpsPie");
         this.func_238183_a_(new MatrixStack(), this.field_238174_aV_);
         this.field_71424_I.func_76319_b();
      }

      this.field_71424_I.func_76320_a("blit");
      this.field_147124_at.func_147609_e();
      RenderSystem.popMatrix();
      RenderSystem.pushMatrix();
      this.field_147124_at.func_147615_c(this.field_195558_d.func_198109_k(), this.field_195558_d.func_198091_l());
      RenderSystem.popMatrix();
      this.field_71424_I.func_219895_b("updateDisplay");
      this.field_195558_d.func_227802_e_();
      int i1 = this.func_213243_aC();
      if ((double)i1 < AbstractOption.field_216701_h.func_216733_c()) {
         RenderSystem.limitDisplayFPS(i1);
      }

      this.field_71424_I.func_219895_b("yield");
      Thread.yield();
      this.field_71424_I.func_76319_b();
      this.field_195558_d.func_227799_a_("Post render");
      ++this.field_71420_M;
      boolean flag = this.func_71356_B() && (this.field_71462_r != null && this.field_71462_r.func_231177_au__() || this.field_213279_p != null && this.field_213279_p.func_212969_a()) && !this.field_71437_Z.func_71344_c();
      if (this.field_71445_n != flag) {
         if (this.field_71445_n) {
            this.field_193996_ah = this.field_71428_T.field_194147_b;
         } else {
            this.field_71428_T.field_194147_b = this.field_193996_ah;
         }

         this.field_71445_n = flag;
      }

      long l = Util.func_211178_c();
      this.field_181542_y.func_181747_a(l - this.field_181543_z);
      this.field_181543_z = l;
      this.field_71424_I.func_76320_a("fpsUpdate");

      while(Util.func_211177_b() >= this.field_71419_L + 1000L) {
         field_71470_ab = this.field_71420_M;
         this.field_71426_K = String.format("%d fps T: %s%s%s%s B: %d", field_71470_ab, (double)this.field_71474_y.field_74350_i == AbstractOption.field_216701_h.func_216733_c() ? "inf" : this.field_71474_y.field_74350_i, this.field_71474_y.field_74352_v ? " vsync" : "", this.field_71474_y.field_238330_f_.toString(), this.field_71474_y.field_74345_l == CloudOption.OFF ? "" : (this.field_71474_y.field_74345_l == CloudOption.FAST ? " fast-clouds" : " fancy-clouds"), this.field_71474_y.field_205217_U);
         this.field_71419_L += 1000L;
         this.field_71420_M = 0;
         this.field_71427_U.func_76471_b();
         if (!this.field_71427_U.func_76468_d()) {
            this.field_71427_U.func_76463_a();
         }
      }

      this.field_71424_I.func_76319_b();
   }

   private boolean func_238202_aF_() {
      return this.field_71474_y.field_74330_P && this.field_71474_y.field_74329_Q && !this.field_71474_y.field_74319_N;
   }

   private void func_238201_a_(boolean p_238201_1_, @Nullable LongTickDetector p_238201_2_) {
      if (p_238201_1_) {
         if (!this.field_238173_aU_.func_233505_a_()) {
            this.field_238172_aT_ = 0;
            this.field_238173_aU_.func_233507_c_();
         }

         ++this.field_238172_aT_;
      } else {
         this.field_238173_aU_.func_233506_b_();
      }

      this.field_71424_I = LongTickDetector.func_233523_a_(this.field_238173_aU_.func_233508_d_(), p_238201_2_);
   }

   private void func_238210_b_(boolean p_238210_1_, @Nullable LongTickDetector p_238210_2_) {
      if (p_238210_2_ != null) {
         p_238210_2_.func_233525_b_();
      }

      if (p_238210_1_) {
         this.field_238174_aV_ = this.field_238173_aU_.func_233509_e_();
      } else {
         this.field_238174_aV_ = null;
      }

      this.field_71424_I = this.field_238173_aU_.func_233508_d_();
   }

   public void func_213226_a() {
      int i = this.field_195558_d.func_216521_a(this.field_71474_y.field_74335_Z, this.func_211821_e());
      this.field_195558_d.func_216525_a((double)i);
      if (this.field_71462_r != null) {
         this.field_71462_r.func_231152_a_(this, this.field_195558_d.func_198107_o(), this.field_195558_d.func_198087_p());
      }

      Framebuffer framebuffer = this.func_147110_a();
      framebuffer.func_216491_a(this.field_195558_d.func_198109_k(), this.field_195558_d.func_198091_l(), field_142025_a);
      this.field_71460_t.func_147704_a(this.field_195558_d.func_198109_k(), this.field_195558_d.func_198091_l());
      this.field_71417_B.func_198021_g();
   }

   public void func_241216_b_() {
      this.field_71417_B.func_241563_k_();
   }

   private int func_213243_aC() {
      return this.field_71441_e != null || this.field_71462_r == null && this.field_213279_p == null ? this.field_195558_d.func_198082_x() : 60;
   }

   public void func_71398_f() {
      try {
         field_71444_a = new byte[0];
         this.field_71438_f.func_72728_f();
      } catch (Throwable throwable1) {
      }

      try {
         System.gc();
         if (this.field_71455_al && this.field_71437_Z != null) {
            this.field_71437_Z.func_71263_m(true);
         }

         this.func_213231_b(new DirtMessageScreen(new TranslationTextComponent("menu.savingLevel")));
      } catch (Throwable throwable) {
      }

      System.gc();
   }

   void func_71383_b(int p_71383_1_) {
      if (this.field_238174_aV_ != null) {
         List<DataPoint> list = this.field_238174_aV_.func_219917_a(this.field_71465_an);
         if (!list.isEmpty()) {
            DataPoint datapoint = list.remove(0);
            if (p_71383_1_ == 0) {
               if (!datapoint.field_219945_c.isEmpty()) {
                  int i = this.field_71465_an.lastIndexOf(30);
                  if (i >= 0) {
                     this.field_71465_an = this.field_71465_an.substring(0, i);
                  }
               }
            } else {
               --p_71383_1_;
               if (p_71383_1_ < list.size() && !"unspecified".equals((list.get(p_71383_1_)).field_219945_c)) {
                  if (!this.field_71465_an.isEmpty()) {
                     this.field_71465_an = this.field_71465_an + '\u001e';
                  }

                  this.field_71465_an = this.field_71465_an + (list.get(p_71383_1_)).field_219945_c;
               }
            }

         }
      }
   }

   private void func_238183_a_(MatrixStack p_238183_1_, IProfileResult p_238183_2_) {
      List<DataPoint> list = p_238183_2_.func_219917_a(this.field_71465_an);
      DataPoint datapoint = list.remove(0);
      RenderSystem.clear(256, field_142025_a);
      RenderSystem.matrixMode(5889);
      RenderSystem.loadIdentity();
      RenderSystem.ortho(0.0D, (double)this.field_195558_d.func_198109_k(), (double)this.field_195558_d.func_198091_l(), 0.0D, 1000.0D, 3000.0D);
      RenderSystem.matrixMode(5888);
      RenderSystem.loadIdentity();
      RenderSystem.translatef(0.0F, 0.0F, -2000.0F);
      RenderSystem.lineWidth(1.0F);
      RenderSystem.disableTexture();
      Tessellator tessellator = Tessellator.func_178181_a();
      BufferBuilder bufferbuilder = tessellator.func_178180_c();
      int i = 160;
      int j = this.field_195558_d.func_198109_k() - 160 - 10;
      int k = this.field_195558_d.func_198091_l() - 320;
      RenderSystem.enableBlend();
      bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
      bufferbuilder.func_225582_a_((double)((float)j - 176.0F), (double)((float)k - 96.0F - 16.0F), 0.0D).func_225586_a_(200, 0, 0, 0).func_181675_d();
      bufferbuilder.func_225582_a_((double)((float)j - 176.0F), (double)(k + 320), 0.0D).func_225586_a_(200, 0, 0, 0).func_181675_d();
      bufferbuilder.func_225582_a_((double)((float)j + 176.0F), (double)(k + 320), 0.0D).func_225586_a_(200, 0, 0, 0).func_181675_d();
      bufferbuilder.func_225582_a_((double)((float)j + 176.0F), (double)((float)k - 96.0F - 16.0F), 0.0D).func_225586_a_(200, 0, 0, 0).func_181675_d();
      tessellator.func_78381_a();
      RenderSystem.disableBlend();
      double d0 = 0.0D;

      for(DataPoint datapoint1 : list) {
         int l = MathHelper.func_76128_c(datapoint1.field_219943_a / 4.0D) + 1;
         bufferbuilder.func_181668_a(6, DefaultVertexFormats.field_181706_f);
         int i1 = datapoint1.func_219942_a();
         int j1 = i1 >> 16 & 255;
         int k1 = i1 >> 8 & 255;
         int l1 = i1 & 255;
         bufferbuilder.func_225582_a_((double)j, (double)k, 0.0D).func_225586_a_(j1, k1, l1, 255).func_181675_d();

         for(int i2 = l; i2 >= 0; --i2) {
            float f = (float)((d0 + datapoint1.field_219943_a * (double)i2 / (double)l) * (double)((float)Math.PI * 2F) / 100.0D);
            float f1 = MathHelper.func_76126_a(f) * 160.0F;
            float f2 = MathHelper.func_76134_b(f) * 160.0F * 0.5F;
            bufferbuilder.func_225582_a_((double)((float)j + f1), (double)((float)k - f2), 0.0D).func_225586_a_(j1, k1, l1, 255).func_181675_d();
         }

         tessellator.func_78381_a();
         bufferbuilder.func_181668_a(5, DefaultVertexFormats.field_181706_f);

         for(int l2 = l; l2 >= 0; --l2) {
            float f3 = (float)((d0 + datapoint1.field_219943_a * (double)l2 / (double)l) * (double)((float)Math.PI * 2F) / 100.0D);
            float f4 = MathHelper.func_76126_a(f3) * 160.0F;
            float f5 = MathHelper.func_76134_b(f3) * 160.0F * 0.5F;
            if (!(f5 > 0.0F)) {
               bufferbuilder.func_225582_a_((double)((float)j + f4), (double)((float)k - f5), 0.0D).func_225586_a_(j1 >> 1, k1 >> 1, l1 >> 1, 255).func_181675_d();
               bufferbuilder.func_225582_a_((double)((float)j + f4), (double)((float)k - f5 + 10.0F), 0.0D).func_225586_a_(j1 >> 1, k1 >> 1, l1 >> 1, 255).func_181675_d();
            }
         }

         tessellator.func_78381_a();
         d0 += datapoint1.field_219943_a;
      }

      DecimalFormat decimalformat = new DecimalFormat("##0.00");
      decimalformat.setDecimalFormatSymbols(DecimalFormatSymbols.getInstance(Locale.ROOT));
      RenderSystem.enableTexture();
      String s = IProfileResult.func_225434_b(datapoint.field_219945_c);
      String s1 = "";
      if (!"unspecified".equals(s)) {
         s1 = s1 + "[0] ";
      }

      if (s.isEmpty()) {
         s1 = s1 + "ROOT ";
      } else {
         s1 = s1 + s + ' ';
      }

      int k2 = 16777215;
      this.field_71466_p.func_238405_a_(p_238183_1_, s1, (float)(j - 160), (float)(k - 80 - 16), 16777215);
      s1 = decimalformat.format(datapoint.field_219944_b) + "%";
      this.field_71466_p.func_238405_a_(p_238183_1_, s1, (float)(j + 160 - this.field_71466_p.func_78256_a(s1)), (float)(k - 80 - 16), 16777215);

      for(int j2 = 0; j2 < list.size(); ++j2) {
         DataPoint datapoint2 = list.get(j2);
         StringBuilder stringbuilder = new StringBuilder();
         if ("unspecified".equals(datapoint2.field_219945_c)) {
            stringbuilder.append("[?] ");
         } else {
            stringbuilder.append("[").append(j2 + 1).append("] ");
         }

         String s2 = stringbuilder.append(datapoint2.field_219945_c).toString();
         this.field_71466_p.func_238405_a_(p_238183_1_, s2, (float)(j - 160), (float)(k + 80 + j2 * 8 + 20), datapoint2.func_219942_a());
         s2 = decimalformat.format(datapoint2.field_219943_a) + "%";
         this.field_71466_p.func_238405_a_(p_238183_1_, s2, (float)(j + 160 - 50 - this.field_71466_p.func_78256_a(s2)), (float)(k + 80 + j2 * 8 + 20), datapoint2.func_219942_a());
         s2 = decimalformat.format(datapoint2.field_219944_b) + "%";
         this.field_71466_p.func_238405_a_(p_238183_1_, s2, (float)(j + 160 - this.field_71466_p.func_78256_a(s2)), (float)(k + 80 + j2 * 8 + 20), datapoint2.func_219942_a());
      }

   }

   public void func_71400_g() {
      this.field_71425_J = false;
   }

   public boolean func_228025_l_() {
      return this.field_71425_J;
   }

   public void func_71385_j(boolean p_71385_1_) {
      if (this.field_71462_r == null) {
         boolean flag = this.func_71356_B() && !this.field_71437_Z.func_71344_c();
         if (flag) {
            this.func_147108_a(new IngameMenuScreen(!p_71385_1_));
            this.field_147127_av.func_147689_b();
         } else {
            this.func_147108_a(new IngameMenuScreen(true));
         }

      }
   }

   private void func_147115_a(boolean p_147115_1_) {
      if (!p_147115_1_) {
         this.field_71429_W = 0;
      }

      if (this.field_71429_W <= 0 && !this.field_71439_g.func_184587_cr()) {
         if (p_147115_1_ && this.field_71476_x != null && this.field_71476_x.func_216346_c() == RayTraceResult.Type.BLOCK) {
            BlockRayTraceResult blockraytraceresult = (BlockRayTraceResult)this.field_71476_x;
            BlockPos blockpos = blockraytraceresult.func_216350_a();
            if (!this.field_71441_e.func_180495_p(blockpos).func_196958_f()) {
               Direction direction = blockraytraceresult.func_216354_b();
               if (this.field_71442_b.func_180512_c(blockpos, direction)) {
                  this.field_71452_i.func_180532_a(blockpos, direction);
                  this.field_71439_g.func_184609_a(Hand.MAIN_HAND);
               }
            }

         } else {
            this.field_71442_b.func_78767_c();
         }
      }
   }

   private void func_147116_af() {
      if (this.field_71429_W <= 0) {
         if (this.field_71476_x == null) {
            field_147123_G.error("Null returned as 'hitResult', this shouldn't happen!");
            if (this.field_71442_b.func_78762_g()) {
               this.field_71429_W = 10;
            }

         } else if (!this.field_71439_g.func_184838_M()) {
            switch(this.field_71476_x.func_216346_c()) {
            case ENTITY:
               this.field_71442_b.func_78764_a(this.field_71439_g, ((EntityRayTraceResult)this.field_71476_x).func_216348_a());
               break;
            case BLOCK:
               BlockRayTraceResult blockraytraceresult = (BlockRayTraceResult)this.field_71476_x;
               BlockPos blockpos = blockraytraceresult.func_216350_a();
               if (!this.field_71441_e.func_180495_p(blockpos).func_196958_f()) {
                  this.field_71442_b.func_180511_b(blockpos, blockraytraceresult.func_216354_b());
                  break;
               }
            case MISS:
               if (this.field_71442_b.func_78762_g()) {
                  this.field_71429_W = 10;
               }

               this.field_71439_g.func_184821_cY();
            }

            this.field_71439_g.func_184609_a(Hand.MAIN_HAND);
         }
      }
   }

   private void func_147121_ag() {
      if (!this.field_71442_b.func_181040_m()) {
         this.field_71467_ac = 4;
         if (!this.field_71439_g.func_184838_M()) {
            if (this.field_71476_x == null) {
               field_147123_G.warn("Null returned as 'hitResult', this shouldn't happen!");
            }

            for(Hand hand : Hand.values()) {
               ItemStack itemstack = this.field_71439_g.func_184586_b(hand);
               if (this.field_71476_x != null) {
                  switch(this.field_71476_x.func_216346_c()) {
                  case ENTITY:
                     EntityRayTraceResult entityraytraceresult = (EntityRayTraceResult)this.field_71476_x;
                     Entity entity = entityraytraceresult.func_216348_a();
                     ActionResultType actionresulttype = this.field_71442_b.func_187102_a(this.field_71439_g, entity, entityraytraceresult, hand);
                     if (!actionresulttype.func_226246_a_()) {
                        actionresulttype = this.field_71442_b.func_187097_a(this.field_71439_g, entity, hand);
                     }

                     if (actionresulttype.func_226246_a_()) {
                        if (actionresulttype.func_226247_b_()) {
                           this.field_71439_g.func_184609_a(hand);
                        }

                        return;
                     }
                     break;
                  case BLOCK:
                     BlockRayTraceResult blockraytraceresult = (BlockRayTraceResult)this.field_71476_x;
                     int i = itemstack.func_190916_E();
                     ActionResultType actionresulttype1 = this.field_71442_b.func_217292_a(this.field_71439_g, this.field_71441_e, hand, blockraytraceresult);
                     if (actionresulttype1.func_226246_a_()) {
                        if (actionresulttype1.func_226247_b_()) {
                           this.field_71439_g.func_184609_a(hand);
                           if (!itemstack.func_190926_b() && (itemstack.func_190916_E() != i || this.field_71442_b.func_78758_h())) {
                              this.field_71460_t.field_78516_c.func_187460_a(hand);
                           }
                        }

                        return;
                     }

                     if (actionresulttype1 == ActionResultType.FAIL) {
                        return;
                     }
                  }
               }

               if (!itemstack.func_190926_b()) {
                  ActionResultType actionresulttype2 = this.field_71442_b.func_187101_a(this.field_71439_g, this.field_71441_e, hand);
                  if (actionresulttype2.func_226246_a_()) {
                     if (actionresulttype2.func_226247_b_()) {
                        this.field_71439_g.func_184609_a(hand);
                     }

                     this.field_71460_t.field_78516_c.func_187460_a(hand);
                     return;
                  }
               }
            }

         }
      }
   }

   public MusicTicker func_181535_r() {
      return this.field_147126_aw;
   }

   public void func_71407_l() {
      if (this.field_71467_ac > 0) {
         --this.field_71467_ac;
      }

      this.field_71424_I.func_76320_a("gui");
      if (!this.field_71445_n) {
         this.field_71456_v.func_73831_a();
      }

      this.field_71424_I.func_76319_b();
      this.field_71460_t.func_78473_a(1.0F);
      this.field_193035_aW.func_193297_a(this.field_71441_e, this.field_71476_x);
      this.field_71424_I.func_76320_a("gameMode");
      if (!this.field_71445_n && this.field_71441_e != null) {
         this.field_71442_b.func_78765_e();
      }

      this.field_71424_I.func_219895_b("textures");
      if (this.field_71441_e != null) {
         this.field_71446_o.func_110550_d();
      }

      if (this.field_71462_r == null && this.field_71439_g != null) {
         if (this.field_71439_g.func_233643_dh_() && !(this.field_71462_r instanceof DeathScreen)) {
            this.func_147108_a((Screen)null);
         } else if (this.field_71439_g.func_70608_bn() && this.field_71441_e != null) {
            this.func_147108_a(new SleepInMultiplayerScreen());
         }
      } else if (this.field_71462_r != null && this.field_71462_r instanceof SleepInMultiplayerScreen && !this.field_71439_g.func_70608_bn()) {
         this.func_147108_a((Screen)null);
      }

      if (this.field_71462_r != null) {
         this.field_71429_W = 10000;
      }

      if (this.field_71462_r != null) {
         Screen.func_231153_a_(() -> {
            this.field_71462_r.func_231023_e_();
         }, "Ticking screen", this.field_71462_r.getClass().getCanonicalName());
      }

      if (!this.field_71474_y.field_74330_P) {
         this.field_71456_v.func_212910_m();
      }

      if (this.field_213279_p == null && (this.field_71462_r == null || this.field_71462_r.field_230711_n_)) {
         this.field_71424_I.func_219895_b("Keybindings");
         this.func_184117_aA();
         if (this.field_71429_W > 0) {
            --this.field_71429_W;
         }
      }

      if (this.field_71441_e != null) {
         this.field_71424_I.func_219895_b("gameRenderer");
         if (!this.field_71445_n) {
            this.field_71460_t.func_78464_a();
         }

         this.field_71424_I.func_219895_b("levelRenderer");
         if (!this.field_71445_n) {
            this.field_71438_f.func_72734_e();
         }

         this.field_71424_I.func_219895_b("level");
         if (!this.field_71445_n) {
            if (this.field_71441_e.func_228332_n_() > 0) {
               this.field_71441_e.func_225605_c_(this.field_71441_e.func_228332_n_() - 1);
            }

            this.field_71441_e.func_217419_d();
         }
      } else if (this.field_71460_t.func_147706_e() != null) {
         this.field_71460_t.func_181022_b();
      }

      if (!this.field_71445_n) {
         this.field_147126_aw.func_73660_a();
      }

      this.field_147127_av.func_215290_a(this.field_71445_n);
      if (this.field_71441_e != null) {
         if (!this.field_71445_n) {
            if (!this.field_71474_y.field_244601_E && this.func_244600_aM()) {
               ITextComponent itextcomponent = new TranslationTextComponent("tutorial.socialInteractions.title");
               ITextComponent itextcomponent1 = new TranslationTextComponent("tutorial.socialInteractions.description", Tutorial.func_193291_a("socialInteractions"));
               this.field_244598_aV = new TutorialToast(TutorialToast.Icons.SOCIAL_INTERACTIONS, itextcomponent, itextcomponent1, true);
               this.field_193035_aW.func_244698_a(this.field_244598_aV, 160);
               this.field_71474_y.field_244601_E = true;
               this.field_71474_y.func_74303_b();
            }

            this.field_193035_aW.func_193303_d();

            try {
               this.field_71441_e.func_72835_b(() -> {
                  return true;
               });
            } catch (Throwable throwable) {
               CrashReport crashreport = CrashReport.func_85055_a(throwable, "Exception in world tick");
               if (this.field_71441_e == null) {
                  CrashReportCategory crashreportcategory = crashreport.func_85058_a("Affected level");
                  crashreportcategory.func_71507_a("Problem", "Level is null!");
               } else {
                  this.field_71441_e.func_72914_a(crashreport);
               }

               throw new ReportedException(crashreport);
            }
         }

         this.field_71424_I.func_219895_b("animateTick");
         if (!this.field_71445_n && this.field_71441_e != null) {
            this.field_71441_e.func_73029_E(MathHelper.func_76128_c(this.field_71439_g.func_226277_ct_()), MathHelper.func_76128_c(this.field_71439_g.func_226278_cu_()), MathHelper.func_76128_c(this.field_71439_g.func_226281_cx_()));
         }

         this.field_71424_I.func_219895_b("particles");
         if (!this.field_71445_n) {
            this.field_71452_i.func_78868_a();
         }
      } else if (this.field_71453_ak != null) {
         this.field_71424_I.func_219895_b("pendingConnection");
         this.field_71453_ak.func_74428_b();
      }

      this.field_71424_I.func_219895_b("keyboard");
      this.field_195559_v.func_204870_b();
      this.field_71424_I.func_76319_b();
   }

   private boolean func_244600_aM() {
      return !this.field_71455_al || this.field_71437_Z != null && this.field_71437_Z.func_71344_c();
   }

   private void func_184117_aA() {
      for(; this.field_71474_y.field_151457_aa.func_151468_f(); this.field_71438_f.func_174979_m()) {
         PointOfView pointofview = this.field_71474_y.func_243230_g();
         this.field_71474_y.func_243229_a(this.field_71474_y.func_243230_g().func_243194_c());
         if (pointofview.func_243192_a() != this.field_71474_y.func_243230_g().func_243192_a()) {
            this.field_71460_t.func_175066_a(this.field_71474_y.func_243230_g().func_243192_a() ? this.func_175606_aa() : null);
         }
      }

      while(this.field_71474_y.field_151458_ab.func_151468_f()) {
         this.field_71474_y.field_74326_T = !this.field_71474_y.field_74326_T;
      }

      for(int i = 0; i < 9; ++i) {
         boolean flag = this.field_71474_y.field_193629_ap.func_151470_d();
         boolean flag1 = this.field_71474_y.field_193630_aq.func_151470_d();
         if (this.field_71474_y.field_151456_ac[i].func_151468_f()) {
            if (this.field_71439_g.func_175149_v()) {
               this.field_71456_v.func_175187_g().func_175260_a(i);
            } else if (!this.field_71439_g.func_184812_l_() || this.field_71462_r != null || !flag1 && !flag) {
               this.field_71439_g.field_71071_by.field_70461_c = i;
            } else {
               CreativeScreen.func_192044_a(this, i, flag1, flag);
            }
         }
      }

      while(this.field_71474_y.field_244602_au.func_151468_f()) {
         if (!this.func_244600_aM()) {
            this.field_71439_g.func_146105_b(field_244596_I, true);
            NarratorChatListener.field_193643_a.func_216864_a(field_244596_I.getString());
         } else {
            if (this.field_244598_aV != null) {
               this.field_193035_aW.func_244697_a(this.field_244598_aV);
               this.field_244598_aV = null;
            }

            this.func_147108_a(new SocialInteractionsScreen());
         }
      }

      while(this.field_71474_y.field_151445_Q.func_151468_f()) {
         if (this.field_71442_b.func_110738_j()) {
            this.field_71439_g.func_175163_u();
         } else {
            this.field_193035_aW.func_193296_a();
            this.func_147108_a(new InventoryScreen(this.field_71439_g));
         }
      }

      while(this.field_71474_y.field_194146_ao.func_151468_f()) {
         this.func_147108_a(new AdvancementsScreen(this.field_71439_g.field_71174_a.func_191982_f()));
      }

      while(this.field_71474_y.field_186718_X.func_151468_f()) {
         if (!this.field_71439_g.func_175149_v()) {
            this.func_147114_u().func_147297_a(new CPlayerDiggingPacket(CPlayerDiggingPacket.Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.field_177992_a, Direction.DOWN));
         }
      }

      while(this.field_71474_y.field_74316_C.func_151468_f()) {
         if (!this.field_71439_g.func_175149_v() && this.field_71439_g.func_225609_n_(Screen.func_231172_r_())) {
            this.field_71439_g.func_184609_a(Hand.MAIN_HAND);
         }
      }

      boolean flag2 = this.field_71474_y.field_74343_n != ChatVisibility.HIDDEN;
      if (flag2) {
         while(this.field_71474_y.field_74310_D.func_151468_f()) {
            this.func_238207_b_("");
         }

         if (this.field_71462_r == null && this.field_213279_p == null && this.field_71474_y.field_74323_J.func_151468_f()) {
            this.func_238207_b_("/");
         }
      }

      if (this.field_71439_g.func_184587_cr()) {
         if (!this.field_71474_y.field_74313_G.func_151470_d()) {
            this.field_71442_b.func_78766_c(this.field_71439_g);
         }

         while(this.field_71474_y.field_74312_F.func_151468_f()) {
         }

         while(this.field_71474_y.field_74313_G.func_151468_f()) {
         }

         while(this.field_71474_y.field_74322_I.func_151468_f()) {
         }
      } else {
         while(this.field_71474_y.field_74312_F.func_151468_f()) {
            this.func_147116_af();
         }

         while(this.field_71474_y.field_74313_G.func_151468_f()) {
            this.func_147121_ag();
         }

         while(this.field_71474_y.field_74322_I.func_151468_f()) {
            this.func_147112_ai();
         }
      }

      if (this.field_71474_y.field_74313_G.func_151470_d() && this.field_71467_ac == 0 && !this.field_71439_g.func_184587_cr()) {
         this.func_147121_ag();
      }

      this.func_147115_a(this.field_71462_r == null && this.field_71474_y.field_74312_F.func_151470_d() && this.field_71417_B.func_198035_h());
   }

   public static DatapackCodec func_238180_a_(SaveFormat.LevelSave p_238180_0_) {
      MinecraftServer.func_240777_a_(p_238180_0_);
      DatapackCodec datapackcodec = p_238180_0_.func_237297_e_();
      if (datapackcodec == null) {
         throw new IllegalStateException("Failed to load data pack config");
      } else {
         return datapackcodec;
      }
   }

   public static IServerConfiguration func_238181_a_(SaveFormat.LevelSave p_238181_0_, DynamicRegistries.Impl p_238181_1_, IResourceManager p_238181_2_, DatapackCodec p_238181_3_) {
      WorldSettingsImport<INBT> worldsettingsimport = WorldSettingsImport.func_244335_a(NBTDynamicOps.field_210820_a, p_238181_2_, p_238181_1_);
      IServerConfiguration iserverconfiguration = p_238181_0_.func_237284_a_(worldsettingsimport, p_238181_3_);
      if (iserverconfiguration == null) {
         throw new IllegalStateException("Failed to load world");
      } else {
         return iserverconfiguration;
      }
   }

   public void func_238191_a_(String p_238191_1_) {
      this.func_238195_a_(p_238191_1_, DynamicRegistries.func_239770_b_(), Minecraft::func_238180_a_, Minecraft::func_238181_a_, false, Minecraft.WorldSelectionType.BACKUP);
   }

   public void func_238192_a_(String p_238192_1_, WorldSettings p_238192_2_, DynamicRegistries.Impl p_238192_3_, DimensionGeneratorSettings p_238192_4_) {
      this.func_238195_a_(p_238192_1_, p_238192_3_, (p_238179_1_) -> {
         return p_238192_2_.func_234958_g_();
      }, (p_238187_3_, p_238187_4_, p_238187_5_, p_238187_6_) -> {
         WorldGenSettingsExport<JsonElement> worldgensettingsexport = WorldGenSettingsExport.func_240896_a_(JsonOps.INSTANCE, p_238192_3_);
         WorldSettingsImport<JsonElement> worldsettingsimport = WorldSettingsImport.func_244335_a(JsonOps.INSTANCE, p_238187_5_, p_238192_3_);
         DataResult<DimensionGeneratorSettings> dataresult = DimensionGeneratorSettings.field_236201_a_.encodeStart(worldgensettingsexport, p_238192_4_).setLifecycle(Lifecycle.stable()).flatMap((p_243209_1_) -> {
            return DimensionGeneratorSettings.field_236201_a_.parse(worldsettingsimport, p_243209_1_);
         });
         DimensionGeneratorSettings dimensiongeneratorsettings = dataresult.resultOrPartial(Util.func_240982_a_("Error reading worldgen settings after loading data packs: ", field_147123_G::error)).orElse(p_238192_4_);
         return new ServerWorldInfo(p_238192_2_, dimensiongeneratorsettings, dataresult.lifecycle());
      }, false, Minecraft.WorldSelectionType.CREATE);
   }

   private void func_238195_a_(String p_238195_1_, DynamicRegistries.Impl p_238195_2_, Function<SaveFormat.LevelSave, DatapackCodec> p_238195_3_, Function4<SaveFormat.LevelSave, DynamicRegistries.Impl, IResourceManager, DatapackCodec, IServerConfiguration> p_238195_4_, boolean p_238195_5_, Minecraft.WorldSelectionType p_238195_6_) {
      SaveFormat.LevelSave saveformat$levelsave;
      try {
         saveformat$levelsave = this.field_71469_aa.func_237274_c_(p_238195_1_);
      } catch (IOException ioexception2) {
         field_147123_G.warn("Failed to read level {} data", p_238195_1_, ioexception2);
         SystemToast.func_238535_a_(this, p_238195_1_);
         this.func_147108_a((Screen)null);
         return;
      }

      Minecraft.PackManager minecraft$packmanager;
      try {
         minecraft$packmanager = this.func_238189_a_(p_238195_2_, p_238195_3_, p_238195_4_, p_238195_5_, saveformat$levelsave);
      } catch (Exception exception) {
         field_147123_G.warn("Failed to load datapacks, can't proceed with server load", (Throwable)exception);
         this.func_147108_a(new DatapackFailureScreen(() -> {
            this.func_238195_a_(p_238195_1_, p_238195_2_, p_238195_3_, p_238195_4_, true, p_238195_6_);
         }));

         try {
            saveformat$levelsave.close();
         } catch (IOException ioexception) {
            field_147123_G.warn("Failed to unlock access to level {}", p_238195_1_, ioexception);
         }

         return;
      }

      IServerConfiguration iserverconfiguration = minecraft$packmanager.func_238226_c_();
      boolean flag = iserverconfiguration.func_230418_z_().func_236229_j_();
      boolean flag1 = iserverconfiguration.func_230401_A_() != Lifecycle.stable();
      if (p_238195_6_ == Minecraft.WorldSelectionType.NONE || !flag && !flag1) {
         this.func_213254_o();
         this.field_213277_ad.set((TrackingChunkStatusListener)null);

         try {
            saveformat$levelsave.func_237287_a_(p_238195_2_, iserverconfiguration);
            minecraft$packmanager.func_238225_b_().func_240971_i_();
            YggdrasilAuthenticationService yggdrasilauthenticationservice = new YggdrasilAuthenticationService(this.field_110453_aa);
            MinecraftSessionService minecraftsessionservice = yggdrasilauthenticationservice.createMinecraftSessionService();
            GameProfileRepository gameprofilerepository = yggdrasilauthenticationservice.createProfileRepository();
            PlayerProfileCache playerprofilecache = new PlayerProfileCache(gameprofilerepository, new File(this.field_71412_D, MinecraftServer.field_152367_a.getName()));
            SkullTileEntity.func_184293_a(playerprofilecache);
            SkullTileEntity.func_184294_a(minecraftsessionservice);
            PlayerProfileCache.func_187320_a(false);
            this.field_71437_Z = MinecraftServer.func_240784_a_((p_238188_8_) -> {
               return new IntegratedServer(p_238188_8_, this, p_238195_2_, saveformat$levelsave, minecraft$packmanager.func_238224_a_(), minecraft$packmanager.func_238225_b_(), iserverconfiguration, minecraftsessionservice, gameprofilerepository, playerprofilecache, (p_238211_1_) -> {
                  TrackingChunkStatusListener trackingchunkstatuslistener = new TrackingChunkStatusListener(p_238211_1_ + 0);
                  trackingchunkstatuslistener.func_219521_a();
                  this.field_213277_ad.set(trackingchunkstatuslistener);
                  return new ChainedChunkStatusListener(trackingchunkstatuslistener, this.field_213275_aU::add);
               });
            });
            this.field_71455_al = true;
         } catch (Throwable throwable) {
            CrashReport crashreport = CrashReport.func_85055_a(throwable, "Starting integrated server");
            CrashReportCategory crashreportcategory = crashreport.func_85058_a("Starting integrated server");
            crashreportcategory.func_71507_a("Level ID", p_238195_1_);
            crashreportcategory.func_71507_a("Level Name", iserverconfiguration.func_76065_j());
            throw new ReportedException(crashreport);
         }

         while(this.field_213277_ad.get() == null) {
            Thread.yield();
         }

         WorldLoadProgressScreen worldloadprogressscreen = new WorldLoadProgressScreen(this.field_213277_ad.get());
         this.func_147108_a(worldloadprogressscreen);
         this.field_71424_I.func_76320_a("waitForServer");

         while(!this.field_71437_Z.func_71200_ad()) {
            worldloadprogressscreen.func_231023_e_();
            this.func_195542_b(false);

            try {
               Thread.sleep(16L);
            } catch (InterruptedException interruptedexception) {
            }

            if (this.field_71433_S != null) {
               func_71377_b(this.field_71433_S);
               return;
            }
         }

         this.field_71424_I.func_76319_b();
         SocketAddress socketaddress = this.field_71437_Z.func_147137_ag().func_151270_a();
         NetworkManager networkmanager = NetworkManager.func_150722_a(socketaddress);
         networkmanager.func_150719_a(new ClientLoginNetHandler(networkmanager, this, (Screen)null, (p_229998_0_) -> {
         }));
         networkmanager.func_179290_a(new CHandshakePacket(socketaddress.toString(), 0, ProtocolType.LOGIN));
         networkmanager.func_179290_a(new CLoginStartPacket(this.func_110432_I().func_148256_e()));
         this.field_71453_ak = networkmanager;
      } else {
         this.func_241559_a_(p_238195_6_, p_238195_1_, flag, () -> {
            this.func_238195_a_(p_238195_1_, p_238195_2_, p_238195_3_, p_238195_4_, p_238195_5_, Minecraft.WorldSelectionType.NONE);
         });
         minecraft$packmanager.close();

         try {
            saveformat$levelsave.close();
         } catch (IOException ioexception1) {
            field_147123_G.warn("Failed to unlock access to level {}", p_238195_1_, ioexception1);
         }

      }
   }

   private void func_241559_a_(Minecraft.WorldSelectionType p_241559_1_, String p_241559_2_, boolean p_241559_3_, Runnable p_241559_4_) {
      if (p_241559_1_ == Minecraft.WorldSelectionType.BACKUP) {
         ITextComponent itextcomponent;
         ITextComponent itextcomponent1;
         if (p_241559_3_) {
            itextcomponent = new TranslationTextComponent("selectWorld.backupQuestion.customized");
            itextcomponent1 = new TranslationTextComponent("selectWorld.backupWarning.customized");
         } else {
            itextcomponent = new TranslationTextComponent("selectWorld.backupQuestion.experimental");
            itextcomponent1 = new TranslationTextComponent("selectWorld.backupWarning.experimental");
         }

         this.func_147108_a(new ConfirmBackupScreen((Screen)null, (p_241561_3_, p_241561_4_) -> {
            if (p_241561_3_) {
               EditWorldScreen.func_241651_a_(this.field_71469_aa, p_241559_2_);
            }

            p_241559_4_.run();
         }, itextcomponent, itextcomponent1, false));
      } else {
         this.func_147108_a(new ConfirmScreen((p_241560_3_) -> {
            if (p_241560_3_) {
               p_241559_4_.run();
            } else {
               this.func_147108_a((Screen)null);

               try (SaveFormat.LevelSave saveformat$levelsave = this.field_71469_aa.func_237274_c_(p_241559_2_)) {
                  saveformat$levelsave.func_237299_g_();
               } catch (IOException ioexception) {
                  SystemToast.func_238538_b_(this, p_241559_2_);
                  field_147123_G.error("Failed to delete world {}", p_241559_2_, ioexception);
               }
            }

         }, new TranslationTextComponent("selectWorld.backupQuestion.experimental"), new TranslationTextComponent("selectWorld.backupWarning.experimental"), DialogTexts.field_240636_g_, DialogTexts.field_240633_d_));
      }

   }

   public Minecraft.PackManager func_238189_a_(DynamicRegistries.Impl p_238189_1_, Function<SaveFormat.LevelSave, DatapackCodec> p_238189_2_, Function4<SaveFormat.LevelSave, DynamicRegistries.Impl, IResourceManager, DatapackCodec, IServerConfiguration> p_238189_3_, boolean p_238189_4_, SaveFormat.LevelSave p_238189_5_) throws InterruptedException, ExecutionException {
      DatapackCodec datapackcodec = p_238189_2_.apply(p_238189_5_);
      ResourcePackList resourcepacklist = new ResourcePackList(new ServerPackFinder(), new FolderPackFinder(p_238189_5_.func_237285_a_(FolderName.field_237251_g_).toFile(), IPackNameDecorator.field_232627_c_));

      try {
         DatapackCodec datapackcodec1 = MinecraftServer.func_240772_a_(resourcepacklist, datapackcodec, p_238189_4_);
         CompletableFuture<DataPackRegistries> completablefuture = DataPackRegistries.func_240961_a_(resourcepacklist.func_232623_f_(), Commands.EnvironmentType.INTEGRATED, 2, Util.func_215072_e(), this);
         this.func_213161_c(completablefuture::isDone);
         DataPackRegistries datapackregistries = completablefuture.get();
         IServerConfiguration iserverconfiguration = p_238189_3_.apply(p_238189_5_, p_238189_1_, datapackregistries.func_240970_h_(), datapackcodec1);
         return new Minecraft.PackManager(resourcepacklist, datapackregistries, iserverconfiguration);
      } catch (ExecutionException | InterruptedException interruptedexception) {
         resourcepacklist.close();
         throw interruptedexception;
      }
   }

   public void func_71403_a(ClientWorld p_71403_1_) {
      WorkingScreen workingscreen = new WorkingScreen();
      workingscreen.func_200210_a(new TranslationTextComponent("connect.joining"));
      this.func_213241_c(workingscreen);
      this.field_71441_e = p_71403_1_;
      this.func_213257_b(p_71403_1_);
      if (!this.field_71455_al) {
         AuthenticationService authenticationservice = new YggdrasilAuthenticationService(this.field_110453_aa);
         MinecraftSessionService minecraftsessionservice = authenticationservice.createMinecraftSessionService();
         GameProfileRepository gameprofilerepository = authenticationservice.createProfileRepository();
         PlayerProfileCache playerprofilecache = new PlayerProfileCache(gameprofilerepository, new File(this.field_71412_D, MinecraftServer.field_152367_a.getName()));
         SkullTileEntity.func_184293_a(playerprofilecache);
         SkullTileEntity.func_184294_a(minecraftsessionservice);
         PlayerProfileCache.func_187320_a(false);
      }

   }

   public void func_213254_o() {
      this.func_213231_b(new WorkingScreen());
   }

   public void func_213231_b(Screen p_213231_1_) {
      ClientPlayNetHandler clientplaynethandler = this.func_147114_u();
      if (clientplaynethandler != null) {
         this.func_213159_be();
         clientplaynethandler.func_147296_c();
      }

      IntegratedServer integratedserver = this.field_71437_Z;
      this.field_71437_Z = null;
      this.field_71460_t.func_190564_k();
      this.field_71442_b = null;
      NarratorChatListener.field_193643_a.func_193642_b();
      this.func_213241_c(p_213231_1_);
      if (this.field_71441_e != null) {
         if (integratedserver != null) {
            this.field_71424_I.func_76320_a("waitForServer");

            while(!integratedserver.func_213201_w()) {
               this.func_195542_b(false);
            }

            this.field_71424_I.func_76319_b();
         }

         this.field_195554_ax.func_195749_c();
         this.field_71456_v.func_181029_i();
         this.field_71422_O = null;
         this.field_71455_al = false;
         this.field_213274_aO.func_216815_b();
      }

      this.field_71441_e = null;
      this.func_213257_b((ClientWorld)null);
      this.field_71439_g = null;
   }

   private void func_213241_c(Screen p_213241_1_) {
      this.field_71424_I.func_76320_a("forcedTick");
      this.field_147127_av.func_147690_c();
      this.field_175622_Z = null;
      this.field_71453_ak = null;
      this.func_147108_a(p_213241_1_);
      this.func_195542_b(false);
      this.field_71424_I.func_76319_b();
   }

   public void func_241562_c_(Screen p_241562_1_) {
      this.field_71424_I.func_76320_a("forcedTick");
      this.func_147108_a(p_241562_1_);
      this.func_195542_b(false);
      this.field_71424_I.func_76319_b();
   }

   private void func_213257_b(@Nullable ClientWorld p_213257_1_) {
      this.field_71438_f.func_72732_a(p_213257_1_);
      this.field_71452_i.func_78870_a(p_213257_1_);
      TileEntityRendererDispatcher.field_147556_a.func_147543_a(p_213257_1_);
      this.func_230150_b_();
   }

   public boolean func_238216_r_() {
      return this.field_238175_ae_ && this.field_244734_au.serversAllowed();
   }

   public boolean func_238198_a_(UUID p_238198_1_) {
      if (this.func_238217_s_()) {
         return this.field_244597_aC.func_244756_c(p_238198_1_);
      } else {
         return (this.field_71439_g == null || !p_238198_1_.equals(this.field_71439_g.func_110124_au())) && !p_238198_1_.equals(Util.field_240973_b_);
      }
   }

   public boolean func_238217_s_() {
      return this.field_238176_af_ && this.field_244734_au.chatAllowed();
   }

   public final boolean func_71355_q() {
      return this.field_71459_aj;
   }

   @Nullable
   public ClientPlayNetHandler func_147114_u() {
      return this.field_71439_g == null ? null : this.field_71439_g.field_71174_a;
   }

   public static boolean func_71382_s() {
      return !field_71432_P.field_71474_y.field_74319_N;
   }

   public static boolean func_71375_t() {
      return field_71432_P.field_71474_y.field_238330_f_.func_238162_a_() >= GraphicsFanciness.FANCY.func_238162_a_();
   }

   public static boolean func_238218_y_() {
      return field_71432_P.field_71474_y.field_238330_f_.func_238162_a_() >= GraphicsFanciness.FABULOUS.func_238162_a_();
   }

   public static boolean func_71379_u() {
      return field_71432_P.field_71474_y.field_74348_k != AmbientOcclusionStatus.OFF;
   }

   private void func_147112_ai() {
      if (this.field_71476_x != null && this.field_71476_x.func_216346_c() != RayTraceResult.Type.MISS) {
         boolean flag = this.field_71439_g.field_71075_bZ.field_75098_d;
         TileEntity tileentity = null;
         RayTraceResult.Type raytraceresult$type = this.field_71476_x.func_216346_c();
         ItemStack itemstack;
         if (raytraceresult$type == RayTraceResult.Type.BLOCK) {
            BlockPos blockpos = ((BlockRayTraceResult)this.field_71476_x).func_216350_a();
            BlockState blockstate = this.field_71441_e.func_180495_p(blockpos);
            Block block = blockstate.func_177230_c();
            if (blockstate.func_196958_f()) {
               return;
            }

            itemstack = block.func_185473_a(this.field_71441_e, blockpos, blockstate);
            if (itemstack.func_190926_b()) {
               return;
            }

            if (flag && Screen.func_231172_r_() && block.func_235695_q_()) {
               tileentity = this.field_71441_e.func_175625_s(blockpos);
            }
         } else {
            if (raytraceresult$type != RayTraceResult.Type.ENTITY || !flag) {
               return;
            }

            Entity entity = ((EntityRayTraceResult)this.field_71476_x).func_216348_a();
            if (entity instanceof PaintingEntity) {
               itemstack = new ItemStack(Items.field_151159_an);
            } else if (entity instanceof LeashKnotEntity) {
               itemstack = new ItemStack(Items.field_151058_ca);
            } else if (entity instanceof ItemFrameEntity) {
               ItemFrameEntity itemframeentity = (ItemFrameEntity)entity;
               ItemStack itemstack1 = itemframeentity.func_82335_i();
               if (itemstack1.func_190926_b()) {
                  itemstack = new ItemStack(Items.field_151160_bD);
               } else {
                  itemstack = itemstack1.func_77946_l();
               }
            } else if (entity instanceof AbstractMinecartEntity) {
               AbstractMinecartEntity abstractminecartentity = (AbstractMinecartEntity)entity;
               Item item;
               switch(abstractminecartentity.func_184264_v()) {
               case FURNACE:
                  item = Items.field_151109_aJ;
                  break;
               case CHEST:
                  item = Items.field_151108_aI;
                  break;
               case TNT:
                  item = Items.field_151142_bV;
                  break;
               case HOPPER:
                  item = Items.field_151140_bW;
                  break;
               case COMMAND_BLOCK:
                  item = Items.field_151095_cc;
                  break;
               default:
                  item = Items.field_151143_au;
               }

               itemstack = new ItemStack(item);
            } else if (entity instanceof BoatEntity) {
               itemstack = new ItemStack(((BoatEntity)entity).func_184455_j());
            } else if (entity instanceof ArmorStandEntity) {
               itemstack = new ItemStack(Items.field_179565_cj);
            } else if (entity instanceof EnderCrystalEntity) {
               itemstack = new ItemStack(Items.field_185158_cP);
            } else {
               SpawnEggItem spawneggitem = SpawnEggItem.func_200889_b(entity.func_200600_R());
               if (spawneggitem == null) {
                  return;
               }

               itemstack = new ItemStack(spawneggitem);
            }
         }

         if (itemstack.func_190926_b()) {
            String s = "";
            if (raytraceresult$type == RayTraceResult.Type.BLOCK) {
               s = Registry.field_212618_g.func_177774_c(this.field_71441_e.func_180495_p(((BlockRayTraceResult)this.field_71476_x).func_216350_a()).func_177230_c()).toString();
            } else if (raytraceresult$type == RayTraceResult.Type.ENTITY) {
               s = Registry.field_212629_r.func_177774_c(((EntityRayTraceResult)this.field_71476_x).func_216348_a().func_200600_R()).toString();
            }

            field_147123_G.warn("Picking on: [{}] {} gave null item", raytraceresult$type, s);
         } else {
            PlayerInventory playerinventory = this.field_71439_g.field_71071_by;
            if (tileentity != null) {
               this.func_184119_a(itemstack, tileentity);
            }

            int i = playerinventory.func_184429_b(itemstack);
            if (flag) {
               playerinventory.func_184434_a(itemstack);
               this.field_71442_b.func_78761_a(this.field_71439_g.func_184586_b(Hand.MAIN_HAND), 36 + playerinventory.field_70461_c);
            } else if (i != -1) {
               if (PlayerInventory.func_184435_e(i)) {
                  playerinventory.field_70461_c = i;
               } else {
                  this.field_71442_b.func_187100_a(i);
               }
            }

         }
      }
   }

   private ItemStack func_184119_a(ItemStack p_184119_1_, TileEntity p_184119_2_) {
      CompoundNBT compoundnbt = p_184119_2_.func_189515_b(new CompoundNBT());
      if (p_184119_1_.func_77973_b() instanceof SkullItem && compoundnbt.func_74764_b("SkullOwner")) {
         CompoundNBT compoundnbt2 = compoundnbt.func_74775_l("SkullOwner");
         p_184119_1_.func_196082_o().func_218657_a("SkullOwner", compoundnbt2);
         return p_184119_1_;
      } else {
         p_184119_1_.func_77983_a("BlockEntityTag", compoundnbt);
         CompoundNBT compoundnbt1 = new CompoundNBT();
         ListNBT listnbt = new ListNBT();
         listnbt.add(StringNBT.func_229705_a_("\"(+NBT)\""));
         compoundnbt1.func_218657_a("Lore", listnbt);
         p_184119_1_.func_77983_a("display", compoundnbt1);
         return p_184119_1_;
      }
   }

   public CrashReport func_71396_d(CrashReport p_71396_1_) {
      func_228009_a_(this.field_135017_as, this.field_110447_Z, this.field_71474_y, p_71396_1_);
      if (this.field_71441_e != null) {
         this.field_71441_e.func_72914_a(p_71396_1_);
      }

      return p_71396_1_;
   }

   public static void func_228009_a_(@Nullable LanguageManager p_228009_0_, String p_228009_1_, @Nullable GameSettings p_228009_2_, CrashReport p_228009_3_) {
      CrashReportCategory crashreportcategory = p_228009_3_.func_85056_g();
      crashreportcategory.func_189529_a("Launched Version", () -> {
         return p_228009_1_;
      });
      crashreportcategory.func_189529_a("Backend library", RenderSystem::getBackendDescription);
      crashreportcategory.func_189529_a("Backend API", RenderSystem::getApiDescription);
      crashreportcategory.func_189529_a("GL Caps", RenderSystem::getCapsString);
      crashreportcategory.func_189529_a("Using VBOs", () -> {
         return "Yes";
      });
      crashreportcategory.func_189529_a("Is Modded", () -> {
         String s1 = ClientBrandRetriever.getClientModName();
         if (!"vanilla".equals(s1)) {
            return "Definitely; Client brand changed to '" + s1 + "'";
         } else {
            return Minecraft.class.getSigners() == null ? "Very likely; Jar signature invalidated" : "Probably not. Jar signature remains and client brand is untouched.";
         }
      });
      crashreportcategory.func_71507_a("Type", "Client (map_client.txt)");
      if (p_228009_2_ != null) {
         if (field_71432_P != null) {
            String s = field_71432_P.func_241558_U_().func_243499_m();
            if (s != null) {
               crashreportcategory.func_71507_a("GPU Warnings", s);
            }
         }

         crashreportcategory.func_71507_a("Graphics mode", p_228009_2_.field_238330_f_);
         crashreportcategory.func_189529_a("Resource Packs", () -> {
            StringBuilder stringbuilder = new StringBuilder();

            for(String s1 : p_228009_2_.field_151453_l) {
               if (stringbuilder.length() > 0) {
                  stringbuilder.append(", ");
               }

               stringbuilder.append(s1);
               if (p_228009_2_.field_183018_l.contains(s1)) {
                  stringbuilder.append(" (incompatible)");
               }
            }

            return stringbuilder.toString();
         });
      }

      if (p_228009_0_ != null) {
         crashreportcategory.func_189529_a("Current Language", () -> {
            return p_228009_0_.func_135041_c().toString();
         });
      }

      crashreportcategory.func_189529_a("CPU", PlatformDescriptors::func_227775_b_);
   }

   public static Minecraft func_71410_x() {
      return field_71432_P;
   }

   public CompletableFuture<Void> func_213245_w() {
      return this.func_213169_a(this::func_213237_g).thenCompose((p_229993_0_) -> {
         return p_229993_0_;
      });
   }

   public void func_70000_a(Snooper p_70000_1_) {
      p_70000_1_.func_152768_a("fps", field_71470_ab);
      p_70000_1_.func_152768_a("vsync_enabled", this.field_71474_y.field_74352_v);
      p_70000_1_.func_152768_a("display_frequency", this.field_195558_d.func_227798_a_());
      p_70000_1_.func_152768_a("display_type", this.field_195558_d.func_198113_j() ? "fullscreen" : "windowed");
      p_70000_1_.func_152768_a("run_time", (Util.func_211177_b() - p_70000_1_.func_130105_g()) / 60L * 1000L);
      p_70000_1_.func_152768_a("current_action", this.func_181538_aA());
      p_70000_1_.func_152768_a("language", this.field_71474_y.field_74363_ab == null ? "en_us" : this.field_71474_y.field_74363_ab);
      String s = ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN ? "little" : "big";
      p_70000_1_.func_152768_a("endianness", s);
      p_70000_1_.func_152768_a("subtitles", this.field_71474_y.field_186717_N);
      p_70000_1_.func_152768_a("touch", this.field_71474_y.field_85185_A ? "touch" : "mouse");
      int i = 0;

      for(ResourcePackInfo resourcepackinfo : this.field_110448_aq.func_198980_d()) {
         if (!resourcepackinfo.func_195797_g() && !resourcepackinfo.func_195798_h()) {
            p_70000_1_.func_152768_a("resource_pack[" + i++ + "]", resourcepackinfo.func_195790_f());
         }
      }

      p_70000_1_.func_152768_a("resource_packs", i);
      if (this.field_71437_Z != null) {
         p_70000_1_.func_152768_a("snooper_partner", this.field_71437_Z.func_80003_ah().func_80006_f());
      }

   }

   private String func_181538_aA() {
      if (this.field_71437_Z != null) {
         return this.field_71437_Z.func_71344_c() ? "hosting_lan" : "singleplayer";
      } else if (this.field_71422_O != null) {
         return this.field_71422_O.func_181041_d() ? "playing_lan" : "multiplayer";
      } else {
         return "out_of_game";
      }
   }

   public void func_71351_a(@Nullable ServerData p_71351_1_) {
      this.field_71422_O = p_71351_1_;
   }

   @Nullable
   public ServerData func_147104_D() {
      return this.field_71422_O;
   }

   public boolean func_71387_A() {
      return this.field_71455_al;
   }

   public boolean func_71356_B() {
      return this.field_71455_al && this.field_71437_Z != null;
   }

   @Nullable
   public IntegratedServer func_71401_C() {
      return this.field_71437_Z;
   }

   public Snooper func_71378_E() {
      return this.field_71427_U;
   }

   public Session func_110432_I() {
      return this.field_71449_j;
   }

   public PropertyMap func_181037_M() {
      if (this.field_181038_N.isEmpty()) {
         GameProfile gameprofile = this.func_152347_ac().fillProfileProperties(this.field_71449_j.func_148256_e(), false);
         this.field_181038_N.putAll(gameprofile.getProperties());
      }

      return this.field_181038_N;
   }

   public Proxy func_110437_J() {
      return this.field_110453_aa;
   }

   public TextureManager func_110434_K() {
      return this.field_71446_o;
   }

   public IResourceManager func_195551_G() {
      return this.field_110451_am;
   }

   public ResourcePackList func_195548_H() {
      return this.field_110448_aq;
   }

   public DownloadingPackFinder func_195541_I() {
      return this.field_195554_ax;
   }

   public File func_195549_J() {
      return this.field_130070_K;
   }

   public LanguageManager func_135016_M() {
      return this.field_135017_as;
   }

   public Function<ResourceLocation, TextureAtlasSprite> func_228015_a_(ResourceLocation p_228015_1_) {
      return this.field_175617_aL.func_229356_a_(p_228015_1_)::func_195424_a;
   }

   public boolean func_147111_S() {
      return this.field_147129_ai;
   }

   public boolean func_147113_T() {
      return this.field_71445_n;
   }

   public GPUWarning func_241558_U_() {
      return this.field_241557_ar_;
   }

   public SoundHandler func_147118_V() {
      return this.field_147127_av;
   }

   public BackgroundMusicSelector func_238178_U_() {
      if (this.field_71462_r instanceof WinGameScreen) {
         return BackgroundMusicTracks.field_232672_c_;
      } else if (this.field_71439_g != null) {
         if (this.field_71439_g.field_70170_p.func_234923_W_() == World.field_234920_i_) {
            return this.field_71456_v.func_184046_j().func_184054_d() ? BackgroundMusicTracks.field_232673_d_ : BackgroundMusicTracks.field_232674_e_;
         } else {
            Biome.Category biome$category = this.field_71439_g.field_70170_p.func_226691_t_(this.field_71439_g.func_233580_cy_()).func_201856_r();
            if (!this.field_147126_aw.func_239540_b_(BackgroundMusicTracks.field_232675_f_) && (!this.field_71439_g.func_204231_K() || biome$category != Biome.Category.OCEAN && biome$category != Biome.Category.RIVER)) {
               return this.field_71439_g.field_70170_p.func_234923_W_() != World.field_234919_h_ && this.field_71439_g.field_71075_bZ.field_75098_d && this.field_71439_g.field_71075_bZ.field_75101_c ? BackgroundMusicTracks.field_232671_b_ : this.field_71441_e.func_225523_d_().func_235201_b_(this.field_71439_g.func_233580_cy_()).func_235094_x_().orElse(BackgroundMusicTracks.field_232676_g_);
            } else {
               return BackgroundMusicTracks.field_232675_f_;
            }
         }
      } else {
         return BackgroundMusicTracks.field_232670_a_;
      }
   }

   public MinecraftSessionService func_152347_ac() {
      return this.field_152355_az;
   }

   public SkinManager func_152342_ad() {
      return this.field_152350_aA;
   }

   @Nullable
   public Entity func_175606_aa() {
      return this.field_175622_Z;
   }

   public void func_175607_a(Entity p_175607_1_) {
      this.field_175622_Z = p_175607_1_;
      this.field_71460_t.func_175066_a(p_175607_1_);
   }

   public boolean func_238206_b_(Entity p_238206_1_) {
      return p_238206_1_.func_225510_bt_() || this.field_71439_g != null && this.field_71439_g.func_175149_v() && this.field_71474_y.field_178883_an.func_151470_d() && p_238206_1_.func_200600_R() == EntityType.field_200729_aH;
   }

   protected Thread func_213170_ax() {
      return this.field_152352_aC;
   }

   protected Runnable func_212875_d_(Runnable p_212875_1_) {
      return p_212875_1_;
   }

   protected boolean func_212874_c_(Runnable p_212874_1_) {
      return true;
   }

   public BlockRendererDispatcher func_175602_ab() {
      return this.field_175618_aM;
   }

   public EntityRendererManager func_175598_ae() {
      return this.field_175616_W;
   }

   public ItemRenderer func_175599_af() {
      return this.field_175621_X;
   }

   public FirstPersonRenderer func_175597_ag() {
      return this.field_175620_Y;
   }

   public <T> IMutableSearchTree<T> func_213253_a(SearchTreeManager.Key<T> p_213253_1_) {
      return this.field_193995_ae.func_215358_a(p_213253_1_);
   }

   public FrameTimer func_181539_aj() {
      return this.field_181542_y;
   }

   public boolean func_181540_al() {
      return this.field_181541_X;
   }

   public void func_181537_a(boolean p_181537_1_) {
      this.field_181541_X = p_181537_1_;
   }

   public DataFixer func_184126_aj() {
      return this.field_184131_U;
   }

   public float func_184121_ak() {
      return this.field_71428_T.field_194147_b;
   }

   public float func_193989_ak() {
      return this.field_71428_T.field_194148_c;
   }

   public BlockColors func_184125_al() {
      return this.field_184127_aH;
   }

   public boolean func_189648_am() {
      return this.field_71439_g != null && this.field_71439_g.func_175140_cp() || this.field_71474_y.field_178879_v;
   }

   public ToastGui func_193033_an() {
      return this.field_193034_aS;
   }

   public Tutorial func_193032_ao() {
      return this.field_193035_aW;
   }

   public boolean func_195544_aj() {
      return this.field_195555_I;
   }

   public CreativeSettings func_199403_al() {
      return this.field_191950_u;
   }

   public ModelManager func_209506_al() {
      return this.field_175617_aL;
   }

   public PaintingSpriteUploader func_213263_ao() {
      return this.field_213272_aL;
   }

   public PotionSpriteUploader func_213248_ap() {
      return this.field_213273_aM;
   }

   public void func_213228_a(boolean p_213228_1_) {
      this.field_195555_I = p_213228_1_;
   }

   public IProfiler func_213239_aq() {
      return this.field_71424_I;
   }

   public MinecraftGame func_213229_ar() {
      return this.field_213274_aO;
   }

   public Splashes func_213269_at() {
      return this.field_213271_aF;
   }

   @Nullable
   public LoadingGui func_213250_au() {
      return this.field_213279_p;
   }

   public FilterManager func_244599_aA() {
      return this.field_244597_aC;
   }

   public boolean func_228017_as_() {
      return false;
   }

   public MainWindow func_228018_at_() {
      return this.field_195558_d;
   }

   public RenderTypeBuffers func_228019_au_() {
      return this.field_228006_P_;
   }

   private static ResourcePackInfo func_228011_a_(String p_228011_0_, boolean p_228011_1_, Supplier<IResourcePack> p_228011_2_, IResourcePack p_228011_3_, PackMetadataSection p_228011_4_, ResourcePackInfo.Priority p_228011_5_, IPackNameDecorator p_228011_6_) {
      int i = p_228011_4_.func_198962_b();
      Supplier<IResourcePack> supplier = p_228011_2_;
      if (i <= 3) {
         supplier = func_228021_b_(p_228011_2_);
      }

      if (i <= 4) {
         supplier = func_228022_c_(supplier);
      }

      return new ResourcePackInfo(p_228011_0_, p_228011_1_, supplier, p_228011_3_, p_228011_4_, p_228011_5_, p_228011_6_);
   }

   private static Supplier<IResourcePack> func_228021_b_(Supplier<IResourcePack> p_228021_0_) {
      return () -> {
         return new LegacyResourcePackWrapper(p_228021_0_.get(), LegacyResourcePackWrapper.field_211853_a);
      };
   }

   private static Supplier<IResourcePack> func_228022_c_(Supplier<IResourcePack> p_228022_0_) {
      return () -> {
         return new LegacyResourcePackWrapperV4(p_228022_0_.get());
      };
   }

   public void func_228020_b_(int p_228020_1_) {
      this.field_175617_aL.func_229355_a_(p_228020_1_);
   }

   @OnlyIn(Dist.CLIENT)
   public static final class PackManager implements AutoCloseable {
      private final ResourcePackList field_238221_a_;
      private final DataPackRegistries field_238222_b_;
      private final IServerConfiguration field_238223_c_;

      private PackManager(ResourcePackList p_i232241_1_, DataPackRegistries p_i232241_2_, IServerConfiguration p_i232241_3_) {
         this.field_238221_a_ = p_i232241_1_;
         this.field_238222_b_ = p_i232241_2_;
         this.field_238223_c_ = p_i232241_3_;
      }

      public ResourcePackList func_238224_a_() {
         return this.field_238221_a_;
      }

      public DataPackRegistries func_238225_b_() {
         return this.field_238222_b_;
      }

      public IServerConfiguration func_238226_c_() {
         return this.field_238223_c_;
      }

      public void close() {
         this.field_238221_a_.close();
         this.field_238222_b_.close();
      }
   }

   @OnlyIn(Dist.CLIENT)
   static enum WorldSelectionType {
      NONE,
      CREATE,
      BACKUP;
   }
}
