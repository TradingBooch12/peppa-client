package net.minecraft.client.gui;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class ChatLine<T> {
   private final int field_74543_a;
   private final T field_74541_b;
   private final int field_74542_c;

   public ChatLine(int p_i242050_1_, T p_i242050_2_, int p_i242050_3_) {
      this.field_74541_b = p_i242050_2_;
      this.field_74543_a = p_i242050_1_;
      this.field_74542_c = p_i242050_3_;
   }

   public T func_238169_a_() {
      return this.field_74541_b;
   }

   public int func_74540_b() {
      return this.field_74543_a;
   }

   public int func_74539_c() {
      return this.field_74542_c;
   }
}
