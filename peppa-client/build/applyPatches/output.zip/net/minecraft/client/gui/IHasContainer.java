package net.minecraft.client.gui;

import net.minecraft.inventory.container.Container;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public interface IHasContainer<T extends Container> {
   T func_212873_a_();
}
