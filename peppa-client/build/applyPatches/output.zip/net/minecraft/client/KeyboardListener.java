package net.minecraft.client;

import java.util.Locale;
import javax.annotation.Nullable;
import net.minecraft.block.BlockState;
import net.minecraft.client.gui.IGuiEventListener;
import net.minecraft.client.gui.INestedGuiEventHandler;
import net.minecraft.client.gui.NewChatGui;
import net.minecraft.client.gui.screen.ControlsScreen;
import net.minecraft.client.gui.screen.GamemodeSelectionScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.WithNarratorSettingsScreen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.play.ClientPlayNetHandler;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.client.util.InputMappings;
import net.minecraft.client.util.NativeUtil;
import net.minecraft.command.arguments.BlockStateParser;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.ReportedException;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.ScreenShotHelper;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.EntityRayTraceResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.registry.Registry;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class KeyboardListener {
   private final Minecraft field_197972_a;
   private boolean field_197973_b;
   private final ClipboardHelper field_216821_c = new ClipboardHelper();
   private long field_197974_c = -1L;
   private long field_204871_d = -1L;
   private long field_204872_e = -1L;
   private boolean field_197975_d;

   public KeyboardListener(Minecraft p_i47674_1_) {
      this.field_197972_a = p_i47674_1_;
   }

   private void func_197964_a(String p_197964_1_, Object... p_197964_2_) {
      this.field_197972_a.field_71456_v.func_146158_b().func_146227_a((new StringTextComponent("")).func_230529_a_((new TranslationTextComponent("debug.prefix")).func_240701_a_(new TextFormatting[]{TextFormatting.YELLOW, TextFormatting.BOLD})).func_240702_b_(" ").func_230529_a_(new TranslationTextComponent(p_197964_1_, p_197964_2_)));
   }

   private void func_204869_b(String p_204869_1_, Object... p_204869_2_) {
      this.field_197972_a.field_71456_v.func_146158_b().func_146227_a((new StringTextComponent("")).func_230529_a_((new TranslationTextComponent("debug.prefix")).func_240701_a_(new TextFormatting[]{TextFormatting.RED, TextFormatting.BOLD})).func_240702_b_(" ").func_230529_a_(new TranslationTextComponent(p_204869_1_, p_204869_2_)));
   }

   private boolean func_197962_c(int p_197962_1_) {
      if (this.field_197974_c > 0L && this.field_197974_c < Util.func_211177_b() - 100L) {
         return true;
      } else {
         switch(p_197962_1_) {
         case 65:
            this.field_197972_a.field_71438_f.func_72712_a();
            this.func_197964_a("debug.reload_chunks.message");
            return true;
         case 66:
            boolean flag = !this.field_197972_a.func_175598_ae().func_178634_b();
            this.field_197972_a.func_175598_ae().func_178629_b(flag);
            this.func_197964_a(flag ? "debug.show_hitboxes.on" : "debug.show_hitboxes.off");
            return true;
         case 67:
            if (this.field_197972_a.field_71439_g.func_175140_cp()) {
               return false;
            } else {
               ClientPlayNetHandler clientplaynethandler = this.field_197972_a.field_71439_g.field_71174_a;
               if (clientplaynethandler == null) {
                  return false;
               }

               this.func_197964_a("debug.copy_location.message");
               this.func_197960_a(String.format(Locale.ROOT, "/execute in %s run tp @s %.2f %.2f %.2f %.2f %.2f", this.field_197972_a.field_71439_g.field_70170_p.func_234923_W_().func_240901_a_(), this.field_197972_a.field_71439_g.func_226277_ct_(), this.field_197972_a.field_71439_g.func_226278_cu_(), this.field_197972_a.field_71439_g.func_226281_cx_(), this.field_197972_a.field_71439_g.field_70177_z, this.field_197972_a.field_71439_g.field_70125_A));
               return true;
            }
         case 68:
            if (this.field_197972_a.field_71456_v != null) {
               this.field_197972_a.field_71456_v.func_146158_b().func_146231_a(false);
            }

            return true;
         case 70:
            AbstractOption.field_216706_m.func_216727_a(this.field_197972_a.field_71474_y, MathHelper.func_151237_a((double)(this.field_197972_a.field_71474_y.field_151451_c + (Screen.func_231173_s_() ? -1 : 1)), AbstractOption.field_216706_m.func_216732_b(), AbstractOption.field_216706_m.func_216733_c()));
            this.func_197964_a("debug.cycle_renderdistance.message", this.field_197972_a.field_71474_y.field_151451_c);
            return true;
         case 71:
            boolean flag1 = this.field_197972_a.field_184132_p.func_190075_b();
            this.func_197964_a(flag1 ? "debug.chunk_boundaries.on" : "debug.chunk_boundaries.off");
            return true;
         case 72:
            this.field_197972_a.field_71474_y.field_82882_x = !this.field_197972_a.field_71474_y.field_82882_x;
            this.func_197964_a(this.field_197972_a.field_71474_y.field_82882_x ? "debug.advanced_tooltips.on" : "debug.advanced_tooltips.off");
            this.field_197972_a.field_71474_y.func_74303_b();
            return true;
         case 73:
            if (!this.field_197972_a.field_71439_g.func_175140_cp()) {
               this.func_211556_a(this.field_197972_a.field_71439_g.func_211513_k(2), !Screen.func_231173_s_());
            }

            return true;
         case 78:
            if (!this.field_197972_a.field_71439_g.func_211513_k(2)) {
               this.func_197964_a("debug.creative_spectator.error");
            } else if (!this.field_197972_a.field_71439_g.func_175149_v()) {
               this.field_197972_a.field_71439_g.func_71165_d("/gamemode spectator");
            } else {
               this.field_197972_a.field_71439_g.func_71165_d("/gamemode " + this.field_197972_a.field_71442_b.func_241822_k().func_77149_b());
            }

            return true;
         case 80:
            this.field_197972_a.field_71474_y.field_82881_y = !this.field_197972_a.field_71474_y.field_82881_y;
            this.field_197972_a.field_71474_y.func_74303_b();
            this.func_197964_a(this.field_197972_a.field_71474_y.field_82881_y ? "debug.pause_focus.on" : "debug.pause_focus.off");
            return true;
         case 81:
            this.func_197964_a("debug.help.message");
            NewChatGui newchatgui = this.field_197972_a.field_71456_v.func_146158_b();
            newchatgui.func_146227_a(new TranslationTextComponent("debug.reload_chunks.help"));
            newchatgui.func_146227_a(new TranslationTextComponent("debug.show_hitboxes.help"));
            newchatgui.func_146227_a(new TranslationTextComponent("debug.copy_location.help"));
            newchatgui.func_146227_a(new TranslationTextComponent("debug.clear_chat.help"));
            newchatgui.func_146227_a(new TranslationTextComponent("debug.cycle_renderdistance.help"));
            newchatgui.func_146227_a(new TranslationTextComponent("debug.chunk_boundaries.help"));
            newchatgui.func_146227_a(new TranslationTextComponent("debug.advanced_tooltips.help"));
            newchatgui.func_146227_a(new TranslationTextComponent("debug.inspect.help"));
            newchatgui.func_146227_a(new TranslationTextComponent("debug.creative_spectator.help"));
            newchatgui.func_146227_a(new TranslationTextComponent("debug.pause_focus.help"));
            newchatgui.func_146227_a(new TranslationTextComponent("debug.help.help"));
            newchatgui.func_146227_a(new TranslationTextComponent("debug.reload_resourcepacks.help"));
            newchatgui.func_146227_a(new TranslationTextComponent("debug.pause.help"));
            newchatgui.func_146227_a(new TranslationTextComponent("debug.gamemodes.help"));
            return true;
         case 84:
            this.func_197964_a("debug.reload_resourcepacks.message");
            this.field_197972_a.func_213237_g();
            return true;
         case 293:
            if (!this.field_197972_a.field_71439_g.func_211513_k(2)) {
               this.func_197964_a("debug.gamemodes.error");
            } else {
               this.field_197972_a.func_147108_a(new GamemodeSelectionScreen());
            }

            return true;
         default:
            return false;
         }
      }
   }

   private void func_211556_a(boolean p_211556_1_, boolean p_211556_2_) {
      RayTraceResult raytraceresult = this.field_197972_a.field_71476_x;
      if (raytraceresult != null) {
         switch(raytraceresult.func_216346_c()) {
         case BLOCK:
            BlockPos blockpos = ((BlockRayTraceResult)raytraceresult).func_216350_a();
            BlockState blockstate = this.field_197972_a.field_71439_g.field_70170_p.func_180495_p(blockpos);
            if (p_211556_1_) {
               if (p_211556_2_) {
                  this.field_197972_a.field_71439_g.field_71174_a.func_211523_k().func_211547_a(blockpos, (p_211561_3_) -> {
                     this.func_211558_a(blockstate, blockpos, p_211561_3_);
                     this.func_197964_a("debug.inspect.server.block");
                  });
               } else {
                  TileEntity tileentity = this.field_197972_a.field_71439_g.field_70170_p.func_175625_s(blockpos);
                  CompoundNBT compoundnbt1 = tileentity != null ? tileentity.func_189515_b(new CompoundNBT()) : null;
                  this.func_211558_a(blockstate, blockpos, compoundnbt1);
                  this.func_197964_a("debug.inspect.client.block");
               }
            } else {
               this.func_211558_a(blockstate, blockpos, (CompoundNBT)null);
               this.func_197964_a("debug.inspect.client.block");
            }
            break;
         case ENTITY:
            Entity entity = ((EntityRayTraceResult)raytraceresult).func_216348_a();
            ResourceLocation resourcelocation = Registry.field_212629_r.func_177774_c(entity.func_200600_R());
            if (p_211556_1_) {
               if (p_211556_2_) {
                  this.field_197972_a.field_71439_g.field_71174_a.func_211523_k().func_211549_a(entity.func_145782_y(), (p_227999_3_) -> {
                     this.func_211557_a(resourcelocation, entity.func_213303_ch(), p_227999_3_);
                     this.func_197964_a("debug.inspect.server.entity");
                  });
               } else {
                  CompoundNBT compoundnbt = entity.func_189511_e(new CompoundNBT());
                  this.func_211557_a(resourcelocation, entity.func_213303_ch(), compoundnbt);
                  this.func_197964_a("debug.inspect.client.entity");
               }
            } else {
               this.func_211557_a(resourcelocation, entity.func_213303_ch(), (CompoundNBT)null);
               this.func_197964_a("debug.inspect.client.entity");
            }
         }

      }
   }

   private void func_211558_a(BlockState p_211558_1_, BlockPos p_211558_2_, @Nullable CompoundNBT p_211558_3_) {
      if (p_211558_3_ != null) {
         p_211558_3_.func_82580_o("x");
         p_211558_3_.func_82580_o("y");
         p_211558_3_.func_82580_o("z");
         p_211558_3_.func_82580_o("id");
      }

      StringBuilder stringbuilder = new StringBuilder(BlockStateParser.func_197247_a(p_211558_1_));
      if (p_211558_3_ != null) {
         stringbuilder.append((Object)p_211558_3_);
      }

      String s = String.format(Locale.ROOT, "/setblock %d %d %d %s", p_211558_2_.func_177958_n(), p_211558_2_.func_177956_o(), p_211558_2_.func_177952_p(), stringbuilder);
      this.func_197960_a(s);
   }

   private void func_211557_a(ResourceLocation p_211557_1_, Vector3d p_211557_2_, @Nullable CompoundNBT p_211557_3_) {
      String s;
      if (p_211557_3_ != null) {
         p_211557_3_.func_82580_o("UUID");
         p_211557_3_.func_82580_o("Pos");
         p_211557_3_.func_82580_o("Dimension");
         String s1 = p_211557_3_.func_197637_c().getString();
         s = String.format(Locale.ROOT, "/summon %s %.2f %.2f %.2f %s", p_211557_1_.toString(), p_211557_2_.field_72450_a, p_211557_2_.field_72448_b, p_211557_2_.field_72449_c, s1);
      } else {
         s = String.format(Locale.ROOT, "/summon %s %.2f %.2f %.2f", p_211557_1_.toString(), p_211557_2_.field_72450_a, p_211557_2_.field_72448_b, p_211557_2_.field_72449_c);
      }

      this.func_197960_a(s);
   }

   public void func_197961_a(long p_197961_1_, int p_197961_3_, int p_197961_4_, int p_197961_5_, int p_197961_6_) {
      if (p_197961_1_ == this.field_197972_a.func_228018_at_().func_198092_i()) {
         if (this.field_197974_c > 0L) {
            if (!InputMappings.func_216506_a(Minecraft.func_71410_x().func_228018_at_().func_198092_i(), 67) || !InputMappings.func_216506_a(Minecraft.func_71410_x().func_228018_at_().func_198092_i(), 292)) {
               this.field_197974_c = -1L;
            }
         } else if (InputMappings.func_216506_a(Minecraft.func_71410_x().func_228018_at_().func_198092_i(), 67) && InputMappings.func_216506_a(Minecraft.func_71410_x().func_228018_at_().func_198092_i(), 292)) {
            this.field_197975_d = true;
            this.field_197974_c = Util.func_211177_b();
            this.field_204871_d = Util.func_211177_b();
            this.field_204872_e = 0L;
         }

         INestedGuiEventHandler inestedguieventhandler = this.field_197972_a.field_71462_r;
         if (p_197961_5_ == 1 && (!(this.field_197972_a.field_71462_r instanceof ControlsScreen) || ((ControlsScreen)inestedguieventhandler).field_152177_g <= Util.func_211177_b() - 20L)) {
            if (this.field_197972_a.field_71474_y.field_152395_am.func_197976_a(p_197961_3_, p_197961_4_)) {
               this.field_197972_a.func_228018_at_().func_198077_g();
               this.field_197972_a.field_71474_y.field_74353_u = this.field_197972_a.func_228018_at_().func_198113_j();
               this.field_197972_a.field_71474_y.func_74303_b();
               return;
            }

            if (this.field_197972_a.field_71474_y.field_151447_Z.func_197976_a(p_197961_3_, p_197961_4_)) {
               if (Screen.func_231172_r_()) {
               }

               ScreenShotHelper.func_148260_a(this.field_197972_a.field_71412_D, this.field_197972_a.func_228018_at_().func_198109_k(), this.field_197972_a.func_228018_at_().func_198091_l(), this.field_197972_a.func_147110_a(), (p_212449_1_) -> {
                  this.field_197972_a.execute(() -> {
                     this.field_197972_a.field_71456_v.func_146158_b().func_146227_a(p_212449_1_);
                  });
               });
               return;
            }
         }

         boolean flag = inestedguieventhandler == null || !(inestedguieventhandler.func_241217_q_() instanceof TextFieldWidget) || !((TextFieldWidget)inestedguieventhandler.func_241217_q_()).func_212955_f();
         if (p_197961_5_ != 0 && p_197961_3_ == 66 && Screen.func_231172_r_() && flag) {
            AbstractOption.field_216715_v.func_216722_a(this.field_197972_a.field_71474_y, 1);
            if (inestedguieventhandler instanceof WithNarratorSettingsScreen) {
               ((WithNarratorSettingsScreen)inestedguieventhandler).func_243317_i();
            }
         }

         if (inestedguieventhandler != null) {
            boolean[] aboolean = new boolean[]{false};
            Screen.func_231153_a_(() -> {
               if (p_197961_5_ != 1 && (p_197961_5_ != 2 || !this.field_197973_b)) {
                  if (p_197961_5_ == 0) {
                     aboolean[0] = inestedguieventhandler.func_223281_a_(p_197961_3_, p_197961_4_, p_197961_6_);
                  }
               } else {
                  aboolean[0] = inestedguieventhandler.func_231046_a_(p_197961_3_, p_197961_4_, p_197961_6_);
               }

            }, "keyPressed event handler", inestedguieventhandler.getClass().getCanonicalName());
            if (aboolean[0]) {
               return;
            }
         }

         if (this.field_197972_a.field_71462_r == null || this.field_197972_a.field_71462_r.field_230711_n_) {
            InputMappings.Input inputmappings$input = InputMappings.func_197954_a(p_197961_3_, p_197961_4_);
            if (p_197961_5_ == 0) {
               KeyBinding.func_197980_a(inputmappings$input, false);
               if (p_197961_3_ == 292) {
                  if (this.field_197975_d) {
                     this.field_197975_d = false;
                  } else {
                     this.field_197972_a.field_71474_y.field_74330_P = !this.field_197972_a.field_71474_y.field_74330_P;
                     this.field_197972_a.field_71474_y.field_74329_Q = this.field_197972_a.field_71474_y.field_74330_P && Screen.func_231173_s_();
                     this.field_197972_a.field_71474_y.field_181657_aC = this.field_197972_a.field_71474_y.field_74330_P && Screen.func_231174_t_();
                  }
               }
            } else {
               if (p_197961_3_ == 293 && this.field_197972_a.field_71460_t != null) {
                  this.field_197972_a.field_71460_t.func_175071_c();
               }

               boolean flag1 = false;
               if (this.field_197972_a.field_71462_r == null) {
                  if (p_197961_3_ == 256) {
                     boolean flag2 = InputMappings.func_216506_a(Minecraft.func_71410_x().func_228018_at_().func_198092_i(), 292);
                     this.field_197972_a.func_71385_j(flag2);
                  }

                  flag1 = InputMappings.func_216506_a(Minecraft.func_71410_x().func_228018_at_().func_198092_i(), 292) && this.func_197962_c(p_197961_3_);
                  this.field_197975_d |= flag1;
                  if (p_197961_3_ == 290) {
                     this.field_197972_a.field_71474_y.field_74319_N = !this.field_197972_a.field_71474_y.field_74319_N;
                  }
               }

               if (flag1) {
                  KeyBinding.func_197980_a(inputmappings$input, false);
               } else {
                  KeyBinding.func_197980_a(inputmappings$input, true);
                  KeyBinding.func_197981_a(inputmappings$input);
               }

               if (this.field_197972_a.field_71474_y.field_74329_Q && p_197961_3_ >= 48 && p_197961_3_ <= 57) {
                  this.field_197972_a.func_71383_b(p_197961_3_ - 48);
               }
            }
         }

      }
   }

   private void func_197963_a(long p_197963_1_, int p_197963_3_, int p_197963_4_) {
      if (p_197963_1_ == this.field_197972_a.func_228018_at_().func_198092_i()) {
         IGuiEventListener iguieventlistener = this.field_197972_a.field_71462_r;
         if (iguieventlistener != null && this.field_197972_a.func_213250_au() == null) {
            if (Character.charCount(p_197963_3_) == 1) {
               Screen.func_231153_a_(() -> {
                  iguieventlistener.func_231042_a_((char)p_197963_3_, p_197963_4_);
               }, "charTyped event handler", iguieventlistener.getClass().getCanonicalName());
            } else {
               for(char c0 : Character.toChars(p_197963_3_)) {
                  Screen.func_231153_a_(() -> {
                     iguieventlistener.func_231042_a_(c0, p_197963_4_);
                  }, "charTyped event handler", iguieventlistener.getClass().getCanonicalName());
               }
            }

         }
      }
   }

   public void func_197967_a(boolean p_197967_1_) {
      this.field_197973_b = p_197967_1_;
   }

   public void func_197968_a(long p_197968_1_) {
      InputMappings.func_216505_a(p_197968_1_, (p_228001_1_, p_228001_3_, p_228001_4_, p_228001_5_, p_228001_6_) -> {
         this.field_197972_a.execute(() -> {
            this.func_197961_a(p_228001_1_, p_228001_3_, p_228001_4_, p_228001_5_, p_228001_6_);
         });
      }, (p_228000_1_, p_228000_3_, p_228000_4_) -> {
         this.field_197972_a.execute(() -> {
            this.func_197963_a(p_228000_1_, p_228000_3_, p_228000_4_);
         });
      });
   }

   public String func_197965_a() {
      return this.field_216821_c.func_216487_a(this.field_197972_a.func_228018_at_().func_198092_i(), (p_227998_1_, p_227998_2_) -> {
         if (p_227998_1_ != 65545) {
            this.field_197972_a.func_228018_at_().func_198084_a(p_227998_1_, p_227998_2_);
         }

      });
   }

   public void func_197960_a(String p_197960_1_) {
      this.field_216821_c.func_216489_a(this.field_197972_a.func_228018_at_().func_198092_i(), p_197960_1_);
   }

   public void func_204870_b() {
      if (this.field_197974_c > 0L) {
         long i = Util.func_211177_b();
         long j = 10000L - (i - this.field_197974_c);
         long k = i - this.field_204871_d;
         if (j < 0L) {
            if (Screen.func_231172_r_()) {
               NativeUtil.func_216393_a();
            }

            throw new ReportedException(new CrashReport("Manually triggered debug crash", new Throwable()));
         }

         if (k >= 1000L) {
            if (this.field_204872_e == 0L) {
               this.func_197964_a("debug.crash.message");
            } else {
               this.func_204869_b("debug.crash.warning", MathHelper.func_76123_f((float)j / 1000.0F));
            }

            this.field_204871_d = i;
            ++this.field_204872_e;
         }
      }

   }
}
