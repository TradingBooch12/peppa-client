package net.minecraft.advancements;

import com.google.common.collect.Lists;
import com.mojang.brigadier.CommandDispatcher;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import net.minecraft.command.CommandSource;
import net.minecraft.command.FunctionObject;
import net.minecraft.resources.FunctionReloader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.tags.ITag;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.GameRules;

public class FunctionManager {
   private static final ResourceLocation field_200001_d = new ResourceLocation("tick");
   private static final ResourceLocation field_200222_e = new ResourceLocation("load");
   private final MinecraftServer field_193069_c;
   private boolean field_194021_h;
   private final ArrayDeque<FunctionManager.QueuedCommand> field_194020_g = new ArrayDeque<>();
   private final List<FunctionManager.QueuedCommand> field_222855_j = Lists.newArrayList();
   private final List<FunctionObject> field_200003_j = Lists.newArrayList();
   private boolean field_200223_l;
   private FunctionReloader field_240944_i_;

   public FunctionManager(MinecraftServer p_i232597_1_, FunctionReloader p_i232597_2_) {
      this.field_193069_c = p_i232597_1_;
      this.field_240944_i_ = p_i232597_2_;
      this.func_240948_b_(p_i232597_2_);
   }

   public int func_193065_c() {
      return this.field_193069_c.func_200252_aR().func_223592_c(GameRules.field_223619_v);
   }

   public CommandDispatcher<CommandSource> func_195446_d() {
      return this.field_193069_c.func_195571_aL().func_197054_a();
   }

   public void func_73660_a() {
      this.func_240945_a_(this.field_200003_j, field_200001_d);
      if (this.field_200223_l) {
         this.field_200223_l = false;
         Collection<FunctionObject> collection = this.field_240944_i_.func_240942_b_().func_241834_b(field_200222_e).func_230236_b_();
         this.func_240945_a_(collection, field_200222_e);
      }

   }

   private void func_240945_a_(Collection<FunctionObject> p_240945_1_, ResourceLocation p_240945_2_) {
      this.field_193069_c.func_213185_aS().func_194340_a(p_240945_2_::toString);

      for(FunctionObject functionobject : p_240945_1_) {
         this.func_195447_a(functionobject, this.func_195448_f());
      }

      this.field_193069_c.func_213185_aS().func_76319_b();
   }

   public int func_195447_a(FunctionObject p_195447_1_, CommandSource p_195447_2_) {
      int i = this.func_193065_c();
      if (this.field_194021_h) {
         if (this.field_194020_g.size() + this.field_222855_j.size() < i) {
            this.field_222855_j.add(new FunctionManager.QueuedCommand(this, p_195447_2_, new FunctionObject.FunctionEntry(p_195447_1_)));
         }

         return 0;
      } else {
         try {
            this.field_194021_h = true;
            int j = 0;
            FunctionObject.IEntry[] afunctionobject$ientry = p_195447_1_.func_193528_a();

            for(int k = afunctionobject$ientry.length - 1; k >= 0; --k) {
               this.field_194020_g.push(new FunctionManager.QueuedCommand(this, p_195447_2_, afunctionobject$ientry[k]));
            }

            while(!this.field_194020_g.isEmpty()) {
               try {
                  FunctionManager.QueuedCommand functionmanager$queuedcommand = this.field_194020_g.removeFirst();
                  this.field_193069_c.func_213185_aS().func_194340_a(functionmanager$queuedcommand::toString);
                  functionmanager$queuedcommand.func_194222_a(this.field_194020_g, i);
                  if (!this.field_222855_j.isEmpty()) {
                     Lists.reverse(this.field_222855_j).forEach(this.field_194020_g::addFirst);
                     this.field_222855_j.clear();
                  }
               } finally {
                  this.field_193069_c.func_213185_aS().func_76319_b();
               }

               ++j;
               if (j >= i) {
                  return j;
               }
            }

            return j;
         } finally {
            this.field_194020_g.clear();
            this.field_222855_j.clear();
            this.field_194021_h = false;
         }
      }
   }

   public void func_240946_a_(FunctionReloader p_240946_1_) {
      this.field_240944_i_ = p_240946_1_;
      this.func_240948_b_(p_240946_1_);
   }

   private void func_240948_b_(FunctionReloader p_240948_1_) {
      this.field_200003_j.clear();
      this.field_200003_j.addAll(p_240948_1_.func_240942_b_().func_241834_b(field_200001_d).func_230236_b_());
      this.field_200223_l = true;
   }

   public CommandSource func_195448_f() {
      return this.field_193069_c.func_195573_aM().func_197033_a(2).func_197031_a();
   }

   public Optional<FunctionObject> func_215361_a(ResourceLocation p_215361_1_) {
      return this.field_240944_i_.func_240940_a_(p_215361_1_);
   }

   public ITag<FunctionObject> func_240947_b_(ResourceLocation p_240947_1_) {
      return this.field_240944_i_.func_240943_b_(p_240947_1_);
   }

   public Iterable<ResourceLocation> func_240949_f_() {
      return this.field_240944_i_.func_240931_a_().keySet();
   }

   public Iterable<ResourceLocation> func_240950_g_() {
      return this.field_240944_i_.func_240942_b_().func_199908_a();
   }

   public static class QueuedCommand {
      private final FunctionManager field_194223_a;
      private final CommandSource field_194224_b;
      private final FunctionObject.IEntry field_194225_c;

      public QueuedCommand(FunctionManager p_i48018_1_, CommandSource p_i48018_2_, FunctionObject.IEntry p_i48018_3_) {
         this.field_194223_a = p_i48018_1_;
         this.field_194224_b = p_i48018_2_;
         this.field_194225_c = p_i48018_3_;
      }

      public void func_194222_a(ArrayDeque<FunctionManager.QueuedCommand> p_194222_1_, int p_194222_2_) {
         try {
            this.field_194225_c.func_196998_a(this.field_194223_a, this.field_194224_b, p_194222_1_, p_194222_2_);
         } catch (Throwable throwable) {
         }

      }

      public String toString() {
         return this.field_194225_c.toString();
      }
   }
}
