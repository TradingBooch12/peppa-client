package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.util.JSONUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.Registry;

public class EnterBlockTrigger extends AbstractCriterionTrigger<EnterBlockTrigger.Instance> {
   private static final ResourceLocation field_192196_a = new ResourceLocation("enter_block");

   public ResourceLocation func_192163_a() {
      return field_192196_a;
   }

   public EnterBlockTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      Block block = func_226550_a_(p_230241_1_);
      StatePropertiesPredicate statepropertiespredicate = StatePropertiesPredicate.func_227186_a_(p_230241_1_.get("state"));
      if (block != null) {
         statepropertiespredicate.func_227183_a_(block.func_176194_O(), (p_226548_1_) -> {
            throw new JsonSyntaxException("Block " + block + " has no property " + p_226548_1_);
         });
      }

      return new EnterBlockTrigger.Instance(p_230241_2_, block, statepropertiespredicate);
   }

   @Nullable
   private static Block func_226550_a_(JsonObject p_226550_0_) {
      if (p_226550_0_.has("block")) {
         ResourceLocation resourcelocation = new ResourceLocation(JSONUtils.func_151200_h(p_226550_0_, "block"));
         return Registry.field_212618_g.func_241873_b(resourcelocation).orElseThrow(() -> {
            return new JsonSyntaxException("Unknown block type '" + resourcelocation + "'");
         });
      } else {
         return null;
      }
   }

   public void func_192193_a(ServerPlayerEntity p_192193_1_, BlockState p_192193_2_) {
      this.func_235959_a_(p_192193_1_, (p_226549_1_) -> {
         return p_226549_1_.func_192260_a(p_192193_2_);
      });
   }

   public static class Instance extends CriterionInstance {
      private final Block field_192261_a;
      private final StatePropertiesPredicate field_192262_b;

      public Instance(EntityPredicate.AndPredicate p_i231560_1_, @Nullable Block p_i231560_2_, StatePropertiesPredicate p_i231560_3_) {
         super(EnterBlockTrigger.field_192196_a, p_i231560_1_);
         this.field_192261_a = p_i231560_2_;
         this.field_192262_b = p_i231560_3_;
      }

      public static EnterBlockTrigger.Instance func_203920_a(Block p_203920_0_) {
         return new EnterBlockTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, p_203920_0_, StatePropertiesPredicate.field_227178_a_);
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         if (this.field_192261_a != null) {
            jsonobject.addProperty("block", Registry.field_212618_g.func_177774_c(this.field_192261_a).toString());
         }

         jsonobject.add("state", this.field_192262_b.func_227180_a_());
         return jsonobject;
      }

      public boolean func_192260_a(BlockState p_192260_1_) {
         if (this.field_192261_a != null && !p_192260_1_.func_203425_a(this.field_192261_a)) {
            return false;
         } else {
            return this.field_192262_b.func_227181_a_(p_192260_1_);
         }
      }
   }
}
