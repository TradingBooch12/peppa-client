package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import net.minecraft.advancements.ICriterionInstance;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.util.ResourceLocation;

public class ImpossibleTrigger implements ICriterionTrigger<ImpossibleTrigger.Instance> {
   private static final ResourceLocation field_192205_a = new ResourceLocation("impossible");

   public ResourceLocation func_192163_a() {
      return field_192205_a;
   }

   public void func_192165_a(PlayerAdvancements p_192165_1_, ICriterionTrigger.Listener<ImpossibleTrigger.Instance> p_192165_2_) {
   }

   public void func_192164_b(PlayerAdvancements p_192164_1_, ICriterionTrigger.Listener<ImpossibleTrigger.Instance> p_192164_2_) {
   }

   public void func_192167_a(PlayerAdvancements p_192167_1_) {
   }

   public ImpossibleTrigger.Instance func_230307_a_(JsonObject p_230307_1_, ConditionArrayParser p_230307_2_) {
      return new ImpossibleTrigger.Instance();
   }

   public static class Instance implements ICriterionInstance {
      public ResourceLocation func_192244_a() {
         return ImpossibleTrigger.field_192205_a;
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         return new JsonObject();
      }
   }
}
