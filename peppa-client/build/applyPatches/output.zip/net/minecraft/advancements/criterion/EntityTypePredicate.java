package net.minecraft.advancements.criterion;

import com.google.common.base.Joiner;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSyntaxException;
import javax.annotation.Nullable;
import net.minecraft.entity.EntityType;
import net.minecraft.tags.ITag;
import net.minecraft.tags.TagCollectionManager;
import net.minecraft.util.JSONUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.Registry;

public abstract class EntityTypePredicate {
   public static final EntityTypePredicate field_209371_a = new EntityTypePredicate() {
      public boolean func_209368_a(EntityType<?> p_209368_1_) {
         return true;
      }

      public JsonElement func_209369_a() {
         return JsonNull.INSTANCE;
      }
   };
   private static final Joiner field_209372_b = Joiner.on(", ");

   public abstract boolean func_209368_a(EntityType<?> p_209368_1_);

   public abstract JsonElement func_209369_a();

   public static EntityTypePredicate func_209370_a(@Nullable JsonElement p_209370_0_) {
      if (p_209370_0_ != null && !p_209370_0_.isJsonNull()) {
         String s = JSONUtils.func_151206_a(p_209370_0_, "type");
         if (s.startsWith("#")) {
            ResourceLocation resourcelocation1 = new ResourceLocation(s.substring(1));
            return new EntityTypePredicate.TagPredicate(TagCollectionManager.func_242178_a().func_241838_d().func_241834_b(resourcelocation1));
         } else {
            ResourceLocation resourcelocation = new ResourceLocation(s);
            EntityType<?> entitytype = Registry.field_212629_r.func_241873_b(resourcelocation).orElseThrow(() -> {
               return new JsonSyntaxException("Unknown entity type '" + resourcelocation + "', valid types are: " + field_209372_b.join(Registry.field_212629_r.func_148742_b()));
            });
            return new EntityTypePredicate.TypePredicate(entitytype);
         }
      } else {
         return field_209371_a;
      }
   }

   public static EntityTypePredicate func_217999_b(EntityType<?> p_217999_0_) {
      return new EntityTypePredicate.TypePredicate(p_217999_0_);
   }

   public static EntityTypePredicate func_217998_a(ITag<EntityType<?>> p_217998_0_) {
      return new EntityTypePredicate.TagPredicate(p_217998_0_);
   }

   static class TagPredicate extends EntityTypePredicate {
      private final ITag<EntityType<?>> field_218001_b;

      public TagPredicate(ITag<EntityType<?>> p_i50558_1_) {
         this.field_218001_b = p_i50558_1_;
      }

      public boolean func_209368_a(EntityType<?> p_209368_1_) {
         return this.field_218001_b.func_230235_a_(p_209368_1_);
      }

      public JsonElement func_209369_a() {
         return new JsonPrimitive("#" + TagCollectionManager.func_242178_a().func_241838_d().func_232975_b_(this.field_218001_b));
      }
   }

   static class TypePredicate extends EntityTypePredicate {
      private final EntityType<?> field_218000_b;

      public TypePredicate(EntityType<?> p_i50556_1_) {
         this.field_218000_b = p_i50556_1_;
      }

      public boolean func_209368_a(EntityType<?> p_209368_1_) {
         return this.field_218000_b == p_209368_1_;
      }

      public JsonElement func_209369_a() {
         return new JsonPrimitive(Registry.field_212629_r.func_177774_c(this.field_218000_b).toString());
      }
   }
}
