package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.vector.Vector3d;

public class LevitationTrigger extends AbstractCriterionTrigger<LevitationTrigger.Instance> {
   private static final ResourceLocation field_193164_a = new ResourceLocation("levitation");

   public ResourceLocation func_192163_a() {
      return field_193164_a;
   }

   public LevitationTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      DistancePredicate distancepredicate = DistancePredicate.func_193421_a(p_230241_1_.get("distance"));
      MinMaxBounds.IntBound minmaxbounds$intbound = MinMaxBounds.IntBound.func_211344_a(p_230241_1_.get("duration"));
      return new LevitationTrigger.Instance(p_230241_2_, distancepredicate, minmaxbounds$intbound);
   }

   public void func_193162_a(ServerPlayerEntity p_193162_1_, Vector3d p_193162_2_, int p_193162_3_) {
      this.func_235959_a_(p_193162_1_, (p_226852_3_) -> {
         return p_226852_3_.func_193201_a(p_193162_1_, p_193162_2_, p_193162_3_);
      });
   }

   public static class Instance extends CriterionInstance {
      private final DistancePredicate field_193202_a;
      private final MinMaxBounds.IntBound field_193203_b;

      public Instance(EntityPredicate.AndPredicate p_i231638_1_, DistancePredicate p_i231638_2_, MinMaxBounds.IntBound p_i231638_3_) {
         super(LevitationTrigger.field_193164_a, p_i231638_1_);
         this.field_193202_a = p_i231638_2_;
         this.field_193203_b = p_i231638_3_;
      }

      public static LevitationTrigger.Instance func_203930_a(DistancePredicate p_203930_0_) {
         return new LevitationTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, p_203930_0_, MinMaxBounds.IntBound.field_211347_e);
      }

      public boolean func_193201_a(ServerPlayerEntity p_193201_1_, Vector3d p_193201_2_, int p_193201_3_) {
         if (!this.field_193202_a.func_193422_a(p_193201_2_.field_72450_a, p_193201_2_.field_72448_b, p_193201_2_.field_72449_c, p_193201_1_.func_226277_ct_(), p_193201_1_.func_226278_cu_(), p_193201_1_.func_226281_cx_())) {
            return false;
         } else {
            return this.field_193203_b.func_211339_d(p_193201_3_);
         }
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         jsonobject.add("distance", this.field_193202_a.func_203994_a());
         jsonobject.add("duration", this.field_193203_b.func_200321_c());
         return jsonobject;
      }
   }
}
