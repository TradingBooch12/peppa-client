package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.loot.LootContext;
import net.minecraft.util.ResourceLocation;

public class TameAnimalTrigger extends AbstractCriterionTrigger<TameAnimalTrigger.Instance> {
   private static final ResourceLocation field_193179_a = new ResourceLocation("tame_animal");

   public ResourceLocation func_192163_a() {
      return field_193179_a;
   }

   public TameAnimalTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      EntityPredicate.AndPredicate entitypredicate$andpredicate = EntityPredicate.AndPredicate.func_234587_a_(p_230241_1_, "entity", p_230241_3_);
      return new TameAnimalTrigger.Instance(p_230241_2_, entitypredicate$andpredicate);
   }

   public void func_193178_a(ServerPlayerEntity p_193178_1_, AnimalEntity p_193178_2_) {
      LootContext lootcontext = EntityPredicate.func_234575_b_(p_193178_1_, p_193178_2_);
      this.func_235959_a_(p_193178_1_, (p_227251_1_) -> {
         return p_227251_1_.func_236323_a_(lootcontext);
      });
   }

   public static class Instance extends CriterionInstance {
      private final EntityPredicate.AndPredicate field_193217_a;

      public Instance(EntityPredicate.AndPredicate p_i231963_1_, EntityPredicate.AndPredicate p_i231963_2_) {
         super(TameAnimalTrigger.field_193179_a, p_i231963_1_);
         this.field_193217_a = p_i231963_2_;
      }

      public static TameAnimalTrigger.Instance func_203938_c() {
         return new TameAnimalTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, EntityPredicate.AndPredicate.field_234582_a_);
      }

      public static TameAnimalTrigger.Instance func_215124_a(EntityPredicate p_215124_0_) {
         return new TameAnimalTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, EntityPredicate.AndPredicate.func_234585_a_(p_215124_0_));
      }

      public boolean func_236323_a_(LootContext p_236323_1_) {
         return this.field_193217_a.func_234588_a_(p_236323_1_);
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         jsonobject.add("entity", this.field_193217_a.func_234586_a_(p_230240_1_));
         return jsonobject;
      }
   }
}
