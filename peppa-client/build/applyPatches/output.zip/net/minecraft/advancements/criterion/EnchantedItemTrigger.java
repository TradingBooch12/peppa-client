package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.util.ResourceLocation;

public class EnchantedItemTrigger extends AbstractCriterionTrigger<EnchantedItemTrigger.Instance> {
   private static final ResourceLocation field_192191_a = new ResourceLocation("enchanted_item");

   public ResourceLocation func_192163_a() {
      return field_192191_a;
   }

   public EnchantedItemTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      ItemPredicate itempredicate = ItemPredicate.func_192492_a(p_230241_1_.get("item"));
      MinMaxBounds.IntBound minmaxbounds$intbound = MinMaxBounds.IntBound.func_211344_a(p_230241_1_.get("levels"));
      return new EnchantedItemTrigger.Instance(p_230241_2_, itempredicate, minmaxbounds$intbound);
   }

   public void func_192190_a(ServerPlayerEntity p_192190_1_, ItemStack p_192190_2_, int p_192190_3_) {
      this.func_235959_a_(p_192190_1_, (p_226528_2_) -> {
         return p_226528_2_.func_192257_a(p_192190_2_, p_192190_3_);
      });
   }

   public static class Instance extends CriterionInstance {
      private final ItemPredicate field_192258_a;
      private final MinMaxBounds.IntBound field_192259_b;

      public Instance(EntityPredicate.AndPredicate p_i231556_1_, ItemPredicate p_i231556_2_, MinMaxBounds.IntBound p_i231556_3_) {
         super(EnchantedItemTrigger.field_192191_a, p_i231556_1_);
         this.field_192258_a = p_i231556_2_;
         this.field_192259_b = p_i231556_3_;
      }

      public static EnchantedItemTrigger.Instance func_203918_c() {
         return new EnchantedItemTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, ItemPredicate.field_192495_a, MinMaxBounds.IntBound.field_211347_e);
      }

      public boolean func_192257_a(ItemStack p_192257_1_, int p_192257_2_) {
         if (!this.field_192258_a.func_192493_a(p_192257_1_)) {
            return false;
         } else {
            return this.field_192259_b.func_211339_d(p_192257_2_);
         }
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         jsonobject.add("item", this.field_192258_a.func_200319_a());
         jsonobject.add("levels", this.field_192259_b.func_200321_c());
         return jsonobject;
      }
   }
}
