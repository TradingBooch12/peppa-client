package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.util.ResourceLocation;

public class EffectsChangedTrigger extends AbstractCriterionTrigger<EffectsChangedTrigger.Instance> {
   private static final ResourceLocation field_193154_a = new ResourceLocation("effects_changed");

   public ResourceLocation func_192163_a() {
      return field_193154_a;
   }

   public EffectsChangedTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      MobEffectsPredicate mobeffectspredicate = MobEffectsPredicate.func_193471_a(p_230241_1_.get("effects"));
      return new EffectsChangedTrigger.Instance(p_230241_2_, mobeffectspredicate);
   }

   public void func_193153_a(ServerPlayerEntity p_193153_1_) {
      this.func_235959_a_(p_193153_1_, (p_226524_1_) -> {
         return p_226524_1_.func_193195_a(p_193153_1_);
      });
   }

   public static class Instance extends CriterionInstance {
      private final MobEffectsPredicate field_193196_a;

      public Instance(EntityPredicate.AndPredicate p_i231553_1_, MobEffectsPredicate p_i231553_2_) {
         super(EffectsChangedTrigger.field_193154_a, p_i231553_1_);
         this.field_193196_a = p_i231553_2_;
      }

      public static EffectsChangedTrigger.Instance func_203917_a(MobEffectsPredicate p_203917_0_) {
         return new EffectsChangedTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, p_203917_0_);
      }

      public boolean func_193195_a(ServerPlayerEntity p_193195_1_) {
         return this.field_193196_a.func_193472_a(p_193195_1_);
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         jsonobject.add("effects", this.field_193196_a.func_204013_b());
         return jsonobject;
      }
   }
}
