package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.loot.LootContext;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;

public class PlayerHurtEntityTrigger extends AbstractCriterionTrigger<PlayerHurtEntityTrigger.Instance> {
   private static final ResourceLocation field_192222_a = new ResourceLocation("player_hurt_entity");

   public ResourceLocation func_192163_a() {
      return field_192222_a;
   }

   public PlayerHurtEntityTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      DamagePredicate damagepredicate = DamagePredicate.func_192364_a(p_230241_1_.get("damage"));
      EntityPredicate.AndPredicate entitypredicate$andpredicate = EntityPredicate.AndPredicate.func_234587_a_(p_230241_1_, "entity", p_230241_3_);
      return new PlayerHurtEntityTrigger.Instance(p_230241_2_, damagepredicate, entitypredicate$andpredicate);
   }

   public void func_192220_a(ServerPlayerEntity p_192220_1_, Entity p_192220_2_, DamageSource p_192220_3_, float p_192220_4_, float p_192220_5_, boolean p_192220_6_) {
      LootContext lootcontext = EntityPredicate.func_234575_b_(p_192220_1_, p_192220_2_);
      this.func_235959_a_(p_192220_1_, (p_226956_6_) -> {
         return p_226956_6_.func_235609_a_(p_192220_1_, lootcontext, p_192220_3_, p_192220_4_, p_192220_5_, p_192220_6_);
      });
   }

   public static class Instance extends CriterionInstance {
      private final DamagePredicate field_192279_a;
      private final EntityPredicate.AndPredicate field_192280_b;

      public Instance(EntityPredicate.AndPredicate p_i241190_1_, DamagePredicate p_i241190_2_, EntityPredicate.AndPredicate p_i241190_3_) {
         super(PlayerHurtEntityTrigger.field_192222_a, p_i241190_1_);
         this.field_192279_a = p_i241190_2_;
         this.field_192280_b = p_i241190_3_;
      }

      public static PlayerHurtEntityTrigger.Instance func_203936_a(DamagePredicate.Builder p_203936_0_) {
         return new PlayerHurtEntityTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, p_203936_0_.func_203970_b(), EntityPredicate.AndPredicate.field_234582_a_);
      }

      public boolean func_235609_a_(ServerPlayerEntity p_235609_1_, LootContext p_235609_2_, DamageSource p_235609_3_, float p_235609_4_, float p_235609_5_, boolean p_235609_6_) {
         if (!this.field_192279_a.func_192365_a(p_235609_1_, p_235609_3_, p_235609_4_, p_235609_5_, p_235609_6_)) {
            return false;
         } else {
            return this.field_192280_b.func_234588_a_(p_235609_2_);
         }
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         jsonobject.add("damage", this.field_192279_a.func_203977_a());
         jsonobject.add("entity", this.field_192280_b.func_234586_a_(p_230240_1_));
         return jsonobject;
      }
   }
}
