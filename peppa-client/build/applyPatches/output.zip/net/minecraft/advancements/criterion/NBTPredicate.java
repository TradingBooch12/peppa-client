package net.minecraft.advancements.criterion;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSyntaxException;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.nbt.INBT;
import net.minecraft.nbt.JsonToNBT;
import net.minecraft.nbt.NBTUtil;
import net.minecraft.util.JSONUtils;

public class NBTPredicate {
   public static final NBTPredicate field_193479_a = new NBTPredicate((CompoundNBT)null);
   @Nullable
   private final CompoundNBT field_193480_b;

   public NBTPredicate(@Nullable CompoundNBT p_i47536_1_) {
      this.field_193480_b = p_i47536_1_;
   }

   public boolean func_193478_a(ItemStack p_193478_1_) {
      return this == field_193479_a ? true : this.func_193477_a(p_193478_1_.func_77978_p());
   }

   public boolean func_193475_a(Entity p_193475_1_) {
      return this == field_193479_a ? true : this.func_193477_a(func_196981_b(p_193475_1_));
   }

   public boolean func_193477_a(@Nullable INBT p_193477_1_) {
      if (p_193477_1_ == null) {
         return this == field_193479_a;
      } else {
         return this.field_193480_b == null || NBTUtil.func_181123_a(this.field_193480_b, p_193477_1_, true);
      }
   }

   public JsonElement func_200322_a() {
      return (JsonElement)(this != field_193479_a && this.field_193480_b != null ? new JsonPrimitive(this.field_193480_b.toString()) : JsonNull.INSTANCE);
   }

   public static NBTPredicate func_193476_a(@Nullable JsonElement p_193476_0_) {
      if (p_193476_0_ != null && !p_193476_0_.isJsonNull()) {
         CompoundNBT compoundnbt;
         try {
            compoundnbt = JsonToNBT.func_180713_a(JSONUtils.func_151206_a(p_193476_0_, "nbt"));
         } catch (CommandSyntaxException commandsyntaxexception) {
            throw new JsonSyntaxException("Invalid nbt tag: " + commandsyntaxexception.getMessage());
         }

         return new NBTPredicate(compoundnbt);
      } else {
         return field_193479_a;
      }
   }

   public static CompoundNBT func_196981_b(Entity p_196981_0_) {
      CompoundNBT compoundnbt = p_196981_0_.func_189511_e(new CompoundNBT());
      if (p_196981_0_ instanceof PlayerEntity) {
         ItemStack itemstack = ((PlayerEntity)p_196981_0_).field_71071_by.func_70448_g();
         if (!itemstack.func_190926_b()) {
            compoundnbt.func_218657_a("SelectedItem", itemstack.func_77955_b(new CompoundNBT()));
         }
      }

      return compoundnbt;
   }
}
