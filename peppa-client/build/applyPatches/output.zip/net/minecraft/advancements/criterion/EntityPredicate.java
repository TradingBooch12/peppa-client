package net.minecraft.advancements.criterion;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import java.util.function.Predicate;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.MobEntity;
import net.minecraft.entity.passive.CatEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.loot.FishingPredicate;
import net.minecraft.loot.LootContext;
import net.minecraft.loot.LootParameterSets;
import net.minecraft.loot.LootParameters;
import net.minecraft.loot.conditions.EntityHasProperty;
import net.minecraft.loot.conditions.ILootCondition;
import net.minecraft.loot.conditions.LootConditionManager;
import net.minecraft.scoreboard.Team;
import net.minecraft.tags.ITag;
import net.minecraft.util.JSONUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.server.ServerWorld;

public class EntityPredicate {
   public static final EntityPredicate field_192483_a = new EntityPredicate(EntityTypePredicate.field_209371_a, DistancePredicate.field_193423_a, LocationPredicate.field_193455_a, MobEffectsPredicate.field_193473_a, NBTPredicate.field_193479_a, EntityFlagsPredicate.field_217979_a, EntityEquipmentPredicate.field_217958_a, PlayerPredicate.field_226989_a_, FishingPredicate.field_234635_a_, (String)null, (ResourceLocation)null);
   private final EntityTypePredicate field_192484_b;
   private final DistancePredicate field_192485_c;
   private final LocationPredicate field_193435_d;
   private final MobEffectsPredicate field_193436_e;
   private final NBTPredicate field_193437_f;
   private final EntityFlagsPredicate field_217994_h;
   private final EntityEquipmentPredicate field_217995_i;
   private final PlayerPredicate field_226609_j_;
   private final FishingPredicate field_234572_j_;
   private final EntityPredicate field_234573_k_;
   private final EntityPredicate field_234574_l_;
   @Nullable
   private final String field_226610_k_;
   @Nullable
   private final ResourceLocation field_217996_j;

   private EntityPredicate(EntityTypePredicate p_i241236_1_, DistancePredicate p_i241236_2_, LocationPredicate p_i241236_3_, MobEffectsPredicate p_i241236_4_, NBTPredicate p_i241236_5_, EntityFlagsPredicate p_i241236_6_, EntityEquipmentPredicate p_i241236_7_, PlayerPredicate p_i241236_8_, FishingPredicate p_i241236_9_, @Nullable String p_i241236_10_, @Nullable ResourceLocation p_i241236_11_) {
      this.field_192484_b = p_i241236_1_;
      this.field_192485_c = p_i241236_2_;
      this.field_193435_d = p_i241236_3_;
      this.field_193436_e = p_i241236_4_;
      this.field_193437_f = p_i241236_5_;
      this.field_217994_h = p_i241236_6_;
      this.field_217995_i = p_i241236_7_;
      this.field_226609_j_ = p_i241236_8_;
      this.field_234572_j_ = p_i241236_9_;
      this.field_234573_k_ = this;
      this.field_234574_l_ = this;
      this.field_226610_k_ = p_i241236_10_;
      this.field_217996_j = p_i241236_11_;
   }

   private EntityPredicate(EntityTypePredicate p_i231578_1_, DistancePredicate p_i231578_2_, LocationPredicate p_i231578_3_, MobEffectsPredicate p_i231578_4_, NBTPredicate p_i231578_5_, EntityFlagsPredicate p_i231578_6_, EntityEquipmentPredicate p_i231578_7_, PlayerPredicate p_i231578_8_, FishingPredicate p_i231578_9_, EntityPredicate p_i231578_10_, EntityPredicate p_i231578_11_, @Nullable String p_i231578_12_, @Nullable ResourceLocation p_i231578_13_) {
      this.field_192484_b = p_i231578_1_;
      this.field_192485_c = p_i231578_2_;
      this.field_193435_d = p_i231578_3_;
      this.field_193436_e = p_i231578_4_;
      this.field_193437_f = p_i231578_5_;
      this.field_217994_h = p_i231578_6_;
      this.field_217995_i = p_i231578_7_;
      this.field_226609_j_ = p_i231578_8_;
      this.field_234572_j_ = p_i231578_9_;
      this.field_234573_k_ = p_i231578_10_;
      this.field_234574_l_ = p_i231578_11_;
      this.field_226610_k_ = p_i231578_12_;
      this.field_217996_j = p_i231578_13_;
   }

   public boolean func_192482_a(ServerPlayerEntity p_192482_1_, @Nullable Entity p_192482_2_) {
      return this.func_217993_a(p_192482_1_.func_71121_q(), p_192482_1_.func_213303_ch(), p_192482_2_);
   }

   public boolean func_217993_a(ServerWorld p_217993_1_, @Nullable Vector3d p_217993_2_, @Nullable Entity p_217993_3_) {
      if (this == field_192483_a) {
         return true;
      } else if (p_217993_3_ == null) {
         return false;
      } else if (!this.field_192484_b.func_209368_a(p_217993_3_.func_200600_R())) {
         return false;
      } else {
         if (p_217993_2_ == null) {
            if (this.field_192485_c != DistancePredicate.field_193423_a) {
               return false;
            }
         } else if (!this.field_192485_c.func_193422_a(p_217993_2_.field_72450_a, p_217993_2_.field_72448_b, p_217993_2_.field_72449_c, p_217993_3_.func_226277_ct_(), p_217993_3_.func_226278_cu_(), p_217993_3_.func_226281_cx_())) {
            return false;
         }

         if (!this.field_193435_d.func_193452_a(p_217993_1_, p_217993_3_.func_226277_ct_(), p_217993_3_.func_226278_cu_(), p_217993_3_.func_226281_cx_())) {
            return false;
         } else if (!this.field_193436_e.func_193469_a(p_217993_3_)) {
            return false;
         } else if (!this.field_193437_f.func_193475_a(p_217993_3_)) {
            return false;
         } else if (!this.field_217994_h.func_217974_a(p_217993_3_)) {
            return false;
         } else if (!this.field_217995_i.func_217955_a(p_217993_3_)) {
            return false;
         } else if (!this.field_226609_j_.func_226998_a_(p_217993_3_)) {
            return false;
         } else if (!this.field_234572_j_.func_234638_a_(p_217993_3_)) {
            return false;
         } else if (!this.field_234573_k_.func_217993_a(p_217993_1_, p_217993_2_, p_217993_3_.func_184187_bx())) {
            return false;
         } else if (!this.field_234574_l_.func_217993_a(p_217993_1_, p_217993_2_, p_217993_3_ instanceof MobEntity ? ((MobEntity)p_217993_3_).func_70638_az() : null)) {
            return false;
         } else {
            if (this.field_226610_k_ != null) {
               Team team = p_217993_3_.func_96124_cp();
               if (team == null || !this.field_226610_k_.equals(team.func_96661_b())) {
                  return false;
               }
            }

            return this.field_217996_j == null || p_217993_3_ instanceof CatEntity && ((CatEntity)p_217993_3_).func_213423_ee().equals(this.field_217996_j);
         }
      }
   }

   public static EntityPredicate func_192481_a(@Nullable JsonElement p_192481_0_) {
      if (p_192481_0_ != null && !p_192481_0_.isJsonNull()) {
         JsonObject jsonobject = JSONUtils.func_151210_l(p_192481_0_, "entity");
         EntityTypePredicate entitytypepredicate = EntityTypePredicate.func_209370_a(jsonobject.get("type"));
         DistancePredicate distancepredicate = DistancePredicate.func_193421_a(jsonobject.get("distance"));
         LocationPredicate locationpredicate = LocationPredicate.func_193454_a(jsonobject.get("location"));
         MobEffectsPredicate mobeffectspredicate = MobEffectsPredicate.func_193471_a(jsonobject.get("effects"));
         NBTPredicate nbtpredicate = NBTPredicate.func_193476_a(jsonobject.get("nbt"));
         EntityFlagsPredicate entityflagspredicate = EntityFlagsPredicate.func_217975_a(jsonobject.get("flags"));
         EntityEquipmentPredicate entityequipmentpredicate = EntityEquipmentPredicate.func_217956_a(jsonobject.get("equipment"));
         PlayerPredicate playerpredicate = PlayerPredicate.func_227000_a_(jsonobject.get("player"));
         FishingPredicate fishingpredicate = FishingPredicate.func_234639_a_(jsonobject.get("fishing_hook"));
         EntityPredicate entitypredicate = func_192481_a(jsonobject.get("vehicle"));
         EntityPredicate entitypredicate1 = func_192481_a(jsonobject.get("targeted_entity"));
         String s = JSONUtils.func_151219_a(jsonobject, "team", (String)null);
         ResourceLocation resourcelocation = jsonobject.has("catType") ? new ResourceLocation(JSONUtils.func_151200_h(jsonobject, "catType")) : null;
         return (new EntityPredicate.Builder()).func_209366_a(entitytypepredicate).func_203997_a(distancepredicate).func_203999_a(locationpredicate).func_209367_a(mobeffectspredicate).func_209365_a(nbtpredicate).func_217987_a(entityflagspredicate).func_217985_a(entityequipmentpredicate).func_226613_a_(playerpredicate).func_234580_a_(fishingpredicate).func_226614_a_(s).func_234579_a_(entitypredicate).func_234581_b_(entitypredicate1).func_217988_b(resourcelocation).func_204000_b();
      } else {
         return field_192483_a;
      }
   }

   public JsonElement func_204006_a() {
      if (this == field_192483_a) {
         return JsonNull.INSTANCE;
      } else {
         JsonObject jsonobject = new JsonObject();
         jsonobject.add("type", this.field_192484_b.func_209369_a());
         jsonobject.add("distance", this.field_192485_c.func_203994_a());
         jsonobject.add("location", this.field_193435_d.func_204009_a());
         jsonobject.add("effects", this.field_193436_e.func_204013_b());
         jsonobject.add("nbt", this.field_193437_f.func_200322_a());
         jsonobject.add("flags", this.field_217994_h.func_217976_a());
         jsonobject.add("equipment", this.field_217995_i.func_217957_a());
         jsonobject.add("player", this.field_226609_j_.func_226995_a_());
         jsonobject.add("fishing_hook", this.field_234572_j_.func_234637_a_());
         jsonobject.add("vehicle", this.field_234573_k_.func_204006_a());
         jsonobject.add("targeted_entity", this.field_234574_l_.func_204006_a());
         jsonobject.addProperty("team", this.field_226610_k_);
         if (this.field_217996_j != null) {
            jsonobject.addProperty("catType", this.field_217996_j.toString());
         }

         return jsonobject;
      }
   }

   public static LootContext func_234575_b_(ServerPlayerEntity p_234575_0_, Entity p_234575_1_) {
      return (new LootContext.Builder(p_234575_0_.func_71121_q())).func_216015_a(LootParameters.field_216281_a, p_234575_1_).func_216015_a(LootParameters.field_237457_g_, p_234575_0_.func_213303_ch()).func_216023_a(p_234575_0_.func_70681_au()).func_216022_a(LootParameterSets.field_237454_j_);
   }

   public static class AndPredicate {
      public static final EntityPredicate.AndPredicate field_234582_a_ = new EntityPredicate.AndPredicate(new ILootCondition[0]);
      private final ILootCondition[] field_234583_b_;
      private final Predicate<LootContext> field_234584_c_;

      private AndPredicate(ILootCondition[] p_i231580_1_) {
         this.field_234583_b_ = p_i231580_1_;
         this.field_234584_c_ = LootConditionManager.func_216305_a(p_i231580_1_);
      }

      public static EntityPredicate.AndPredicate func_234591_a_(ILootCondition... p_234591_0_) {
         return new EntityPredicate.AndPredicate(p_234591_0_);
      }

      public static EntityPredicate.AndPredicate func_234587_a_(JsonObject p_234587_0_, String p_234587_1_, ConditionArrayParser p_234587_2_) {
         JsonElement jsonelement = p_234587_0_.get(p_234587_1_);
         return func_234589_a_(p_234587_1_, p_234587_2_, jsonelement);
      }

      public static EntityPredicate.AndPredicate[] func_234592_b_(JsonObject p_234592_0_, String p_234592_1_, ConditionArrayParser p_234592_2_) {
         JsonElement jsonelement = p_234592_0_.get(p_234592_1_);
         if (jsonelement != null && !jsonelement.isJsonNull()) {
            JsonArray jsonarray = JSONUtils.func_151207_m(jsonelement, p_234592_1_);
            EntityPredicate.AndPredicate[] aentitypredicate$andpredicate = new EntityPredicate.AndPredicate[jsonarray.size()];

            for(int i = 0; i < jsonarray.size(); ++i) {
               aentitypredicate$andpredicate[i] = func_234589_a_(p_234592_1_ + "[" + i + "]", p_234592_2_, jsonarray.get(i));
            }

            return aentitypredicate$andpredicate;
         } else {
            return new EntityPredicate.AndPredicate[0];
         }
      }

      private static EntityPredicate.AndPredicate func_234589_a_(String p_234589_0_, ConditionArrayParser p_234589_1_, @Nullable JsonElement p_234589_2_) {
         if (p_234589_2_ != null && p_234589_2_.isJsonArray()) {
            ILootCondition[] ailootcondition = p_234589_1_.func_234050_a_(p_234589_2_.getAsJsonArray(), p_234589_1_.func_234049_a_().toString() + "/" + p_234589_0_, LootParameterSets.field_237454_j_);
            return new EntityPredicate.AndPredicate(ailootcondition);
         } else {
            EntityPredicate entitypredicate = EntityPredicate.func_192481_a(p_234589_2_);
            return func_234585_a_(entitypredicate);
         }
      }

      public static EntityPredicate.AndPredicate func_234585_a_(EntityPredicate p_234585_0_) {
         if (p_234585_0_ == EntityPredicate.field_192483_a) {
            return field_234582_a_;
         } else {
            ILootCondition ilootcondition = EntityHasProperty.func_237477_a_(LootContext.EntityTarget.THIS, p_234585_0_).build();
            return new EntityPredicate.AndPredicate(new ILootCondition[]{ilootcondition});
         }
      }

      public boolean func_234588_a_(LootContext p_234588_1_) {
         return this.field_234584_c_.test(p_234588_1_);
      }

      public JsonElement func_234586_a_(ConditionArraySerializer p_234586_1_) {
         return (JsonElement)(this.field_234583_b_.length == 0 ? JsonNull.INSTANCE : p_234586_1_.func_235681_a_(this.field_234583_b_));
      }

      public static JsonElement func_234590_a_(EntityPredicate.AndPredicate[] p_234590_0_, ConditionArraySerializer p_234590_1_) {
         if (p_234590_0_.length == 0) {
            return JsonNull.INSTANCE;
         } else {
            JsonArray jsonarray = new JsonArray();

            for(EntityPredicate.AndPredicate entitypredicate$andpredicate : p_234590_0_) {
               jsonarray.add(entitypredicate$andpredicate.func_234586_a_(p_234590_1_));
            }

            return jsonarray;
         }
      }
   }

   public static class Builder {
      private EntityTypePredicate field_204001_a = EntityTypePredicate.field_209371_a;
      private DistancePredicate field_204002_b = DistancePredicate.field_193423_a;
      private LocationPredicate field_204003_c = LocationPredicate.field_193455_a;
      private MobEffectsPredicate field_204004_d = MobEffectsPredicate.field_193473_a;
      private NBTPredicate field_204005_e = NBTPredicate.field_193479_a;
      private EntityFlagsPredicate field_217990_f = EntityFlagsPredicate.field_217979_a;
      private EntityEquipmentPredicate field_217991_g = EntityEquipmentPredicate.field_217958_a;
      private PlayerPredicate field_226611_h_ = PlayerPredicate.field_226989_a_;
      private FishingPredicate field_234576_i_ = FishingPredicate.field_234635_a_;
      private EntityPredicate field_234577_j_ = EntityPredicate.field_192483_a;
      private EntityPredicate field_234578_k_ = EntityPredicate.field_192483_a;
      private String field_226612_i_;
      private ResourceLocation field_217992_h;

      public static EntityPredicate.Builder func_203996_a() {
         return new EntityPredicate.Builder();
      }

      public EntityPredicate.Builder func_203998_a(EntityType<?> p_203998_1_) {
         this.field_204001_a = EntityTypePredicate.func_217999_b(p_203998_1_);
         return this;
      }

      public EntityPredicate.Builder func_217989_a(ITag<EntityType<?>> p_217989_1_) {
         this.field_204001_a = EntityTypePredicate.func_217998_a(p_217989_1_);
         return this;
      }

      public EntityPredicate.Builder func_217986_a(ResourceLocation p_217986_1_) {
         this.field_217992_h = p_217986_1_;
         return this;
      }

      public EntityPredicate.Builder func_209366_a(EntityTypePredicate p_209366_1_) {
         this.field_204001_a = p_209366_1_;
         return this;
      }

      public EntityPredicate.Builder func_203997_a(DistancePredicate p_203997_1_) {
         this.field_204002_b = p_203997_1_;
         return this;
      }

      public EntityPredicate.Builder func_203999_a(LocationPredicate p_203999_1_) {
         this.field_204003_c = p_203999_1_;
         return this;
      }

      public EntityPredicate.Builder func_209367_a(MobEffectsPredicate p_209367_1_) {
         this.field_204004_d = p_209367_1_;
         return this;
      }

      public EntityPredicate.Builder func_209365_a(NBTPredicate p_209365_1_) {
         this.field_204005_e = p_209365_1_;
         return this;
      }

      public EntityPredicate.Builder func_217987_a(EntityFlagsPredicate p_217987_1_) {
         this.field_217990_f = p_217987_1_;
         return this;
      }

      public EntityPredicate.Builder func_217985_a(EntityEquipmentPredicate p_217985_1_) {
         this.field_217991_g = p_217985_1_;
         return this;
      }

      public EntityPredicate.Builder func_226613_a_(PlayerPredicate p_226613_1_) {
         this.field_226611_h_ = p_226613_1_;
         return this;
      }

      public EntityPredicate.Builder func_234580_a_(FishingPredicate p_234580_1_) {
         this.field_234576_i_ = p_234580_1_;
         return this;
      }

      public EntityPredicate.Builder func_234579_a_(EntityPredicate p_234579_1_) {
         this.field_234577_j_ = p_234579_1_;
         return this;
      }

      public EntityPredicate.Builder func_234581_b_(EntityPredicate p_234581_1_) {
         this.field_234578_k_ = p_234581_1_;
         return this;
      }

      public EntityPredicate.Builder func_226614_a_(@Nullable String p_226614_1_) {
         this.field_226612_i_ = p_226614_1_;
         return this;
      }

      public EntityPredicate.Builder func_217988_b(@Nullable ResourceLocation p_217988_1_) {
         this.field_217992_h = p_217988_1_;
         return this;
      }

      public EntityPredicate func_204000_b() {
         return new EntityPredicate(this.field_204001_a, this.field_204002_b, this.field_204003_c, this.field_204004_d, this.field_204005_e, this.field_217990_f, this.field_217991_g, this.field_226611_h_, this.field_234576_i_, this.field_234577_j_, this.field_234578_k_, this.field_226612_i_, this.field_217992_h);
      }
   }
}
