package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.util.JSONUtils;
import net.minecraft.util.ResourceLocation;

public class RecipeUnlockedTrigger extends AbstractCriterionTrigger<RecipeUnlockedTrigger.Instance> {
   private static final ResourceLocation field_192227_a = new ResourceLocation("recipe_unlocked");

   public ResourceLocation func_192163_a() {
      return field_192227_a;
   }

   public RecipeUnlockedTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      ResourceLocation resourcelocation = new ResourceLocation(JSONUtils.func_151200_h(p_230241_1_, "recipe"));
      return new RecipeUnlockedTrigger.Instance(p_230241_2_, resourcelocation);
   }

   public void func_192225_a(ServerPlayerEntity p_192225_1_, IRecipe<?> p_192225_2_) {
      this.func_235959_a_(p_192225_1_, (p_227018_1_) -> {
         return p_227018_1_.func_193215_a(p_192225_2_);
      });
   }

   public static RecipeUnlockedTrigger.Instance func_235675_a_(ResourceLocation p_235675_0_) {
      return new RecipeUnlockedTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, p_235675_0_);
   }

   public static class Instance extends CriterionInstance {
      private final ResourceLocation field_212243_a;

      public Instance(EntityPredicate.AndPredicate p_i231865_1_, ResourceLocation p_i231865_2_) {
         super(RecipeUnlockedTrigger.field_192227_a, p_i231865_1_);
         this.field_212243_a = p_i231865_2_;
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         jsonobject.addProperty("recipe", this.field_212243_a.toString());
         return jsonobject;
      }

      public boolean func_193215_a(IRecipe<?> p_193215_1_) {
         return this.field_212243_a.equals(p_193215_1_.func_199560_c());
      }
   }
}
