package net.minecraft.advancements.criterion;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.List;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.potion.Potion;
import net.minecraft.tags.ITag;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.JSONUtils;
import net.minecraft.util.ResourceLocation;

public class InventoryChangeTrigger extends AbstractCriterionTrigger<InventoryChangeTrigger.Instance> {
   private static final ResourceLocation field_192209_a = new ResourceLocation("inventory_changed");

   public ResourceLocation func_192163_a() {
      return field_192209_a;
   }

   public InventoryChangeTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      JsonObject jsonobject = JSONUtils.func_151218_a(p_230241_1_, "slots", new JsonObject());
      MinMaxBounds.IntBound minmaxbounds$intbound = MinMaxBounds.IntBound.func_211344_a(jsonobject.get("occupied"));
      MinMaxBounds.IntBound minmaxbounds$intbound1 = MinMaxBounds.IntBound.func_211344_a(jsonobject.get("full"));
      MinMaxBounds.IntBound minmaxbounds$intbound2 = MinMaxBounds.IntBound.func_211344_a(jsonobject.get("empty"));
      ItemPredicate[] aitempredicate = ItemPredicate.func_192494_b(p_230241_1_.get("items"));
      return new InventoryChangeTrigger.Instance(p_230241_2_, minmaxbounds$intbound, minmaxbounds$intbound1, minmaxbounds$intbound2, aitempredicate);
   }

   public void func_234803_a_(ServerPlayerEntity p_234803_1_, PlayerInventory p_234803_2_, ItemStack p_234803_3_) {
      int i = 0;
      int j = 0;
      int k = 0;

      for(int l = 0; l < p_234803_2_.func_70302_i_(); ++l) {
         ItemStack itemstack = p_234803_2_.func_70301_a(l);
         if (itemstack.func_190926_b()) {
            ++j;
         } else {
            ++k;
            if (itemstack.func_190916_E() >= itemstack.func_77976_d()) {
               ++i;
            }
         }
      }

      this.func_234804_a_(p_234803_1_, p_234803_2_, p_234803_3_, i, j, k);
   }

   private void func_234804_a_(ServerPlayerEntity p_234804_1_, PlayerInventory p_234804_2_, ItemStack p_234804_3_, int p_234804_4_, int p_234804_5_, int p_234804_6_) {
      this.func_235959_a_(p_234804_1_, (p_234802_5_) -> {
         return p_234802_5_.func_234805_a_(p_234804_2_, p_234804_3_, p_234804_4_, p_234804_5_, p_234804_6_);
      });
   }

   public static class Instance extends CriterionInstance {
      private final MinMaxBounds.IntBound field_192266_a;
      private final MinMaxBounds.IntBound field_192267_b;
      private final MinMaxBounds.IntBound field_192268_c;
      private final ItemPredicate[] field_192269_d;

      public Instance(EntityPredicate.AndPredicate p_i231597_1_, MinMaxBounds.IntBound p_i231597_2_, MinMaxBounds.IntBound p_i231597_3_, MinMaxBounds.IntBound p_i231597_4_, ItemPredicate[] p_i231597_5_) {
         super(InventoryChangeTrigger.field_192209_a, p_i231597_1_);
         this.field_192266_a = p_i231597_2_;
         this.field_192267_b = p_i231597_3_;
         this.field_192268_c = p_i231597_4_;
         this.field_192269_d = p_i231597_5_;
      }

      public static InventoryChangeTrigger.Instance func_203923_a(ItemPredicate... p_203923_0_) {
         return new InventoryChangeTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, MinMaxBounds.IntBound.field_211347_e, MinMaxBounds.IntBound.field_211347_e, MinMaxBounds.IntBound.field_211347_e, p_203923_0_);
      }

      public static InventoryChangeTrigger.Instance func_203922_a(IItemProvider... p_203922_0_) {
         ItemPredicate[] aitempredicate = new ItemPredicate[p_203922_0_.length];

         for(int i = 0; i < p_203922_0_.length; ++i) {
            aitempredicate[i] = new ItemPredicate((ITag<Item>)null, p_203922_0_[i].func_199767_j(), MinMaxBounds.IntBound.field_211347_e, MinMaxBounds.IntBound.field_211347_e, EnchantmentPredicate.field_226534_b_, EnchantmentPredicate.field_226534_b_, (Potion)null, NBTPredicate.field_193479_a);
         }

         return func_203923_a(aitempredicate);
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         if (!this.field_192266_a.func_211335_c() || !this.field_192267_b.func_211335_c() || !this.field_192268_c.func_211335_c()) {
            JsonObject jsonobject1 = new JsonObject();
            jsonobject1.add("occupied", this.field_192266_a.func_200321_c());
            jsonobject1.add("full", this.field_192267_b.func_200321_c());
            jsonobject1.add("empty", this.field_192268_c.func_200321_c());
            jsonobject.add("slots", jsonobject1);
         }

         if (this.field_192269_d.length > 0) {
            JsonArray jsonarray = new JsonArray();

            for(ItemPredicate itempredicate : this.field_192269_d) {
               jsonarray.add(itempredicate.func_200319_a());
            }

            jsonobject.add("items", jsonarray);
         }

         return jsonobject;
      }

      public boolean func_234805_a_(PlayerInventory p_234805_1_, ItemStack p_234805_2_, int p_234805_3_, int p_234805_4_, int p_234805_5_) {
         if (!this.field_192267_b.func_211339_d(p_234805_3_)) {
            return false;
         } else if (!this.field_192268_c.func_211339_d(p_234805_4_)) {
            return false;
         } else if (!this.field_192266_a.func_211339_d(p_234805_5_)) {
            return false;
         } else {
            int i = this.field_192269_d.length;
            if (i == 0) {
               return true;
            } else if (i != 1) {
               List<ItemPredicate> list = new ObjectArrayList<>(this.field_192269_d);
               int j = p_234805_1_.func_70302_i_();

               for(int k = 0; k < j; ++k) {
                  if (list.isEmpty()) {
                     return true;
                  }

                  ItemStack itemstack = p_234805_1_.func_70301_a(k);
                  if (!itemstack.func_190926_b()) {
                     list.removeIf((p_234806_1_) -> {
                        return p_234806_1_.func_192493_a(itemstack);
                     });
                  }
               }

               return list.isEmpty();
            } else {
               return !p_234805_2_.func_190926_b() && this.field_192269_d[0].func_192493_a(p_234805_2_);
            }
         }
      }
   }
}
