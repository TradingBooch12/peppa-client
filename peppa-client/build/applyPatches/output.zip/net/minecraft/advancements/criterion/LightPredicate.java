package net.minecraft.advancements.criterion;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import javax.annotation.Nullable;
import net.minecraft.util.JSONUtils;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.server.ServerWorld;

public class LightPredicate {
   public static final LightPredicate field_226854_a_ = new LightPredicate(MinMaxBounds.IntBound.field_211347_e);
   private final MinMaxBounds.IntBound field_226855_b_;

   private LightPredicate(MinMaxBounds.IntBound p_i225753_1_) {
      this.field_226855_b_ = p_i225753_1_;
   }

   public boolean func_226858_a_(ServerWorld p_226858_1_, BlockPos p_226858_2_) {
      if (this == field_226854_a_) {
         return true;
      } else if (!p_226858_1_.func_195588_v(p_226858_2_)) {
         return false;
      } else {
         return this.field_226855_b_.func_211339_d(p_226858_1_.func_201696_r(p_226858_2_));
      }
   }

   public JsonElement func_226856_a_() {
      if (this == field_226854_a_) {
         return JsonNull.INSTANCE;
      } else {
         JsonObject jsonobject = new JsonObject();
         jsonobject.add("light", this.field_226855_b_.func_200321_c());
         return jsonobject;
      }
   }

   public static LightPredicate func_226857_a_(@Nullable JsonElement p_226857_0_) {
      if (p_226857_0_ != null && !p_226857_0_.isJsonNull()) {
         JsonObject jsonobject = JSONUtils.func_151210_l(p_226857_0_, "light");
         MinMaxBounds.IntBound minmaxbounds$intbound = MinMaxBounds.IntBound.func_211344_a(jsonobject.get("light"));
         return new LightPredicate(minmaxbounds$intbound);
      } else {
         return field_226854_a_;
      }
   }
}
