package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.util.ResourceLocation;

public class ItemDurabilityTrigger extends AbstractCriterionTrigger<ItemDurabilityTrigger.Instance> {
   private static final ResourceLocation field_193159_a = new ResourceLocation("item_durability_changed");

   public ResourceLocation func_192163_a() {
      return field_193159_a;
   }

   public ItemDurabilityTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      ItemPredicate itempredicate = ItemPredicate.func_192492_a(p_230241_1_.get("item"));
      MinMaxBounds.IntBound minmaxbounds$intbound = MinMaxBounds.IntBound.func_211344_a(p_230241_1_.get("durability"));
      MinMaxBounds.IntBound minmaxbounds$intbound1 = MinMaxBounds.IntBound.func_211344_a(p_230241_1_.get("delta"));
      return new ItemDurabilityTrigger.Instance(p_230241_2_, itempredicate, minmaxbounds$intbound, minmaxbounds$intbound1);
   }

   public void func_193158_a(ServerPlayerEntity p_193158_1_, ItemStack p_193158_2_, int p_193158_3_) {
      this.func_235959_a_(p_193158_1_, (p_226653_2_) -> {
         return p_226653_2_.func_193197_a(p_193158_2_, p_193158_3_);
      });
   }

   public static class Instance extends CriterionInstance {
      private final ItemPredicate field_193198_a;
      private final MinMaxBounds.IntBound field_193199_b;
      private final MinMaxBounds.IntBound field_193200_c;

      public Instance(EntityPredicate.AndPredicate p_i231598_1_, ItemPredicate p_i231598_2_, MinMaxBounds.IntBound p_i231598_3_, MinMaxBounds.IntBound p_i231598_4_) {
         super(ItemDurabilityTrigger.field_193159_a, p_i231598_1_);
         this.field_193198_a = p_i231598_2_;
         this.field_193199_b = p_i231598_3_;
         this.field_193200_c = p_i231598_4_;
      }

      public static ItemDurabilityTrigger.Instance func_234816_a_(EntityPredicate.AndPredicate p_234816_0_, ItemPredicate p_234816_1_, MinMaxBounds.IntBound p_234816_2_) {
         return new ItemDurabilityTrigger.Instance(p_234816_0_, p_234816_1_, p_234816_2_, MinMaxBounds.IntBound.field_211347_e);
      }

      public boolean func_193197_a(ItemStack p_193197_1_, int p_193197_2_) {
         if (!this.field_193198_a.func_192493_a(p_193197_1_)) {
            return false;
         } else if (!this.field_193199_b.func_211339_d(p_193197_1_.func_77958_k() - p_193197_2_)) {
            return false;
         } else {
            return this.field_193200_c.func_211339_d(p_193197_1_.func_77952_i() - p_193197_2_);
         }
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         jsonobject.add("item", this.field_193198_a.func_200319_a());
         jsonobject.add("durability", this.field_193199_b.func_200321_c());
         jsonobject.add("delta", this.field_193200_c.func_200321_c());
         return jsonobject;
      }
   }
}
