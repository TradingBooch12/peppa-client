package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.loot.LootContext;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;

public class KilledTrigger extends AbstractCriterionTrigger<KilledTrigger.Instance> {
   private final ResourceLocation field_192214_b;

   public KilledTrigger(ResourceLocation p_i47433_1_) {
      this.field_192214_b = p_i47433_1_;
   }

   public ResourceLocation func_192163_a() {
      return this.field_192214_b;
   }

   public KilledTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      return new KilledTrigger.Instance(this.field_192214_b, p_230241_2_, EntityPredicate.AndPredicate.func_234587_a_(p_230241_1_, "entity", p_230241_3_), DamageSourcePredicate.func_192447_a(p_230241_1_.get("killing_blow")));
   }

   public void func_192211_a(ServerPlayerEntity p_192211_1_, Entity p_192211_2_, DamageSource p_192211_3_) {
      LootContext lootcontext = EntityPredicate.func_234575_b_(p_192211_1_, p_192211_2_);
      this.func_235959_a_(p_192211_1_, (p_226846_3_) -> {
         return p_226846_3_.func_235050_a_(p_192211_1_, lootcontext, p_192211_3_);
      });
   }

   public static class Instance extends CriterionInstance {
      private final EntityPredicate.AndPredicate field_192271_a;
      private final DamageSourcePredicate field_192272_b;

      public Instance(ResourceLocation p_i231630_1_, EntityPredicate.AndPredicate p_i231630_2_, EntityPredicate.AndPredicate p_i231630_3_, DamageSourcePredicate p_i231630_4_) {
         super(p_i231630_1_, p_i231630_2_);
         this.field_192271_a = p_i231630_3_;
         this.field_192272_b = p_i231630_4_;
      }

      public static KilledTrigger.Instance func_203928_a(EntityPredicate.Builder p_203928_0_) {
         return new KilledTrigger.Instance(CriteriaTriggers.field_192122_b.field_192214_b, EntityPredicate.AndPredicate.field_234582_a_, EntityPredicate.AndPredicate.func_234585_a_(p_203928_0_.func_204000_b()), DamageSourcePredicate.field_192449_a);
      }

      public static KilledTrigger.Instance func_203927_c() {
         return new KilledTrigger.Instance(CriteriaTriggers.field_192122_b.field_192214_b, EntityPredicate.AndPredicate.field_234582_a_, EntityPredicate.AndPredicate.field_234582_a_, DamageSourcePredicate.field_192449_a);
      }

      public static KilledTrigger.Instance func_203929_a(EntityPredicate.Builder p_203929_0_, DamageSourcePredicate.Builder p_203929_1_) {
         return new KilledTrigger.Instance(CriteriaTriggers.field_192122_b.field_192214_b, EntityPredicate.AndPredicate.field_234582_a_, EntityPredicate.AndPredicate.func_234585_a_(p_203929_0_.func_204000_b()), p_203929_1_.func_203979_b());
      }

      public static KilledTrigger.Instance func_203926_d() {
         return new KilledTrigger.Instance(CriteriaTriggers.field_192123_c.field_192214_b, EntityPredicate.AndPredicate.field_234582_a_, EntityPredicate.AndPredicate.field_234582_a_, DamageSourcePredicate.field_192449_a);
      }

      public boolean func_235050_a_(ServerPlayerEntity p_235050_1_, LootContext p_235050_2_, DamageSource p_235050_3_) {
         return !this.field_192272_b.func_193418_a(p_235050_1_, p_235050_3_) ? false : this.field_192271_a.func_234588_a_(p_235050_2_);
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         jsonobject.add("entity", this.field_192271_a.func_234586_a_(p_230240_1_));
         jsonobject.add("killing_blow", this.field_192272_b.func_203991_a());
         return jsonobject;
      }
   }
}
