package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;

public class UsedEnderEyeTrigger extends AbstractCriterionTrigger<UsedEnderEyeTrigger.Instance> {
   private static final ResourceLocation field_192242_a = new ResourceLocation("used_ender_eye");

   public ResourceLocation func_192163_a() {
      return field_192242_a;
   }

   public UsedEnderEyeTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      MinMaxBounds.FloatBound minmaxbounds$floatbound = MinMaxBounds.FloatBound.func_211356_a(p_230241_1_.get("distance"));
      return new UsedEnderEyeTrigger.Instance(p_230241_2_, minmaxbounds$floatbound);
   }

   public void func_192239_a(ServerPlayerEntity p_192239_1_, BlockPos p_192239_2_) {
      double d0 = p_192239_1_.func_226277_ct_() - (double)p_192239_2_.func_177958_n();
      double d1 = p_192239_1_.func_226281_cx_() - (double)p_192239_2_.func_177952_p();
      double d2 = d0 * d0 + d1 * d1;
      this.func_235959_a_(p_192239_1_, (p_227325_2_) -> {
         return p_227325_2_.func_192288_a(d2);
      });
   }

   public static class Instance extends CriterionInstance {
      private final MinMaxBounds.FloatBound field_192289_a;

      public Instance(EntityPredicate.AndPredicate p_i232030_1_, MinMaxBounds.FloatBound p_i232030_2_) {
         super(UsedEnderEyeTrigger.field_192242_a, p_i232030_1_);
         this.field_192289_a = p_i232030_2_;
      }

      public boolean func_192288_a(double p_192288_1_) {
         return this.field_192289_a.func_211351_a(p_192288_1_);
      }
   }
}
