package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.world.server.ServerWorld;

public class NetherTravelTrigger extends AbstractCriterionTrigger<NetherTravelTrigger.Instance> {
   private static final ResourceLocation field_193169_a = new ResourceLocation("nether_travel");

   public ResourceLocation func_192163_a() {
      return field_193169_a;
   }

   public NetherTravelTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      LocationPredicate locationpredicate = LocationPredicate.func_193454_a(p_230241_1_.get("entered"));
      LocationPredicate locationpredicate1 = LocationPredicate.func_193454_a(p_230241_1_.get("exited"));
      DistancePredicate distancepredicate = DistancePredicate.func_193421_a(p_230241_1_.get("distance"));
      return new NetherTravelTrigger.Instance(p_230241_2_, locationpredicate, locationpredicate1, distancepredicate);
   }

   public void func_193168_a(ServerPlayerEntity p_193168_1_, Vector3d p_193168_2_) {
      this.func_235959_a_(p_193168_1_, (p_226945_2_) -> {
         return p_226945_2_.func_193206_a(p_193168_1_.func_71121_q(), p_193168_2_, p_193168_1_.func_226277_ct_(), p_193168_1_.func_226278_cu_(), p_193168_1_.func_226281_cx_());
      });
   }

   public static class Instance extends CriterionInstance {
      private final LocationPredicate field_193207_a;
      private final LocationPredicate field_193208_b;
      private final DistancePredicate field_193209_c;

      public Instance(EntityPredicate.AndPredicate p_i231785_1_, LocationPredicate p_i231785_2_, LocationPredicate p_i231785_3_, DistancePredicate p_i231785_4_) {
         super(NetherTravelTrigger.field_193169_a, p_i231785_1_);
         this.field_193207_a = p_i231785_2_;
         this.field_193208_b = p_i231785_3_;
         this.field_193209_c = p_i231785_4_;
      }

      public static NetherTravelTrigger.Instance func_203933_a(DistancePredicate p_203933_0_) {
         return new NetherTravelTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, LocationPredicate.field_193455_a, LocationPredicate.field_193455_a, p_203933_0_);
      }

      public boolean func_193206_a(ServerWorld p_193206_1_, Vector3d p_193206_2_, double p_193206_3_, double p_193206_5_, double p_193206_7_) {
         if (!this.field_193207_a.func_193452_a(p_193206_1_, p_193206_2_.field_72450_a, p_193206_2_.field_72448_b, p_193206_2_.field_72449_c)) {
            return false;
         } else if (!this.field_193208_b.func_193452_a(p_193206_1_, p_193206_3_, p_193206_5_, p_193206_7_)) {
            return false;
         } else {
            return this.field_193209_c.func_193422_a(p_193206_2_.field_72450_a, p_193206_2_.field_72448_b, p_193206_2_.field_72449_c, p_193206_3_, p_193206_5_, p_193206_7_);
         }
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         jsonobject.add("entered", this.field_193207_a.func_204009_a());
         jsonobject.add("exited", this.field_193208_b.func_204009_a());
         jsonobject.add("distance", this.field_193209_c.func_203994_a());
         return jsonobject;
      }
   }
}
