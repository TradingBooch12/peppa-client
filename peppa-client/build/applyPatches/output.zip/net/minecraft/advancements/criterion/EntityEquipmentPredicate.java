package net.minecraft.advancements.criterion;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.Items;
import net.minecraft.util.JSONUtils;
import net.minecraft.world.raid.Raid;

public class EntityEquipmentPredicate {
   public static final EntityEquipmentPredicate field_217958_a = new EntityEquipmentPredicate(ItemPredicate.field_192495_a, ItemPredicate.field_192495_a, ItemPredicate.field_192495_a, ItemPredicate.field_192495_a, ItemPredicate.field_192495_a, ItemPredicate.field_192495_a);
   public static final EntityEquipmentPredicate field_217959_b = new EntityEquipmentPredicate(ItemPredicate.Builder.func_200309_a().func_200308_a(Items.field_196191_eg).func_218002_a(Raid.func_221312_H().func_77978_p()).func_200310_b(), ItemPredicate.field_192495_a, ItemPredicate.field_192495_a, ItemPredicate.field_192495_a, ItemPredicate.field_192495_a, ItemPredicate.field_192495_a);
   private final ItemPredicate field_217960_c;
   private final ItemPredicate field_217961_d;
   private final ItemPredicate field_217962_e;
   private final ItemPredicate field_217963_f;
   private final ItemPredicate field_217964_g;
   private final ItemPredicate field_217965_h;

   public EntityEquipmentPredicate(ItemPredicate p_i50809_1_, ItemPredicate p_i50809_2_, ItemPredicate p_i50809_3_, ItemPredicate p_i50809_4_, ItemPredicate p_i50809_5_, ItemPredicate p_i50809_6_) {
      this.field_217960_c = p_i50809_1_;
      this.field_217961_d = p_i50809_2_;
      this.field_217962_e = p_i50809_3_;
      this.field_217963_f = p_i50809_4_;
      this.field_217964_g = p_i50809_5_;
      this.field_217965_h = p_i50809_6_;
   }

   public boolean func_217955_a(@Nullable Entity p_217955_1_) {
      if (this == field_217958_a) {
         return true;
      } else if (!(p_217955_1_ instanceof LivingEntity)) {
         return false;
      } else {
         LivingEntity livingentity = (LivingEntity)p_217955_1_;
         if (!this.field_217960_c.func_192493_a(livingentity.func_184582_a(EquipmentSlotType.HEAD))) {
            return false;
         } else if (!this.field_217961_d.func_192493_a(livingentity.func_184582_a(EquipmentSlotType.CHEST))) {
            return false;
         } else if (!this.field_217962_e.func_192493_a(livingentity.func_184582_a(EquipmentSlotType.LEGS))) {
            return false;
         } else if (!this.field_217963_f.func_192493_a(livingentity.func_184582_a(EquipmentSlotType.FEET))) {
            return false;
         } else if (!this.field_217964_g.func_192493_a(livingentity.func_184582_a(EquipmentSlotType.MAINHAND))) {
            return false;
         } else {
            return this.field_217965_h.func_192493_a(livingentity.func_184582_a(EquipmentSlotType.OFFHAND));
         }
      }
   }

   public static EntityEquipmentPredicate func_217956_a(@Nullable JsonElement p_217956_0_) {
      if (p_217956_0_ != null && !p_217956_0_.isJsonNull()) {
         JsonObject jsonobject = JSONUtils.func_151210_l(p_217956_0_, "equipment");
         ItemPredicate itempredicate = ItemPredicate.func_192492_a(jsonobject.get("head"));
         ItemPredicate itempredicate1 = ItemPredicate.func_192492_a(jsonobject.get("chest"));
         ItemPredicate itempredicate2 = ItemPredicate.func_192492_a(jsonobject.get("legs"));
         ItemPredicate itempredicate3 = ItemPredicate.func_192492_a(jsonobject.get("feet"));
         ItemPredicate itempredicate4 = ItemPredicate.func_192492_a(jsonobject.get("mainhand"));
         ItemPredicate itempredicate5 = ItemPredicate.func_192492_a(jsonobject.get("offhand"));
         return new EntityEquipmentPredicate(itempredicate, itempredicate1, itempredicate2, itempredicate3, itempredicate4, itempredicate5);
      } else {
         return field_217958_a;
      }
   }

   public JsonElement func_217957_a() {
      if (this == field_217958_a) {
         return JsonNull.INSTANCE;
      } else {
         JsonObject jsonobject = new JsonObject();
         jsonobject.add("head", this.field_217960_c.func_200319_a());
         jsonobject.add("chest", this.field_217961_d.func_200319_a());
         jsonobject.add("legs", this.field_217962_e.func_200319_a());
         jsonobject.add("feet", this.field_217963_f.func_200319_a());
         jsonobject.add("mainhand", this.field_217964_g.func_200319_a());
         jsonobject.add("offhand", this.field_217965_h.func_200319_a());
         return jsonobject;
      }
   }

   public static class Builder {
      private ItemPredicate field_234260_a_ = ItemPredicate.field_192495_a;
      private ItemPredicate field_234261_b_ = ItemPredicate.field_192495_a;
      private ItemPredicate field_234262_c_ = ItemPredicate.field_192495_a;
      private ItemPredicate field_234263_d_ = ItemPredicate.field_192495_a;
      private ItemPredicate field_234264_e_ = ItemPredicate.field_192495_a;
      private ItemPredicate field_234265_f_ = ItemPredicate.field_192495_a;

      public static EntityEquipmentPredicate.Builder func_234266_a_() {
         return new EntityEquipmentPredicate.Builder();
      }

      public EntityEquipmentPredicate.Builder func_234267_a_(ItemPredicate p_234267_1_) {
         this.field_234260_a_ = p_234267_1_;
         return this;
      }

      public EntityEquipmentPredicate.Builder func_234269_b_(ItemPredicate p_234269_1_) {
         this.field_234261_b_ = p_234269_1_;
         return this;
      }

      public EntityEquipmentPredicate.Builder func_234270_c_(ItemPredicate p_234270_1_) {
         this.field_234262_c_ = p_234270_1_;
         return this;
      }

      public EntityEquipmentPredicate.Builder func_234271_d_(ItemPredicate p_234271_1_) {
         this.field_234263_d_ = p_234271_1_;
         return this;
      }

      public EntityEquipmentPredicate func_234268_b_() {
         return new EntityEquipmentPredicate(this.field_234260_a_, this.field_234261_b_, this.field_234262_c_, this.field_234263_d_, this.field_234264_e_, this.field_234265_f_);
      }
   }
}
