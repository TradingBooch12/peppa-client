package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import net.minecraft.entity.merchant.villager.AbstractVillagerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.loot.LootContext;
import net.minecraft.util.ResourceLocation;

public class VillagerTradeTrigger extends AbstractCriterionTrigger<VillagerTradeTrigger.Instance> {
   private static final ResourceLocation field_192237_a = new ResourceLocation("villager_trade");

   public ResourceLocation func_192163_a() {
      return field_192237_a;
   }

   public VillagerTradeTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      EntityPredicate.AndPredicate entitypredicate$andpredicate = EntityPredicate.AndPredicate.func_234587_a_(p_230241_1_, "villager", p_230241_3_);
      ItemPredicate itempredicate = ItemPredicate.func_192492_a(p_230241_1_.get("item"));
      return new VillagerTradeTrigger.Instance(p_230241_2_, entitypredicate$andpredicate, itempredicate);
   }

   public void func_215114_a(ServerPlayerEntity p_215114_1_, AbstractVillagerEntity p_215114_2_, ItemStack p_215114_3_) {
      LootContext lootcontext = EntityPredicate.func_234575_b_(p_215114_1_, p_215114_2_);
      this.func_235959_a_(p_215114_1_, (p_227267_2_) -> {
         return p_227267_2_.func_236575_a_(lootcontext, p_215114_3_);
      });
   }

   public static class Instance extends CriterionInstance {
      private final EntityPredicate.AndPredicate field_192286_a;
      private final ItemPredicate field_192287_b;

      public Instance(EntityPredicate.AndPredicate p_i232013_1_, EntityPredicate.AndPredicate p_i232013_2_, ItemPredicate p_i232013_3_) {
         super(VillagerTradeTrigger.field_192237_a, p_i232013_1_);
         this.field_192286_a = p_i232013_2_;
         this.field_192287_b = p_i232013_3_;
      }

      public static VillagerTradeTrigger.Instance func_203939_c() {
         return new VillagerTradeTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, EntityPredicate.AndPredicate.field_234582_a_, ItemPredicate.field_192495_a);
      }

      public boolean func_236575_a_(LootContext p_236575_1_, ItemStack p_236575_2_) {
         if (!this.field_192286_a.func_234588_a_(p_236575_1_)) {
            return false;
         } else {
            return this.field_192287_b.func_192493_a(p_236575_2_);
         }
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         jsonobject.add("item", this.field_192287_b.func_200319_a());
         jsonobject.add("villager", this.field_192286_a.func_234586_a_(p_230240_1_));
         return jsonobject;
      }
   }
}
