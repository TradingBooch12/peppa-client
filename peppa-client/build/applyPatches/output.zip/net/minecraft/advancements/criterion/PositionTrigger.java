package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.util.JSONUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.server.ServerWorld;

public class PositionTrigger extends AbstractCriterionTrigger<PositionTrigger.Instance> {
   private final ResourceLocation field_192217_a;

   public PositionTrigger(ResourceLocation p_i47432_1_) {
      this.field_192217_a = p_i47432_1_;
   }

   public ResourceLocation func_192163_a() {
      return this.field_192217_a;
   }

   public PositionTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      JsonObject jsonobject = JSONUtils.func_151218_a(p_230241_1_, "location", p_230241_1_);
      LocationPredicate locationpredicate = LocationPredicate.func_193454_a(jsonobject);
      return new PositionTrigger.Instance(this.field_192217_a, p_230241_2_, locationpredicate);
   }

   public void func_192215_a(ServerPlayerEntity p_192215_1_) {
      this.func_235959_a_(p_192215_1_, (p_226923_1_) -> {
         return p_226923_1_.func_193204_a(p_192215_1_.func_71121_q(), p_192215_1_.func_226277_ct_(), p_192215_1_.func_226278_cu_(), p_192215_1_.func_226281_cx_());
      });
   }

   public static class Instance extends CriterionInstance {
      private final LocationPredicate field_193205_a;

      public Instance(ResourceLocation p_i231661_1_, EntityPredicate.AndPredicate p_i231661_2_, LocationPredicate p_i231661_3_) {
         super(p_i231661_1_, p_i231661_2_);
         this.field_193205_a = p_i231661_3_;
      }

      public static PositionTrigger.Instance func_203932_a(LocationPredicate p_203932_0_) {
         return new PositionTrigger.Instance(CriteriaTriggers.field_192135_o.field_192217_a, EntityPredicate.AndPredicate.field_234582_a_, p_203932_0_);
      }

      public static PositionTrigger.Instance func_203931_c() {
         return new PositionTrigger.Instance(CriteriaTriggers.field_192136_p.field_192217_a, EntityPredicate.AndPredicate.field_234582_a_, LocationPredicate.field_193455_a);
      }

      public static PositionTrigger.Instance func_215120_d() {
         return new PositionTrigger.Instance(CriteriaTriggers.field_215101_H.field_192217_a, EntityPredicate.AndPredicate.field_234582_a_, LocationPredicate.field_193455_a);
      }

      public boolean func_193204_a(ServerWorld p_193204_1_, double p_193204_2_, double p_193204_4_, double p_193204_6_) {
         return this.field_193205_a.func_193452_a(p_193204_1_, p_193204_2_, p_193204_4_, p_193204_6_);
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         jsonobject.add("location", this.field_193205_a.func_204009_a());
         return jsonobject;
      }
   }
}
