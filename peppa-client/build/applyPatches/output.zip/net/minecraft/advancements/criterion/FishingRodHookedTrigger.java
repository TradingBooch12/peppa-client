package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import java.util.Collection;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.loot.LootContext;
import net.minecraft.loot.LootParameters;
import net.minecraft.util.ResourceLocation;

public class FishingRodHookedTrigger extends AbstractCriterionTrigger<FishingRodHookedTrigger.Instance> {
   private static final ResourceLocation field_204821_a = new ResourceLocation("fishing_rod_hooked");

   public ResourceLocation func_192163_a() {
      return field_204821_a;
   }

   public FishingRodHookedTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      ItemPredicate itempredicate = ItemPredicate.func_192492_a(p_230241_1_.get("rod"));
      EntityPredicate.AndPredicate entitypredicate$andpredicate = EntityPredicate.AndPredicate.func_234587_a_(p_230241_1_, "entity", p_230241_3_);
      ItemPredicate itempredicate1 = ItemPredicate.func_192492_a(p_230241_1_.get("item"));
      return new FishingRodHookedTrigger.Instance(p_230241_2_, itempredicate, entitypredicate$andpredicate, itempredicate1);
   }

   public void func_204820_a(ServerPlayerEntity p_204820_1_, ItemStack p_204820_2_, FishingBobberEntity p_204820_3_, Collection<ItemStack> p_204820_4_) {
      LootContext lootcontext = EntityPredicate.func_234575_b_(p_204820_1_, (Entity)(p_204820_3_.func_234607_k_() != null ? p_204820_3_.func_234607_k_() : p_204820_3_));
      this.func_235959_a_(p_204820_1_, (p_234658_3_) -> {
         return p_234658_3_.func_234659_a_(p_204820_2_, lootcontext, p_204820_4_);
      });
   }

   public static class Instance extends CriterionInstance {
      private final ItemPredicate field_204831_a;
      private final EntityPredicate.AndPredicate field_204832_b;
      private final ItemPredicate field_204833_c;

      public Instance(EntityPredicate.AndPredicate p_i231592_1_, ItemPredicate p_i231592_2_, EntityPredicate.AndPredicate p_i231592_3_, ItemPredicate p_i231592_4_) {
         super(FishingRodHookedTrigger.field_204821_a, p_i231592_1_);
         this.field_204831_a = p_i231592_2_;
         this.field_204832_b = p_i231592_3_;
         this.field_204833_c = p_i231592_4_;
      }

      public static FishingRodHookedTrigger.Instance func_204829_a(ItemPredicate p_204829_0_, EntityPredicate p_204829_1_, ItemPredicate p_204829_2_) {
         return new FishingRodHookedTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, p_204829_0_, EntityPredicate.AndPredicate.func_234585_a_(p_204829_1_), p_204829_2_);
      }

      public boolean func_234659_a_(ItemStack p_234659_1_, LootContext p_234659_2_, Collection<ItemStack> p_234659_3_) {
         if (!this.field_204831_a.func_192493_a(p_234659_1_)) {
            return false;
         } else if (!this.field_204832_b.func_234588_a_(p_234659_2_)) {
            return false;
         } else {
            if (this.field_204833_c != ItemPredicate.field_192495_a) {
               boolean flag = false;
               Entity entity = p_234659_2_.func_216031_c(LootParameters.field_216281_a);
               if (entity instanceof ItemEntity) {
                  ItemEntity itementity = (ItemEntity)entity;
                  if (this.field_204833_c.func_192493_a(itementity.func_92059_d())) {
                     flag = true;
                  }
               }

               for(ItemStack itemstack : p_234659_3_) {
                  if (this.field_204833_c.func_192493_a(itemstack)) {
                     flag = true;
                     break;
                  }
               }

               if (!flag) {
                  return false;
               }
            }

            return true;
         }
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         jsonobject.add("rod", this.field_204831_a.func_200319_a());
         jsonobject.add("entity", this.field_204832_b.func_234586_a_(p_230240_1_));
         jsonobject.add("item", this.field_204833_c.func_200319_a());
         return jsonobject;
      }
   }
}
