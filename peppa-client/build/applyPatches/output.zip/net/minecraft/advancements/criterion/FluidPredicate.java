package net.minecraft.advancements.criterion;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import javax.annotation.Nullable;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.tags.ITag;
import net.minecraft.tags.TagCollectionManager;
import net.minecraft.util.JSONUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.server.ServerWorld;

public class FluidPredicate {
   public static final FluidPredicate field_226643_a_ = new FluidPredicate((ITag<Fluid>)null, (Fluid)null, StatePropertiesPredicate.field_227178_a_);
   @Nullable
   private final ITag<Fluid> field_226644_b_;
   @Nullable
   private final Fluid field_226645_c_;
   private final StatePropertiesPredicate field_226646_d_;

   public FluidPredicate(@Nullable ITag<Fluid> p_i225738_1_, @Nullable Fluid p_i225738_2_, StatePropertiesPredicate p_i225738_3_) {
      this.field_226644_b_ = p_i225738_1_;
      this.field_226645_c_ = p_i225738_2_;
      this.field_226646_d_ = p_i225738_3_;
   }

   public boolean func_226649_a_(ServerWorld p_226649_1_, BlockPos p_226649_2_) {
      if (this == field_226643_a_) {
         return true;
      } else if (!p_226649_1_.func_195588_v(p_226649_2_)) {
         return false;
      } else {
         FluidState fluidstate = p_226649_1_.func_204610_c(p_226649_2_);
         Fluid fluid = fluidstate.func_206886_c();
         if (this.field_226644_b_ != null && !this.field_226644_b_.func_230235_a_(fluid)) {
            return false;
         } else if (this.field_226645_c_ != null && fluid != this.field_226645_c_) {
            return false;
         } else {
            return this.field_226646_d_.func_227185_a_(fluidstate);
         }
      }
   }

   public static FluidPredicate func_226648_a_(@Nullable JsonElement p_226648_0_) {
      if (p_226648_0_ != null && !p_226648_0_.isJsonNull()) {
         JsonObject jsonobject = JSONUtils.func_151210_l(p_226648_0_, "fluid");
         Fluid fluid = null;
         if (jsonobject.has("fluid")) {
            ResourceLocation resourcelocation = new ResourceLocation(JSONUtils.func_151200_h(jsonobject, "fluid"));
            fluid = Registry.field_212619_h.func_82594_a(resourcelocation);
         }

         ITag<Fluid> itag = null;
         if (jsonobject.has("tag")) {
            ResourceLocation resourcelocation1 = new ResourceLocation(JSONUtils.func_151200_h(jsonobject, "tag"));
            itag = TagCollectionManager.func_242178_a().func_241837_c().func_199910_a(resourcelocation1);
            if (itag == null) {
               throw new JsonSyntaxException("Unknown fluid tag '" + resourcelocation1 + "'");
            }
         }

         StatePropertiesPredicate statepropertiespredicate = StatePropertiesPredicate.func_227186_a_(jsonobject.get("state"));
         return new FluidPredicate(itag, fluid, statepropertiespredicate);
      } else {
         return field_226643_a_;
      }
   }

   public JsonElement func_226647_a_() {
      if (this == field_226643_a_) {
         return JsonNull.INSTANCE;
      } else {
         JsonObject jsonobject = new JsonObject();
         if (this.field_226645_c_ != null) {
            jsonobject.addProperty("fluid", Registry.field_212619_h.func_177774_c(this.field_226645_c_).toString());
         }

         if (this.field_226644_b_ != null) {
            jsonobject.addProperty("tag", TagCollectionManager.func_242178_a().func_241837_c().func_232975_b_(this.field_226644_b_).toString());
         }

         jsonobject.add("state", this.field_226646_d_.func_227180_a_());
         return jsonobject;
      }
   }
}
