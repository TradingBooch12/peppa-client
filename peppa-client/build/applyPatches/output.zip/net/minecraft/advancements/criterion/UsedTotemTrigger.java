package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.ResourceLocation;

public class UsedTotemTrigger extends AbstractCriterionTrigger<UsedTotemTrigger.Instance> {
   private static final ResourceLocation field_193188_a = new ResourceLocation("used_totem");

   public ResourceLocation func_192163_a() {
      return field_193188_a;
   }

   public UsedTotemTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      ItemPredicate itempredicate = ItemPredicate.func_192492_a(p_230241_1_.get("item"));
      return new UsedTotemTrigger.Instance(p_230241_2_, itempredicate);
   }

   public void func_193187_a(ServerPlayerEntity p_193187_1_, ItemStack p_193187_2_) {
      this.func_235959_a_(p_193187_1_, (p_227409_1_) -> {
         return p_227409_1_.func_193218_a(p_193187_2_);
      });
   }

   public static class Instance extends CriterionInstance {
      private final ItemPredicate field_193219_a;

      public Instance(EntityPredicate.AndPredicate p_i232051_1_, ItemPredicate p_i232051_2_) {
         super(UsedTotemTrigger.field_193188_a, p_i232051_1_);
         this.field_193219_a = p_i232051_2_;
      }

      public static UsedTotemTrigger.Instance func_203941_a(IItemProvider p_203941_0_) {
         return new UsedTotemTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, ItemPredicate.Builder.func_200309_a().func_200308_a(p_203941_0_).func_200310_b());
      }

      public boolean func_193218_a(ItemStack p_193218_1_) {
         return this.field_193219_a.func_192493_a(p_193218_1_);
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         jsonobject.add("item", this.field_193219_a.func_200319_a());
         return jsonobject;
      }
   }
}
