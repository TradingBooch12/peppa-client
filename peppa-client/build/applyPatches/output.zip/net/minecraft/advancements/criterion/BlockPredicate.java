package net.minecraft.advancements.criterion;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.tags.ITag;
import net.minecraft.tags.TagCollectionManager;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.JSONUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.server.ServerWorld;

public class BlockPredicate {
   public static final BlockPredicate field_226231_a_ = new BlockPredicate((ITag<Block>)null, (Block)null, StatePropertiesPredicate.field_227178_a_, NBTPredicate.field_193479_a);
   @Nullable
   private final ITag<Block> field_226232_b_;
   @Nullable
   private final Block field_226233_c_;
   private final StatePropertiesPredicate field_226234_d_;
   private final NBTPredicate field_226235_e_;

   public BlockPredicate(@Nullable ITag<Block> p_i225708_1_, @Nullable Block p_i225708_2_, StatePropertiesPredicate p_i225708_3_, NBTPredicate p_i225708_4_) {
      this.field_226232_b_ = p_i225708_1_;
      this.field_226233_c_ = p_i225708_2_;
      this.field_226234_d_ = p_i225708_3_;
      this.field_226235_e_ = p_i225708_4_;
   }

   public boolean func_226238_a_(ServerWorld p_226238_1_, BlockPos p_226238_2_) {
      if (this == field_226231_a_) {
         return true;
      } else if (!p_226238_1_.func_195588_v(p_226238_2_)) {
         return false;
      } else {
         BlockState blockstate = p_226238_1_.func_180495_p(p_226238_2_);
         Block block = blockstate.func_177230_c();
         if (this.field_226232_b_ != null && !this.field_226232_b_.func_230235_a_(block)) {
            return false;
         } else if (this.field_226233_c_ != null && block != this.field_226233_c_) {
            return false;
         } else if (!this.field_226234_d_.func_227181_a_(blockstate)) {
            return false;
         } else {
            if (this.field_226235_e_ != NBTPredicate.field_193479_a) {
               TileEntity tileentity = p_226238_1_.func_175625_s(p_226238_2_);
               if (tileentity == null || !this.field_226235_e_.func_193477_a(tileentity.func_189515_b(new CompoundNBT()))) {
                  return false;
               }
            }

            return true;
         }
      }
   }

   public static BlockPredicate func_226237_a_(@Nullable JsonElement p_226237_0_) {
      if (p_226237_0_ != null && !p_226237_0_.isJsonNull()) {
         JsonObject jsonobject = JSONUtils.func_151210_l(p_226237_0_, "block");
         NBTPredicate nbtpredicate = NBTPredicate.func_193476_a(jsonobject.get("nbt"));
         Block block = null;
         if (jsonobject.has("block")) {
            ResourceLocation resourcelocation = new ResourceLocation(JSONUtils.func_151200_h(jsonobject, "block"));
            block = Registry.field_212618_g.func_82594_a(resourcelocation);
         }

         ITag<Block> itag = null;
         if (jsonobject.has("tag")) {
            ResourceLocation resourcelocation1 = new ResourceLocation(JSONUtils.func_151200_h(jsonobject, "tag"));
            itag = TagCollectionManager.func_242178_a().func_241835_a().func_199910_a(resourcelocation1);
            if (itag == null) {
               throw new JsonSyntaxException("Unknown block tag '" + resourcelocation1 + "'");
            }
         }

         StatePropertiesPredicate statepropertiespredicate = StatePropertiesPredicate.func_227186_a_(jsonobject.get("state"));
         return new BlockPredicate(itag, block, statepropertiespredicate, nbtpredicate);
      } else {
         return field_226231_a_;
      }
   }

   public JsonElement func_226236_a_() {
      if (this == field_226231_a_) {
         return JsonNull.INSTANCE;
      } else {
         JsonObject jsonobject = new JsonObject();
         if (this.field_226233_c_ != null) {
            jsonobject.addProperty("block", Registry.field_212618_g.func_177774_c(this.field_226233_c_).toString());
         }

         if (this.field_226232_b_ != null) {
            jsonobject.addProperty("tag", TagCollectionManager.func_242178_a().func_241835_a().func_232975_b_(this.field_226232_b_).toString());
         }

         jsonobject.add("nbt", this.field_226235_e_.func_200322_a());
         jsonobject.add("state", this.field_226234_d_.func_227180_a_());
         return jsonobject;
      }
   }

   public static class Builder {
      @Nullable
      private Block field_226239_a_;
      @Nullable
      private ITag<Block> field_226240_b_;
      private StatePropertiesPredicate field_226241_c_ = StatePropertiesPredicate.field_227178_a_;
      private NBTPredicate field_226242_d_ = NBTPredicate.field_193479_a;

      private Builder() {
      }

      public static BlockPredicate.Builder func_226243_a_() {
         return new BlockPredicate.Builder();
      }

      public BlockPredicate.Builder func_233458_a_(Block p_233458_1_) {
         this.field_226239_a_ = p_233458_1_;
         return this;
      }

      public BlockPredicate.Builder func_226244_a_(ITag<Block> p_226244_1_) {
         this.field_226240_b_ = p_226244_1_;
         return this;
      }

      public BlockPredicate.Builder func_233459_a_(StatePropertiesPredicate p_233459_1_) {
         this.field_226241_c_ = p_233459_1_;
         return this;
      }

      public BlockPredicate func_226245_b_() {
         return new BlockPredicate(this.field_226240_b_, this.field_226239_a_, this.field_226241_c_, this.field_226242_d_);
      }
   }
}
