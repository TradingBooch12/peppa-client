package net.minecraft.advancements.criterion;

import com.google.common.collect.Maps;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import it.unimi.dsi.fastutil.objects.Object2BooleanMap;
import it.unimi.dsi.fastutil.objects.Object2BooleanOpenHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Predicate;
import javax.annotation.Nullable;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementManager;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.CriterionProgress;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.crafting.RecipeBook;
import net.minecraft.stats.Stat;
import net.minecraft.stats.StatType;
import net.minecraft.stats.StatisticsManager;
import net.minecraft.util.JSONUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.GameType;

public class PlayerPredicate {
   public static final PlayerPredicate field_226989_a_ = (new PlayerPredicate.Default()).func_227012_b_();
   private final MinMaxBounds.IntBound field_226990_b_;
   private final GameType field_226991_c_;
   private final Map<Stat<?>, MinMaxBounds.IntBound> field_226992_d_;
   private final Object2BooleanMap<ResourceLocation> field_226993_e_;
   private final Map<ResourceLocation, PlayerPredicate.IAdvancementPredicate> field_226994_f_;

   private static PlayerPredicate.IAdvancementPredicate func_227004_b_(JsonElement p_227004_0_) {
      if (p_227004_0_.isJsonPrimitive()) {
         boolean flag = p_227004_0_.getAsBoolean();
         return new PlayerPredicate.CompletedAdvancementPredicate(flag);
      } else {
         Object2BooleanMap<String> object2booleanmap = new Object2BooleanOpenHashMap<>();
         JsonObject jsonobject = JSONUtils.func_151210_l(p_227004_0_, "criterion data");
         jsonobject.entrySet().forEach((p_227003_1_) -> {
            boolean flag1 = JSONUtils.func_151216_b(p_227003_1_.getValue(), "criterion test");
            object2booleanmap.put(p_227003_1_.getKey(), flag1);
         });
         return new PlayerPredicate.CriteriaPredicate(object2booleanmap);
      }
   }

   private PlayerPredicate(MinMaxBounds.IntBound p_i225770_1_, GameType p_i225770_2_, Map<Stat<?>, MinMaxBounds.IntBound> p_i225770_3_, Object2BooleanMap<ResourceLocation> p_i225770_4_, Map<ResourceLocation, PlayerPredicate.IAdvancementPredicate> p_i225770_5_) {
      this.field_226990_b_ = p_i225770_1_;
      this.field_226991_c_ = p_i225770_2_;
      this.field_226992_d_ = p_i225770_3_;
      this.field_226993_e_ = p_i225770_4_;
      this.field_226994_f_ = p_i225770_5_;
   }

   public boolean func_226998_a_(Entity p_226998_1_) {
      if (this == field_226989_a_) {
         return true;
      } else if (!(p_226998_1_ instanceof ServerPlayerEntity)) {
         return false;
      } else {
         ServerPlayerEntity serverplayerentity = (ServerPlayerEntity)p_226998_1_;
         if (!this.field_226990_b_.func_211339_d(serverplayerentity.field_71068_ca)) {
            return false;
         } else if (this.field_226991_c_ != GameType.NOT_SET && this.field_226991_c_ != serverplayerentity.field_71134_c.func_73081_b()) {
            return false;
         } else {
            StatisticsManager statisticsmanager = serverplayerentity.func_147099_x();

            for(Entry<Stat<?>, MinMaxBounds.IntBound> entry : this.field_226992_d_.entrySet()) {
               int i = statisticsmanager.func_77444_a(entry.getKey());
               if (!entry.getValue().func_211339_d(i)) {
                  return false;
               }
            }

            RecipeBook recipebook = serverplayerentity.func_192037_E();

            for(it.unimi.dsi.fastutil.objects.Object2BooleanMap.Entry<ResourceLocation> entry2 : this.field_226993_e_.object2BooleanEntrySet()) {
               if (recipebook.func_226144_b_(entry2.getKey()) != entry2.getBooleanValue()) {
                  return false;
               }
            }

            if (!this.field_226994_f_.isEmpty()) {
               PlayerAdvancements playeradvancements = serverplayerentity.func_192039_O();
               AdvancementManager advancementmanager = serverplayerentity.func_184102_h().func_191949_aK();

               for(Entry<ResourceLocation, PlayerPredicate.IAdvancementPredicate> entry1 : this.field_226994_f_.entrySet()) {
                  Advancement advancement = advancementmanager.func_192778_a(entry1.getKey());
                  if (advancement == null || !entry1.getValue().test(playeradvancements.func_192747_a(advancement))) {
                     return false;
                  }
               }
            }

            return true;
         }
      }
   }

   public static PlayerPredicate func_227000_a_(@Nullable JsonElement p_227000_0_) {
      if (p_227000_0_ != null && !p_227000_0_.isJsonNull()) {
         JsonObject jsonobject = JSONUtils.func_151210_l(p_227000_0_, "player");
         MinMaxBounds.IntBound minmaxbounds$intbound = MinMaxBounds.IntBound.func_211344_a(jsonobject.get("level"));
         String s = JSONUtils.func_151219_a(jsonobject, "gamemode", "");
         GameType gametype = GameType.func_185328_a(s, GameType.NOT_SET);
         Map<Stat<?>, MinMaxBounds.IntBound> map = Maps.newHashMap();
         JsonArray jsonarray = JSONUtils.func_151213_a(jsonobject, "stats", (JsonArray)null);
         if (jsonarray != null) {
            for(JsonElement jsonelement : jsonarray) {
               JsonObject jsonobject1 = JSONUtils.func_151210_l(jsonelement, "stats entry");
               ResourceLocation resourcelocation = new ResourceLocation(JSONUtils.func_151200_h(jsonobject1, "type"));
               StatType<?> stattype = Registry.field_212634_w.func_82594_a(resourcelocation);
               if (stattype == null) {
                  throw new JsonParseException("Invalid stat type: " + resourcelocation);
               }

               ResourceLocation resourcelocation1 = new ResourceLocation(JSONUtils.func_151200_h(jsonobject1, "stat"));
               Stat<?> stat = func_226997_a_(stattype, resourcelocation1);
               MinMaxBounds.IntBound minmaxbounds$intbound1 = MinMaxBounds.IntBound.func_211344_a(jsonobject1.get("value"));
               map.put(stat, minmaxbounds$intbound1);
            }
         }

         Object2BooleanMap<ResourceLocation> object2booleanmap = new Object2BooleanOpenHashMap<>();
         JsonObject jsonobject2 = JSONUtils.func_151218_a(jsonobject, "recipes", new JsonObject());

         for(Entry<String, JsonElement> entry : jsonobject2.entrySet()) {
            ResourceLocation resourcelocation2 = new ResourceLocation(entry.getKey());
            boolean flag = JSONUtils.func_151216_b(entry.getValue(), "recipe present");
            object2booleanmap.put(resourcelocation2, flag);
         }

         Map<ResourceLocation, PlayerPredicate.IAdvancementPredicate> map1 = Maps.newHashMap();
         JsonObject jsonobject3 = JSONUtils.func_151218_a(jsonobject, "advancements", new JsonObject());

         for(Entry<String, JsonElement> entry1 : jsonobject3.entrySet()) {
            ResourceLocation resourcelocation3 = new ResourceLocation(entry1.getKey());
            PlayerPredicate.IAdvancementPredicate playerpredicate$iadvancementpredicate = func_227004_b_(entry1.getValue());
            map1.put(resourcelocation3, playerpredicate$iadvancementpredicate);
         }

         return new PlayerPredicate(minmaxbounds$intbound, gametype, map, object2booleanmap, map1);
      } else {
         return field_226989_a_;
      }
   }

   private static <T> Stat<T> func_226997_a_(StatType<T> p_226997_0_, ResourceLocation p_226997_1_) {
      Registry<T> registry = p_226997_0_.func_199080_a();
      T t = registry.func_82594_a(p_226997_1_);
      if (t == null) {
         throw new JsonParseException("Unknown object " + p_226997_1_ + " for stat type " + Registry.field_212634_w.func_177774_c(p_226997_0_));
      } else {
         return p_226997_0_.func_199076_b(t);
      }
   }

   private static <T> ResourceLocation func_226996_a_(Stat<T> p_226996_0_) {
      return p_226996_0_.func_197921_a().func_199080_a().func_177774_c(p_226996_0_.func_197920_b());
   }

   public JsonElement func_226995_a_() {
      if (this == field_226989_a_) {
         return JsonNull.INSTANCE;
      } else {
         JsonObject jsonobject = new JsonObject();
         jsonobject.add("level", this.field_226990_b_.func_200321_c());
         if (this.field_226991_c_ != GameType.NOT_SET) {
            jsonobject.addProperty("gamemode", this.field_226991_c_.func_77149_b());
         }

         if (!this.field_226992_d_.isEmpty()) {
            JsonArray jsonarray = new JsonArray();
            this.field_226992_d_.forEach((p_226999_1_, p_226999_2_) -> {
               JsonObject jsonobject3 = new JsonObject();
               jsonobject3.addProperty("type", Registry.field_212634_w.func_177774_c(p_226999_1_.func_197921_a()).toString());
               jsonobject3.addProperty("stat", func_226996_a_(p_226999_1_).toString());
               jsonobject3.add("value", p_226999_2_.func_200321_c());
               jsonarray.add(jsonobject3);
            });
            jsonobject.add("stats", jsonarray);
         }

         if (!this.field_226993_e_.isEmpty()) {
            JsonObject jsonobject1 = new JsonObject();
            this.field_226993_e_.forEach((p_227002_1_, p_227002_2_) -> {
               jsonobject1.addProperty(p_227002_1_.toString(), p_227002_2_);
            });
            jsonobject.add("recipes", jsonobject1);
         }

         if (!this.field_226994_f_.isEmpty()) {
            JsonObject jsonobject2 = new JsonObject();
            this.field_226994_f_.forEach((p_227001_1_, p_227001_2_) -> {
               jsonobject2.add(p_227001_1_.toString(), p_227001_2_.func_225544_a_());
            });
            jsonobject.add("advancements", jsonobject2);
         }

         return jsonobject;
      }
   }

   static class CompletedAdvancementPredicate implements PlayerPredicate.IAdvancementPredicate {
      private final boolean field_227006_a_;

      public CompletedAdvancementPredicate(boolean p_i225773_1_) {
         this.field_227006_a_ = p_i225773_1_;
      }

      public JsonElement func_225544_a_() {
         return new JsonPrimitive(this.field_227006_a_);
      }

      public boolean test(AdvancementProgress p_test_1_) {
         return p_test_1_.func_192105_a() == this.field_227006_a_;
      }
   }

   static class CriteriaPredicate implements PlayerPredicate.IAdvancementPredicate {
      private final Object2BooleanMap<String> field_227005_a_;

      public CriteriaPredicate(Object2BooleanMap<String> p_i225772_1_) {
         this.field_227005_a_ = p_i225772_1_;
      }

      public JsonElement func_225544_a_() {
         JsonObject jsonobject = new JsonObject();
         this.field_227005_a_.forEach(jsonobject::addProperty);
         return jsonobject;
      }

      public boolean test(AdvancementProgress p_test_1_) {
         for(it.unimi.dsi.fastutil.objects.Object2BooleanMap.Entry<String> entry : this.field_227005_a_.object2BooleanEntrySet()) {
            CriterionProgress criterionprogress = p_test_1_.func_192106_c(entry.getKey());
            if (criterionprogress == null || criterionprogress.func_192151_a() != entry.getBooleanValue()) {
               return false;
            }
         }

         return true;
      }
   }

   public static class Default {
      private MinMaxBounds.IntBound field_227007_a_ = MinMaxBounds.IntBound.field_211347_e;
      private GameType field_227008_b_ = GameType.NOT_SET;
      private final Map<Stat<?>, MinMaxBounds.IntBound> field_227009_c_ = Maps.newHashMap();
      private final Object2BooleanMap<ResourceLocation> field_227010_d_ = new Object2BooleanOpenHashMap<>();
      private final Map<ResourceLocation, PlayerPredicate.IAdvancementPredicate> field_227011_e_ = Maps.newHashMap();

      public PlayerPredicate func_227012_b_() {
         return new PlayerPredicate(this.field_227007_a_, this.field_227008_b_, this.field_227009_c_, this.field_227010_d_, this.field_227011_e_);
      }
   }

   interface IAdvancementPredicate extends Predicate<AdvancementProgress> {
      JsonElement func_225544_a_();
   }
}
