package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.potion.Potion;
import net.minecraft.tags.ITag;
import net.minecraft.util.IItemProvider;
import net.minecraft.util.ResourceLocation;

public class ConsumeItemTrigger extends AbstractCriterionTrigger<ConsumeItemTrigger.Instance> {
   private static final ResourceLocation field_193149_a = new ResourceLocation("consume_item");

   public ResourceLocation func_192163_a() {
      return field_193149_a;
   }

   public ConsumeItemTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      return new ConsumeItemTrigger.Instance(p_230241_2_, ItemPredicate.func_192492_a(p_230241_1_.get("item")));
   }

   public void func_193148_a(ServerPlayerEntity p_193148_1_, ItemStack p_193148_2_) {
      this.func_235959_a_(p_193148_1_, (p_226325_1_) -> {
         return p_226325_1_.func_193193_a(p_193148_2_);
      });
   }

   public static class Instance extends CriterionInstance {
      private final ItemPredicate field_193194_a;

      public Instance(EntityPredicate.AndPredicate p_i231522_1_, ItemPredicate p_i231522_2_) {
         super(ConsumeItemTrigger.field_193149_a, p_i231522_1_);
         this.field_193194_a = p_i231522_2_;
      }

      public static ConsumeItemTrigger.Instance func_203914_c() {
         return new ConsumeItemTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, ItemPredicate.field_192495_a);
      }

      public static ConsumeItemTrigger.Instance func_203913_a(IItemProvider p_203913_0_) {
         return new ConsumeItemTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, new ItemPredicate((ITag<Item>)null, p_203913_0_.func_199767_j(), MinMaxBounds.IntBound.field_211347_e, MinMaxBounds.IntBound.field_211347_e, EnchantmentPredicate.field_226534_b_, EnchantmentPredicate.field_226534_b_, (Potion)null, NBTPredicate.field_193479_a));
      }

      public boolean func_193193_a(ItemStack p_193193_1_) {
         return this.field_193194_a.func_192493_a(p_193193_1_);
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         jsonobject.add("item", this.field_193194_a.func_200319_a());
         return jsonobject;
      }
   }
}
