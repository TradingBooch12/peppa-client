package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.util.JSONUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.server.ServerWorld;

public class PlacedBlockTrigger extends AbstractCriterionTrigger<PlacedBlockTrigger.Instance> {
   private static final ResourceLocation field_193174_a = new ResourceLocation("placed_block");

   public ResourceLocation func_192163_a() {
      return field_193174_a;
   }

   public PlacedBlockTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      Block block = func_226950_a_(p_230241_1_);
      StatePropertiesPredicate statepropertiespredicate = StatePropertiesPredicate.func_227186_a_(p_230241_1_.get("state"));
      if (block != null) {
         statepropertiespredicate.func_227183_a_(block.func_176194_O(), (p_226948_1_) -> {
            throw new JsonSyntaxException("Block " + block + " has no property " + p_226948_1_ + ":");
         });
      }

      LocationPredicate locationpredicate = LocationPredicate.func_193454_a(p_230241_1_.get("location"));
      ItemPredicate itempredicate = ItemPredicate.func_192492_a(p_230241_1_.get("item"));
      return new PlacedBlockTrigger.Instance(p_230241_2_, block, statepropertiespredicate, locationpredicate, itempredicate);
   }

   @Nullable
   private static Block func_226950_a_(JsonObject p_226950_0_) {
      if (p_226950_0_.has("block")) {
         ResourceLocation resourcelocation = new ResourceLocation(JSONUtils.func_151200_h(p_226950_0_, "block"));
         return Registry.field_212618_g.func_241873_b(resourcelocation).orElseThrow(() -> {
            return new JsonSyntaxException("Unknown block type '" + resourcelocation + "'");
         });
      } else {
         return null;
      }
   }

   public void func_193173_a(ServerPlayerEntity p_193173_1_, BlockPos p_193173_2_, ItemStack p_193173_3_) {
      BlockState blockstate = p_193173_1_.func_71121_q().func_180495_p(p_193173_2_);
      this.func_235959_a_(p_193173_1_, (p_226949_4_) -> {
         return p_226949_4_.func_193210_a(blockstate, p_193173_2_, p_193173_1_.func_71121_q(), p_193173_3_);
      });
   }

   public static class Instance extends CriterionInstance {
      private final Block field_193211_a;
      private final StatePropertiesPredicate field_193212_b;
      private final LocationPredicate field_193213_c;
      private final ItemPredicate field_193214_d;

      public Instance(EntityPredicate.AndPredicate p_i231810_1_, @Nullable Block p_i231810_2_, StatePropertiesPredicate p_i231810_3_, LocationPredicate p_i231810_4_, ItemPredicate p_i231810_5_) {
         super(PlacedBlockTrigger.field_193174_a, p_i231810_1_);
         this.field_193211_a = p_i231810_2_;
         this.field_193212_b = p_i231810_3_;
         this.field_193213_c = p_i231810_4_;
         this.field_193214_d = p_i231810_5_;
      }

      public static PlacedBlockTrigger.Instance func_203934_a(Block p_203934_0_) {
         return new PlacedBlockTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, p_203934_0_, StatePropertiesPredicate.field_227178_a_, LocationPredicate.field_193455_a, ItemPredicate.field_192495_a);
      }

      public boolean func_193210_a(BlockState p_193210_1_, BlockPos p_193210_2_, ServerWorld p_193210_3_, ItemStack p_193210_4_) {
         if (this.field_193211_a != null && !p_193210_1_.func_203425_a(this.field_193211_a)) {
            return false;
         } else if (!this.field_193212_b.func_227181_a_(p_193210_1_)) {
            return false;
         } else if (!this.field_193213_c.func_193453_a(p_193210_3_, (float)p_193210_2_.func_177958_n(), (float)p_193210_2_.func_177956_o(), (float)p_193210_2_.func_177952_p())) {
            return false;
         } else {
            return this.field_193214_d.func_192493_a(p_193210_4_);
         }
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         if (this.field_193211_a != null) {
            jsonobject.addProperty("block", Registry.field_212618_g.func_177774_c(this.field_193211_a).toString());
         }

         jsonobject.add("state", this.field_193212_b.func_227180_a_());
         jsonobject.add("location", this.field_193213_c.func_204009_a());
         jsonobject.add("item", this.field_193214_d.func_200319_a());
         return jsonobject;
      }
   }
}
