package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.tileentity.BeaconTileEntity;
import net.minecraft.util.ResourceLocation;

public class ConstructBeaconTrigger extends AbstractCriterionTrigger<ConstructBeaconTrigger.Instance> {
   private static final ResourceLocation field_192181_a = new ResourceLocation("construct_beacon");

   public ResourceLocation func_192163_a() {
      return field_192181_a;
   }

   public ConstructBeaconTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      MinMaxBounds.IntBound minmaxbounds$intbound = MinMaxBounds.IntBound.func_211344_a(p_230241_1_.get("level"));
      return new ConstructBeaconTrigger.Instance(p_230241_2_, minmaxbounds$intbound);
   }

   public void func_192180_a(ServerPlayerEntity p_192180_1_, BeaconTileEntity p_192180_2_) {
      this.func_235959_a_(p_192180_1_, (p_226308_1_) -> {
         return p_226308_1_.func_192252_a(p_192180_2_);
      });
   }

   public static class Instance extends CriterionInstance {
      private final MinMaxBounds.IntBound field_192253_a;

      public Instance(EntityPredicate.AndPredicate p_i231507_1_, MinMaxBounds.IntBound p_i231507_2_) {
         super(ConstructBeaconTrigger.field_192181_a, p_i231507_1_);
         this.field_192253_a = p_i231507_2_;
      }

      public static ConstructBeaconTrigger.Instance func_203912_a(MinMaxBounds.IntBound p_203912_0_) {
         return new ConstructBeaconTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, p_203912_0_);
      }

      public boolean func_192252_a(BeaconTileEntity p_192252_1_) {
         return this.field_192253_a.func_211339_d(p_192252_1_.func_191979_s());
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         jsonobject.add("level", this.field_192253_a.func_200321_c());
         return jsonobject;
      }
   }
}
