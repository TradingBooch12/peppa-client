package net.minecraft.advancements.criterion;

import com.google.common.collect.Maps;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonSyntaxException;
import java.util.Collections;
import java.util.Map;
import java.util.Map.Entry;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.potion.Effect;
import net.minecraft.potion.EffectInstance;
import net.minecraft.util.JSONUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.registry.Registry;

public class MobEffectsPredicate {
   public static final MobEffectsPredicate field_193473_a = new MobEffectsPredicate(Collections.emptyMap());
   private final Map<Effect, MobEffectsPredicate.InstancePredicate> field_193474_b;

   public MobEffectsPredicate(Map<Effect, MobEffectsPredicate.InstancePredicate> p_i47538_1_) {
      this.field_193474_b = p_i47538_1_;
   }

   public static MobEffectsPredicate func_204014_a() {
      return new MobEffectsPredicate(Maps.newLinkedHashMap());
   }

   public MobEffectsPredicate func_204015_a(Effect p_204015_1_) {
      this.field_193474_b.put(p_204015_1_, new MobEffectsPredicate.InstancePredicate());
      return this;
   }

   public boolean func_193469_a(Entity p_193469_1_) {
      if (this == field_193473_a) {
         return true;
      } else {
         return p_193469_1_ instanceof LivingEntity ? this.func_193470_a(((LivingEntity)p_193469_1_).func_193076_bZ()) : false;
      }
   }

   public boolean func_193472_a(LivingEntity p_193472_1_) {
      return this == field_193473_a ? true : this.func_193470_a(p_193472_1_.func_193076_bZ());
   }

   public boolean func_193470_a(Map<Effect, EffectInstance> p_193470_1_) {
      if (this == field_193473_a) {
         return true;
      } else {
         for(Entry<Effect, MobEffectsPredicate.InstancePredicate> entry : this.field_193474_b.entrySet()) {
            EffectInstance effectinstance = p_193470_1_.get(entry.getKey());
            if (!entry.getValue().func_193463_a(effectinstance)) {
               return false;
            }
         }

         return true;
      }
   }

   public static MobEffectsPredicate func_193471_a(@Nullable JsonElement p_193471_0_) {
      if (p_193471_0_ != null && !p_193471_0_.isJsonNull()) {
         JsonObject jsonobject = JSONUtils.func_151210_l(p_193471_0_, "effects");
         Map<Effect, MobEffectsPredicate.InstancePredicate> map = Maps.newLinkedHashMap();

         for(Entry<String, JsonElement> entry : jsonobject.entrySet()) {
            ResourceLocation resourcelocation = new ResourceLocation(entry.getKey());
            Effect effect = Registry.field_212631_t.func_241873_b(resourcelocation).orElseThrow(() -> {
               return new JsonSyntaxException("Unknown effect '" + resourcelocation + "'");
            });
            MobEffectsPredicate.InstancePredicate mobeffectspredicate$instancepredicate = MobEffectsPredicate.InstancePredicate.func_193464_a(JSONUtils.func_151210_l(entry.getValue(), entry.getKey()));
            map.put(effect, mobeffectspredicate$instancepredicate);
         }

         return new MobEffectsPredicate(map);
      } else {
         return field_193473_a;
      }
   }

   public JsonElement func_204013_b() {
      if (this == field_193473_a) {
         return JsonNull.INSTANCE;
      } else {
         JsonObject jsonobject = new JsonObject();

         for(Entry<Effect, MobEffectsPredicate.InstancePredicate> entry : this.field_193474_b.entrySet()) {
            jsonobject.add(Registry.field_212631_t.func_177774_c(entry.getKey()).toString(), entry.getValue().func_204012_a());
         }

         return jsonobject;
      }
   }

   public static class InstancePredicate {
      private final MinMaxBounds.IntBound field_193465_a;
      private final MinMaxBounds.IntBound field_193466_b;
      @Nullable
      private final Boolean field_193467_c;
      @Nullable
      private final Boolean field_193468_d;

      public InstancePredicate(MinMaxBounds.IntBound p_i49709_1_, MinMaxBounds.IntBound p_i49709_2_, @Nullable Boolean p_i49709_3_, @Nullable Boolean p_i49709_4_) {
         this.field_193465_a = p_i49709_1_;
         this.field_193466_b = p_i49709_2_;
         this.field_193467_c = p_i49709_3_;
         this.field_193468_d = p_i49709_4_;
      }

      public InstancePredicate() {
         this(MinMaxBounds.IntBound.field_211347_e, MinMaxBounds.IntBound.field_211347_e, (Boolean)null, (Boolean)null);
      }

      public boolean func_193463_a(@Nullable EffectInstance p_193463_1_) {
         if (p_193463_1_ == null) {
            return false;
         } else if (!this.field_193465_a.func_211339_d(p_193463_1_.func_76458_c())) {
            return false;
         } else if (!this.field_193466_b.func_211339_d(p_193463_1_.func_76459_b())) {
            return false;
         } else if (this.field_193467_c != null && this.field_193467_c != p_193463_1_.func_82720_e()) {
            return false;
         } else {
            return this.field_193468_d == null || this.field_193468_d == p_193463_1_.func_188418_e();
         }
      }

      public JsonElement func_204012_a() {
         JsonObject jsonobject = new JsonObject();
         jsonobject.add("amplifier", this.field_193465_a.func_200321_c());
         jsonobject.add("duration", this.field_193466_b.func_200321_c());
         jsonobject.addProperty("ambient", this.field_193467_c);
         jsonobject.addProperty("visible", this.field_193468_d);
         return jsonobject;
      }

      public static MobEffectsPredicate.InstancePredicate func_193464_a(JsonObject p_193464_0_) {
         MinMaxBounds.IntBound minmaxbounds$intbound = MinMaxBounds.IntBound.func_211344_a(p_193464_0_.get("amplifier"));
         MinMaxBounds.IntBound minmaxbounds$intbound1 = MinMaxBounds.IntBound.func_211344_a(p_193464_0_.get("duration"));
         Boolean obool = p_193464_0_.has("ambient") ? JSONUtils.func_151212_i(p_193464_0_, "ambient") : null;
         Boolean obool1 = p_193464_0_.has("visible") ? JSONUtils.func_151212_i(p_193464_0_, "visible") : null;
         return new MobEffectsPredicate.InstancePredicate(minmaxbounds$intbound, minmaxbounds$intbound1, obool, obool1);
      }
   }
}
