package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import net.minecraft.entity.merchant.villager.VillagerEntity;
import net.minecraft.entity.monster.ZombieEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.loot.LootContext;
import net.minecraft.util.ResourceLocation;

public class CuredZombieVillagerTrigger extends AbstractCriterionTrigger<CuredZombieVillagerTrigger.Instance> {
   private static final ResourceLocation field_192186_a = new ResourceLocation("cured_zombie_villager");

   public ResourceLocation func_192163_a() {
      return field_192186_a;
   }

   public CuredZombieVillagerTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      EntityPredicate.AndPredicate entitypredicate$andpredicate = EntityPredicate.AndPredicate.func_234587_a_(p_230241_1_, "zombie", p_230241_3_);
      EntityPredicate.AndPredicate entitypredicate$andpredicate1 = EntityPredicate.AndPredicate.func_234587_a_(p_230241_1_, "villager", p_230241_3_);
      return new CuredZombieVillagerTrigger.Instance(p_230241_2_, entitypredicate$andpredicate, entitypredicate$andpredicate1);
   }

   public void func_192183_a(ServerPlayerEntity p_192183_1_, ZombieEntity p_192183_2_, VillagerEntity p_192183_3_) {
      LootContext lootcontext = EntityPredicate.func_234575_b_(p_192183_1_, p_192183_2_);
      LootContext lootcontext1 = EntityPredicate.func_234575_b_(p_192183_1_, p_192183_3_);
      this.func_235959_a_(p_192183_1_, (p_233969_2_) -> {
         return p_233969_2_.func_233970_a_(lootcontext, lootcontext1);
      });
   }

   public static class Instance extends CriterionInstance {
      private final EntityPredicate.AndPredicate field_192255_a;
      private final EntityPredicate.AndPredicate field_192256_b;

      public Instance(EntityPredicate.AndPredicate p_i231535_1_, EntityPredicate.AndPredicate p_i231535_2_, EntityPredicate.AndPredicate p_i231535_3_) {
         super(CuredZombieVillagerTrigger.field_192186_a, p_i231535_1_);
         this.field_192255_a = p_i231535_2_;
         this.field_192256_b = p_i231535_3_;
      }

      public static CuredZombieVillagerTrigger.Instance func_203916_c() {
         return new CuredZombieVillagerTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, EntityPredicate.AndPredicate.field_234582_a_, EntityPredicate.AndPredicate.field_234582_a_);
      }

      public boolean func_233970_a_(LootContext p_233970_1_, LootContext p_233970_2_) {
         if (!this.field_192255_a.func_234588_a_(p_233970_1_)) {
            return false;
         } else {
            return this.field_192256_b.func_234588_a_(p_233970_2_);
         }
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         jsonobject.add("zombie", this.field_192255_a.func_234586_a_(p_230240_1_));
         jsonobject.add("villager", this.field_192256_b.func_234586_a_(p_230240_1_));
         return jsonobject;
      }
   }
}
