package net.minecraft.advancements.criterion;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonObject;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.advancements.ICriterionTrigger;
import net.minecraft.advancements.PlayerAdvancements;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.LootContext;

public abstract class AbstractCriterionTrigger<T extends CriterionInstance> implements ICriterionTrigger<T> {
   private final Map<PlayerAdvancements, Set<ICriterionTrigger.Listener<T>>> field_227069_a_ = Maps.newIdentityHashMap();

   public final void func_192165_a(PlayerAdvancements p_192165_1_, ICriterionTrigger.Listener<T> p_192165_2_) {
      this.field_227069_a_.computeIfAbsent(p_192165_1_, (p_227072_0_) -> {
         return Sets.newHashSet();
      }).add(p_192165_2_);
   }

   public final void func_192164_b(PlayerAdvancements p_192164_1_, ICriterionTrigger.Listener<T> p_192164_2_) {
      Set<ICriterionTrigger.Listener<T>> set = this.field_227069_a_.get(p_192164_1_);
      if (set != null) {
         set.remove(p_192164_2_);
         if (set.isEmpty()) {
            this.field_227069_a_.remove(p_192164_1_);
         }
      }

   }

   public final void func_192167_a(PlayerAdvancements p_192167_1_) {
      this.field_227069_a_.remove(p_192167_1_);
   }

   protected abstract T func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_);

   public final T func_230307_a_(JsonObject p_230307_1_, ConditionArrayParser p_230307_2_) {
      EntityPredicate.AndPredicate entitypredicate$andpredicate = EntityPredicate.AndPredicate.func_234587_a_(p_230307_1_, "player", p_230307_2_);
      return this.func_230241_b_(p_230307_1_, entitypredicate$andpredicate, p_230307_2_);
   }

   protected void func_235959_a_(ServerPlayerEntity p_235959_1_, Predicate<T> p_235959_2_) {
      PlayerAdvancements playeradvancements = p_235959_1_.func_192039_O();
      Set<ICriterionTrigger.Listener<T>> set = this.field_227069_a_.get(playeradvancements);
      if (set != null && !set.isEmpty()) {
         LootContext lootcontext = EntityPredicate.func_234575_b_(p_235959_1_, p_235959_1_);
         List<ICriterionTrigger.Listener<T>> list = null;

         for(ICriterionTrigger.Listener<T> listener : set) {
            T t = listener.func_192158_a();
            if (t.func_233383_b_().func_234588_a_(lootcontext) && p_235959_2_.test(t)) {
               if (list == null) {
                  list = Lists.newArrayList();
               }

               list.add(listener);
            }
         }

         if (list != null) {
            for(ICriterionTrigger.Listener<T> listener1 : list) {
               listener1.func_192159_a(playeradvancements);
            }
         }

      }
   }
}
