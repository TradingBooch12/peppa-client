package net.minecraft.advancements.criterion;

import com.google.gson.JsonObject;
import javax.annotation.Nullable;
import net.minecraft.entity.AgeableEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.loot.ConditionArrayParser;
import net.minecraft.loot.ConditionArraySerializer;
import net.minecraft.loot.LootContext;
import net.minecraft.util.ResourceLocation;

public class BredAnimalsTrigger extends AbstractCriterionTrigger<BredAnimalsTrigger.Instance> {
   private static final ResourceLocation field_192171_a = new ResourceLocation("bred_animals");

   public ResourceLocation func_192163_a() {
      return field_192171_a;
   }

   public BredAnimalsTrigger.Instance func_230241_b_(JsonObject p_230241_1_, EntityPredicate.AndPredicate p_230241_2_, ConditionArrayParser p_230241_3_) {
      EntityPredicate.AndPredicate entitypredicate$andpredicate = EntityPredicate.AndPredicate.func_234587_a_(p_230241_1_, "parent", p_230241_3_);
      EntityPredicate.AndPredicate entitypredicate$andpredicate1 = EntityPredicate.AndPredicate.func_234587_a_(p_230241_1_, "partner", p_230241_3_);
      EntityPredicate.AndPredicate entitypredicate$andpredicate2 = EntityPredicate.AndPredicate.func_234587_a_(p_230241_1_, "child", p_230241_3_);
      return new BredAnimalsTrigger.Instance(p_230241_2_, entitypredicate$andpredicate, entitypredicate$andpredicate1, entitypredicate$andpredicate2);
   }

   public void func_192168_a(ServerPlayerEntity p_192168_1_, AnimalEntity p_192168_2_, AnimalEntity p_192168_3_, @Nullable AgeableEntity p_192168_4_) {
      LootContext lootcontext = EntityPredicate.func_234575_b_(p_192168_1_, p_192168_2_);
      LootContext lootcontext1 = EntityPredicate.func_234575_b_(p_192168_1_, p_192168_3_);
      LootContext lootcontext2 = p_192168_4_ != null ? EntityPredicate.func_234575_b_(p_192168_1_, p_192168_4_) : null;
      this.func_235959_a_(p_192168_1_, (p_233510_3_) -> {
         return p_233510_3_.func_233511_a_(lootcontext, lootcontext1, lootcontext2);
      });
   }

   public static class Instance extends CriterionInstance {
      private final EntityPredicate.AndPredicate field_192247_a;
      private final EntityPredicate.AndPredicate field_192248_b;
      private final EntityPredicate.AndPredicate field_192249_c;

      public Instance(EntityPredicate.AndPredicate p_i231484_1_, EntityPredicate.AndPredicate p_i231484_2_, EntityPredicate.AndPredicate p_i231484_3_, EntityPredicate.AndPredicate p_i231484_4_) {
         super(BredAnimalsTrigger.field_192171_a, p_i231484_1_);
         this.field_192247_a = p_i231484_2_;
         this.field_192248_b = p_i231484_3_;
         this.field_192249_c = p_i231484_4_;
      }

      public static BredAnimalsTrigger.Instance func_203908_c() {
         return new BredAnimalsTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, EntityPredicate.AndPredicate.field_234582_a_, EntityPredicate.AndPredicate.field_234582_a_, EntityPredicate.AndPredicate.field_234582_a_);
      }

      public static BredAnimalsTrigger.Instance func_203909_a(EntityPredicate.Builder p_203909_0_) {
         return new BredAnimalsTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, EntityPredicate.AndPredicate.field_234582_a_, EntityPredicate.AndPredicate.field_234582_a_, EntityPredicate.AndPredicate.func_234585_a_(p_203909_0_.func_204000_b()));
      }

      public static BredAnimalsTrigger.Instance func_241332_a_(EntityPredicate p_241332_0_, EntityPredicate p_241332_1_, EntityPredicate p_241332_2_) {
         return new BredAnimalsTrigger.Instance(EntityPredicate.AndPredicate.field_234582_a_, EntityPredicate.AndPredicate.func_234585_a_(p_241332_0_), EntityPredicate.AndPredicate.func_234585_a_(p_241332_1_), EntityPredicate.AndPredicate.func_234585_a_(p_241332_2_));
      }

      public boolean func_233511_a_(LootContext p_233511_1_, LootContext p_233511_2_, @Nullable LootContext p_233511_3_) {
         if (this.field_192249_c == EntityPredicate.AndPredicate.field_234582_a_ || p_233511_3_ != null && this.field_192249_c.func_234588_a_(p_233511_3_)) {
            return this.field_192247_a.func_234588_a_(p_233511_1_) && this.field_192248_b.func_234588_a_(p_233511_2_) || this.field_192247_a.func_234588_a_(p_233511_2_) && this.field_192248_b.func_234588_a_(p_233511_1_);
         } else {
            return false;
         }
      }

      public JsonObject func_230240_a_(ConditionArraySerializer p_230240_1_) {
         JsonObject jsonobject = super.func_230240_a_(p_230240_1_);
         jsonobject.add("parent", this.field_192247_a.func_234586_a_(p_230240_1_));
         jsonobject.add("partner", this.field_192248_b.func_234586_a_(p_230240_1_));
         jsonobject.add("child", this.field_192249_c.func_234586_a_(p_230240_1_));
         return jsonobject;
      }
   }
}
