package net.minecraft.advancements.criterion;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import java.util.Optional;
import javax.annotation.Nullable;
import net.minecraft.block.CampfireBlock;
import net.minecraft.util.JSONUtils;
import net.minecraft.util.RegistryKey;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.gen.feature.structure.Structure;
import net.minecraft.world.server.ServerWorld;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class LocationPredicate {
   private static final Logger field_235305_b_ = LogManager.getLogger();
   public static final LocationPredicate field_193455_a = new LocationPredicate(MinMaxBounds.FloatBound.field_211359_e, MinMaxBounds.FloatBound.field_211359_e, MinMaxBounds.FloatBound.field_211359_e, (RegistryKey<Biome>)null, (Structure<?>)null, (RegistryKey<World>)null, (Boolean)null, LightPredicate.field_226854_a_, BlockPredicate.field_226231_a_, FluidPredicate.field_226643_a_);
   private final MinMaxBounds.FloatBound field_193457_c;
   private final MinMaxBounds.FloatBound field_193458_d;
   private final MinMaxBounds.FloatBound field_193459_e;
   @Nullable
   private final RegistryKey<Biome> field_193456_b;
   @Nullable
   private final Structure<?> field_193460_f;
   @Nullable
   private final RegistryKey<World> field_193461_g;
   @Nullable
   private final Boolean field_235306_i_;
   private final LightPredicate field_226864_h_;
   private final BlockPredicate field_226865_i_;
   private final FluidPredicate field_226866_j_;

   public LocationPredicate(MinMaxBounds.FloatBound p_i241961_1_, MinMaxBounds.FloatBound p_i241961_2_, MinMaxBounds.FloatBound p_i241961_3_, @Nullable RegistryKey<Biome> p_i241961_4_, @Nullable Structure<?> p_i241961_5_, @Nullable RegistryKey<World> p_i241961_6_, @Nullable Boolean p_i241961_7_, LightPredicate p_i241961_8_, BlockPredicate p_i241961_9_, FluidPredicate p_i241961_10_) {
      this.field_193457_c = p_i241961_1_;
      this.field_193458_d = p_i241961_2_;
      this.field_193459_e = p_i241961_3_;
      this.field_193456_b = p_i241961_4_;
      this.field_193460_f = p_i241961_5_;
      this.field_193461_g = p_i241961_6_;
      this.field_235306_i_ = p_i241961_7_;
      this.field_226864_h_ = p_i241961_8_;
      this.field_226865_i_ = p_i241961_9_;
      this.field_226866_j_ = p_i241961_10_;
   }

   public static LocationPredicate func_242665_a(RegistryKey<Biome> p_242665_0_) {
      return new LocationPredicate(MinMaxBounds.FloatBound.field_211359_e, MinMaxBounds.FloatBound.field_211359_e, MinMaxBounds.FloatBound.field_211359_e, p_242665_0_, (Structure<?>)null, (RegistryKey<World>)null, (Boolean)null, LightPredicate.field_226854_a_, BlockPredicate.field_226231_a_, FluidPredicate.field_226643_a_);
   }

   public static LocationPredicate func_235308_a_(RegistryKey<World> p_235308_0_) {
      return new LocationPredicate(MinMaxBounds.FloatBound.field_211359_e, MinMaxBounds.FloatBound.field_211359_e, MinMaxBounds.FloatBound.field_211359_e, (RegistryKey<Biome>)null, (Structure<?>)null, p_235308_0_, (Boolean)null, LightPredicate.field_226854_a_, BlockPredicate.field_226231_a_, FluidPredicate.field_226643_a_);
   }

   public static LocationPredicate func_218020_a(Structure<?> p_218020_0_) {
      return new LocationPredicate(MinMaxBounds.FloatBound.field_211359_e, MinMaxBounds.FloatBound.field_211359_e, MinMaxBounds.FloatBound.field_211359_e, (RegistryKey<Biome>)null, p_218020_0_, (RegistryKey<World>)null, (Boolean)null, LightPredicate.field_226854_a_, BlockPredicate.field_226231_a_, FluidPredicate.field_226643_a_);
   }

   public boolean func_193452_a(ServerWorld p_193452_1_, double p_193452_2_, double p_193452_4_, double p_193452_6_) {
      return this.func_193453_a(p_193452_1_, (float)p_193452_2_, (float)p_193452_4_, (float)p_193452_6_);
   }

   public boolean func_193453_a(ServerWorld p_193453_1_, float p_193453_2_, float p_193453_3_, float p_193453_4_) {
      if (!this.field_193457_c.func_211354_d(p_193453_2_)) {
         return false;
      } else if (!this.field_193458_d.func_211354_d(p_193453_3_)) {
         return false;
      } else if (!this.field_193459_e.func_211354_d(p_193453_4_)) {
         return false;
      } else if (this.field_193461_g != null && this.field_193461_g != p_193453_1_.func_234923_W_()) {
         return false;
      } else {
         BlockPos blockpos = new BlockPos((double)p_193453_2_, (double)p_193453_3_, (double)p_193453_4_);
         boolean flag = p_193453_1_.func_195588_v(blockpos);
         Optional<RegistryKey<Biome>> optional = p_193453_1_.func_241828_r().func_243612_b(Registry.field_239720_u_).func_230519_c_(p_193453_1_.func_226691_t_(blockpos));
         if (!optional.isPresent()) {
            return false;
         } else if (this.field_193456_b == null || flag && this.field_193456_b == optional.get()) {
            if (this.field_193460_f == null || flag && p_193453_1_.func_241112_a_().func_235010_a_(blockpos, true, this.field_193460_f).func_75069_d()) {
               if (this.field_235306_i_ == null || flag && this.field_235306_i_ == CampfireBlock.func_235474_a_(p_193453_1_, blockpos)) {
                  if (!this.field_226864_h_.func_226858_a_(p_193453_1_, blockpos)) {
                     return false;
                  } else if (!this.field_226865_i_.func_226238_a_(p_193453_1_, blockpos)) {
                     return false;
                  } else {
                     return this.field_226866_j_.func_226649_a_(p_193453_1_, blockpos);
                  }
               } else {
                  return false;
               }
            } else {
               return false;
            }
         } else {
            return false;
         }
      }
   }

   public JsonElement func_204009_a() {
      if (this == field_193455_a) {
         return JsonNull.INSTANCE;
      } else {
         JsonObject jsonobject = new JsonObject();
         if (!this.field_193457_c.func_211335_c() || !this.field_193458_d.func_211335_c() || !this.field_193459_e.func_211335_c()) {
            JsonObject jsonobject1 = new JsonObject();
            jsonobject1.add("x", this.field_193457_c.func_200321_c());
            jsonobject1.add("y", this.field_193458_d.func_200321_c());
            jsonobject1.add("z", this.field_193459_e.func_200321_c());
            jsonobject.add("position", jsonobject1);
         }

         if (this.field_193461_g != null) {
            World.field_234917_f_.encodeStart(JsonOps.INSTANCE, this.field_193461_g).resultOrPartial(field_235305_b_::error).ifPresent((p_235307_1_) -> {
               jsonobject.add("dimension", p_235307_1_);
            });
         }

         if (this.field_193460_f != null) {
            jsonobject.addProperty("feature", this.field_193460_f.func_143025_a());
         }

         if (this.field_193456_b != null) {
            jsonobject.addProperty("biome", this.field_193456_b.func_240901_a_().toString());
         }

         if (this.field_235306_i_ != null) {
            jsonobject.addProperty("smokey", this.field_235306_i_);
         }

         jsonobject.add("light", this.field_226864_h_.func_226856_a_());
         jsonobject.add("block", this.field_226865_i_.func_226236_a_());
         jsonobject.add("fluid", this.field_226866_j_.func_226647_a_());
         return jsonobject;
      }
   }

   public static LocationPredicate func_193454_a(@Nullable JsonElement p_193454_0_) {
      if (p_193454_0_ != null && !p_193454_0_.isJsonNull()) {
         JsonObject jsonobject = JSONUtils.func_151210_l(p_193454_0_, "location");
         JsonObject jsonobject1 = JSONUtils.func_151218_a(jsonobject, "position", new JsonObject());
         MinMaxBounds.FloatBound minmaxbounds$floatbound = MinMaxBounds.FloatBound.func_211356_a(jsonobject1.get("x"));
         MinMaxBounds.FloatBound minmaxbounds$floatbound1 = MinMaxBounds.FloatBound.func_211356_a(jsonobject1.get("y"));
         MinMaxBounds.FloatBound minmaxbounds$floatbound2 = MinMaxBounds.FloatBound.func_211356_a(jsonobject1.get("z"));
         RegistryKey<World> registrykey = jsonobject.has("dimension") ? ResourceLocation.field_240908_a_.parse(JsonOps.INSTANCE, jsonobject.get("dimension")).resultOrPartial(field_235305_b_::error).map((p_235310_0_) -> {
            return RegistryKey.func_240903_a_(Registry.field_239699_ae_, p_235310_0_);
         }).orElse((RegistryKey<World>)null) : null;
         Structure<?> structure = jsonobject.has("feature") ? Structure.field_236365_a_.get(JSONUtils.func_151200_h(jsonobject, "feature")) : null;
         RegistryKey<Biome> registrykey1 = null;
         if (jsonobject.has("biome")) {
            ResourceLocation resourcelocation = new ResourceLocation(JSONUtils.func_151200_h(jsonobject, "biome"));
            registrykey1 = RegistryKey.func_240903_a_(Registry.field_239720_u_, resourcelocation);
         }

         Boolean obool = jsonobject.has("smokey") ? jsonobject.get("smokey").getAsBoolean() : null;
         LightPredicate lightpredicate = LightPredicate.func_226857_a_(jsonobject.get("light"));
         BlockPredicate blockpredicate = BlockPredicate.func_226237_a_(jsonobject.get("block"));
         FluidPredicate fluidpredicate = FluidPredicate.func_226648_a_(jsonobject.get("fluid"));
         return new LocationPredicate(minmaxbounds$floatbound, minmaxbounds$floatbound1, minmaxbounds$floatbound2, registrykey1, structure, registrykey, obool, lightpredicate, blockpredicate, fluidpredicate);
      } else {
         return field_193455_a;
      }
   }

   public static class Builder {
      private MinMaxBounds.FloatBound field_218014_a = MinMaxBounds.FloatBound.field_211359_e;
      private MinMaxBounds.FloatBound field_218015_b = MinMaxBounds.FloatBound.field_211359_e;
      private MinMaxBounds.FloatBound field_218016_c = MinMaxBounds.FloatBound.field_211359_e;
      @Nullable
      private RegistryKey<Biome> field_218017_d;
      @Nullable
      private Structure<?> field_218018_e;
      @Nullable
      private RegistryKey<World> field_218019_f;
      @Nullable
      private Boolean field_235311_g_;
      private LightPredicate field_226867_g_ = LightPredicate.field_226854_a_;
      private BlockPredicate field_226868_h_ = BlockPredicate.field_226231_a_;
      private FluidPredicate field_226869_i_ = FluidPredicate.field_226643_a_;

      public static LocationPredicate.Builder func_226870_a_() {
         return new LocationPredicate.Builder();
      }

      public LocationPredicate.Builder func_242666_a(@Nullable RegistryKey<Biome> p_242666_1_) {
         this.field_218017_d = p_242666_1_;
         return this;
      }

      public LocationPredicate.Builder func_235312_a_(BlockPredicate p_235312_1_) {
         this.field_226868_h_ = p_235312_1_;
         return this;
      }

      public LocationPredicate.Builder func_235313_a_(Boolean p_235313_1_) {
         this.field_235311_g_ = p_235313_1_;
         return this;
      }

      public LocationPredicate func_218013_a() {
         return new LocationPredicate(this.field_218014_a, this.field_218015_b, this.field_218016_c, this.field_218017_d, this.field_218018_e, this.field_218019_f, this.field_235311_g_, this.field_226867_g_, this.field_226868_h_, this.field_226869_i_);
      }
   }
}
