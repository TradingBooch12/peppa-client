package net.minecraft.advancements;

import com.google.common.collect.Lists;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import java.util.Arrays;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.command.FunctionObject;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.LootContext;
import net.minecraft.loot.LootParameterSets;
import net.minecraft.loot.LootParameters;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.JSONUtils;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvents;

public class AdvancementRewards {
   public static final AdvancementRewards field_192114_a = new AdvancementRewards(0, new ResourceLocation[0], new ResourceLocation[0], FunctionObject.CacheableFunction.field_193519_a);
   private final int field_192115_b;
   private final ResourceLocation[] field_192116_c;
   private final ResourceLocation[] field_192117_d;
   private final FunctionObject.CacheableFunction field_193129_e;

   public AdvancementRewards(int p_i47587_1_, ResourceLocation[] p_i47587_2_, ResourceLocation[] p_i47587_3_, FunctionObject.CacheableFunction p_i47587_4_) {
      this.field_192115_b = p_i47587_1_;
      this.field_192116_c = p_i47587_2_;
      this.field_192117_d = p_i47587_3_;
      this.field_193129_e = p_i47587_4_;
   }

   public void func_192113_a(ServerPlayerEntity p_192113_1_) {
      p_192113_1_.func_195068_e(this.field_192115_b);
      LootContext lootcontext = (new LootContext.Builder(p_192113_1_.func_71121_q())).func_216015_a(LootParameters.field_216281_a, p_192113_1_).func_216015_a(LootParameters.field_237457_g_, p_192113_1_.func_213303_ch()).func_216023_a(p_192113_1_.func_70681_au()).func_216022_a(LootParameterSets.field_216265_f);
      boolean flag = false;

      for(ResourceLocation resourcelocation : this.field_192116_c) {
         for(ItemStack itemstack : p_192113_1_.field_71133_b.func_200249_aQ().func_186521_a(resourcelocation).func_216113_a(lootcontext)) {
            if (p_192113_1_.func_191521_c(itemstack)) {
               p_192113_1_.field_70170_p.func_184148_a((PlayerEntity)null, p_192113_1_.func_226277_ct_(), p_192113_1_.func_226278_cu_(), p_192113_1_.func_226281_cx_(), SoundEvents.field_187638_cR, SoundCategory.PLAYERS, 0.2F, ((p_192113_1_.func_70681_au().nextFloat() - p_192113_1_.func_70681_au().nextFloat()) * 0.7F + 1.0F) * 2.0F);
               flag = true;
            } else {
               ItemEntity itementity = p_192113_1_.func_71019_a(itemstack, false);
               if (itementity != null) {
                  itementity.func_174868_q();
                  itementity.func_200217_b(p_192113_1_.func_110124_au());
               }
            }
         }
      }

      if (flag) {
         p_192113_1_.field_71069_bz.func_75142_b();
      }

      if (this.field_192117_d.length > 0) {
         p_192113_1_.func_193102_a(this.field_192117_d);
      }

      MinecraftServer minecraftserver = p_192113_1_.field_71133_b;
      this.field_193129_e.func_218039_a(minecraftserver.func_193030_aL()).ifPresent((p_215098_2_) -> {
         minecraftserver.func_193030_aL().func_195447_a(p_215098_2_, p_192113_1_.func_195051_bN().func_197031_a().func_197033_a(2));
      });
   }

   public String toString() {
      return "AdvancementRewards{experience=" + this.field_192115_b + ", loot=" + Arrays.toString((Object[])this.field_192116_c) + ", recipes=" + Arrays.toString((Object[])this.field_192117_d) + ", function=" + this.field_193129_e + '}';
   }

   public JsonElement func_200286_b() {
      if (this == field_192114_a) {
         return JsonNull.INSTANCE;
      } else {
         JsonObject jsonobject = new JsonObject();
         if (this.field_192115_b != 0) {
            jsonobject.addProperty("experience", this.field_192115_b);
         }

         if (this.field_192116_c.length > 0) {
            JsonArray jsonarray = new JsonArray();

            for(ResourceLocation resourcelocation : this.field_192116_c) {
               jsonarray.add(resourcelocation.toString());
            }

            jsonobject.add("loot", jsonarray);
         }

         if (this.field_192117_d.length > 0) {
            JsonArray jsonarray1 = new JsonArray();

            for(ResourceLocation resourcelocation1 : this.field_192117_d) {
               jsonarray1.add(resourcelocation1.toString());
            }

            jsonobject.add("recipes", jsonarray1);
         }

         if (this.field_193129_e.func_200376_a() != null) {
            jsonobject.addProperty("function", this.field_193129_e.func_200376_a().toString());
         }

         return jsonobject;
      }
   }

   public static AdvancementRewards func_241096_a_(JsonObject p_241096_0_) throws JsonParseException {
      int i = JSONUtils.func_151208_a(p_241096_0_, "experience", 0);
      JsonArray jsonarray = JSONUtils.func_151213_a(p_241096_0_, "loot", new JsonArray());
      ResourceLocation[] aresourcelocation = new ResourceLocation[jsonarray.size()];

      for(int j = 0; j < aresourcelocation.length; ++j) {
         aresourcelocation[j] = new ResourceLocation(JSONUtils.func_151206_a(jsonarray.get(j), "loot[" + j + "]"));
      }

      JsonArray jsonarray1 = JSONUtils.func_151213_a(p_241096_0_, "recipes", new JsonArray());
      ResourceLocation[] aresourcelocation1 = new ResourceLocation[jsonarray1.size()];

      for(int k = 0; k < aresourcelocation1.length; ++k) {
         aresourcelocation1[k] = new ResourceLocation(JSONUtils.func_151206_a(jsonarray1.get(k), "recipes[" + k + "]"));
      }

      FunctionObject.CacheableFunction functionobject$cacheablefunction;
      if (p_241096_0_.has("function")) {
         functionobject$cacheablefunction = new FunctionObject.CacheableFunction(new ResourceLocation(JSONUtils.func_151200_h(p_241096_0_, "function")));
      } else {
         functionobject$cacheablefunction = FunctionObject.CacheableFunction.field_193519_a;
      }

      return new AdvancementRewards(i, aresourcelocation, aresourcelocation1, functionobject$cacheablefunction);
   }

   public static class Builder {
      private int field_200282_a;
      private final List<ResourceLocation> field_200283_b = Lists.newArrayList();
      private final List<ResourceLocation> field_200284_c = Lists.newArrayList();
      @Nullable
      private ResourceLocation field_200285_d;

      public static AdvancementRewards.Builder func_203907_a(int p_203907_0_) {
         return (new AdvancementRewards.Builder()).func_203906_b(p_203907_0_);
      }

      public AdvancementRewards.Builder func_203906_b(int p_203906_1_) {
         this.field_200282_a += p_203906_1_;
         return this;
      }

      public static AdvancementRewards.Builder func_200280_c(ResourceLocation p_200280_0_) {
         return (new AdvancementRewards.Builder()).func_200279_d(p_200280_0_);
      }

      public AdvancementRewards.Builder func_200279_d(ResourceLocation p_200279_1_) {
         this.field_200284_c.add(p_200279_1_);
         return this;
      }

      public AdvancementRewards func_200281_a() {
         return new AdvancementRewards(this.field_200282_a, this.field_200283_b.toArray(new ResourceLocation[0]), this.field_200284_c.toArray(new ResourceLocation[0]), this.field_200285_d == null ? FunctionObject.CacheableFunction.field_193519_a : new FunctionObject.CacheableFunction(this.field_200285_d));
      }
   }
}
